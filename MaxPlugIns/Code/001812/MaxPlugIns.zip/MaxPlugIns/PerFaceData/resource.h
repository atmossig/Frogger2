//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PerFaceData.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDD_PANEL                       101
#define IDB_ISL_IMAGE                   103
#define IDB_ISL_MASK                    104
#define IDB_ISLMASK                     105
#define IDB_ISLIMAGE                    106
#define IDD_ROLLUP                      107
#define IDB_BLITZIMAGE                  108
#define IDB_BLITZMASK                   109
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_NUM_SELECTS                 1001
#define IDC_DATASET_NAME                1003
#define IDC_DATA_SIZE                   1004
#define IDC_DATA_PTR                    1005
#define IDC_BUTTON4                     1008
#define IDC_ISL_LOGO                    1010
#define IDC_ISLLOGO                     1010
#define IDC_RESET_DEFAULTS              1016
#define IDC_DATASET_TITLE               1017
#define IDC_SELECT_COPY                 1018
#define IDC_SELECT_PASTE                1019
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
