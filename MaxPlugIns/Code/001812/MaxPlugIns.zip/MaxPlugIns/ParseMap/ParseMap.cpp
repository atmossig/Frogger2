// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 2000 Interactive Studios Ltd.
//
//    File : ParseMap.cpp
// Purpose : map file parser
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "ParseMap.h"


// -------------------
// Function prototypes

// char line functions
static void LoadLine(char *cp, char *ep, char *line);
static char *NextCharLine(char *cp, char *ep);
static char *TidyLine(char *line);

// get tab indentation from level
static char *GetIndent(int level);


// -----------------
// Types and classes

// ** 'CPMAttrib' class

/* --------------------------------------------------------------------------------
   Function : CPMAttrib::CPMAttrib
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMAttrib::CPMAttrib()
{
	next = prev = this;

	type = PMATTRIB_NULL;
	string[0] = 0;
	ival = 0;
	fval = 0.f;
	strcpy(ident, "ROOT");

	enoof = 0;
	estrings = NULL;
	eivals = NULL;
	efvals = NULL;

	datn = 0;
	datp = NULL;
}


/* --------------------------------------------------------------------------------
   Function : CPMAttrib::CPMAttrib
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMAttrib::CPMAttrib(CPMAttrib *root)
{
	next = root;
	prev = root->prev;
	root->prev->next = this;
	root->prev = this;

	type = PMATTRIB_NULL;
	string[0] = 0;
	ival = 0;
	fval = 0.f;
	strcpy(ident, "");

	enoof = 0;
	estrings = NULL;
	eivals = NULL;
	efvals = NULL;

	datn = 0;
	datp = NULL;
}


/* --------------------------------------------------------------------------------
   Function : CPMAttrib::~CPMAttrib
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMAttrib::~CPMAttrib()
{
	prev->next = next;
	next->prev = prev;

	// free enumerations
	switch (type)
	{
	case PMATTRIB_ENUMSTRING:
		if (estrings)
			free(estrings);
		break;
	case PMATTRIB_ENUMINT:
		if (eivals)
			free(eivals);
		break;
	case PMATTRIB_ENUMFLOAT:
		if (efvals)
			free(efvals);
		break;
	}
}


/* --------------------------------------------------------------------------------
   Function : CPMAttrib::DeleteAll
   Purpose : delete all attributes
   Parameters : 
   Returns : 
   Info : 
*/

void CPMAttrib::DeleteAll()
{
	while (next != this)
		delete next;
	delete this;
}


/* --------------------------------------------------------------------------------
   Function : CPMAttrib::Find
   Purpose : Find attribute from ident
   Parameters : ident pointer
   Returns : attribute, else NULL
   Info : 
*/

CPMAttrib *CPMAttrib::Find(char *ident)
{
	CPMAttrib	*attrib;
	for (attrib = this->next; attrib != this; attrib = attrib->next)
		if (stricmp(ident, attrib->ident) == NULL)
			return attrib;
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : CPMAttrib::Clone
   Purpose : clone attribute
   Parameters : attribute to clone
   Returns : 
   Info : 
*/

void CPMAttrib::Clone(CPMAttrib *attrib)
{
	// copy identifier
	strncpy(ident, attrib->ident, PMMAX_IDENT_LEN);
	// copy type
	type = attrib->type;

	// copy type specific data
	switch (type)
	{
	case PMATTRIB_STRING:
		strncpy(string, attrib->string, PMMAX_STRING_LEN);
		break;
	case PMATTRIB_INT:
		ival = attrib->ival;
		break;
	case PMATTRIB_FLOAT:
		fval = attrib->fval;
		break;
	case PMATTRIB_BOOL:
		bval = attrib->bval;
		break;
	case PMATTRIB_ENUMSTRING:
		if ((enoof = attrib->enoof) > 0)
		{
			estrings = (char *)malloc(enoof*PMMAX_STRING_LEN);
			memcpy(estrings, attrib->estrings, enoof*PMMAX_STRING_LEN);
		}
		break;
	case PMATTRIB_ENUMINT:
		if ((enoof = attrib->enoof) > 0)
		{
			eivals = (int *)malloc(enoof*sizeof(int));
			memcpy(eivals, attrib->eivals, enoof*sizeof(int));
		}
		break;
	case PMATTRIB_ENUMFLOAT:
		if ((enoof = attrib->enoof) > 0)
		{
			efvals = (float *)malloc(enoof*sizeof(float));
			memcpy(efvals, attrib->eivals, enoof*sizeof(float));
		}
		break;
	case PMATTRIB_DATA:
		datn = attrib->datn;
		datp = attrib->datp;
		break;
	}
}


// ** 'CPMNode' class

/* --------------------------------------------------------------------------------
   Function : CPMNode::CPMNode
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMNode::CPMNode()
{
	next = prev = this;
	parent = NULL;
	children = NULL;

	strcpy(type, "ROOT");

	attribs = new CPMAttrib();
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::CPMNode
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMNode::CPMNode(CPMNode *parentNode)
{
	next = prev = this;
	parent = NULL;
	children = NULL;

	strcpy(type, "");

	attribs = new CPMAttrib();

	if (parentNode != NULL)
		parentNode->AttachChild(this);
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::CPMNode
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMNode::~CPMNode()
{
	// delete all children
	if (children)
	{
		while (children->next != children)
			delete children->next;
		delete children;
	}

	// disconnect from siblings
	next->prev = prev;
	prev->next = next;

	// fix the parent's children pointer if necessary
	if ((parent) && (parent->children == this))
		parent->children = (next == prev) ? NULL : next;

	// delete all this nodes attributes
	attribs->DeleteAll();
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::SetType
   Purpose : set node type
   Parameters : type string
   Returns : 
   Info : 
*/

void CPMNode::SetType(char *type)
{
	strcpy(this->type, type);
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AttachChild
   Purpose : makes the specified node a child of this node.
   Parameters : child node pointer
   Returns : 
   Info : 
*/

void CPMNode::AttachChild(CPMNode *child)
{
	parent = this;
	if (children == NULL)
		children = child;
	else
	{
		child->prev = children->prev;
		child->next = children;
		children->prev->next = child;
		children->prev = child;
	}
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::Read
   Purpose : read in map file
   Parameters : file struct pointer
   Returns : 
   Info : 
*/

int CPMNode::Read(TPMFile *file)
{
	static char		path[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR], fname[_MAX_FNAME], ext[_MAX_EXT];
#if 0
	TPMFile			*newFile;
#endif

	CPMNode			*node;
	char			line[1024], block[PMMAX_IDENT_LEN];
	char			*rp, *tp, *ap, *wp1, *wp2;


	while (file->sp < file->ep)
	{
		LoadLine(file->sp, file->ep, line);
		file->sp = NextCharLine(file->sp, file->ep);

		rp = TidyLine(line);

		// ** Parse this packed line

		switch (*rp)
		{
		// directive?
		case '#':
#if 0
			// #include
			if (stricmp(rp+1, "include") == NULL)
			{
				// isolate include file
				wp1 = strchr(rp, '"');
				if (wp1)
					wp2 = strchr(wp1+1, '"');
				if (wp2 && (wp2-wp1) > 1)
				{
					// include file is relative to current file (??!!)
					_splitpath(file->filename, drive, dir, fname, ext);
					*wp2 = 0;
					sprintf(path, "%s%s%s", drive, dir, wp1+1);

					// 
					if ((newFile = pmOpenFile(path)) != NULL)
					{
						Read(newFile);
						pmCloseFile(newFile);
						newFile = NULL;
					}
				}
			}
#endif

			// #?
			break;

		// block start
		case '{':
			node = new CPMNode(this);
			node->Read(file);
			strcpy(node->type, block);
			break;

		// block end
		case '}':
			return 1;

		// could be a tag or block name
		default:
			if (strlen(rp) > 0)
			{
				if ((ap = strchr(rp, '=')) != NULL)
				{
					// get the tag assignment variable name
					tp = ap;
					while (tp > rp && (*tp == '=' || *tp == ' ' || *tp == '/t'))
						tp--;
					if (tp > rp)
					{
						// terminate tag name
						*(tp+1) = 0;

						// ** The line seems to be a tag assignment. We need to determine what type
						// ** of assignment this is.. [string, float, int, bool]

						ap++;								// skip equals sign
						wp1 = wp2 = NULL;					// null working char pointers

						// enumerations always contain commmas
						if (strchr(ap, ',') != NULL)
						{
							// ** Enumeration

							// need to determine the enumeration type
							if (strchr(ap, '"') != NULL)
							{
								// ** Strings

								while (ap != NULL)
								{
									wp1 = strchr(ap, '"');
									if (wp1)
										wp2 = strchr(wp1+1, '"');
									if (wp2 && (wp2-wp1) > 1)
									{
										*wp2 = 0;
										AddAttribEnum(rp, wp1+1);
									}
									ap = strchr(wp2+1, ',');
								}
							}
							else if (strchr(ap, '.') != NULL)
							{
								// ** Floats
							}
							else if ((*ap >= '0' && *ap <= '9') || *ap == '-')
							{
								// ** Integers

								while (ap != NULL)
								{
									AddAttribEnum(rp, atoi(ap));
									ap = strchr(ap, ',');
									if (ap != NULL)
										ap++;
								}
								break;
							}

							// ** Unknown Enumeration

							break;
						}

						// strings are always enclosed within a pair of quotes..
						wp1 = strchr(ap, '"');
						if (wp1)
							wp2 = strchr(wp1+1, '"');
						if (wp2 && (wp2-wp1) > 1)
						{
							// attribute: string
							*wp2 = 0;
							AddAttrib(rp, wp1+1);
							break;
						}

						// boolean true?
						if (stricmp(ap, "true") == NULL)
						{
							// attribute: boolean true
							AddAttrib(rp, true);
							break;
						}
						// boolean false?
						if (stricmp(ap, "false") == NULL)
						{
							// attribute: boolean false
							AddAttrib(rp, false);
							break;
						}

						// as floats always have a point..
						wp1 = strchr(ap, '.');
						if (wp1)
						{
							for (;;ap++)
								if ((*ap >= '0' && *ap <= '9') || *ap == '.' || *ap == '-')
								{
									break;
								}

							// attribute: float
							AddAttrib(rp, (float)atof(ap));
							break;
						}
						else if ((*ap >= '0' && *ap <= '9') || *ap == '-')
						{
							// attribute: integer
							AddAttrib(rp, atoi(ap));
							break;
						}

						// ** Cannot determine assignment type!!!
					}
				}
				else
				{
					// assume block name
					strcpy(block, rp);
				}
			}
			break;
		}
	}
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::Write
   Purpose : write out node to file
   Parameters : file struct pointer
   Returns : 1 okay, 0 error
   Info : 
*/

int CPMNode::Write(TPMFile *file)
{
	static int	level = 0;
	char		*indent;
	CPMNode		*node;
	CPMAttrib	*attrib;

	// write node type name and opening brace
	indent = GetIndent(level);
	fprintf(file->fp, "\n%s%s\n%s{\n", indent, type, indent);

	// write all this nodes attributes
	indent = GetIndent(level+1);
	for (attrib = attribs->next; attrib != attribs; attrib = attrib->next)
	{
		switch (attrib->type)
		{
		case PMATTRIB_STRING:
			fprintf(file->fp, "%s%s = \"%s\"\n", indent, attrib->ident, attrib->string);
			break;
		case PMATTRIB_INT:
			fprintf(file->fp, "%s%s = %d\n", indent, attrib->ident, attrib->ival);
			break;
		case PMATTRIB_FLOAT:
			fprintf(file->fp, "%s%s = %.2f\n", indent, attrib->ident, attrib->fval);
			break;
		case PMATTRIB_BOOL:
			fprintf(file->fp, "%s%s = %s\n", indent, attrib->ident, (attrib->bval == true) ? "true" : "false");
			break;
		}
	}

	// write all nodes children
	if ((node = children) != NULL)
	{
		level++;
		do
			{
			node->Write(file);
			node = node->next;
			}
		while (node != children);
		level--;
	}

	// write nodes matching closing brace
	indent = GetIndent(level);
	fprintf(file->fp, "%s}\n", indent);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttrib
   Purpose : add tagged string attribute to node
   Parameters : attribute ident string pointer, string attribute
   Returns : 
   Info : 
*/

void CPMNode::AddAttrib(char *ident, char *string)
{
	CPMAttrib	*attrib;

	attrib = new CPMAttrib(attribs);
	attrib->type = PMATTRIB_STRING;
	strcpy(attrib->ident, ident);
	strcpy(attrib->string, string);
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttrib
   Purpose : add tagged integer attribute to node
   Parameters : attribute ident string pointer, string attribute
   Returns : 
   Info : 
*/

void CPMNode::AddAttrib(char *ident, int ival)
{
	CPMAttrib	*attrib;

	attrib = new CPMAttrib(attribs);
	attrib->type = PMATTRIB_INT;
	strcpy(attrib->ident, ident);
	attrib->ival = ival;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttrib
   Purpose : add tagged float attribute to node
   Parameters : attribute ident string pointer, string attribute
   Returns : 
   Info : 
*/

void CPMNode::AddAttrib(char *ident, float fval)
{
	CPMAttrib	*attrib;

	attrib = new CPMAttrib(attribs);
	attrib->type = PMATTRIB_FLOAT;
	strcpy(attrib->ident, ident);
	attrib->fval = fval;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttrib
   Purpose : add tagged boolean attribute to node
   Parameters : attribute ident string pointer, boolean value
   Returns : 
   Info : 
*/

void CPMNode::AddAttrib(char *ident, bool bval)
{
	CPMAttrib	*attrib;

	attrib = new CPMAttrib(attribs);
	attrib->type = PMATTRIB_BOOL;
	strcpy(attrib->ident, ident);
	attrib->bval = bval;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttribEnum
   Purpose : add tagged string enumeration attribute to node
   Parameters : attribute ident string pointer, string pointer
   Returns : 
   Info : 
*/

void CPMNode::AddAttribEnum(char *ident, char *string)
{
	CPMAttrib	*attrib;

	// does this enumeration already exist?
	if ((attrib = attribs->Find(ident)) == NULL)
	{
		// no.. so create the initial enumeration type
		attrib = new CPMAttrib(attribs);
		attrib->type = PMATTRIB_ENUMSTRING;
		strcpy(attrib->ident, ident);
		attrib->estrings = (char *)malloc(PMMAX_STRING_LEN);
		strcpy(attrib->estrings, string);
		attrib->enoof++;
	}
	// is of the required type?
	else if (attrib->type == PMATTRIB_ENUMSTRING)
	{
		// append string to current attribute
		attrib->estrings = (char *)realloc(attrib->estrings, (attrib->enoof+1)*PMMAX_STRING_LEN);
		strcpy(attrib->estrings+attrib->enoof*PMMAX_STRING_LEN, string);
		attrib->enoof++;
	}
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttribEnum
   Purpose : add tagged integer enumeration attribute to node
   Parameters : attribute ident string pointer, integer value
   Returns : 
   Info : 
*/

void CPMNode::AddAttribEnum(char *ident, int ival)
{
	CPMAttrib	*attrib;

	// does this enumeration already exist?
	if ((attrib = attribs->Find(ident)) == NULL)
	{
		// no.. so create the initial enumeration type
		attrib = new CPMAttrib(attribs);
		attrib->type = PMATTRIB_ENUMINT;
		strcpy(attrib->ident, ident);
		attrib->eivals = (int *)malloc(sizeof(int));
		attrib->eivals[0] = ival;
		attrib->enoof++;
	}
	// is of the required type?
	else if (attrib->type == PMATTRIB_ENUMINT)
	{
		// append int to current attribute
		attrib->eivals = (int *)realloc(attrib->eivals, (attrib->enoof+1)*sizeof(int));
		attrib->eivals[attrib->enoof] = ival;
		attrib->enoof++;
	}
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttribFloat
   Purpose : add tagged float enumeration attribute to node
   Parameters : attribute ident string pointer, float value
   Returns : 
   Info : 
*/

void CPMNode::AddAttribEnum(char *ident, float fval)
{
	CPMAttrib	*attrib;

	// does this enumeration already exist?
	if ((attrib = attribs->Find(ident)) == NULL)
	{
		// no.. so create the initial enumeration type
		attrib = new CPMAttrib(attribs);
		attrib->type = PMATTRIB_ENUMFLOAT;
		strcpy(attrib->ident, ident);
		attrib->efvals = (float *)malloc(sizeof(float));
		attrib->efvals[0] = fval;
		attrib->enoof++;
	}
	// is of the required type?
	else if (attrib->type == PMATTRIB_ENUMFLOAT)
	{
		// append float to current attribute
		attrib->efvals = (float *)realloc(attrib->efvals, (attrib->enoof+1)*sizeof(float));
		attrib->efvals[attrib->enoof] = fval;
		attrib->enoof++;
	}
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::AddAttribFloat
   Purpose : add tagged data attribute to node
   Parameters : attribute ident string pointer, data pointer, [data size]
   Returns : 0 if an attribute already exists with the given ident or 1
   Info : no management of the data is performed
*/

int CPMNode::AddAttribData(char *ident, void *data, int size)
{
	CPMAttrib	*attrib;

	if (attribs->Find(ident) != NULL)
		return 0;

	attrib = new CPMAttrib(attribs);
	attrib->type = PMATTRIB_DATA;
	strcpy(attrib->ident, ident);
	attrib->datp = data;
	attrib->datn = size;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttrib
   Purpose : get string attribute from this node
   Parameters : attribute ident string pointer
   Returns : NULL - no such attribute, else string pointer
   Info : 
*/

char *CPMNode::GetAttrib(char *ident)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return NULL;
	if (attrib->type != PMATTRIB_STRING)
		return NULL;
	return attrib->string;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttrib
   Purpose : get integer attribute from this node
   Parameters : attribute ident string pointer, integer reference
   Returns : 0 - no such attribute, else 1 and integer ref is set
   Info : 
*/

int CPMNode::GetAttrib(char *ident, int& ival)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return 0;
	if (attrib->type != PMATTRIB_INT)
		return 0;
	ival = attrib->ival;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttrib
   Purpose : get float attribute from this node
   Parameters : attribute ident string pointer, float reference
   Returns : 0 - no such attribute, else 1 and float ref is set
   Info : 
*/

int CPMNode::GetAttrib(char *ident, float& fval)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return 0;
	if (attrib->type != PMATTRIB_FLOAT)
		return 0;
	fval = attrib->fval;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttrib
   Purpose : get boolean attribute from this node
   Parameters : attribute ident string pointer, boolean reference
   Returns : 0 - no such attribute, else 1 and boolean ref is set
   Info : 
*/

int CPMNode::GetAttrib(char *ident, bool& bval)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return 0;
	if (attrib->type != PMATTRIB_BOOL)
		return 0;
	bval = attrib->bval;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttribEnum
   Purpose : get string attribute enumeration from this node
   Parameters : attribute ident string pointer, enum index
   Returns : NULL - no such attribute or invalid index, else string pointer
   Info : 
*/

char *CPMNode::GetAttribEnum(char *ident, int ei)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return NULL;
	if (attrib->type != PMATTRIB_ENUMSTRING || ei >= attrib->enoof)
		return NULL;
	return attrib->estrings+ei*PMMAX_STRING_LEN;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttribEnum
   Purpose : get integer attribute enumeration from this node
   Parameters : attribute ident string pointer, enum index, integer reference
   Returns : 0 - no such attribute or invalid index, else 1 and integer ref is set
   Info : 
*/

int CPMNode::GetAttribEnum(char *ident, int ei, int& ival)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return 0;
	if (attrib->type != PMATTRIB_ENUMINT || ei >= attrib->enoof)
		return 0;
	ival = attrib->eivals[ei];
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttribEnum
   Purpose : get float attribute enumeration from this node
   Parameters : attribute ident string pointer, enum index, float reference
   Returns : 0 - no such attribute or invalid index, else 1 and float ref is set
   Info : 
*/

int CPMNode::GetAttribEnum(char *ident, int ei, float& fval)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return 0;
	if (attrib->type != PMATTRIB_ENUMFLOAT || ei >= attrib->enoof)
		return 0;
	fval = attrib->efvals[ei];
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttribEnumNoof
   Purpose : get attribute number of enumerations from this node
   Parameters : attribute ident string pointer, noof int reference
   Returns : 0 - no such attribute, else 1 and int ref is set
   Info : 
*/

int CPMNode::GetAttribEnumNoof(char *ident, int& noof)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return 0;
	if (attrib->type != PMATTRIB_ENUMSTRING && attrib->type != PMATTRIB_ENUMINT && attrib->type != PMATTRIB_ENUMFLOAT)
		return 0;
	noof = attrib->enoof;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::FindAttribEnum
   Purpose : find index of enumeration string
   Parameters : attribute ident string pointer, enum string pointer
   Returns : -1 - no such attribute or no string found, else index into enum list
   Info : 
*/

int CPMNode::FindAttribEnum(char *ident, char *string)
{
	int		noof, n;
	char	*ret;

	if (GetAttribEnumNoof(ident, noof) == 0)
		return -1;
	for (n=0; n < noof; n++)
		if ((ret = GetAttribEnum(ident, n)) != NULL)
		{
			if (stricmp(string, ret) == 0)
			{
				return n;
			}
		}
	return -1;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttribData
   Purpose : get data attribute from this node
   Parameters : attribute ident string pointer, [data size return variable]
   Returns : NULL - no such data attribute, else data pointer [and size set]
   Info : 
*/

void *CPMNode::GetAttribData(char *ident, int *size)
{
	CPMAttrib	*attrib;

	if (size != NULL)
		*size = 0;
	if ((attrib = attribs->Find(ident)) == NULL)
		return NULL;
	if (attrib->type != PMATTRIB_DATA)
		return NULL;

	if (size != NULL)
		*size = attrib->datn;
	return attrib->datp;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::GetAttribType
   Purpose : get attribute type from this node
   Parameters : ident pointer
   Returns : PMATTRIB_NULL - unknown ident, or any one of the enum PMATTRIBS
   Info : 
*/

int CPMNode::GetAttribType(char *ident)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return PMATTRIB_NULL;
	return attrib->type;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::FindAttrib
   Purpose : find the identified attribute from this node
   Parameters : ident pointer
   Returns : attribute instance or NULL
   Info : 
*/

CPMAttrib *CPMNode::FindAttrib(char *ident)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) == NULL)
		return NULL;
	return attrib;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::DelAttrib
   Purpose : delete attribute from node with ident
   Parameters : ident pointer
   Returns : 0 - no such attribute, else 1 and deleted
   Info : 
*/

int CPMNode::DelAttrib(char *ident)
{
	CPMAttrib	*attrib;
	if ((attrib = attribs->Find(ident)) != NULL)
		delete attrib;
	return (attrib != NULL);
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::EnumAttribs
   Purpose : enumerate the this nodes attributes, calling context user function
   Parameters : attribute ident string pointer, [context]
   Returns : PMENUM_CONTINUE = continue enumeration, PMENUM_END = end
   Info : 
*/

int CPMNode::EnumAttribs(TPMEnumAttribFunc *funcPtr, void *context)
{
	CPMAttrib	*attrib;
	for (attrib = attribs->next; attrib != attribs; attrib = attrib->next)
		funcPtr(attrib, context);
	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::EnumNodes
   Purpose : recursively enumerate the node tree for specific node idents, calling user function on entry
   Parameters : function pointer, [context, type of node to find]
   Returns : PMENUM_CONTINUE = continue enumeration, PMENUM_END = end, PMENUM_END_PATH = just end this path
   Info : 
*/

int CPMNode::EnumNodes(TPMEnumNodeFunc *funcPtr, void *context, char *type)
{
	int		ret;
	CPMNode	*node;

	if (type == NULL || stricmp(this->type, type) == NULL)
	{
		if ((ret = funcPtr(this, context)) != PMENUM_CONTINUE)
		{
			return ret;
		}
	}
	if ((node = children) != NULL)
	{
		do
		{
			if ((ret = node->EnumNodes(funcPtr, context, type)) == PMENUM_END)
			{
				return ret;
			}
			node = node->next;
		}
		while (node != children);
	}
	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::EnumNodes
   Purpose : recursively enumerate the node tree for specific node idents, calling user function on entry (pre) and exit (post)
   Parameters : pre function pointer, pre context, post function pointer, post context, [type of node to find]
   Returns : PMENUM_CONTINUE = continue enumeration, PMENUM_END = end, PMENUM_END_PATH = just end this path
   Info : 
*/

int CPMNode::EnumNodes(TPMEnumNodeFunc *preFuncPtr, void *preContext, TPMEnumNodeFunc *postFuncPtr, void *postContext, char *type)
{
	int		ret;
	CPMNode	*node;

	if (type == NULL || stricmp(this->type, type) == NULL)
	{
		if ((ret = preFuncPtr(this, preContext)) != PMENUM_CONTINUE)
		{
			return ret;
		}
	}
	if ((node = children) != NULL)
	{
		do
		{
			if ((ret = node->EnumNodes(preFuncPtr, preContext, postFuncPtr, postContext, type)) == PMENUM_END)
			{
				return ret;
			}
			node = node->next;
		}
		while (node != children);
	}
	if (type == NULL || stricmp(this->type, type) == NULL)
	{
		if ((ret = postFuncPtr(this, postContext)) != PMENUM_CONTINUE)
		{
			return ret;
		}
	}
	return 0;
}


/* --------------------------------------------------------------------------------
   Function : CPMNode::Clone
   Purpose : clone this node instance
   Parameters : level instance to clone
   Returns : 
   Info : 
*/

void CPMNode::Clone(CPMNode *node)
{
	CPMNode		*lpNode, *newNode;
	CPMAttrib	*lpAttrib, *newAttrib;

	if ((lpNode = node->children) != NULL)
	{
		do
		{
			newNode = new CPMNode(this);
			newNode->Clone(lpNode);

			lpNode = lpNode->next;
		} while (lpNode != node->children);
	}

	// copy node type
	strncpy(type, node->type, PMMAX_IDENT_LEN);

	// copy all attributes
	for (lpAttrib = node->attribs->next; lpAttrib != node->attribs; lpAttrib = lpAttrib->next)
	{
		newAttrib = new CPMAttrib(attribs);
		newAttrib->Clone(lpAttrib);
	}
}


// ** 'CPMLevel' class

/* --------------------------------------------------------------------------------
   Function : CPMLevel::CPMLevel
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMLevel::CPMLevel()
{
	root = new CPMNode;
}


/* --------------------------------------------------------------------------------
   Function : CPMLevel::~CPMLevel
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

CPMLevel::~CPMLevel()
{
	delete root;
}


/* --------------------------------------------------------------------------------
   Function : CPMLevel::Read
   Purpose : read file to create node tree
   Parameters : file struct pointer
   Returns : 
   Info : 
*/

void CPMLevel::Read(TPMFile *file)
{
	root->Read(file);
}


/* --------------------------------------------------------------------------------
   Function : CPMLevel::Write
   Purpose : write node tree to file
   Parameters : file struct pointer
   Returns : 
   Info : 
*/

void CPMLevel::Write(TPMFile *file)
{
	fprintf(file->fp, "\n");
	fprintf(file->fp, "// Level: %s\n", file->filename);
	fprintf(file->fp, "// file generated by MaxPlugin\n");
	fprintf(file->fp, "\n");

	if (root->children)
		root->children->Write(file);
}


/* --------------------------------------------------------------------------------
   Function : CPMLevel::EnumNodes
   Purpose : recursively enumerate the node tree for specific node idents, calling user function on node entry
   Parameters : pre function pointer, [context, type of node to find]
   Returns : PMENUM_CONTINUE = continue enumeration, PMENUM_END = end, PMENUM_END_PATH = just end this path
   Info : 
*/

int CPMLevel::EnumNodes(TPMEnumNodeFunc *funcPtr, void *context, char *type)
{
	return root->EnumNodes(funcPtr, context, type);
}


/* --------------------------------------------------------------------------------
   Function : CPMLevel::EnumNodes
   Purpose : recursively enumerate the node tree for specific node idents, calling user function on node entry (pre) and exit (post)
   Parameters : pre function pointer, pre context, post function pointer, post context, [type of node to find]
   Returns : PMENUM_CONTINUE = continue enumeration, PMENUM_END = end, PMENUM_END_PATH = just end this path
   Info : 
*/

int CPMLevel::EnumNodes(TPMEnumNodeFunc *preFuncPtr, void *preContext, TPMEnumNodeFunc *postFuncPtr, void *postContext, char *type)
{
	return root->EnumNodes(preFuncPtr, preContext, postFuncPtr, postContext, type);
}


/* --------------------------------------------------------------------------------
   Function : CPMLevel::Clone
   Purpose : clone this level instance
   Parameters : level instance to clone
   Returns : 
   Info : 
*/

void CPMLevel::Clone(CPMLevel *level)
{
	root->Clone(level->root);
}


// ---------------
// Other functions

/* --------------------------------------------------------------------------------
   Function : LoadLine
   Purpose : load a line of text from the a char strean
   Parameters : current char pointer, end char stream pointer, text line to load
   Returns : 
   Info : 
*/

static void LoadLine(char *cp, char *ep, char *line)
{
	while (cp < ep)
	{
		if (*cp == 0x0a || *cp == 0x0d)
			break;
		*line++ = *cp++;
	}
	*line = 0;
}


/* --------------------------------------------------------------------------------
   Function : NextCharLine
   Purpose : return the next line from the char stream
   Parameters : current char pointer, end char stream pointer
   Returns : pointer to next char line
   Info : 
*/

static char *NextCharLine(char *cp, char *ep)
{
	while (cp < ep)
	{
		if (*cp == 0x0a || *cp == 0x0d)
			break;
		cp++;
	}
	if (*(cp+1) == 0x0a || *(cp+1) == 0x0d)
		return cp+2;
	return cp+1;
}


/* --------------------------------------------------------------------------------
   Function : TidyLine
   Purpose : tidy up the line by removing all trailing chars and fillers
   Parameters : pointer to text line to tidy up (ASCIIZ)
   Returns : tidied line pointer
   Info : 
*/

static char *TidyLine(char *line)
{
	static char	buf[_MAX_PATH];
	char		c, *sp, *dp, *rp, q;

	// save line in temp buffer
	strcpy(buf, line);

	sp = buf;
	// strip all leading spaces and tabs
	while ((c = *sp) != 0)
	{
		if (c != 0x09 && c != 0x20)
		{
			break;
		}
		sp++;
	}
	if (c == 0)
	{
		// if zero found.. use NULL line
		line[0] = 0;
		return line;
	}

	rp = dp = line;
	// strip all filler spaces and comments
	q = 0;
	while ((c = *sp) != 0)
	{
		// don't strip inbetween strings
		if (q)
		{
			*dp++ = c;
			if (c == '"')
				q = 0;
		}
		else
		{
			if (c == '"')
				q = 1;
			if (c == '/' && *(sp+1) == '/')
				break;
			if (c != 0x09 && c != 0x20)
				*dp++ = c;
		}
		sp++;
	}

	// terminate packed line and return
	*dp = 0;
	return rp;
}


/* --------------------------------------------------------------------------------
   Function : GetIndent
   Purpose : return tab indentation from current level
   Parameters : current level [0,1,2...]
   Returns : tab indentation string
   Info : 
*/

static char *GetIndent(int level)
{
	static char	indent[32];
	indent[level] = 0;
	while (level--)
		indent[level] = '\t';
	return indent;
}


// ------------------
// Shortcut functions

/* --------------------------------------------------------------------------------
   Function : pmLoadLevel
   Purpose : load in level objects
   Parameters : filename or file memory stream pointer,
				file input type [PMLOAD_FILE, PMLOAD_MEMORY]. default = file,
				file length if loadType == PMLOAD_MEMORY. default = 0
   Returns : instance of level class or NULL if failed
   Info : 
*/

CPMLevel *pmLoadLevel(char *fileIn, int loadType, int fileLen)
{
	CPMLevel	*level;
	TPMFile		*file;

	if ((file = pmOpenFile(fileIn, (loadType == PMLOAD_FILE) ? PMMODE_READ_FILE : PMMODE_READ_MEMORY, fileLen)) == NULL)
		return NULL;

	level = new CPMLevel;
	level->Read(file);
	pmCloseFile(file);
	return level;
}


/* --------------------------------------------------------------------------------
   Function : pmDeleteLevel
   Purpose : delete previously loaded level
   Parameters : level class pointer, (from pmLoadLevel function)
   Returns : 
   Info : 
*/

void pmDeleteLevel(CPMLevel *level)
{
	if (level)
		delete level;
}


/* --------------------------------------------------------------------------------
   Function : pmCloneLevel
   Purpose : clone a new instance of this level
   Parameters : level class pointer
   Returns : pointer to cloned level instance
   Info : 
*/

CPMLevel *pmCloneLevel(CPMLevel *level)
{
	CPMLevel	*newLevel;

	if (level == NULL)
		return NULL;

	newLevel = new CPMLevel;
	newLevel->Clone(level);
	return newLevel;
}


/* --------------------------------------------------------------------------------
   Function : pmOpenFile
   Purpose : open level file into file struct
   Parameters : filename or file memory stream pointer,
				mode [PMMODE_READ_FILE = read file, PMMODE_READ_MEMORY = read memory, PMMODE_WRITE = write],
				file length if mode == PMMODE_READ_MEMORY. default = 0
   Returns : file struct pointer, or NULL if fail
   Info : 
*/

TPMFile	*pmOpenFile(char *fileIn, int mode, int fileLen)
{
	TPMFile		*file;
	FILE		*fp;
	int			len;
	char		*buf;

	switch (mode)
	{
	case PMMODE_READ_FILE:

		// open and read in the file
		if ((fp = fopen(fileIn, "rt")) == NULL)
			return NULL;
		// calculate file length, allocate buffer and read file in
		fseek(fp, 0, SEEK_END);
		len = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		if ((buf = (char *)malloc(len)) == NULL)
		{
			fclose(fp);
			return NULL;
		}
		len = fread(buf, 1, len, fp);			// re-calc file length
		fclose(fp);

		// allocate and init file read buffer
		file = (TPMFile *)malloc(sizeof(TPMFile));
		file->buf = file->sp = buf;
		file->ep = buf + len;
		file->fp = NULL;
		file->mode = mode;
		strcpy(file->filename, fileIn);

		// return our file handle
		return file;

	case PMMODE_READ_MEMORY:

		// use the pre-opened memory stream
		file = (TPMFile *)malloc(sizeof(TPMFile));
		file->buf = file->sp = fileIn;
		file->ep = fileIn + fileLen;
		file->fp = NULL;
		file->mode = mode;
		strcpy(file->filename, "");

		// return our file handle
		return file;

	case PMMODE_WRITE:

		// open file for writing
		if ((fp = fopen(fileIn, "wt")) == NULL)
			return NULL;

		// allocate and init file write buffer
		file = (TPMFile *)malloc(sizeof(TPMFile));
		file->buf = file->sp = file->ep = NULL;
		file->fp = fp;
		file->mode = mode;
		strcpy(file->filename, fileIn);

		// return our file handle
		return file;
	}

	// unknown file mode
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : pmCloseFile
   Purpose : close previously open file structure
   Parameters : file struct pointer [returned from pmOpenFile]
   Returns : 
   Info : 
*/

void pmCloseFile(TPMFile *file)
{
	if (file == NULL)
		return;
	switch (file->mode)
	{
	case PMMODE_READ_FILE:
		if (file->buf)
			free(file->buf);
		break;
	case PMMODE_READ_MEMORY:
		break;
	case PMMODE_WRITE:
		if (file->fp)
			fclose(file->fp);
		break;
	}
	free(file);
}
