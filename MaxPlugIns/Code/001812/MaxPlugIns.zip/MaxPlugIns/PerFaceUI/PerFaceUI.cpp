
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of PerFaceUI.gup, (c) 2000 Blitz Games Ltd.
//
//    File : PerFaceUI.cpp
// Purpose : Implementation of the utility
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "PerFaceUI.h"
#include "ParseMap.h"

#include "resource.h"

// include our per face data modifier
#include "PerFaceData.h"


// PerFaceUI class ident
#define PERFACEUI_CLASS_ID	Class_ID(0x510679fc, 0x4b5d3e6)

// window message on node selection changed
#define WMU_SELCHANGE	(WM_USER+2048)

// user option return value
enum USEROPTS
{
	USEROPT_CANCEL,
	USEROPT_MERGE,
	USEROPT_MERGEALL,
	USEROPT_NEW,
	USEROPT_NEWALL,
};


// --------------------------------------------------------------------------------
// PerFaceUI Class Definition
// --------------------------------------------------------------------------------
class PerFaceUI : public UtilityObj
{
	public:
		HWND						hPanel;
		IUtil						*iu;
		Interface					*ip;

		// methods derived from UtilityObj
		void						BeginEditParams(Interface *ip,IUtil *iu);
		void						EndEditParams(Interface *ip,IUtil *iu);
		void						SelectionSetChanged(Interface *ip, IUtil *iu);

		void						Init(HWND hWnd);
		void						Destroy(HWND hWnd);
		
		void						DeleteThis() {}						// null since we use a single static instance

		BOOL						PanelDialogProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

		// constructor / destructor
									PerFaceUI();
									~PerFaceUI();
};

// single static instance of our class definition
static PerFaceUI thePerFaceUI;


// --------------------------------------------------------------------------------
// PerFaceUI Class Descriptor
// --------------------------------------------------------------------------------
class PerFaceUIClassDesc:public ClassDesc
{
	public:
		int				IsPublic()						{return 1;}
		void			*Create(BOOL loading = FALSE)	{return &thePerFaceUI;}
		const TCHAR		*ClassName()					{return GetString(IDS_CLASS_NAME);}
		SClass_ID		SuperClassID()					{return UTILITY_CLASS_ID;}
		Class_ID		ClassID()						{return PERFACEUI_CLASS_ID;}
		const TCHAR		*Category()						{return GetString(IDS_CATEGORY);}
		void			ResetClassParams(BOOL reset)	{}
};

// instance of our class descriptor
static PerFaceUIClassDesc PerFaceUIDesc;
ClassDesc *GetPerFaceUIDesc() {return &PerFaceUIDesc;}


// main panel dialog procedure
static BOOL CALLBACK perFaceUIDialogProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// user options dialog procedure
static BOOL CALLBACK procUserOptions(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);


// --------------------------------------------------------------------------------
// Dispatch Panel Procedure
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : perFaceUIDialogProc
   Purpose : our panel page window procedure
   Parameters : dialog handle, message, additional message info, additional message info
   Returns : return TRUE if processed message, else FALSE
   Info : 
*/

static BOOL CALLBACK perFaceUIDialogProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	PerFaceUI	*util;

	if (msg == WM_INITDIALOG)
	{
		util = (PerFaceUI *)lParam;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)util);
		return util->PanelDialogProc(hWnd, msg, wParam, lParam);
	}
	if (util = (PerFaceUI *)GetWindowLong(hWnd, GWL_USERDATA))
	{
		if (msg == WM_DESTROY)
			SetWindowLong(hWnd, GWL_USERDATA, 0);
		return util->PanelDialogProc(hWnd, msg, wParam, lParam);
	}
	return FALSE;
}



// --------------------------------------------------------------------------------
// PerFaceUI Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PerFaceUI::PerFaceUI
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceUI::PerFaceUI()
{
	iu = NULL;
	ip = NULL;	
	hPanel = NULL;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceUI::~PerFaceUI
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceUI::~PerFaceUI()
{
}


/* --------------------------------------------------------------------------------
   Function : PerFaceUI::BeginEditParams
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void PerFaceUI::BeginEditParams(Interface *ip,IUtil *iu)
{
	this->iu = iu;
	this->ip = ip;

	// add our rollup page in the panel
	hPanel = ip->AddRollupPage(hInstance, MAKEINTRESOURCE(IDD_PANEL), ::perFaceUIDialogProc, GetString(IDS_PARAMS), (LPARAM)this);

	// check for new node selection
	SelectionSetChanged(ip, iu);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceUI::EndEditParams
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/
	
void PerFaceUI::EndEditParams(Interface *ip,IUtil *iu) 
{
	ip->DeleteRollupPage(hPanel);
	hPanel = NULL;

	this->ip = NULL;
	this->iu = NULL;
}


/* --------------------------------------------------------------------------------
   Function : Pivot::SelectionSetChanged
   Purpose : called when the selection set changed
   Parameters : valid interface pointer, current utility pointer
   Returns : 
   Info : 
*/

void PerFaceUI::SelectionSetChanged(Interface *ip, IUtil *iu)
{
	INode	*node;

	node = (ip->GetSelNodeCount() >= 1) ? ip->GetSelNode(0) : NULL;
	if (hPanel)
		SendMessage(hPanel, WMU_SELCHANGE, 0, 0);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceUI::Init
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void PerFaceUI::Init(HWND hWnd)
{
}


/* --------------------------------------------------------------------------------
   Function : PerFaceUI::Destroy
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void PerFaceUI::Destroy(HWND hWnd)
{
}


/* --------------------------------------------------------------------------------
   Function : PerFaceUI::PanelDialogProc
   Purpose : class scoped panel procedure
   Parameters : dialog handle, message, additional message info, additional message info
   Returns : return TRUE if processed message, else FALSE
   Info : 
*/

BOOL PerFaceUI::PanelDialogProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static TCHAR		outp[260], fname[_MAX_FNAME];
	static ICustImage	*image = NULL;
	static HIMAGELIST	imageList = NULL;

	HBITMAP				bitmap, mask;
	int					i, j, noofFaces, flag, opts, noof;
	ObjectState			os;
	Modifier			*perFaceMod;
	PerFaceModData		*perFaceData;
	PerFaceEntry		*perFace;
	ModContext			*modContext;
	Object				*objRef;
	IDerivedObject		*derivedObjMod;
	TriObject			*triObj;
	TVFace				*mapFace;
	INodeTab			flash;
	CPMLevel			*fdrInst;
	OPENFILENAME		ofn;
	FilterList			fls;
	INode				*node;

	switch (msg)
	{
	case WM_INITDIALOG:

		// ** Create Window

		// create custom image list within our dialog
		image = GetICustImage(GetDlgItem(hWnd, IDC_ISLLOGO));
		imageList = ImageList_Create(86, 21, TRUE, 2, 2);
		// load image bitmaps and assign to the image list
		bitmap = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BLITZIMAGE));
		mask = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BLITZMASK));
		ImageList_Add(imageList, bitmap, mask);
		// delete our images
		DeleteObject(mask);
		DeleteObject(bitmap);
		image->SetImage(imageList, 0, 86, 21);

		Init(hWnd);
		break;


	case WM_DESTROY:

		// ** Destroy Window

		// release images
		if (image)
			ReleaseICustImage(image);
		image = NULL;
		if (imageList)
			ImageList_Destroy(imageList);
		imageList = NULL;

		Destroy(hWnd);
		break;


	case WM_COMMAND:

		switch (LOWORD(wParam))
		{
		case IDC_LOADRES:

			// ** Load Template Resource

			// default user options to new
			opts = USEROPT_NEW;

			// loop around ALL current node selections
			for (i=0; i<ip->GetSelNodeCount(); i++)
			{
				if ((node = ip->GetSelNode(i)) != NULL)
				{
					// can a perfacedata modifier be applied to this node.. ie. is it a triobject mesh?
					os = node->EvalWorldState(ip->GetTime());
					if (os.obj->SuperClassID() != GEOMOBJECT_CLASS_ID || !os.obj->IsRenderable() || !os.obj->IsDeformable())
						break;

					// does this node already have a perfacedata modifier applied?
					if (opts != USEROPT_NEWALL || opts != USEROPT_MERGEALL)
					{
						if ((perFaceData = PerFaceData_GetData(node)) != NULL)
						{
							int	parms[2];
							parms[0] = (int)ip;
							parms[1] = (int)node;
							opts = DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_USEROPTIONS), ip->GetMAXHWnd(), (DLGPROC)procUserOptions, (LPARAM)parms);
							if (opts == USEROPT_CANCEL)
							{
								DPrintf("User Cancelled Export");
								return 1;
							}
						}
					}

					// delete perfacedata instance if new data requested
					if ((opts == USEROPT_NEW || opts == USEROPT_NEWALL) && perFaceData != NULL)
					{
						// get our nodes modifier context,,
						if ((modContext = PerFaceData_GetModContext(node)) != NULL)
						{
							DPrintf("Deleting current instance of PerFaceData from node \"%s\" Modifier Context", node->GetName());

							// and delete instance of local data
							SAFE_DELETE(modContext->localData);
							perFaceData = NULL;
						}
					}

					// make sure a modifier exists for this node
					if (perFaceData == NULL)
					{
						// ** Before applying the PerFaceData modifier to the target node, we need to prepare the targets
						// ** mapping channel. This mapping channel is used to uniquely identify each face in the mesh.

						// set the PerFaceData mapping channel
						triObj = (TriObject *)os.obj;
						triObj->GetMesh().setNumMaps(PERFACEDATA_MAPPING_CHANNEL+1, TRUE);
						triObj->GetMesh().setMapSupport(PERFACEDATA_MAPPING_CHANNEL, TRUE);
						triObj->GetMesh().setNumMapVerts(PERFACEDATA_MAPPING_CHANNEL, triObj->GetMesh().getNumFaces()*3);

						// set unique idents for every PerFaceData mapping channel face
						if ((mapFace = triObj->GetMesh().mapFaces(PERFACEDATA_MAPPING_CHANNEL)) != NULL)
							for (j=0; j<triObj->GetMesh().getNumFaces(); j++)
							{
								mapFace[j].setTVerts(j*3+0, j*3+1, j*3+2);
							}

						// record the number of faces on this mesh
						noofFaces = triObj->GetMesh().getNumFaces();

						// force all views to be re-evaluated
						ip->ForceCompleteRedraw();


						// ** Apply our PerFaceData modifier the selected target node. At the moment only one set data maybe
						// ** attached to polygons

						// flash the effected node
						flash.Append(1, &node);

						// create instance of PerFaceData..
						perFaceData = PerFaceData_CreateData();
						if (perFaceData == NULL)
							DPrintf("PerFaceData instance cannot be created");
						else
						{
							DPrintf("PerFaceData instance created");

							// set our data set name
							perFaceData->SetDataName(_T("*Unknown Data*"));

							// add a face entry for every face in the selected nodes mesh
							for (j=0; j<noofFaces; j++)
							{
								perFace = perFaceData->AddFace();
								if (perFace != NULL)
									perFace->SetIdent(j*3+0, j*3+1, j*3+2);
							}

							// as this node already had our modifier assigned?
							if ((modContext = PerFaceData_GetModContext(node)) != NULL)
							{
								DPrintf("Updating nodes Modifier Context with new PerFaceData");

								// therefore just update this nodes modifier context
								modContext->localData = perFaceData;
							}
							else
							{
								// create an instance of our modifier and attach to the selected node
								perFaceMod = (Modifier *)ip->CreateInstance(OSM_CLASS_ID, PERFACEDATA_CLASS_ID);
								if (perFaceMod == NULL)
								{
									// unable to create our modifier instance.. delete all our mesh face data
									SAFE_DELETE(perFaceData)
								}
								else
								{
									DPrintf("Adding PerFaceMod Modifier to node \"%s\"", node->GetName());

									// get this nodes object ref and create new reference object
									objRef = node->GetObjectRef();
									derivedObjMod = CreateDerivedObject(objRef);

									// create our mod context.. (this should be okay to create in this module)
									modContext = PerFaceData_CreateModContext();
									if (modContext != NULL)
									{
										// push our PerFaceData in the mod context
										modContext->localData = perFaceData;

										// add our modifier to this new object
										derivedObjMod->SetAFlag(A_LOCK_TARGET);
										derivedObjMod->AddModifier(perFaceMod, modContext);
										derivedObjMod->ClearAFlag(A_LOCK_TARGET);

										// use the new object for this node
										node->SetObjectRef(derivedObjMod);

										// update panel information
										SendMessage(hPanel, WMU_SELCHANGE, 0, 0);
									}
								}
							}
						}
					}

					// format our data
					if (perFaceData != NULL)
					{
						// ** Get user to load in template resource file. This resrouce file is used
						// ** to simply 'format' a meshes face data.

						// invaliate filename
						outp[0] = 0;
						// init file type filter
						fls.Append(_T("Max Face Template files (*.mft)"));
						fls.Append(_T("*.mft"));

						// get filename from user
						memset(&ofn, 0, sizeof(ofn));
						ofn.lStructSize	= sizeof(OPENFILENAME);
						ofn.hwndOwner	= ip->GetMAXHWnd();
						ofn.lpstrTitle	= _T("Load Data Resource Template");
						ofn.lpstrFilter	= fls;
						ofn.lpstrFile   = outp;
						ofn.nMaxFile    = 260;
						ofn.lpstrDefExt	= _T("mft");
						ofn.Flags		= OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXPLORER;

						if (GetOpenFileName(&ofn) != 0)
						{
							if ((fdrInst = pmLoadLevel(outp)) != NULL)
							{
								_tsplitpath(outp, NULL, NULL, fname, NULL);
								switch (opts)
								{
								case USEROPT_NEW:
								case USEROPT_NEWALL:
									DPrintf("Loading \"%s\" format file", outp);
									PerFaceData_FormatData(node, fdrInst, fname);
									break;
								case USEROPT_MERGE:
								case USEROPT_MERGEALL:
									DPrintf("Merging \"%s\" format file into existing data", outp);
									PerFaceData_MergeInFormatData(node, fdrInst, fname);
									break;
								}
							}
						}
					}
				}
			}

			// update panel information
			SendMessage(hPanel, WMU_SELCHANGE, 0, 0);

			// flash all modified nodes
			ip->FlashNodes(&flash);
			break;
		}
		break;


	case WMU_SELCHANGE:

		// ** Node Selection Changed

		// enable / disable selection
		flag = ip->GetSelNodeCount() > 0;
		EnableWindow(GetDlgItem(hWnd, IDC_SELNODENAME), flag);

		// print node selection name
		if (ip->GetSelNodeCount() == 0)
			_stprintf(outp, _T("Node: ????"), (lParam != NULL) ? ((INode *)lParam)->GetName() : "???");
		else if (ip->GetSelNodeCount() == 1)
			_stprintf(outp, _T("Node: %s"), ip->GetSelNode(0)->GetName());
		else
			_stprintf(outp, _T("Node: *MULTIPLE*"));
		SetWindowText(GetDlgItem(hWnd, IDC_SELNODENAME), outp);

		// can any of the selected nodes have a perfacedata modifier applied?
		noof = 0;
		for (i=0; i<ip->GetSelNodeCount(); i++)
		{
			os = ip->GetSelNode(i)->EvalWorldState(ip->GetTime());
			if (os.obj->SuperClassID() == GEOMOBJECT_CLASS_ID && os.obj->IsRenderable() && os.obj->IsDeformable())
			{
				noof++;
			}
		}

		// print data name
		_stprintf(outp, _T("Data: NULL"));
		if (noof > 0)
			for (i=0, flag=0; i<ip->GetSelNodeCount(); i++)
			{
				// any valid perfacedata?
				if ((perFaceData = PerFaceData_GetData(ip->GetSelNode(i))) != NULL)
				{
					if (flag == 1 && _tcsicmp(outp, perFaceData->GetDataName()) != 0)
					{
						_stprintf(outp, _T("Data: NULL"));
						break;
					}
					flag = 1;
					_stprintf(outp, "%s%s", _T("Data: "), perFaceData->GetDataName());
				}
			}
		SetWindowText(GetDlgItem(hWnd, IDC_DATANAME), outp);
		EnableWindow(GetDlgItem(hWnd, IDC_DATANAME), (noof > 0) ? 1 : 0);
		EnableWindow(GetDlgItem(hWnd, IDC_LOADRES),  (noof > 0) ? 1 : 0);
		break;


	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MOUSEMOVE:

		// ** Pass Mouse Messages Rollup

		// pass 'em down
		ip->RollupMouseMessage(hWnd, msg, wParam, lParam); 
		break;

	// not one of ours
	default:
		return FALSE;
	}
	return TRUE;
}


/* --------------------------------------------------------------------------------
   Function : procUserOptions
   Purpose : get options from user
   Parameters : parms[2] context pointer, [0] *Interface, [1] *INode
   Returns : USEROPT_CANCEL, USEROPT_MERGE, USEROPT_MERGEALL, USEROPT_NEW, USEROPT_NEWALL
   Info : 
*/

static BOOL CALLBACK procUserOptions(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static TCHAR	outp[260];
	int				*parms;
	Interface		*ip;
	INode			*node;
	PerFaceModData	*perFaceData;


	if (msg != WM_INITDIALOG)
	{
		if ((parms = (int *)GetWindowLong(hWnd, GWL_USERDATA)) == NULL)
			return FALSE;
		ip = (Interface *)parms[0]; node = (INode *)parms[1];
	}
	switch (msg)
	{
	case WM_INITDIALOG:

		// ** Initialise Dialog

		// save user parameters
		parms = (int *)lParam;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)parms);
		ip = (Interface *)parms[0]; node = (INode *)parms[1];

		// enable / disable apply all button
		SendMessage(GetDlgItem(hWnd,  IDC_OPTAPPLYALL), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
		EnableWindow(GetDlgItem(hWnd, IDC_OPTAPPLYALL), ip->GetSelNodeCount() > 1);

		// print node infomation
		if ((perFaceData = PerFaceData_GetData(node)) != NULL)
		{
			_stprintf(outp, "%s%s%s%s%s", _T("PerFaceUI Warning"), _T("   Node: "), node->GetName(), _T("   Data: "), perFaceData->GetDataName());
			SetWindowText(hWnd, outp);
		}

		// set default focus onto cancel button
		wParam = (WPARAM)GetDlgItem(hWnd, IDCANCEL);
		return TRUE;


	case WM_DESTROY:

		// ** Destroy Dialog

		// remove user parameters
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)0);
		return 0;


	case WM_COMMAND:

		// ** Button Commands

		switch (LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hWnd, USEROPT_CANCEL);
			return 0;

		case ID_OPTMERGE:
			if (SendMessage(GetDlgItem(hWnd, IDC_OPTAPPLYALL), BM_GETCHECK, 0, 0) == BST_CHECKED)
				EndDialog(hWnd, USEROPT_MERGEALL);
			else
				EndDialog(hWnd, USEROPT_MERGE);
			return 0;

		case ID_OPTNEW:
			if (SendMessage(GetDlgItem(hWnd, IDC_OPTAPPLYALL), BM_GETCHECK, 0, 0) == BST_CHECKED)
				EndDialog(hWnd, USEROPT_NEWALL);
			else
				EndDialog(hWnd, USEROPT_NEW);
			return 0;
		}
	}

	return FALSE;
}
