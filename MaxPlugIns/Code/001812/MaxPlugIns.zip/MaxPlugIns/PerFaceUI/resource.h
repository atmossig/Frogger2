//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PerFaceUI.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDD_PANEL                       101
#define IDB_ISLIMAGE                    103
#define IDB_ISLMASK                     104
#define IDD_USEROPTIONS                 105
#define IDB_BLITZMASK                   106
#define IDB_BLITZIMAGE                  107
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_SELNODENAME                 1001
#define IDC_ADDMODIFIER                 1002
#define IDC_DATANAME                    1002
#define IDC_LOADRES                     1003
#define IDC_MERGERES                    1004
#define IDC_OPTAPPLYALL                 1004
#define IDC_OPTTEXT                     1005
#define ID_OPTNEW                       1006
#define ID_OPTMERGE                     1007
#define IDC_ISLLOGO                     1010
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
