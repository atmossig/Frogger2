
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of PerFaceData.dlm, (c) 2000 Interactive Studios Ltd.
//
//    File : PerFaceData.h
// Purpose : Header
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __PERFACEUI__H
#define __PERFACEUI__H

#define DLLEXPORT	__declspec( dllexport )

#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#if MAX_RELEASE >= 3000
#include "iparamb2.h"
#include "iparamm2.h"
#else
#include "iparamb.h"
#include "iparamm.h"
#endif
#include "utilapi.h"

#include "CommonFiles.h"

#endif // __PERFACEUI__H
