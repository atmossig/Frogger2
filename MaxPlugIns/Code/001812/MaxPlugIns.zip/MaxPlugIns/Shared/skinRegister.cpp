

// -- Skin Register: Used When Importing Data Into Modifier --

#include "skinregister.h"


///////////////////////////////////////////////////////
// Skin Register Routines
///////////////////////////////////////////////////////

// Add Skin Data To Node
void SKINREG_AddSkinData( INode * node, DWORD sbid, DWORD length, void * data )
{
	if( node && data && length )
		node->AddAppDataChunk( Class_ID( HELPER_CLASS_ID,BONE_CLASS_ID ), SCENE_IMPORT_CLASS_ID, sbid, length, data );
}

// Get Skin Data From Node
AppDataChunk * SKINREG_GetSkinData( INode * node, DWORD sbid )
{
	if( !node )
		return NULL;
	AppDataChunk * dataChunk = NULL;
	if( !( dataChunk = node->GetAppDataChunk( Class_ID( HELPER_CLASS_ID,BONE_CLASS_ID ), SCENE_IMPORT_CLASS_ID, sbid ) ) )
		return NULL;
	return dataChunk;
}

// Remove Skin Data From Node
void SKINREG_RemoveSkinData( INode * node, DWORD sbid )
{
	if( node )
		node->RemoveAppDataChunk( Class_ID( HELPER_CLASS_ID,BONE_CLASS_ID ), SCENE_IMPORT_CLASS_ID, sbid );
}
