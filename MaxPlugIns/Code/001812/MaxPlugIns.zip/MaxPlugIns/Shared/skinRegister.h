

// -- Skin Register: Used When Importing Data Into Modifier --

#ifndef _SKINREG_HEADER_
#define _SKINREG_HEADER_

#include "max.h"


///////////////////////////////////////////////////////
// Skin Register Structure
///////////////////////////////////////////////////////

// skin vertex struture
typedef struct
{
	short idxVert;				// index into mesh vertex list
	Point3 boneVec;				// vector from bone
} SKIN_DATA_VERTEX;


///////////////////////////////////////////////////////
// Skin Register Routines
///////////////////////////////////////////////////////

extern void SKINREG_AddSkinData( INode * node, DWORD sbid, DWORD length, void * data );
extern AppDataChunk * SKINREG_GetSkinData( INode * node, DWORD sbid );
extern void SKINREG_RemoveSkinData( INode * node, DWORD sbid );

#endif
