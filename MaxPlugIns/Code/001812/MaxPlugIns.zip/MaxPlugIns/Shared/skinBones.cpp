

// -- Bone Reference Linked List Structure --

#include "skinbones.h"


///////////////////////////////////////////////////////
// Bone Reference Class Methods
///////////////////////////////////////////////////////

// Initialise Bone Reference
void SkinBoneRef::Init( INode * boneNode )
{
	node = NULL;
	previous = NULL;
	next = NULL;
	transMat.IdentityMatrix();
	refMat.IdentityMatrix();
	// 
	if( boneNode )
	{
		node = boneNode;
		refMat = boneNode->GetNodeTM(0);
	}
}

// UnInitialise Bone Reference
void SkinBoneRef::UnInit( void )
{
	node = NULL;
	previous = NULL;
	next = NULL;
	transMat.IdentityMatrix();
	refMat.IdentityMatrix();
}

// Save Bone Reference
int SkinBoneRef::Save( ISave * isave )
{
//	ULONG writes = 0;
//	isave->Write( ..... );
	return 1;
}

int SkinBoneRef::Load( ILoad * iload )
{
//	ULONG writes = 0;
//	iload->Read( ..... );
	return 1;
}


///////////////////////////////////////////////////////
// Bone Reference Manager Methods
///////////////////////////////////////////////////////

// Initialise Bone Manager
void SkinBoneRefManager::Init( void )
{
	numBones = 0;
	boneRefList = NULL;
}

// UnInitialise Bone Manager
void SkinBoneRefManager::UnInit( void )
{
	DeleteList();
	boneRefList = NULL;
	numBones = 0;
}

// Save All Bone References
IOResult SkinBoneRefManager::Save( ISave * isave )
{
	ULONG		writes;
	SkinBoneRef	* ref;

	// save bone used count
	int bones = Count();
	if (isave->Write(&bones, sizeof(bones), &writes) != IO_OK)
		return IO_ERROR;

	// save all bone references
	ref = GetFirst();
	while (ref)
	{
		if (! ref->Save(isave))
			return IO_ERROR;
		ref = ref->GetNext();
	}

	// successful save
	return IO_OK;
}

// Load And Setup All Bone References
IOResult SkinBoneRefManager::Load( ILoad * iload, int version )
{
	ULONG	reads;
	int		bones;

	// delete all current references
	DeleteList();

	// load bone used count
	bones = 0;
	if (iload->Read(&bones, sizeof(bones), &reads) != IO_OK)
		return IO_ERROR;

	// load all bone references
	for(int i = 0; i < bones; i++)
		AddNode((INode *)NULL);

	// successful load
	return IO_OK;
}

// Delete All Bone Refs
void SkinBoneRefManager::DeleteList()
{
	SkinBoneRef * ref = GetLast();
	while( ref )
	{
		SkinBoneRef * delref = ref;
		ref = ref->GetPrevious();
		if( ref )
			ref->SetNext( NULL );
		free( (void*)delref );
	}
	// zero out these babies!
	boneRefList = NULL;
	numBones = 0;
}

// Create Bone List
int SkinBoneRefManager::CreateList( INode ** boneList, int bones )
{
	// make sure no existing list
	DeleteList();
	// add all bone nodes
	for( int i=0;i<bones;i++ )
		AddNode( boneList[i] );
	// return bone count
	return Count();
}

// Del Bone Node, By Index, From Reference List
int SkinBoneRefManager::DelBoneIndex( int idxBone )
{
	return DelBone( GetBone( idxBone ) );
}

// Del Bone Node, Direct, From Reference List
int SkinBoneRefManager::DelNode( INode * boneNode )
{
	return DelBone( IsTarget( boneNode ) );
}

// Del Bone Node, Direct, From Reference List
int SkinBoneRefManager::DelBone( SkinBoneRef * boneRef )
{
	if( !boneRef )
		return 0;

	// by pass entry in linked list
	SkinBoneRef * prev = boneRef->previous;
	SkinBoneRef * next = boneRef->next;
	if( prev && next )
	{
		// middle entry
		prev->next = next;
		next->previous = prev;
	}
	else if( prev && !next )
	{
		// last entry
		prev->next = NULL;
	}
	else if( !prev && next )
	{
		// first entry
		next->previous = NULL;
		boneRefList = next;
	}
	else if( !prev && !next )
	{
		// single entry
		boneRefList = NULL;
	}

	// break links and delete
	boneRef->UnInit();
	free( (void*)boneRef );

	// drop bone count
	numBones--;

	// bone succesfully deleted
	return 1;
}

// Add Bone Node To Reference List
int SkinBoneRefManager::AddNode( INode * boneNode )
{
	// make bone ref
	SkinBoneRef * boneRef = (SkinBoneRef *)malloc( sizeof(SkinBoneRef) );
	if( !boneRef )
		return 0;			// memory allocation error
	boneRef->Init( boneNode );
	// try and add bone to list
	if( !Add( boneRef ) )
		return 0;
	// succesfully added
	numBones++;
	return 1;
}

// Add Bone Reference
SkinBoneRef * SkinBoneRefManager::Add( SkinBoneRef * boneRef )
{
	// get state of list
	SkinBoneRef * ref = GetFirst();
	// empty?
	if( !ref )
	{
		// add initial entry
		boneRef->SetPrevious( NULL );
		boneRef->SetNext( NULL );
		boneRefList = boneRef;
		return boneRef;
	}
	// append to end of list
	SkinBoneRef * endref = GetLast();
	endref->SetNext( boneRef );
	boneRef->SetPrevious( endref );
	return boneRef;
}

// Get First Bone Reference
SkinBoneRef * SkinBoneRefManager::GetFirst()
{
	if( !boneRefList )
		return NULL;
	return boneRefList;
}

// Get Last Bone Reference
SkinBoneRef * SkinBoneRefManager::GetLast()
{
	SkinBoneRef * ref = GetFirst();
	if( !ref )
		return NULL;
	for( SkinBoneRef * r = ref; r; ref = r, r = r->GetNext() );
	return ref;
}

// Get Next Bone Reference
SkinBoneRef * SkinBoneRefManager::GetNext( SkinBoneRef * boneRef )
{
	if( !boneRef )
		return NULL;
	return boneRef->GetNext();
}

// Get Previous Bone Reference
SkinBoneRef * SkinBoneRefManager::GetPrevious( SkinBoneRef * boneRef )
{
	if( !boneRef )
		return NULL;
	return boneRef->GetPrevious();
}

// Count Bone Refs
int SkinBoneRefManager::Count()
{
	int count = 0;
	if( !boneRefList )
		return count;
	for( SkinBoneRef * boneRef = boneRefList; boneRef; boneRef = GetNext(boneRef), count++ );
	return count;
}

// Get Bone From Index
SkinBoneRef * SkinBoneRefManager::GetBone( int index )
{
	if( !( index >= 0 && index < Count() ) )
		return NULL;
	for( SkinBoneRef * ref = GetFirst(); ref && index; ref = ref->GetNext(), index-- );
	return ref;
}


// Search For Target Reference Bone
SkinBoneRef * SkinBoneRefManager::IsTarget( INode * tarNode )
{
	SkinBoneRef * ref = GetFirst();
	while( ref )
	{
		if( ref->node == tarNode )
			return ref;
		ref = ref->GetNext();
	}
	return ref;
}

// Get Bone Index From Target
int SkinBoneRefManager::GetIndex( INode * node )
{
	int index = 0;
	for( SkinBoneRef * ref = GetFirst(); ref && ref->node != node; ref = ref->GetNext() )
		index++;
	if( index < Count() )
		return index;
	return -1;
}


///////////////////////////////////////////////////////
// Bone Reference Selection
///////////////////////////////////////////////////////

// Set Bone Selection
void SkinBoneRefManager::SetBoneSelect( int idxBone )
{
	boneSelect = idxBone;
}

// Get User Bone Selection - Validateed
int SkinBoneRefManager::GetBoneSelect( void )
{
	// validate selection before returning
	if( boneSelect < Count() && boneSelect >= 0 )
		return boneSelect;			// valid selection
	// invalid bone
	return SKIN_BONEREF_INVALID_SELECTION;
}
