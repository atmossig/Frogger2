
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Skin Data Class, (c) 1999 Interactive Studios Ltd.
//
//    File  : skindata.h
//   Author : Andy Slater
// Purpose  : The shared skin data container class
// Comments : 
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#ifndef _SKINDATA_HEADER_
#define _SKINDATA_HEADER_

#include "max.h"

#include "skinbones.h"
#include "skinassigns.h"


// --------------------------------------------------------------------------------
// Class: Skin Data Class
// --------------------------------------------------------------------------------

class SkinData : public LocalModData
{
	public:
						// constructors
						SkinData();
						// destructor
						~SkinData();

		// methods inherited from LocalModData
						// used to clone myself
		LocalModData	* Clone();

						// return bone reference manager
		SkinBoneRefManager		* GetBones() { return boneRefs; };
						// return vertex assignment manager
		SkinVertAssignManager	* GetAssigns() { return vertexAssigns; }

		
		SkinBoneRefManager		* boneRefs;			// bone reference manager
		SkinVertAssignManager	* vertexAssigns;	// vertex assign manager
		int					boneSelectIndex;		// bone selection index
};

#endif
