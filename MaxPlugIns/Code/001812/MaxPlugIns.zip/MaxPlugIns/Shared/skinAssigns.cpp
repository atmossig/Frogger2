

// -- Vertex Assigment Class --

#include "skinbones.h"
#include "skinassigns.h"


///////////////////////////////////////////////////////
// Vertex Assignment Class Methods
///////////////////////////////////////////////////////

// Initialise Vertex Assignment
void SkinVertAssign::Init( int index )
{
	idxBoneRef = index;
	vec -= vec;
}

// Initialise Vertex Assignment
void SkinVertAssign::UnInit( void )
{
	idxBoneRef = SKIN_VERTASS_NULL_BONE;
	vec -= vec;
}

// Set Vertex Assignment
void SkinVertAssign::Set( int index, Point3 vec )
{
	this->idxBoneRef = index;
	this->vec = vec;
}


///////////////////////////////////////////////////////
// Vertex Assignment Class Methods
///////////////////////////////////////////////////////

// Initialise Vertex Assignment Manager
void SkinVertAssignManager::Init( SkinBoneRefManager * boneRefList )
{
	this->boneRefList = boneRefList;
	numAssigns = 0;
	assignList = NULL;
	skinNode = NULL;
}

// UnInitialise Vertex Assignment Manager
void SkinVertAssignManager::UnInit( void )
{
	// destroy list only
	CreateList( 0 );
}

// Assignment List Creation
int SkinVertAssignManager::CreateList( int numVerts )
{
	// delete current assignment list
	if( assignList )
		free( (void *)assignList );
	assignList = NULL;
	numAssigns = 0;

	// allocate space for all vertex assigns
	if( numVerts )
	{
		assignList = (SkinVertAssign *)malloc( numVerts*sizeof(SkinVertAssign) );
		if( !assignList )
			return 0;
	}
	numAssigns = numVerts;

	// initialise all vertices assignments
	for( int i=0;i<numAssigns;i++ )
	{
		SkinVertAssign * vertAss = GetAssign(i);
		if( !vertAss )
			continue;
		vertAss->Init( SKIN_VERTASS_NULL_BONE );
	}

	// return okay
	return 1;
}

// Is Assign Valid?
int SkinVertAssignManager::IsValid( int idxVert )
{
	if( numAssigns && assignList && idxVert < numAssigns )
		return 1;
	return 0;
}

// Get Vertex Assignment
SkinVertAssign * SkinVertAssignManager::GetAssign( int idxVert )
{
	if( !IsValid( idxVert ) )
		return NULL;
	return &assignList[ idxVert ];
}

// Clear All Current Assignments
int SkinVertAssignManager::ClearAll( Mesh & mesh )
{
	if( !CreateList( mesh.numVerts ) )
		return 0;
	return 1;
}

// Re-Assign All Bones Vertices - ( possible change in mesh vertices )
void SkinVertAssignManager::ReAssignBone(Mesh & mesh, int idxBone)
{
	SkinVertAssign	* vertAss;
	int				idxVert;

	// valid mesh?
	if (numAssigns != mesh.numVerts)
		return;
	// valid bone list?
	if (!boneRefList || !boneRefList->Count())
		return;
	if (idxBone != SKIN_BONEREF_ALL && !boneRefList->GetBone(idxBone))
		return;

	// loop around all vertices
	for (idxVert=0; idxVert < numAssigns; idxVert++)
	{
		if ((vertAss = GetAssign(idxVert)))
		{
			if (idxBone == SKIN_BONEREF_ALL || vertAss->idxBoneRef == idxBone)
				Add(mesh, idxVert, vertAss->idxBoneRef);
		}
	}
}

// Auto Assign Single OR All Bones
void SkinVertAssignManager::AutoAssignBone(Mesh & mesh, int idxBone, int bOverWrite)
{
	float			* distList;
	int				idxVert, distNum, i, idxBoneUse;
	SkinBoneRef		* boneRef;
	SkinVertAssign	* vertAss;
	Point3			refVert, assVert;

	// valid mesh?
	if (numAssigns != mesh.numVerts)
		return;
	// valid bone list?
	if (!boneRefList || !boneRefList->Count())
		return;
	if (idxBone != SKIN_BONEREF_ALL && !boneRefList->GetBone(idxBone))
		return;

	// allocate space for all differences
	if (! (distList = (float *)malloc( boneRefList->Count()*sizeof(float))) )
		return;				// malloc error, abort..

	// loop around all vertices
	for (idxVert=0; idxVert < numAssigns; idxVert++)
	{
		// build vertex-bones distance list
		for (boneRef = boneRefList->GetFirst(), distNum=0; boneRef; boneRef = boneRef->GetNext())
		{
			if (! boneRef->node)
				continue;
			refVert = boneRef->node->GetNodeTM(0).GetTrans(); // *ASL* boneRef->refMat.GetTrans(); *ASL*
			assVert = mesh.verts[ idxVert ];
			distList[ distNum ] = Length((assVert-refVert));
			distNum++;
		}

		// get closest bone
		idxBoneUse = 0;						// default: bone reference index zero
		for (i=0; i < distNum; i++)
		{
			if (distList[ idxBoneUse ] > distList[i])
				idxBoneUse = i;				// use closest bone
		}

		// assign vertex to closest bone
		if (idxBone == SKIN_BONEREF_ALL || idxBone == idxBoneUse)
		{
			if ((vertAss = GetAssign(idxVert)))
			{
				if (vertAss->idxBoneRef == SKIN_VERTASS_NULL_BONE || bOverWrite)
					Add(mesh, idxVert, idxBoneUse);
			}
		}
	}

	// release list
	free((void *)distList);
}

// Clear All Assigns For Bone OR All
void SkinVertAssignManager::ClearBoneAssigns(int idxBone)
{
	SkinVertAssign	* vertAss;
	int				i;

	// valid bone list?
	if (!boneRefList || !boneRefList->Count())
		return;
	if (idxBone != SKIN_BONEREF_ALL && !boneRefList->GetBone(idxBone))
		return;

	// clear all assigns?
	if (idxBone == SKIN_BONEREF_ALL)
		CreateList(numAssigns);
	else
	{
		for (i=0; i<numAssigns; i++)
		{
			if ((vertAss = GetAssign(i)) && vertAss->idxBoneRef == idxBone)
				Sub(i, idxBone);
		}
	}
}

// Add Bone N To Vertex Assignment X
int SkinVertAssignManager::Add( Mesh & mesh, int idxVert, int idxBone )
{
	if( idxVert >= mesh.numVerts )
		return 0;

	SkinBoneRef * boneRef = boneRefList->GetBone( idxBone );
	if( !boneRef )
		return 0;

	SkinVertAssign * vertAss = GetAssign( idxVert );
	if( !vertAss )
		return 0;

	Point3 boneVec( 0,0,0 );
	if( boneRef->node )
		boneVec = mesh.verts[ idxVert ] - boneRef->node->GetNodeTM(0).GetTrans();	// *ASL* boneRef->refMat.GetTrans(); *ASL*
	vertAss->Set( idxBone,boneVec );

	return 1;
}

// Sub Assign Vertex N From Bone X
int SkinVertAssignManager::Sub( int idxVert, int idxBone )
{
	SkinBoneRef * boneRef = boneRefList->GetBone( idxBone );
	if( !boneRef )
		return 0;

	SkinVertAssign * vertAss = GetAssign( idxVert );
	if( !vertAss )
		return 0;

	// only unassign vertex if connected to bone x
	if( vertAss->idxBoneRef != idxBone )
		return 0;
	// 
	vertAss->Init( SKIN_VERTASS_NULL_BONE );

	return 1;
}

// Count All Assignments For Bone N
int SkinVertAssignManager::CountAssigns( int idxBone )
{
	if( !numAssigns || !assignList || !boneRefList->Count() )
		return 0;

	int count = 0;
	//
	for( int i=0;i<numAssigns;i++ )
	{
		SkinVertAssign * vertAss = GetAssign(i);
		if( !vertAss )
			continue;
		if( vertAss->idxBoneRef == idxBone )
			count++;
	}

	//
	return count;
}

// Remap All Assignments Which Use Bone N
int SkinVertAssignManager::Remap( int idxBone )
{
	if( !numAssigns || !assignList || !boneRefList->Count() )
		return 0;

	//
	for( int i=0; i<numAssigns; i++ )
	{
		SkinVertAssign * vertAss = GetAssign(i);
		if( vertAss )
		{
			int idxRef = vertAss->idxBoneRef;
			if( idxRef != SKIN_VERTASS_NULL_BONE && idxRef >= idxBone )
			{
				idxRef = (idxRef == idxBone) ? SKIN_VERTASS_NULL_BONE : idxRef-1;
				if( idxRef <= 0 )
					idxRef = SKIN_VERTASS_NULL_BONE;
				vertAss->idxBoneRef = idxRef;
			}
		}
	}

	//
	return 1;
}


///////////////////////////////////////////////////////
// IO
///////////////////////////////////////////////////////

// Save All Vertex Assigns
IOResult SkinVertAssignManager::Save( ISave *isave )
{
	ULONG			writes;
	int				count, index;
	SkinVertAssign	* vertAss;
	Point3			vec;

	if (!numAssigns || !assignList)
	{
		// save zero assignments
		count = 0;
		if ((isave->Write(&count,sizeof(count), &writes)) != IO_OK)
			return IO_ERROR;
	}
	else
	{
		// save number of assignments
		count = numAssigns;
		if ((isave->Write(&count,sizeof(count), &writes)) != IO_OK)
			return IO_ERROR;

		// save all vertex assignments
		for( int i=0;i<numAssigns;i++ )
		{
			if (! (vertAss = GetAssign(i)))
				continue;

			index = vertAss->idxBoneRef;
			if ((isave->Write(&index, sizeof(index), &writes)) != IO_OK)
				return IO_ERROR;
			vec = vertAss->vec;
			if ((isave->Write(&vec, sizeof(vec), &writes)) != IO_OK)
				return IO_ERROR;
		}
	}

	// save successful
	return IO_OK;
}

// Load All Vertex Assigns
IOResult SkinVertAssignManager::Load( ILoad *iload, int version )
{
	ULONG			reads;
	int				count, index;
	SkinVertAssign	* vertAss;
	Point3			vec;

	// load count
	count = 0;
	if ((iload->Read( &count,sizeof(count), &reads )) != IO_OK)
		return IO_ERROR;

	// allocate space for all loads
	CreateList(count);

	// load all
	for(int i = 0; i < numAssigns; i++)
	{
		if (! (vertAss = GetAssign(i)) )
			continue;
		index = SKIN_VERTASS_NULL_BONE;
		if ((iload->Read(&index, sizeof(index), &reads)) != IO_OK)
			return IO_ERROR;
		if ((iload->Read(&vec, sizeof(vec), &reads)) != IO_OK)
			return IO_ERROR;
		vertAss->Set(index, vec);
	}

	// load successful
	return IO_OK;
}


///////////////////////////////////////////////////////
// Node Mesh Level Methods
///////////////////////////////////////////////////////

// Return Tri Object From Node - ( only if can be derived )
TriObject * SkinVertAssignManager::GetTriObjFromNode( INode * node, int & needDel )
{
	needDel = 0;

	if( !node )
		return NULL;

	ObjectState os = node->EvalWorldState(0);
	Object * obj = (Object * )os.obj;
	if( !obj->CanConvertToType( Class_ID(TRIOBJ_CLASS_ID,0 ) ) )
		return NULL;

	TriObject * tri = NULL;
	if( !( tri = (TriObject *)obj->ConvertToType( 0,Class_ID( TRIOBJ_CLASS_ID,0 ) ) ) )
		return NULL;
	needDel = (tri!=obj) ? 1:0;

	return tri;
}

// Return Pivot Matrix From Node
Matrix3 SkinVertAssignManager::GetPivMatFromNode( INode * node )
{
	Matrix3 retMat( TRUE );

	if( !skinNode )
		return retMat;

	// get pivot components
	Point3 p = node->GetObjOffsetPos();
	Quat r = node->GetObjOffsetRot();
	ScaleValue s = node->GetObjOffsetScale();
	// construct component matrices
	Matrix3 pm( TRUE ), rm( TRUE ), sm( TRUE );
	pm.Translate( p );
	r.MakeMatrix( rm );
	sm.Scale( s.s );
	// construct final pivot matrix
	retMat = (rm*sm)*pm;

	//
	return retMat;
}

// Get Vertex from Mesh - ( pivot/offset transformed )
Point3 SkinVertAssignManager::GetVertFromNode( Mesh & mesh, Matrix3 pivMat, int idxVert )
{
	Point3 retVert( 0,0,0 );

	// valid vertex index
	if( idxVert >= mesh.numVerts )
		return retVert;
	// 
	retVert = mesh.verts[ idxVert ];
	retVert = pivMat * retVert;
	//
	return retVert;
}
