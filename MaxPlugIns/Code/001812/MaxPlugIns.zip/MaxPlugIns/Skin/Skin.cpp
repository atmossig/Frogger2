
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Skin Space Warp V3.0, (c) 1999 Interactive Studios Ltd.
//
//    File  : skin.cpp
// Purpose  : The entire skin plugin
// Comments : If this rebuild crashes.. its getting mailed to autodesk!
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "Skin.h"

#define SKINMOD_DATA_CHUNK	1000

#include "skindata.h"
#include "skinregister.h"

#include "CommonFiles.h"

#include "version.h"

#include "resource.h"

// number of fixed references, need these to maintain backwards compatability
#define NOOF_FIXED_REFS	2

// unique menu id
#define IDC_UNIQUE_MENU_ID	50000


// ---------
// Globals

static int controlsInit = 0;				// initialise flag
static HINSTANCE hInstance = NULL;		// dll plugin instance


// ---------
// Templates

// skin object panel procedure
BOOL CALLBACK SkinObjPanelProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
// skin modifier panel procedure
BOOL CALLBACK SkinModPanelProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// count bone nodes in scene
void CountBoneNodes(INode * node, INodeTab & nodeTab);


// --------------------------------------------------------------------------------
// Skin World Space Object Class
// --------------------------------------------------------------------------------
class SkinWSMObj : public SimpleWSMObject
{
	public:
						SkinWSMObj();
						~SkinWSMObj();

		// methods inherited from Animatble
						// class id
		Class_ID		ClassID() { return SKINOBJ_CLASS_ID; }
						// delete
		void			DeleteThis();
						// begin editing
		void			BeginEditParams(IObjParam *ip, ULONG flags,Animatable *prev);
						// end editing
		void			EndEditParams(IObjParam *ip, ULONG flags,Animatable *next);

		// methods inherited from BaseObject
						// 
		int				DoOwnSelectHilite() { return TRUE; }
						// 
		CreateMouseCallBack * GetCreateMouseCallBack();

		// methods inherited from WSMObject
						// create modifier on binding to node
		Modifier		*CreateWSMMod(INode *node);

		// methods inherited from SimpleWSMObject
						// build the mesh object representation
		void			BuildMesh(TimeValue t);

		IObjParam		*ip;					// max interface
		HWND			hPanel;					// info dialog
};


// --------------------------------------------------------------------------------
// Object Creation Class
// --------------------------------------------------------------------------------
class SkinWSMObjCreate : public CreateMouseCallBack
{
	public:
						// procedural object creation proc
		int				proc(ViewExp *vpt, int msg, int point, int flags, IPoint2 m, Matrix3& mat);
		SkinWSMObj		*skinObj;
};


// --------------------------------------------------------------------------------
// Skin World Space Modifier Class
// --------------------------------------------------------------------------------
class SkinWSMMod : public SimpleWSMMod
{
	public:
						SkinWSMMod();
						SkinWSMMod(INode *node, SkinWSMObj *skinObj);
						~SkinWSMMod();

		HWND			hPanel;							// handle for dialog panel

		// methods inherited from SimpleWSMMod
						// used to retrieve the callback object that will handle the deformation
		Deformer		& GetDeformer(TimeValue t, ModContext &mc, Matrix3& mat, Matrix3& invmat);
						// used to retrieve the validity interval of the modifier
		Interval		GetValidity(TimeValue t);

		// methods inherited from Animatble
						// class id
		Class_ID		ClassID() { return SKINMOD_CLASS_ID; }
						// super class id
		SClass_ID		SuperClassID() { return WSM_CLASS_ID; }
						// class name
		void			GetClassName(TSTR& s) { s = TSTR(GetString(IDS_WSMOD_CLASS_NAME)); }
						// delete this instance
		void			DeleteThis();
						// begin editing
		void			BeginEditParams(IObjParam * ip, ULONG flags,Animatable *prev);
						// end editing
		void			EndEditParams(IObjParam * ip, ULONG flags,Animatable *next);

		// methods inherited from ReferenceMaker
						// used to receive and respond to all messages from its dependents
		RefResult		NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID, RefMessage message);
						// return number of references made
		int				NumRefs();
						// set 'i-th' reference handle
		RefTargetHandle	GetReference(int i);
						// get 'i-th' reference handle
		void			SetReference(int i, RefTargetHandle rtarg);

		// methods inherited from BaseObject
						// name which appears in modifier stack
		TCHAR			* GetObjectName() { return GetString(IDS_WSMOD_CLASS_NAME); }
						// does modifier change topology? ( needed as default is TRUE )
		BOOL			ChangeTopology() { return FALSE; }

		// methods inherited from Modifier
						// return "general deformable object" type for the modifier to know how to modify
		Class_ID		InputType() { return defObjectClassID; }
						// return channels the modifier needs to perform its modification
		ChannelMask		ChannelsUsed()  {return OBJ_CHANNELS;}//		
						// return channels the modifier actually changes
		ChannelMask		ChannelsChanged() {return SELECT_CHANNEL|SUBSEL_TYPE_CHANNEL|GEOM_CHANNEL;}

						// responsible for altering the object and updating validity interval
		void			ModifyObject(TimeValue t, ModContext &mc, ObjectState *os, INode *node);
						// is there a dependency on topology when modifying?
		BOOL			DependOnTopology(ModContext &mc) { return TRUE; }
						// modifier save
		IOResult		Save( ISave * isave );
						// modifier load
		IOResult		Load( ILoad * iload );
						// modifier clone
		RefTargetHandle	Clone(RemapDir& remap = NoRemap());

		// ** Skin
						// handle possible scene import
		void			ImportScene(INode * node, Mesh & mesh);
						// force immediate redraw of all views
		void			ForceRedraw();
						// add bone/s
		void			AddBones(INode ** boneNodes, int numBones);
		int				AddBone(INode * boneNode);
						// del bone/s
		void			DelBones(INode ** boneNodeList, int numBones);
		int				DelBone(INode * boneNode);
						// selected bone
		void			SetSelectBone(INode * boneNode);
		INode			* GetSelectBone(void);
						// perform sub selection hit test on cached mesh
		int				DoSubHitTest(HWND hwnd, SubObjHitList & hitList, int & hits, int bRect, IPoint2 * points);
						// perform actual vertex hit test on cached mesh rather than MAXs
		int				DoMeshVertexHitTest(ViewExp *vp, GraphicsWindow *gw, HitRegion *hr, DWORD flags, SubObjHitList& hitList);
						// detect and update any changes in the mesh
		void			DetectMeshEdits(ObjectState * objState, Mesh & meshCur, Mesh & meshLast);


		SkinBoneRefManager		* boneRefs;			// bone reference manager
		SkinVertAssignManager	* vertexAssigns;	// vertex assign manager

		INode			* selectBone;				// selected bone node
		INode			* nodeWSMMod;				// the node this modifier affects
		int				bUserPick;					// user in pick mode
		int				bUserAssign;				// user in assign vertices mode
		int				bAutoAssignOverwrite;		// auto assign overwrite flag
		int				bDispBoneRelease;			// display release bone flag
		Mesh			meshCache;					// cached mesh after modification
		Mesh			meshNoModLast;				// cached non-modified mesh for detecting mesh edits
		RefTargetHandle fixedRefs[NOOF_FIXED_REFS];	// fixed references, back compatability
};


// --------------------------------------------------------------------------------
// Modifier Deform Class
// --------------------------------------------------------------------------------
class Deform : public Deformer
{
	public:
						// called on every point in the mesh
		Point3			Map(int i, Point3 p);
		SkinWSMMod		*skinMod;
};


// --------------------------------------------------------------------------------
// Interface::DoHitByNameDialog() Callback Class
// --------------------------------------------------------------------------------
class HitByName : public HitByNameDlgCallback
{
	public:
						// selection dialog
		TCHAR			*dialogTitle() { return __T("Select Bones"); }
		TCHAR			*buttonText() { return __T("Select"); }
						// even show hidden helper objects
		BOOL			showHiddenAndFrozen() { return TRUE; }
						// user node filter
		BOOL			useFilter() { return TRUE; }
		int				filter(INode *node);
						// user procedure rather than select nodes
		BOOL			useProc() { return TRUE; }
		void			proc(INodeTab &nodeTab);

		SkinWSMMod		*skinMod;					// modifier instance - access to all
		HWND			panHandle;					// panel window handle
		int				useFlag;					// what to do with selection after we've go it
};


// --------------------------------------------------------------------------------
// Interface::SetPickMode() Callback Class
// --------------------------------------------------------------------------------
class PickMode : public PickModeCallback
{
	public:
							// whenever pick mode needs to hit test
		BOOL				HitTest(IObjParam *ip, HWND hWnd, ViewExp *vpt, IPoint2 m, int flags);
							// whenever user picks something
		BOOL				Pick(IObjParam *ip, ViewExp *vpt);
							// filter pick nodes
		PickNodeCallback	*GetFilter(void);

							// pre/post-processing
		void				EnterMode(IObjParam *ip);
		void				ExitMode(IObjParam *ip);

							// end pick mode on right click or escape
		BOOL				RightClick(IObjParam *ip, ViewExp *vpt) { return TRUE; }

		SkinWSMMod			*skinMod;				// modifier instance - access to all
		HWND				panHandle;				// panel window handle
};


// --------------------------------------------------------------------------------
// Interface::PickNode() Filter Node Class
// --------------------------------------------------------------------------------
class PickNodeFilter : public PickNodeCallback
{
	public:
							// filter out node
		BOOL				Filter(INode * node);
		IObjParam			*ip;						// MAX interface
		SkinWSMMod			*skinMod;					// modifier instance - access to all
};


// --------------------------------------------------------------------------------
// Our Command Mode Class
// --------------------------------------------------------------------------------
class CmdMode : public CommandMode
{
	public:
							// command mode class
		int					Class() { return PICK_COMMAND; }
							// command mode id - my unique id
		int					ID() { return CID_USER + 0xabcd; }

							// number of mouse clicks used by mouse callback proc
		MouseCallBack		*MouseProc(int *numPoints);
							// flag nodes that belong in the foreground plane
		ChangeForegroundCallback *ChangeFGProc() { return CHANGE_FG_SELECTED; }
							// flag if any need to change foreground mode
		BOOL				ChangeFG(CommandMode * oldMode) { return oldMode->ChangeFGProc() != CHANGE_FG_SELECTED; }

							// pre/post-processing
		void				EnterMode(void);
		void				ExitMode(void);

		SkinWSMMod			*skinMod;			// modifier instance - access to all
		HWND				panHandle;			// panel window handle
};


// --------------------------------------------------------------------------------
// Command Mode Mouse Callback Class
// --------------------------------------------------------------------------------
class CmdModeMouse : public MouseCallBack
{
	private:
		HCURSOR				hCurArrow;				// mouse cursor handles
		HCURSOR				hCurVert;
		HCURSOR				hCurVertAdd;
		HCURSOR				hCurVertSub;
		HCURSOR				hCurAdd;
		HCURSOR				hCurSub;

	public:
							// mouse event procedure
		int					proc( HWND hwnd, int msg, int point, int flags, IPoint2 m );
							// xor rectangle into window
		void				DrawXorRect(HWND hwnd, IPoint2 & p1, IPoint2 & p2);


		SkinWSMMod			*skinMod;				// modifier instance - access to all
		HWND				panHandle;				// panel window handle
		IPoint2				userPoints[2];			// user mouse points
		int					bRectRegion;			// rectangular / point region
};


// --------------------------------------------------------------------------------
// Static Class Instances
// --------------------------------------------------------------------------------

// instance of modify object deformer
static Deform	theDeformer;

// instance of select helper objects
static HitByName	theHitByName;

// instance of pick mode and pick node filter
static PickMode			thePickMode;
static PickNodeFilter	thePickNodeFilter;

// instance of vertex assignment command mode
static CmdMode		theCommandMode;
static CmdModeMouse	theCommandModeMouse;


// --------------------------------------------------------------------------------
// SkinWSMObj Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::SkinWSMObj
   Purpose : Constructor
   Parameters :
   Returns : 
   Info : 
*/

SkinWSMObj::SkinWSMObj()
{
	pblock = NULL;						// zero parameter block, not used
	ip = NULL;							// make sure interface invalidated
	hPanel = NULL;						// zero panel
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::~SkinWSMObj
   Purpose : Destructor
   Parameters :
   Returns : 
   Info : 
*/

SkinWSMObj::~SkinWSMObj()
{
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::DeleteThis
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMObj::DeleteThis()
{
	DPrintf("Skin WSM Object deleted");
	delete this;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::BeginEditParams
   Purpose : Initialise UI editing
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMObj::BeginEditParams(IObjParam * ip, ULONG flags,Animatable *prev)
{
	// since we subclass off SimpleWSMObject we call its version
	SimpleWSMObject::BeginEditParams(ip, flags, prev);

	// validate interface for the duration of editing
	this->ip = ip;

	// add info panel
	hPanel = ip->AddRollupPage(hInstance, MAKEINTRESOURCE(IDD_OBJECT_PANEL), (DLGPROC)SkinObjPanelProc, _T("Object Info"), (LPARAM)ip, 0);

	DPrintf("WSMObj - Begin Edit Params");
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::EndEditParams
   Purpose : UnInitialise UI editing
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMObj::EndEditParams(IObjParam * ip, ULONG flags,Animatable *next)
{
	// delete info panel
	if (hPanel && ip)
		ip->DeleteRollupPage(hPanel);
	hPanel = NULL;

	// since we subclass off SimpleWSMObject we call its version
	SimpleWSMObject::EndEditParams(ip, flags, next);

	// invalidate interface
	this->ip = NULL;

	DPrintf("WSMObj - End Edit Params");
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::GetCreateMouseCallback
   Purpose : Return instance of object creation callback
   Parameters :
   Returns : 
   Info : 
*/

// instance of object creation callback
static SkinWSMObjCreate theSkinObjCreate;

CreateMouseCallBack * SkinWSMObj::GetCreateMouseCallBack()
{
	theSkinObjCreate.skinObj = this;
	return &theSkinObjCreate;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::BuildMesh
   Purpose : Builds the mesh representation for the object
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMObj::BuildMesh(TimeValue t)
{
	float size;

	// set object verts
	mesh.setNumVerts(4);
	size = 10;
	mesh.setVert( 0, Point3(0.0f, 0.0f, 0.0f) );
	mesh.setVert( 1, Point3(0.0f, size, 0.0f) );
	mesh.setVert( 2, Point3(size, size, 0.0f) );
	mesh.setVert( 3, Point3(size, 0.0f, 0.0f) );

	// set object polys
	mesh.setNumFaces(2);
	mesh.faces[0].setVerts(0, 3, 1);			// poly0
	mesh.faces[0].setSmGroup(0);
	mesh.faces[0].setEdgeVisFlags(1, 1, 1);
	mesh.faces[1].setVerts(1, 3, 2);			// poly1
	mesh.faces[1].setSmGroup(0);
	mesh.faces[1].setEdgeVisFlags(1, 1, 1);

	// force draw
	mesh.InvalidateGeomCache();
	mesh.InvalidateTopologyCache();
};


/* --------------------------------------------------------------------------------
   Function : SkinWSMObj::CreateWSMMod
   Purpose : Creates instance of space warp modifier on node binding
   Parameters : WSM Object Node
   Returns : modifier
   Info : 
*/

Modifier * SkinWSMObj::CreateWSMMod(INode * node)
{
	DPrintf("Skin bound from node: %s", node->GetName());
	return new SkinWSMMod(node, this );
}


/* --------------------------------------------------------------------------------
   Function : SkinObjPanelProc
   Purpose : Skin object panel dialog procedure
   Parameters :
   Returns : 
   Info : 
*/

BOOL CALLBACK SkinObjPanelProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	IObjParam			*ip;
	HBITMAP				hBMP, hMSK;
	static ICustImage	* ccImage = NULL;
	static HIMAGELIST	hImageList = NULL;

	// retrieve MAX interface
	ip = (IObjParam *)GetWindowLong(hWnd, GWL_USERDATA);

	// handle message
	switch (msg)
	{
		case WM_INITDIALOG:

			// set max interface ptr
			SetWindowLong(hWnd, GWL_USERDATA, lParam);

			// load custom images - 84x19 pixels
			ccImage = GetICustImage(GetDlgItem(hWnd, IDC_OBJECT_IMAGE));
			hImageList = ImageList_Create(86, 21, TRUE, 2, 2);
			// load images
			hBMP = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BITMAP1));
			hMSK = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BITMAP2));
			// add images to list
			ImageList_Add(hImageList, hBMP, hMSK);
			// delete images
			DeleteObject(hBMP);
			DeleteObject(hMSK);
			// set imagelist
			ccImage->SetImage(hImageList, 0, 86, 21);
			break;

		case WM_DESTROY:

			// remove custom image
			if (ccImage)
				ReleaseICustImage(ccImage);
			ccImage = NULL;
			if (hImageList)
				ImageList_Destroy(hImageList);
			hImageList = NULL;
			break;

		default:
			return FALSE;
	}
	return TRUE;
}


// --------------------------------------------------------------------------------
// SkinWSMObjCreate Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : SkinWSMObjCreate::proc
   Purpose : Handles the object construction from the user
   Parameters :
   Returns : finished, abort, carry on
   Info : 
*/

int	SkinWSMObjCreate::proc(ViewExp *vpt, int msg, int point, int flags, IPoint2 m, Matrix3& mat)
{
	Point3 p;

	switch (msg )
	{
		case MOUSE_POINT:
		case MOUSE_MOVE:

			p = vpt->GetPointOnCP(m);
			mat.SetTrans(p);
			skinObj->NotifyDependents(FOREVER, GEOM_CHANNEL, REFMSG_CHANGE);
			if (point == 1 && msg == MOUSE_POINT)
				return CREATE_STOP;
			break;

		case MOUSE_ABORT:
			return CREATE_ABORT;
	}
	return CREATE_CONTINUE;
}


// --------------------------------------------------------------------------------
// SkinWSMMod Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::SkinWSMMod
   Purpose : Constructor
   Parameters :
   Returns : 
   Info : 
*/

SkinWSMMod::SkinWSMMod()
{
	// allocate skinning classes
	boneRefs = new SkinBoneRefManager();
	boneRefs->Init();
	vertexAssigns = new SkinVertAssignManager();
	vertexAssigns->Init(boneRefs);

	// null fixed references
	for (int i=0; i<NOOF_FIXED_REFS; i++)
		fixedRefs[i] = NULL;

	// since we subclass off SimpleWSMMod, deal with vars
	pblock = NULL;										// zero parameter block
	obRef = NULL;										// zero WSMObject reference
	nodeRef = NULL;										// zero node reference (setup internally)

	// null current bone selection
	SetSelectBone(NULL);

	// zero user modes
	bUserPick = 0;					// user not picking selection
	bUserAssign = 0;				// user not assigning vertices

	// influence flags
	bAutoAssignOverwrite = 0;		// no overwrite when auto assigning
	bDispBoneRelease = 0;			// no display bone release

	// null bound node
	nodeWSMMod = NULL;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::SkinWSMMod
   Purpose : Constructor
   Parameters : Node the Modifier is to be bound to, skin WSM Object
   Returns : 
   Info : 
*/

SkinWSMMod::SkinWSMMod(INode *node, SkinWSMObj * skinObj)
{
	// allocate skinning classes
	boneRefs = new SkinBoneRefManager();
	boneRefs->Init();
	vertexAssigns = new SkinVertAssignManager();
	vertexAssigns->Init(boneRefs);

	// null fixed references
	for (int i=0; i<NOOF_FIXED_REFS; i++)
		fixedRefs[i] = NULL;

	// since we subclass off SimpleWSMMod, deal with vars
	pblock = NULL;										// zero parameter block
	obRef = NULL;										// zero WSMObject reference
   	MakeRefByID(FOREVER, SIMPWSMMOD_NODEREF, node);		// make the reference to the space warp node

	DeleteReference(SIMPWSMMOD_NODEREF);

	// null current bone selection
	SetSelectBone(NULL);

	// zero user modes
	bUserPick = 0;					// user not picking selection
	bUserAssign = 0;				// user not assigning vertices

	// influence flags
	bAutoAssignOverwrite = 0;		// no overwrite when auto assigning
	bDispBoneRelease = 0;			// no display bone release

	// null bound node
	nodeWSMMod = NULL;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::~SkinWSMMod
   Purpose : Destructor
   Parameters :
   Returns : 
   Info : 
*/

SkinWSMMod::~SkinWSMMod()
{
	// release skinning classes
	if (vertexAssigns)
	{
		vertexAssigns->UnInit();
		delete vertexAssigns;
	}
	vertexAssigns = NULL;
	if (boneRefs)
	{
		boneRefs->UnInit();
		delete boneRefs;
	}
	boneRefs = NULL;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::DeleteThis
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMMod::DeleteThis()
{
	DPrintf("Skin WSM Modifier deleted");
	delete this;
}
		

/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::BeginEditParams
   Purpose : Initialise UI editing
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMMod::BeginEditParams(IObjParam * ip, ULONG flags,Animatable *prev)
{
	// since we subclass off SimpleWSMMod we call its version
	SimpleWSMMod::BeginEditParams(ip, flags, prev);

	// validate interface for the duration of editing
	this->ip = ip;

	// clear any user edit modes
	bUserPick = 0;
	bUserAssign = 0;

	// add info panel
	hPanel = ip->AddRollupPage(hInstance, MAKEINTRESOURCE(IDD_MODIFIER_PANEL), (DLGPROC)SkinModPanelProc, _T("Object Info"), (LPARAM)this, 0);

	DPrintf("WSMMod - Begin Edit Params");
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::EndEditParams
   Purpose : UnInitialise UI editing
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMMod::EndEditParams(IObjParam * ip, ULONG flags,Animatable *next)
{
	// clear any outstanding pick modes
	ip->ClearPickMode();

	// clear any outstanding command modes
	ip->SetStdCommandMode(CID_OBJMOVE);
	ip->DeleteMode(&theCommandMode);

	// force complete scene redraw - not sure if this is agood idea!
	ForceRedraw();

	// delete info panel
	if (hPanel && ip)
		ip->DeleteRollupPage(hPanel);
	hPanel = NULL;

	// since we subclass off SimpleWSMMod we call its version
	SimpleWSMMod::EndEditParams(ip, flags, next);

	// invalidate interface
	this->ip = NULL;

	DPrintf("WSMMod - End Edit Params");
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::NotifyRefChanged
   Purpose : Handle reference notification messages
   Parameters :
   Returns : 
   Info : 
*/

RefResult SkinWSMMod::NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID, RefMessage message)
{
	int idxBone;

	// is this reference target one of our bones?
	if ((idxBone = boneRefs->GetIndex((INode *)hTarget)) != -1)
	{
		//	DPrintf("Reference notification for bone: %s", ((INode *)hTarget)->GetName());

		// handle notification message
		switch (message)
		{
			case REFMSG_TARGET_DELETED:
				DPrintf("Bone %s deleted in NotifyRefChanged()", (hTarget)?((INode *)hTarget)->GetName():"NULL");
				DelBone((INode *)hTarget);
				break;

			//	case REFMSG_CHANGE:
			//		DPrintf("\t- Change");
			//		break;

			//	case REFMSG_FLAGDEPENDENTS:
			//		DPrintf("\t- Flag dependants");
			//		break;

			//	default:
			//		DPrintf("\t- Unknown 0x%x", message);
			//		break;
		}

		return REF_SUCCEED;
	}

	// since we subclass off SimpleWSMMod we call its version
	return SimpleWSMMod::NotifyRefChanged(changeInt, hTarget, partID, message);
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::NumRefs
   Purpose : Return number fo references in use
   Parameters :
   Returns : Number of references
   Info : Assumes each bone held is registered as a reference
*/

int	SkinWSMMod::NumRefs()
{
	if (boneRefs)
		return SimpleWSMMod::NumRefs() + NOOF_FIXED_REFS + boneRefs->Count();
	else
		return SimpleWSMMod::NumRefs() + NOOF_FIXED_REFS;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::GetReference
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

RefTargetHandle	SkinWSMMod::GetReference(int i)
{
 	int			numRefs, idxBone;
	SkinBoneRef	* boneRef;

	DPrintf("  GetReference() called");
	// NumRefs should return 3 as the SimpleWSMMod class uses the following internal references:
	//	SIMPWSMMOD_OBREF		0
	//	SIMPWSMMOD_NODEREF		1
	//	SIMPWSMMOD_PBLOCKREF	2
	// inherited refs
	numRefs = SimpleWSMMod::NumRefs();
	if (i<numRefs )
		return SimpleWSMMod::GetReference(i);
	else if (i<(numRefs+NOOF_FIXED_REFS))
		return fixedRefs[i-numRefs];
	else
	{
		// its one of ours so hopefully it must be a bone
		idxBone = i-NOOF_FIXED_REFS-numRefs;
		if (boneRefs && (boneRef = boneRefs->GetBone(idxBone)))
			return (RefTargetHandle)boneRef->node;
	}
	// unknown ref index
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::SetReference
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMMod::SetReference(int i, RefTargetHandle rtarg)
{
	int			numRefs, idxBone;
	INode		* node;
	SkinBoneRef	* boneRef;

	DPrintf("  SetReference() called");
	// NumRefs should return 3 as the SimpleWSMMod class uses the following internal references:
	//	SIMPWSMMOD_OBREF		0
	//	SIMPWSMMOD_NODEREF		1
	//	SIMPWSMMOD_PBLOCKREF	2
	numRefs = SimpleWSMMod::NumRefs();
	// since we subclass off SimpleWSMMod we call its version
	// this belongs to SimpleWSMMod, so pass it down
	if (i<numRefs)
	{
		SimpleWSMMod::SetReference(i, rtarg);
		DPrintf("\t - internal");
	}
	else if (i<(numRefs+NOOF_FIXED_REFS))
	{
		fixedRefs[i-numRefs] = rtarg;
		DPrintf("\t - fixed reference");
	}
	else
	{
		// its one of ours so hopefully it must be a bone
		idxBone = i-NOOF_FIXED_REFS-numRefs;
		if (boneRefs && (boneRef = boneRefs->GetBone(idxBone)))
		{
			// safe to cast target as a bone
			node = (INode *)rtarg;
			boneRef->node = node;
			if (node)
				boneRef->refMat = node->GetNodeTM(0);
			else
				boneRef->refMat.IdentityMatrix();
			DPrintf("\t - bone %s", (node) ? node->GetName():"NULL");
		}
	}
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::GetDeformer
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

Deformer & SkinWSMMod::GetDeformer(TimeValue t, ModContext &mc, Matrix3& mat, Matrix3& invmat)
{
	SkinBoneRef	* boneRef;
	Matrix3		curMat;

	// DPrintf("Deformer requested");

	// get all transform matrices for this anim time
	for (boneRef = boneRefs->GetFirst(); boneRef; boneRef = boneRef->GetNext())
	{
		if (! boneRef->node)
			curMat.IdentityMatrix();
		else
			curMat = boneRef->node->GetNodeTM(t);
		boneRef->transMat = curMat;
	}

	theDeformer.skinMod = this;			// allow access to all
	return theDeformer;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::ModifyObject
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

void SkinWSMMod::ModifyObject(TimeValue t, ModContext &mc, ObjectState *os, INode *node)
{
	TriObject		* triObj;
	int				loop, idxSelBone;
	SkinVertAssign	* vertAss;
	SkinData		* exportData;


	//	DPrintf("ModifyObject called");

	//
	// Handle Edit Mesh Changes
	//

	if (! os->obj->IsSubClassOf(triObjectClassID))
		return;
	if (! (triObj = (TriObject *)os->obj) )
		return;
	Mesh & meshNoMod = triObj->mesh;

	// detect and apply changes
	DetectMeshEdits(os, meshNoMod, meshNoModLast);
	// save last for compare
	meshNoModLast = meshNoMod;


	// ** Modification

	// since we subclass off SimpleWSMMod we call its version
	SimpleWSMMod::ModifyObject(t, mc, os, node);

	// load mesh from current object state in pipeline
	if (! os->obj->IsSubClassOf(triObjectClassID))
		return;
	if (! (triObj = (TriObject *)os->obj) )
		return;
	Mesh & mesh = triObj->mesh;

	// handle possible import
	ImportScene(node, mesh);


	// ** Vertex Selection

	// initial vertex assignment
	if (!vertexAssigns->IsValid(0) || vertexAssigns->numAssigns != mesh.numVerts)
		vertexAssigns->CreateList(mesh.numVerts);

	// init mesh for vertex selection
	mesh.selLevel = MESH_VERTEX;
	mesh.vertSel.SetSize(mesh.numVerts);
	mesh.SetDispFlag(DISP_VERTTICKS | DISP_SELVERTS);

	// get bone selection index
	idxSelBone = boneRefs->GetIndex(GetSelectBone());

	// select all vertices which are attached to selected bone
	for(loop = 0; loop < mesh.numVerts; loop++)
	{
		if (! (vertAss = vertexAssigns->GetAssign(loop)) )
			continue;
		// this vertex attached to selected bone?
		if (GetSelectBone() && idxSelBone == vertAss->idxBoneRef)
			mesh.vertSel.Set(loop);
		else
			mesh.vertSel.Clear(loop);

	}


	// ** Saves

	// save the node, the modifier is affecting
	nodeWSMMod = node;
	// cache mesh for hit test
	meshCache = mesh;


	// ** Hang Skin Data Off Mod Context For Export Exposure

	exportData = (SkinData *)mc.localData;
	if (! exportData)
		mc.localData = exportData = new SkinData();
	if (exportData)
	{
		if (! vertexAssigns)
			exportData->vertexAssigns = NULL;
		else
			exportData->vertexAssigns = vertexAssigns;
		if (! boneRefs)
			exportData->boneRefs = NULL;
		else
			exportData->boneRefs = boneRefs;
		exportData->boneSelectIndex = boneRefs->GetIndex(GetSelectBone());
	}


	// ** Update Modified Channels Validity Interval Caches

	Interval valid = GetValidity(t);
	// geometry
	triObj->UpdateValidity(GEOM_CHAN_NUM, valid);
	// selection channels
	triObj->UpdateValidity(SELECT_CHAN_NUM, valid);
	triObj->UpdateValidity(SUBSEL_TYPE_CHAN_NUM, valid);
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::DetectMeshEdits
   Purpose : Detect any changes in editable mesh
   Parameters : node, current object mesh
   Returns : 
   Info : 
*/

void SkinWSMMod::DetectMeshEdits(ObjectState * objState, Mesh & meshCur, Mesh & meshLast)
{
	SkinVertAssign	* vertAss;
	SkinBoneRef		* boneRef;
	int				i, noofDifs;
	Point3			meshAssign;
	Matrix3			matTM;
	AffineParts		affParts;


	// not interested in too drastict mesh modifications - yet
	if (!vertexAssigns->IsValid(0) || vertexAssigns->numAssigns != meshCur.numVerts)
		return;
	if (meshCur.numVerts != meshLast.numVerts)
		return;

	return;

	// check for any change in meshes
	for (i = 0, noofDifs = 0; i < meshCur.numVerts; i++)
	{
		if ((meshCur.verts[i].x != meshLast.verts[i].x) || (meshCur.verts[i].y != meshLast.verts[i].y) || (meshCur.verts[i].z != meshLast.verts[i].z))
		{
			// detected mesh vertex edits
			if (! noofDifs)
				DPrintf("Detected Mesh Vertex Edits");
			noofDifs++;

			// reassign bone
			if (! (vertAss = vertexAssigns->GetAssign(i)) )
				continue;
			if (! (boneRef = boneRefs->GetBone(vertAss->idxBoneRef)) )
				continue;
			if (! (boneRef->node) )
				continue;

			// only reassign vertex to bone if scale at identity
			matTM = boneRef->node->GetNodeTM(0);
			decomp_affine(matTM, &affParts);
			if ((affParts.k.x > 0.999f && affParts.k.x < 1.001f) && (affParts.k.y > 0.999f && affParts.k.y < 1.001f) && (affParts.k.z > 0.999f && affParts.k.z < 1.001f))
			{
				boneRef->refMat = matTM;
				vertexAssigns->Add(meshCur, i, vertAss->idxBoneRef);

				DPrintf("\t - vertex %d reassigned", i);
			}
		}
	}
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::ImportScene
   Purpose : Import scene from node
   Parameters : node, current object mesh
   Returns : 
   Info : 
*/

void SkinWSMMod::ImportScene(INode * node, Mesh & mesh)
{
	AppDataChunk		* dataChunk, * boneChunk;
	int					numBones, i, numSkinVerts, j;
	INode				** boneNodes;
	TCHAR				* boneName;
	SKIN_DATA_VERTEX	* skinVerts;
	SkinVertAssign		* vertAss;


	// as import occurred?
	if (! (dataChunk = SKINREG_GetSkinData(node, (DWORD)ADID_SKIN_REGISTER)) )
		return;

	DPrintf("Import detected");

	// interpret data chunk from appdata
	numBones = dataChunk->length / sizeof(INode *);
	boneNodes = (INode **)dataChunk->data;

	DPrintf("\t- %d bones found", numBones);

	AddBones(boneNodes, numBones);					// add all imported bones into scene
	SetSelectBone(NULL);							// set null selection
	vertexAssigns->CreateList(mesh.numVerts);		// create initial assignment list

	// set bone assignments from imported nodes
	for (i = 0; i < numBones; i++)
	{
		if (boneChunk = SKINREG_GetSkinData(boneNodes[i], (DWORD)ADID_SKIN_DATA))
		{
			if (boneName = (boneNodes[i]) ? boneNodes[i]->GetName() : NULL)
			{
				// interpret data chunk from appdata
				numSkinVerts = boneChunk->length / sizeof(SKIN_DATA_VERTEX);
				skinVerts = (SKIN_DATA_VERTEX *)boneChunk->data;

				DPrintf("\t- %s with %d assignment%s", boneName, numSkinVerts, (numSkinVerts==1) ? "":"s");

				// import all bones assignments
				for (j = 0; j < numSkinVerts; j++)
					if (vertAss = vertexAssigns->GetAssign(skinVerts[j].idxVert))
						vertAss->Set(i, skinVerts[j].boneVec);

			}

			// remove bone node appdata - acknowledge data
			SKINREG_RemoveSkinData(boneNodes[i], (DWORD)ADID_SKIN_DATA);
		}
	}

	// remove node appdata - acknowledge data
	SKINREG_RemoveSkinData(node, (DWORD)ADID_SKIN_REGISTER);

	// force complete scene redraw
	ForceRedraw();

	DPrintf("Import Finished");
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::GetValidity
   Purpose : 
   Parameters :
   Returns : 
   Info : 
*/

Interval SkinWSMMod::GetValidity(TimeValue t)
{
	SkinBoneRef	* boneRef;
	Interval	valid = FOREVER;		// initial valid forever

	// since we subclass off SimpleWSMMod we call its version - always FOREVER
	valid = SimpleWSMMod::GetValidity(t);

	// intersect with all bones transforms
	for (boneRef = boneRefs->GetFirst(); boneRef; boneRef = boneRef->GetNext())
		if (boneRef->node)
			boneRef->node->GetNodeTM(t,&valid);

	// return intersected validity
	return valid;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::Save
   Purpose : Modifier save
   Parameters :
   Returns : 
   Info : 
*/

IOResult SkinWSMMod::Save(ISave *isave)
{
	IOResult	res = IO_OK;		// default all okay
	ULONG		writes;
	int			version, boneSel;

	// since we subclass off SimpleWSMMod we call its version
	if (((res = SimpleWSMMod::Save(isave)) != IO_OK))
	{
		DPrintf("Inherited save method caused an error");
		return res;
	}
	DPrintf("Saved: inherited");

	// save all skinning data
	isave->BeginChunk(SKINMOD_DATA_CHUNK);

	// save current version level
	version = VERSION_CURRENT;
	if (((res = isave->Write(&version, sizeof(version), &writes)) != IO_OK))
	{
		DPrintf("Save Error: skin version");
		isave->EndChunk();
		return res;
	}
	DPrintf("Saved: skin version");

	// save all bone references
	if (boneRefs)
	{
		// save all bones
		if (((res = boneRefs->Save(isave)) != IO_OK))
		{
			DPrintf("Save Error: bone refs");
			isave->EndChunk();
			return res;
		}
		DPrintf("Saved: bone refs");
	}
	else
	{
		// zero bone count
		boneSel = 0;
		if (((res = isave->Write(&boneSel, sizeof(boneSel), &writes)) != IO_OK))
		{
			DPrintf("Save Error: zero bone count");
			isave->EndChunk();
			return res;
		}
		DPrintf("Saved: no bone refs - zero bone count");
	}

	// save bone selection
	if (boneRefs)
	{
		boneSel = boneRefs->GetIndex(GetSelectBone());
		if (((res = isave->Write(&boneSel, sizeof(boneSel), &writes)) != IO_OK))
		{
			DPrintf("Save Error: bone selection");
			isave->EndChunk();
			return res;
		}
		DPrintf("Saved: selected bone %d",boneSel );
	}

	// save vertex assignments
	if (vertexAssigns)
	{
		if (((res = vertexAssigns->Save(isave)) != IO_OK))
		{
			DPrintf("Save Error: vertex assigns");
			isave->EndChunk();
			return res;
		}
		DPrintf("Saved: vertex assigns");
	}
	else
	{
		// zero assignment count
		boneSel = 0;
		if (((res = isave->Write(&boneSel, sizeof(boneSel), &writes)) != IO_OK))
		{
			DPrintf("Save Error: zero vertex assignment count");
			isave->EndChunk();
			return res;
		}
		DPrintf("Saved Error: non assigns - zero vertex assignment count");
	}

	// end my skinng chunk
	isave->EndChunk();

	DPrintf("Save %s for modifier %s", (res==IO_OK) ? "ok" : "error", (nodeRef) ? nodeRef->GetName() : "NULL");

	// return io result
	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::Load
   Purpose : Modifier load
   Parameters :
   Returns : 
   Info : 
*/

IOResult SkinWSMMod::Load(ILoad *iload)
{
	IOResult	res = IO_OK;			// default all okay
	ULONG		reads;
	int			version, boneSel;

	// since we subclass off SimpleWSMMod we call its version
	if (((res = SimpleWSMMod::Load(iload)) != IO_OK))
	{
		DPrintf("Inherited load method caused an error");
		return res;
	}
	DPrintf("Loaded: inherited");

	while (IO_OK==(res=iload->OpenChunk()))
	{
		switch (iload->CurChunkID())
		{
			case SKINMOD_DATA_CHUNK:
				{
					// load current version level
					if (((res = iload->Read(&version, sizeof(version), &reads)) != IO_OK))
					{
						DPrintf("Load Error: skin version");
						return res;
					}
					DPrintf("Loaded: skin version");

					// load all bones
					if (boneRefs)
					{
						// load all bone references
						if (((res = boneRefs->Load(iload, version)) != IO_OK))
						{
							DPrintf("Load Error: bone refs");
							return res;
						}
						DPrintf("Loaded: bone refs");

						// load and set bone selection
						if (((res = iload->Read(&boneSel, sizeof(boneSel), &reads)) != IO_OK))
						{
							DPrintf("Load Error: bone selection");
							return res;
						}
						DPrintf("Loaded: bone refs");
					}

					// load all vertex assignments
					if (vertexAssigns)
					{
						if (((res = vertexAssigns->Load(iload, version)) != IO_OK))
						{
							DPrintf("Load Error: vertex assigns");
							return res;
						}
						DPrintf("Loaded: vertex assignments");
					}
				}
				break;
		}

		// acknowledge chunk
		iload->CloseChunk();
		if (res!=IO_OK)
			return res;
	}

	DPrintf("Load %s for modifier %s", (res!=IO_ERROR) ? "ok" : "error", (nodeRef) ? nodeRef->GetName() : "NULL");
	// return io result
	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::Clone
   Purpose : Modifier clone
   Parameters :
   Returns : 
   Info : Returns null
*/

RefTargetHandle SkinWSMMod::Clone(RemapDir& remap)
{
	DPrintf("Skin null clone");
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::ForceRedraw
   Purpose : Force immediate redraw of all views
   Parameters :
   Returns : 
   Info : Only available if editing, therefore need to check if MAX interface valid
*/

void SkinWSMMod::ForceRedraw( void )
{
	if (ip)
	{
		// these two functions cause an immediate view change
		NotifyDependents(FOREVER, ChannelsChanged(), REFMSG_CHANGE);
		// usually the change wouldn't occur until after the command mode was released
		ip->RedrawViews(ip->GetTime());
	}
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::AddBones
   Purpose : Add bones from node list
   Parameters : Bone node list ptr, number of bones to add
   Returns : 
   Info : 
*/

// Add Bone Nodes
void SkinWSMMod::AddBones(INode ** boneNodes, int numBones)
{
	DPrintf("Trying to add %d bones", numBones);
	for (int i=0; i<numBones; i++)
		AddBone(boneNodes[i]);
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::AddBone
   Purpose : Add single bone node
   Parameters : Bone node ptr
   Returns : 1/0
   Info : also adds reference
*/

// Add Bone Node to Bone List
int SkinWSMMod::AddBone(INode * boneNode)
{
	int idxRef;

	// does this bone already exist?
	if (boneRefs->IsTarget(boneNode))
		return 0;					// abort

	// try and add bone to list
	if( !boneRefs->AddNode(boneNode))
		return 0;					// abort
	DPrintf("Bone added");

	// add max bone reference
	if ((idxRef = NumRefs()-1) < 0)
		return 0;					// abort
	MakeRefByID(FOREVER, idxRef, boneNode);
	DPrintf("Reference %d for bone %s added", idxRef, boneNode->GetName());

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::DelBones
   Purpose : Delete bones
   Parameters : Bone node list ptr, number of bones to add
   Returns : 
   Info :
*/

void SkinWSMMod::DelBones(INode ** boneNodeList, int numBones)
{
	DPrintf("Trying to delete %d bones", numBones);
	for (int i=0; i<numBones; i++)
		DelBone(boneNodeList[i]);
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::DelBone
   Purpose : Delete bone
   Parameters : Bone node ptr
   Returns : 1/0
   Info : also deletes reference
*/

// Del Bone Node from Bone List
int SkinWSMMod::DelBone(INode * boneNode)
{
	int idxBone,idxRef;

	// can only delete if it exists?
	if (!boneRefs->IsTarget(boneNode))
		return 0;				// doesn't exist

	// get current bone index
	if ((idxBone = boneRefs->GetIndex(boneNode)) == -1)
		return 0;				// abort

	// delete max bone reference
	if ((idxRef = SimpleWSMMod::NumRefs() + NOOF_FIXED_REFS + idxBone) < NumRefs())
	{
		DeleteReference(idxRef);
		DPrintf("Reference %d for bone %s deleted", idxRef, boneNode->GetName());
	}

	// delete bone node from bone list
	if (!boneRefs->DelBoneIndex(idxBone))
		return 0;				// abort
	DPrintf("Bone deleted");

	// need to remap all assigned vertices which used this bone
	vertexAssigns->Remap(idxBone);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::SetSelectBone
   Purpose : Set current bone selection
   Parameters : Bone node
   Returns : 
   Info : 
*/

void SkinWSMMod::SetSelectBone(INode * boneNode)
{
	selectBone = boneNode;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::GetSelectBone
   Purpose : Get current bone selection
   Parameters :
   Returns : Currently selected bone node
   Info : 
*/

INode * SkinWSMMod::GetSelectBone(void)
{
	if (boneRefs->GetIndex(selectBone) != -1)
		return selectBone;
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::DoSubHitTest
   Purpose : Perform sub object hit test on cached mesh
   Parameters : viewport handle, hitlist, number of hits, rect or point, point buffer
   Returns : 1/0 - hitlist and hits filled
   Info : 
*/

int	SkinWSMMod::DoSubHitTest(HWND hwnd, SubObjHitList & hitList, int & hits, int bRect, IPoint2 * points)
{
	ViewExp			* vPort;
	GraphicsWindow	* gfxWin;
	HitRegion		hitRegion;
	IPoint2			pts[2];
	int				saveLimits, bHit;
	Matrix3			mat(1);
	MeshSubHitRec	* hit;

	hits = 0;							// zero hits
	if (!ip)
		return 0;						// need valid MAX interface

	// get viewport / graphics window
	if (! (vPort = ip->GetViewport(hwnd)) )
		return 0;
	if (! (gfxWin = vPort->getGW()) )
		return 0;

	// setup hitregion
	if (! bRect)
		MakeHitRegion(hitRegion, POINT_RGN, true, 4, points);
	else
	{
		// create rectangular hit test
		pts[0].x = __min(points[0].x, points[1].x);
		pts[0].y = __min(points[0].y, points[1].y);
		pts[1].x = __max(points[0].x, points[1].x);
		pts[1].y = __max(points[0].y, points[1].y);
		MakeHitRegion(hitRegion, RECT_RGN, true, 4, pts);
	}

	// setup graphics window
	gfxWin->setHitRegion(&hitRegion);
	gfxWin->setTransform(mat);
	gfxWin->setRndLimits(((saveLimits = gfxWin->getRndLimits()) | GW_PICK ) & ~GW_ILLUM);
	gfxWin->setRndLimits(gfxWin->getRndLimits() | GW_BACKCULL);
	gfxWin->clearHitCode();

	// and perform subobject hit test, looking at vertices

//#if MAX_RELEASE == 3000
//	bHit = meshCache.SubObjectHitTest(gfxWin, gfxWin->getMaterial(), &hitRegion, SUBHIT_VERTS | ( (! bRect) ? SUBHIT_ABORTONHIT:0 ), hitList);
//#else
	bHit = DoMeshVertexHitTest(vPort, gfxWin, &hitRegion, SUBHIT_VERTS | ( (! bRect) ? SUBHIT_ABORTONHIT:0 ), hitList);
//#endif

	// restore render limits and release view port
	gfxWin->setRndLimits(saveLimits);
	ip->ReleaseViewport(vPort);

	// count number of actual hits
	for (hit = hitList.First(); hit; hit = hit->Next())
		hits++;

	// return hit successful
	return bHit;
}


/* --------------------------------------------------------------------------------
   Function : SkinWSMMod::DoMeshVertexHitTest
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

int	SkinWSMMod::DoMeshVertexHitTest(ViewExp *vp, GraphicsWindow *gw, HitRegion *hr, DWORD flags, SubObjHitList& hitList)
{
	IPoint2			rawPoints[2];
	Point3			checkPoints[2], meshViewPoint;
	IPoint3			mesh2dIPoint;
	double			distSq, dLenX,dLenY,dLenSq, subHit_dist;
	int				i, bHit, subHit_index;
	Matrix3			aTM, coordSysTM;


	// avoid potential problem with mesh
	if (!vertexAssigns || vertexAssigns->numAssigns != meshCache.numVerts)
		return 0;

	// convert our points to view port contruction plane - consistent with mesh
	if (hr->type == POINT_RGN)
	{
		rawPoints[0].x = hr->pt.x;
		rawPoints[0].y = hr->pt.y;
		checkPoints[0] = vp->GetPointOnCP(rawPoints[0]);
		checkPoints[0] = vp->MapCPToWorld(checkPoints[0]);
	}
	else if (hr->type == RECT_RGN)
	{
		rawPoints[0].x = __min(hr->rect.left, hr->rect.right);
		rawPoints[0].y = __min(hr->rect.top, hr->rect.bottom);
		checkPoints[0] = vp->GetPointOnCP(rawPoints[0]);
		checkPoints[0] = vp->MapCPToWorld(checkPoints[0]);
		rawPoints[1].x = __max(hr->rect.left, hr->rect.right);
		rawPoints[1].y = __max(hr->rect.top, hr->rect.bottom);
		checkPoints[1] = vp->GetPointOnCP(rawPoints[1]);
		checkPoints[1] = vp->MapCPToWorld(checkPoints[1]);
	}
	else
		return 0;

	distSq = hr->epsilon*hr->epsilon;	// square distance crossing for speed 
	bHit = 0;							// zero hit test
	vp->GetAffineTM(aTM);
	aTM.SetTrans(Point3(0,0,0));
	coordSysTM = Inverse(aTM);
	// log all points
	if (hr->type == POINT_RGN)
	{
		// point regioning
		for (i = 0; i < meshCache.getNumVerts(); i++)
		{
			if (! (gw->wTransPoint(&meshCache.getVert(i), &mesh2dIPoint)) )
			{
				dLenX = rawPoints[0].x - mesh2dIPoint.x;
				dLenY = rawPoints[0].y - mesh2dIPoint.y;
				dLenSq = dLenX*dLenX + dLenY*dLenY;
				if ((dLenSq) < distSq)
				{
					// hit occurred
					if (! (flags & SUBHIT_ABORTONHIT))
						hitList.AddHit((DWORD)0, i);
					else
					{
						meshViewPoint = aTM * meshCache.getVert(i);
						if (!bHit || meshViewPoint.z < subHit_dist)
						{
							subHit_dist = meshViewPoint.z;
							subHit_index = i;
						}
					}
					// flag hit occurred
					bHit = 1;
				}
			}
		}
		// log closest hit
		if (bHit && (flags & SUBHIT_ABORTONHIT))
			hitList.AddHit((DWORD)subHit_dist, subHit_index);
	}
	else
	{
		// rectangle regioning
		for (i = 0; i < meshCache.getNumVerts(); i++)
		{
			if (! (gw->wTransPoint(&meshCache.getVert(i), &mesh2dIPoint)) )
			{
				if (mesh2dIPoint.x > rawPoints[0].x && mesh2dIPoint.y > rawPoints[0].y &&
					mesh2dIPoint.x < rawPoints[1].x && mesh2dIPoint.y < rawPoints[1].y)
				{
					bHit = 1;						// flag hit occurred
					hitList.AddHit((DWORD)0, i);
					if (flags & SUBHIT_ABORTONHIT)
						return 1;
				}
			}
		}
	}

	// hit successful
	return bHit;
}


/* --------------------------------------------------------------------------------
   Function : SkinModPanelProc
   Purpose : Skin modifier panel dialog procedure
   Parameters :
   Returns : 
   Info : 
*/

// instances of dialog buttons
static ICustButton	* ccButtonAssign = NULL;		// custom assign button
static ICustButton	* ccButtonScene = NULL;			// custom select scene bone button

// oon change in 
void Panel_OnChangeBoneSelect(SkinWSMMod * skinMod, HWND hwnd);
void Panel_OnChangeBones(SkinWSMMod	* skinMod, HWND hwnd);

BOOL CALLBACK SkinModPanelProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static ICustImage	* ccImage = NULL;
	static HIMAGELIST	hImageList = NULL;
	HBITMAP				hBMP, hMSK;
	SkinWSMMod			* skinMod;
	SkinBoneRef			* boneRef;
	INodeTab			nodeTab;
	INode				* node;
	int					loop, nPos,nCmdId,nSelect, idxBone;
	POINT				curPos;
	HMENU				hMenu,hSubMenu;

	// retrieve modifier instance
	if (msg != WM_INITDIALOG && !(skinMod = (SkinWSMMod *)GetWindowLong(hWnd, GWL_USERDATA)))
		return FALSE;

	// handle message
	switch (msg)
	{
		case WM_INITDIALOG:

			// set max interface ptr
			SetWindowLong(hWnd, GWL_USERDATA, lParam);
			skinMod = (SkinWSMMod *)lParam;

			// init custom assign button
			if (ccButtonAssign = GetICustButton(GetDlgItem(hWnd, IDC_MODIFIER_ASSIGN_MANUAL)))
			{
				ccButtonAssign->SetType(CBT_CHECK);
				ccButtonAssign->SetHighlightColor(GREEN_WASH);
				ccButtonAssign->SetTooltip(FALSE, NULL);
				ccButtonAssign->SetRightClickNotify(TRUE);
				ccButtonAssign->SetButtonDownNotify(FALSE);
			}

			// init custom select scene bone button
			if (ccButtonScene = GetICustButton(GetDlgItem(hWnd, IDC_MODIFIER_SELECT_BONE_SCENE)))
			{
				ccButtonScene->SetType(CBT_CHECK);
				ccButtonScene->SetHighlightColor(GREEN_WASH);
				ccButtonScene->SetTooltip(FALSE, NULL);
				ccButtonScene->SetRightClickNotify(TRUE);
				ccButtonScene->SetButtonDownNotify(FALSE);
			}

			// init custom images - 84x19 pixels
			ccImage = GetICustImage(GetDlgItem(hWnd, IDC_MODIFIER_IMAGE));
			hImageList = ImageList_Create(86, 21, TRUE, 2, 2);
			hBMP = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BITMAP1));
			hMSK = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BITMAP2));
			ImageList_Add(hImageList, hBMP, hMSK);
			DeleteObject(hBMP);
			DeleteObject(hMSK);
			ccImage->SetImage(hImageList, 0, 86, 21);

			// default: don't overwrite assignments when auto assigning
			skinMod->bAutoAssignOverwrite = 0;
			CheckDlgButton(hWnd, IDC_MODIFIER_AUTO_OVERWRITE, (skinMod->bAutoAssignOverwrite) ? BST_CHECKED : BST_UNCHECKED);

			// set display bone release status
			CheckDlgButton(hWnd, IDC_MODIFIER_BONE_RELEASE, (skinMod->bDispBoneRelease) ? BST_CHECKED : BST_UNCHECKED );

			// initialise panel info
			Panel_OnChangeBones(skinMod, hWnd);
			break;

		case WM_DESTROY:

			// remove custom image
			if (ccImage)
				ReleaseICustImage(ccImage);
			ccImage = NULL;
			if (hImageList)
				ImageList_Destroy(hImageList);
			hImageList = NULL;

			// remove custom assign button
			if (ccButtonScene)
				ReleaseICustButton(ccButtonScene);
			ccButtonScene = NULL;

			// remove custom select scene bone button
			if (ccButtonAssign)
				ReleaseICustButton(ccButtonAssign);
			ccButtonAssign = NULL;
			break;

		case WM_COMMAND:

			// handle command
			switch (LOWORD(wParam))
			{
				// do about box
				case IDC_MODIFIER_IMAGE:
					break;

				// add/del bones to from selection
				case IDC_MODIFIER_BONES_ADD:
				case IDC_MODIFIER_BONES_DEL:

					// clear any outstanding pick modes
					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();
						// clear assignment mode
						skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
						skinMod->ip->DeleteMode(&theCommandMode);
					}

					// setup 'hit by name' callback
					theHitByName.skinMod = skinMod;
					theHitByName.panHandle = hWnd;
					theHitByName.useFlag = (LOWORD(wParam) == IDC_MODIFIER_BONES_ADD) ? 0:1;
					if (skinMod->ip)
						skinMod->ip->DoHitByNameDialog(&theHitByName);
					break;

				// add/del all remaining bones in scene
				case IDC_MODIFIER_BONES_ADD_ALL:
				case IDC_MODIFIER_BONES_DEL_ALL:

					// clear any outstanding pick modes
					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();
						// clear assignment mode
						skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
						skinMod->ip->DeleteMode(&theCommandMode);
					}

					node = (skinMod->ip) ? skinMod->ip->GetRootNode() : NULL;
					if (node)
					{
						for (loop = 0; loop < node->NumberOfChildren(); loop++)
							CountBoneNodes(node->GetChildNode(loop), nodeTab);

						if (LOWORD(wParam) == IDC_MODIFIER_BONES_ADD_ALL && MessageBox(hWnd, "Add All Remaining Bones From Scene?", "Add Bones Check", MB_YESNO) == IDYES)
							skinMod->AddBones(nodeTab.Addr(0), nodeTab.Count());
						if (LOWORD(wParam) == IDC_MODIFIER_BONES_DEL_ALL && MessageBox(hWnd, "Remove All Used Bones?", "Delete Bones Check", MB_YESNO  ) == IDYES )
							skinMod->DelBones(nodeTab.Addr(0), nodeTab.Count());
						Panel_OnChangeBones(skinMod, hWnd);
					}
					break;

				// toggle auto assigning overwrite flag
				case IDC_MODIFIER_AUTO_OVERWRITE:
					skinMod->bAutoAssignOverwrite = (IsDlgButtonChecked(hWnd, IDC_MODIFIER_AUTO_OVERWRITE) == BST_CHECKED) ? 1:0;
					break;

				// toggle bone release
				case IDC_MODIFIER_BONE_RELEASE:
					skinMod->bDispBoneRelease = (IsDlgButtonChecked(hWnd, IDC_MODIFIER_BONE_RELEASE) == BST_CHECKED ) ? 1:0;
					skinMod->ForceRedraw();
					break;

				// auto assign selected or all bones
				case IDC_MODIFIER_AUTO_APPLY_ALL:

					if (MessageBox(hWnd, "Ok To Auto Assign All Bones?", "Auto Apply Bones Check", MB_YESNO) != IDYES)
						break;

				case IDC_MODIFIER_AUTO_APPLY:

					// clear any outstanding pick modes
					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();
						// clear assignment mode
						skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
						skinMod->ip->DeleteMode(&theCommandMode);
					}

					// auto assign selected or all bones?
					idxBone = (LOWORD(wParam) == IDC_MODIFIER_AUTO_APPLY_ALL) ? SKIN_BONEREF_ALL : skinMod->boneRefs->GetIndex(skinMod->GetSelectBone());
					if (idxBone != -1)
					{
						// auto assign bone/s
						skinMod->vertexAssigns->AutoAssignBone(skinMod->meshCache, idxBone, skinMod->bAutoAssignOverwrite);
						Panel_OnChangeBoneSelect(skinMod, hWnd);
						skinMod->ForceRedraw();
					}
					break;

				// clear assigns for selected or all bones
				case IDC_MODIFIER_AUTO_CLEAR_ALL:

					if (MessageBox(hWnd, "Ok To Clear All Bones Assignments?", "Clear Assigns Check", MB_YESNO) != IDYES)
						break;

				case IDC_MODIFIER_AUTO_CLEAR:

					// clear any outstanding pick modes
					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();
						// clear assignment mode
						skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
						skinMod->ip->DeleteMode(&theCommandMode);
					}

					// auto assign selected or all bones?
					idxBone = (LOWORD(wParam) == IDC_MODIFIER_AUTO_CLEAR_ALL) ? SKIN_BONEREF_ALL : skinMod->boneRefs->GetIndex(skinMod->GetSelectBone());
					if (idxBone != -1 )
					{
						skinMod->vertexAssigns->ClearBoneAssigns(idxBone);
						Panel_OnChangeBoneSelect(skinMod, hWnd);
						skinMod->ForceRedraw();
					}
					break;

				// select bone from sub menu
				case IDC_MODIFIER_SELECT_BONE_MENU:

					// clear any outstanding pick modes
					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();
						// allow assignmnet mode
						//	// clear assignment mode
						//	skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
						//	skinMod->ip->DeleteMode(&theCommandMode);
					}

					// menu and submenu handles
					hMenu = LoadMenu(hInstance, MAKEINTRESOURCE(IDM_BONE));
					hSubMenu = GetSubMenu(hMenu, 0);

					// count bones to set size of popup menu
					for (boneRef = skinMod->boneRefs->GetFirst(), nPos = 2, nCmdId = IDC_UNIQUE_MENU_ID; boneRef; boneRef = boneRef->GetNext(), nCmdId++, nPos++)
						if (boneRef->node)
							InsertMenu(hSubMenu, nPos, MF_BYPOSITION | MF_STRING, nCmdId, boneRef->node->GetName());

					// flag already selected bone
					if ( (idxBone = skinMod->boneRefs->GetIndex(skinMod->GetSelectBone())) == -1)
						CheckMenuItem(hSubMenu, IDC_BONE_SELECT_NONE, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(hSubMenu, 2+idxBone, MF_BYPOSITION | MF_CHECKED);

					// track users selection in popup menu
					GetCursorPos(&curPos);
					nSelect = TrackPopupMenu(hSubMenu, TPM_RETURNCMD, curPos.x, curPos.y, TPM_NONOTIFY, hWnd, NULL);

					// destroy menu
					DestroyMenu(hMenu);

					// handle menu selection
					if (nSelect && nSelect != IDC_BONE_SELECT_EXIT)
					{
						if ((boneRef = (nSelect == IDC_BONE_SELECT_NONE) ? NULL : skinMod->boneRefs->GetBone(nSelect-IDC_UNIQUE_MENU_ID)))
							skinMod->SetSelectBone(boneRef->node);
						else
							skinMod->SetSelectBone(NULL);
						Panel_OnChangeBoneSelect(skinMod, hWnd);
						skinMod->ForceRedraw();
					}
					break;

				// select bone to use from scene
				case IDC_MODIFIER_SELECT_BONE_SCENE:

					if (skinMod->ip)
					{
						// clear assignment mode
						skinMod->ip->DeleteMode(&theCommandMode);

						// if picking already, release
						if (skinMod->bUserPick)
							skinMod->ip->ClearPickMode();
						else
						{
							// setup pick mode
							thePickMode.skinMod = skinMod;
							thePickMode.panHandle = hWnd;
							skinMod->ip->SetPickMode(&thePickMode);
						}
					}
					break;

				// manual bone assignment
				case IDC_MODIFIER_ASSIGN_MANUAL:

					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();

						// in assignment mode already?
						if (skinMod->bUserAssign)
						{
							// release assignment mode
							skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
							skinMod->ip->DeleteMode(&theCommandMode);
						}
						else
						{
							// init assigment command mode
							theCommandMode.skinMod = skinMod;
							theCommandMode.panHandle = hWnd;
							// and push..
							skinMod->ip->SetCommandMode(&theCommandMode);
						}
					}
					break;

				// reset modifier
				case IDC_MODIFIER_RESET:

					if (! skinMod->boneRefs->Count())
						break;
					if (MessageBox(hWnd, "Ok To Release All Bones And Assignments?", "Reset Check", MB_YESNO) != IDYES)
						break;

					// clear any outstanding pick modes
					if (skinMod->ip)
					{
						// clear pick mode
						skinMod->ip->ClearPickMode();
						// clear assignment mode
						skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
						skinMod->ip->DeleteMode(&theCommandMode);
					}

					// clear ALL vertex assignments
					skinMod->vertexAssigns->ClearBoneAssigns(SKIN_BONEREF_ALL);
					// remove all used bones
					loop = skinMod->boneRefs->Count();
					while (loop > 0)
					{
						if ((boneRef = skinMod->boneRefs->GetBone(loop-1)))
							skinMod->DelBone(boneRef->node);
						loop--;
					}
					// NULL selected bone
					skinMod->SetSelectBone(NULL);
					// force update in views and panel
					skinMod->ForceRedraw();
					Panel_OnChangeBones(skinMod, hWnd);
					break;

				// update change to bone
				case IDC_MODIFIER_REASSIGN:

					if (boneRef = skinMod->boneRefs->IsTarget(skinMod->GetSelectBone()))
					{
						if (boneRef->node)
						{
							// re-assign bone reference
							boneRef->refMat = boneRef->node->GetNodeTM(0);
							// re-assign all vertices which are locked to bone
							idxBone = skinMod->boneRefs->GetIndex(skinMod->GetSelectBone());
							skinMod->vertexAssigns->ReAssignBone(skinMod->meshCache, idxBone);
							// force view update
							skinMod->ForceRedraw();
						}
					}
					break;

				// no message processed
				default:
					return FALSE;
			}
			break;

		default:
			return FALSE;
	}
	return TRUE;
}


/* --------------------------------------------------------------------------------
   Function : Panel_OnChangeBoneSelect
   Purpose : Acknowledge change in bone selection
   Parameters :
   Returns : 
   Info : 
*/

void Panel_OnChangeBoneSelect(SkinWSMMod * skinMod, HWND hwnd)
{
	char			outdlg[256];
	TCHAR			outbut[256];
	SkinBoneRef		* boneRef;

	// we really need a valid skinMod for this to work
	if (!skinMod || !hwnd)
		return;

	// get current selection node and reference
	boneRef = skinMod->boneRefs->IsTarget(skinMod->GetSelectBone());

	// 
	if (! boneRef)
	{
		// disable bone selection edit box
		sprintf(outdlg, "None");
		SetDlgItemText(hwnd, IDC_MODIFIER_BONE_SELECTED, outdlg);

		// disable manual assignment button
		if (ccButtonAssign)
		{
			_stprintf(outbut, _T("Assign Vertices: None"));
			ccButtonAssign->SetText(outbut);
			ccButtonAssign->Enable(FALSE);
		}

		// disable auto-assigning
		sprintf(outdlg, "Apply: None");
		SetDlgItemText(hwnd, IDC_MODIFIER_AUTO_APPLY, outdlg);
		sprintf(outdlg, "Clear: None");
		SetDlgItemText(hwnd, IDC_MODIFIER_AUTO_CLEAR, outdlg);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_APPLY ), FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_CLEAR ), FALSE);
	}
	else
	{
		// valid bone selection
		if (boneRef->node)
		{
			// enable bone selection edit box
			sprintf(outdlg, "%s : %d", boneRef->node->GetName(), skinMod->vertexAssigns->CountAssigns(skinMod->boneRefs->GetIndex(boneRef->node)));
			SetDlgItemText(hwnd, IDC_MODIFIER_BONE_SELECTED, outdlg);

			// enable manual assignment button
			if (ccButtonAssign)
			{
				_stprintf(outbut, _T("Assign Vertices: %s"), boneRef->node->GetName());
				ccButtonAssign->SetText(outbut);
				ccButtonAssign->Enable(TRUE);
			}

			// enable auto-assigning
			sprintf(outdlg, "Apply: %s", boneRef ? boneRef->node->GetName() : "None");
			SetDlgItemText(hwnd, IDC_MODIFIER_AUTO_APPLY, outdlg);
			sprintf(outdlg, "Clear: %s", boneRef ? boneRef->node->GetName() : "None");
			SetDlgItemText(hwnd, IDC_MODIFIER_AUTO_CLEAR, outdlg);
			EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_APPLY), TRUE);
			EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_CLEAR), TRUE);
		}
	}
}


/* --------------------------------------------------------------------------------
   Function : Panel_OnChangeBones
   Purpose : Acknowledge change in bones from panel
   Parameters :
   Returns : 
   Info : 
*/

void Panel_OnChangeBones(SkinWSMMod	* skinMod, HWND hwnd)
{
	char	outp[256];
	int		bones;

	// we really need a valid skinMod for this to work
	if (!skinMod || !hwnd)
		return;

	// any bones used?
	if (! skinMod->boneRefs->Count())
	{
		// print zero bones used
		sprintf(outp, "No Bones Used");
		SetDlgItemText(hwnd, IDC_MODIFIER_PICK_NUM, outp);

		// disable manual assigning
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_STATIC_MANUAL), FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_BONE_RELEASE), FALSE);
		if (ccButtonScene)
			ccButtonScene->Enable(FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_SELECT_BONE_MENU), FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_BONE_SELECTED), FALSE);
		if (ccButtonAssign)
			ccButtonAssign->Enable(FALSE);

		// diasble auto-assigning
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_STATIC_AUTO), FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_APPLY_ALL), FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_CLEAR_ALL), FALSE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_OVERWRITE), FALSE);
	}
	else
	{
		// print bones used
		bones = skinMod->boneRefs->Count();
		sprintf(outp, "Using %d Bone%s From Scene", bones, (bones==1)?"":"s");
		SetDlgItemText(hwnd, IDC_MODIFIER_PICK_NUM, outp);

		// enable manual assigning
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_STATIC_MANUAL), TRUE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_BONE_RELEASE), TRUE);
		if (ccButtonScene)
			ccButtonScene->Enable(TRUE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_SELECT_BONE_MENU), TRUE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_BONE_SELECTED), TRUE);
		if (ccButtonAssign)
			ccButtonAssign->Enable(TRUE);

		// enable auto-assigning
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_STATIC_AUTO), TRUE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_APPLY_ALL), TRUE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_CLEAR_ALL), TRUE);
		EnableWindow(GetDlgItem(hwnd, IDC_MODIFIER_AUTO_OVERWRITE), TRUE);
	}

	// update possible change in selection
	Panel_OnChangeBoneSelect(skinMod, hwnd);
}


/* --------------------------------------------------------------------------------
   Function : CountBoneNodes
   Purpose : Count bone nodes from node
   Parameters : node, nodetab
   Returns : 
   Info : 
*/

void CountBoneNodes(INode * node, INodeTab & nodeTab)
{
	Object * obj;

	if (!node)
		return;

	for (int i = 0; i < node->NumberOfChildren() ; i++)
		CountBoneNodes(node->GetChildNode(i), nodeTab);

	obj = node->GetObjectRef();
	if (obj && obj->SuperClassID() == HELPER_CLASS_ID && obj->ClassID() == Class_ID(BONE_CLASS_ID,0))
	{
		nodeTab.SetCount(nodeTab.Count()+1);
		nodeTab[nodeTab.Count()-1] = node;
	}
}


// --------------------------------------------------------------------------------
// Deform Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : Deform::Map
   Purpose : 
   Parameters : mesh vertex index, point
   Returns : 
   Info : 
*/

Point3 Deform::Map(int i, Point3 p)
{
	SkinVertAssign	* vertAss;
	SkinBoneRef		* boneRef;
	Point3			assignVec, newP;

	// need access to bones and vertex assignments
	if (! skinMod)
		return p;
	// get relevant bone and assign
	if (! (vertAss = skinMod->vertexAssigns->GetAssign(i)) )
		return p;
	if (! (boneRef = skinMod->boneRefs->GetBone(vertAss->idxBoneRef)) )
		return p;
	if( ! (boneRef->node) )
		return p;

	// is display bone released?
	if (skinMod->bDispBoneRelease && skinMod->GetSelectBone() == boneRef->node)
		return p;

	// use internal assignment to modify point
	newP = boneRef->transMat * vertAss->vec;

	// and return
	return newP;


	// calculate modified point
	assignVec = p - boneRef->refMat.GetTrans();
	newP = boneRef->transMat * assignVec;

	return newP;
}


// --------------------------------------------------------------------------------
// HitByName Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : HitByName::filter
   Purpose : Make this node available for selection
   Parameters : Filter in this node?
   Returns : 1/0
   Info : 
*/

int HitByName::filter(INode *node)
{
	// is node a bone?
	Object * obj = node->GetObjectRef();
	if (obj && obj->SuperClassID() == HELPER_CLASS_ID && obj->ClassID() == Class_ID(BONE_CLASS_ID,0))
	{
		// depending if we are adding / deleting bone filter in..
		if (!useFlag && !skinMod->boneRefs->IsTarget(node))
			return 1;
		if ( useFlag &&  skinMod->boneRefs->IsTarget(node))
			return 1;
	}
	// filter out node
	return 0;
}


/* --------------------------------------------------------------------------------
   Function : HitByName::proc
   Purpose : Okay select procedure - process selected nodes
   Parameters : 
   Returns : 
   Info : 
*/

void HitByName::proc(INodeTab &nodeTab)
{
	int boneSel = SKIN_BONEREF_INVALID_SELECTION;

	DPrintf("HitByName trying to %s %d bone%s", (! useFlag) ? "add" : "delete", nodeTab.Count(), (nodeTab.Count()==1) ? "" : "s" );

	if (nodeTab.Count())
	{
		// either add / del bone selection
		if (! useFlag)
			skinMod->AddBones(nodeTab.Addr(0), nodeTab.Count());
		else
			skinMod->DelBones(nodeTab.Addr(0), nodeTab.Count());

		// validate bone selection
		if ((skinMod->boneRefs->GetIndex(skinMod->GetSelectBone())) == -1)
			skinMod->SetSelectBone(NULL);

		// update panel and views
		skinMod->ForceRedraw();
		Panel_OnChangeBones(skinMod, panHandle);
	}
}


// --------------------------------------------------------------------------------
// PickMode Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PickMode::EnterMode
   Purpose : Pick mode pre-process
   Parameters : 
   Returns : 
   Info : 
*/

void PickMode::EnterMode(IObjParam * ip)
{
	DPrintf("  PickMode::EnterMode() called");
	if (ccButtonScene)
		ccButtonScene->SetCheck(TRUE);			// make sure pick button pressed
	if (skinMod)
		skinMod->bUserPick = 1;						// set user picking
}


/* --------------------------------------------------------------------------------
   Function : PickMode::ExitMode
   Purpose : Pick mode post-process
   Parameters : 
   Returns : 
   Info : 
*/

void PickMode::ExitMode(IObjParam * ip)
{
	DPrintf("  PickMode::ExitMode() called");
	if (ccButtonScene)
		ccButtonScene->SetCheck(FALSE);			// make sure pick button released
	if (skinMod)
		skinMod->bUserPick = 0;						// clear user picking
}

/* --------------------------------------------------------------------------------
   Function : PickMode::GetFilter
   Purpose : Get pick mode filter
   Parameters : 
   Returns : 
   Info : 
*/

PickNodeCallback * PickMode::GetFilter(void)
{
	return &thePickNodeFilter;
}


/* --------------------------------------------------------------------------------
   Function : PickMode::HitTest
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

BOOL PickMode::HitTest(IObjParam * ip, HWND hWnd, ViewExp * vpt, IPoint2 m, int flags)
{
	thePickNodeFilter.ip = ip;
	thePickNodeFilter.skinMod = skinMod;
	return ip->PickNode(hWnd, m, &thePickNodeFilter) ? TRUE : FALSE;
}


/* --------------------------------------------------------------------------------
   Function : PickMode::Pick
   Purpose : User picked a bone node from scene
   Parameters : 
   Returns : 
   Info : 
*/

BOOL PickMode::Pick(IObjParam *ip, ViewExp *vpt)
{
	INode * node;

	if (skinMod && (node = vpt->GetClosestHit()))
	{
		// index into bone list for node check
		if (skinMod->boneRefs->GetIndex(node) != -1)
		{
			skinMod->SetSelectBone(node);
			skinMod->ForceRedraw();
			Panel_OnChangeBoneSelect(skinMod, panHandle);
		}
	}
	return TRUE;
}


// --------------------------------------------------------------------------------
// PickNodeFilter Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PickNodeFilter::Filter
   Purpose : Filter proc for above pick from scene
   Parameters : Node
   Returns : Allow to be picked or not
   Info : 1/0
*/

BOOL PickNodeFilter::Filter(INode * node)
{
	// get object from node
	Object * obj = node->GetObjectRef();
	// only allow:
	if (obj &&
		// ..bone helper object
		obj->SuperClassID() == HELPER_CLASS_ID && obj->ClassID() == Class_ID(BONE_CLASS_ID,0) &&
		// ,,a bone in our scene
		skinMod && skinMod->boneRefs->IsTarget(node))
		return TRUE;
	else
		return FALSE;
}


// --------------------------------------------------------------------------------
// CmdMode Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : CmdMode::MouseProc
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

MouseCallBack * CmdMode::MouseProc(int *numPoints)
{
	DPrintf("  CmdMode::MouseProc() called");

	*numPoints = 2;									// only two points per operation (up / down)
	theCommandModeMouse.skinMod = skinMod;			// init mouse callback
	theCommandModeMouse.panHandle = panHandle;
	theCommandModeMouse.bRectRegion = 0;
	return &theCommandModeMouse;					// return mouse callback
}

/* --------------------------------------------------------------------------------
   Function : CmdMode::EnterMode
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void CmdMode::EnterMode(void)
{
	DPrintf("  CmdMode::EnterMode() called");
	if (ccButtonAssign)
		ccButtonAssign->SetCheck(TRUE);
	if (skinMod)
		skinMod->bUserAssign = 1;
}


/* --------------------------------------------------------------------------------
   Function : CmdMode::ExitMode
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void CmdMode::ExitMode(void)
{
	DPrintf("  CmdMode::ExitMode() called");
	if (ccButtonAssign)
		ccButtonAssign->SetCheck(FALSE);
	if (skinMod)
		skinMod->bUserAssign = 0;
}


// --------------------------------------------------------------------------------
// CmdModeMouse Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : CmdModeMouse::proc
   Purpose : Mouse procedure
   Parameters : 
   Returns : 
   Info : 
*/

int	CmdModeMouse::proc(HWND hwnd, int msg, int point, int flags, IPoint2 m)
{
	HCURSOR			hCursor;
	MeshSubHitRec	*hit;
	SubObjHitList	hitCurList, hitList;
	int				hits = 0, idxSelBone;

	// set mouse cursor
	skinMod->DoSubHitTest(hwnd, hitCurList, hits, 0, &m);
	if (flags & MOUSE_CTRL)
		hCursor = (! hits) ? hCurAdd : hCurVertAdd;
	else if (flags & MOUSE_ALT)
		hCursor = (! hits) ? hCurSub : hCurVertSub;
	else
		hCursor = (! hits) ? hCurArrow : hCurVert;

	// process mouse messages
	if (msg == MOUSE_INIT)
	{
		// load all cursors
		hCurArrow	= LoadCursor(NULL, IDC_ARROW);
		hCurVert	= LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR_VERT ));
		hCurVertAdd = LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR_VERT_ADD));
		hCurVertSub = LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR_VERT_SUB));
		hCurAdd		= LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR_ADD));
		hCurSub		= LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR_SUB));
	}
	else if (msg == MOUSE_UNINIT)
	{
		// free cursors
		if (hCurArrow)
			DestroyCursor(hCurArrow);
		hCurArrow = NULL;
		if (hCurVert)
			DestroyCursor(hCurVert);
		hCurVert = NULL;
		if (hCurVertAdd)
			DestroyCursor(hCurVertAdd);
		hCurVertAdd = NULL;
		if (hCurVertSub)
			DestroyCursor(hCurVertSub);
		hCurVertSub = NULL;
		if (hCurAdd)
			DestroyCursor(hCurAdd);
		hCurAdd = NULL;
		if (hCurSub)
			DestroyCursor(hCurSub);
		hCurSub = NULL;
	}
	else if (msg == MOUSE_PROPCLICK)
	{
		// forcefully remove the command mode
		if (skinMod->ip)
		{
			DPrintf("User right clicked command mode");

			skinMod->ip->SetStdCommandMode(CID_OBJMOVE);
			skinMod->ip->DeleteMode(&theCommandMode);
			return FALSE;
		}
	}
	else if (msg == MOUSE_FREEMOVE )
	{
	}
	else if (msg == MOUSE_POINT && point == 0)
	{
		// user pressed down button
		userPoints[0] = userPoints[1] = m;				// save mouse position
		bRectRegion = 0;								// flag point region
	}
	else if (msg == MOUSE_MOVE)
	{
		// user dragging mouse
		if (bRectRegion)								// need to remove rectangle?
			DrawXorRect(hwnd, userPoints[0], userPoints[1]);
		bRectRegion = 1;								// flag rectangular region

		userPoints[1] = m;								// update end point
		DrawXorRect(hwnd, userPoints[0], userPoints[1]);
	}
	else if( msg == MOUSE_ABORT )
	{
		// drag aborted
		if (bRectRegion)								// need to remove rectangle?
			DrawXorRect(hwnd, userPoints[0], userPoints[1]);
	}
	else if(msg == MOUSE_POINT && point == 1)
	{
		// user released button
		if (bRectRegion)								// need to remove rectangle?
			DrawXorRect(hwnd, userPoints[0], userPoints[1]);

		if ((flags & MOUSE_CTRL) || (flags & MOUSE_ALT))
		{
			// get bone selection index 
			if ((idxSelBone = skinMod->boneRefs->GetIndex(skinMod->GetSelectBone())) != -1)
			{
				// perform hit test on vertices on cached mesh
				skinMod->DoSubHitTest(hwnd, hitList, hits, bRectRegion, (bRectRegion) ? userPoints : &m);

				DPrintf("%d vert%s %s %s", hits, (hits==1)?"ex":"ices", (flags & MOUSE_CTRL) ? "added to" : "removed from", skinMod->GetSelectBone()->GetName());

				// handle all vertices hits
				for(hit = hitList.First(); hit; hit = hit->Next())
				{
					// assign / remove vertex to current bone selection
					if (flags & MOUSE_CTRL)
						skinMod->vertexAssigns->Add(skinMod->meshCache, hit->index, idxSelBone);
					else
						skinMod->vertexAssigns->Sub(hit->index, idxSelBone);
				}

				// redraw scene
				skinMod->ForceRedraw();
				// update panel
				Panel_OnChangeBoneSelect(skinMod, panHandle);
			}
		}
	}

	// set mouse cursor
	if (hCursor)
		SetCursor(hCursor);

	return TRUE;
}


/* --------------------------------------------------------------------------------
   Function : CmdModeMouse::proc
   Purpose : Mouse procedure
   Parameters : viewport handle, uses mouse points
   Returns : 
   Info : 
*/

void CmdModeMouse::DrawXorRect(HWND hwnd, IPoint2 & p1, IPoint2 & p2)
{
	RECT rect;
	HDC hdc;

	rect.left   = __min(p1.x, p2.x);
	rect.top    = __min(p1.y, p2.y);
	rect.right	= __max(p1.x, p2.x);
	rect.bottom	= __max(p1.y, p2.y);

	hdc = GetDC(hwnd);
	DrawFocusRect( hdc,&rect );
	ReleaseDC( hwnd,hdc );
}



// ================================================================================
// Our Class Descriptor's
// ================================================================================

// --------------------------------------------------------------------------------
// Skin World Space Object
// --------------------------------------------------------------------------------
class SkinObjClassDesc : public ClassDesc
{
	public:
		int				IsPublic()							{ return 1; }
		void			*Create(BOOL loading = FALSE)		{ return new SkinWSMObj(); }
		const TCHAR		*ClassName()						{ return GetString(IDS_WSOBJ_CLASS_NAME); }
		SClass_ID		SuperClassID()						{ return WSM_OBJECT_CLASS_ID; }
		Class_ID		ClassID()							{ return SKINOBJ_CLASS_ID; }
		const TCHAR		*Category()							{ return GetString(IDS_CATEGORY); }
};

// instance of our object descriptor
static SkinObjClassDesc	theObjClassDesc;
ClassDesc *GetSkinObjDesc() { return &theObjClassDesc; }


// --------------------------------------------------------------------------------
// Skin World Space Modifier
// --------------------------------------------------------------------------------
class SkinModClassDesc : public ClassDesc
{
	public:
		int				IsPublic()							{ return 0; }
		void			*Create(BOOL loading = FALSE)		{ return new SkinWSMMod(); }
		const TCHAR		*ClassName()						{ return GetString(IDS_WSMOD_CLASS_NAME); }
		SClass_ID		SuperClassID()						{ return WSM_CLASS_ID; }
		Class_ID		ClassID()							{ return SKINMOD_CLASS_ID; }
		const TCHAR		*Category()							{ return GetString(IDS_CATEGORY); }
};

// instance of our modifier descriptor
static SkinModClassDesc	theModClassDesc;
ClassDesc *GetSkinModDesc() { return &theModClassDesc; }





#if 0

data:
	bones
	vertex assignments

	used bones
		node

	vertex assignments
		index into bone table OR bone node

 	- this data could quite safely go into the local mod data
	- can't really do that as 

change to mesh..

#endif