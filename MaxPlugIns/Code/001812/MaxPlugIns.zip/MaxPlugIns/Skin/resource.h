//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Skin.rc
//
#define IDS_WSOBJ_CLASS_NAME            1
#define IDS_WSMOD_CLASS_NAME            2
#define IDS_CATEGORY                    3
#define IDS_LIB_DESC                    4
#define IDS_LIBDESCRIPTION              4
#define IDD_OBJECT_PANEL                103
#define IDB_BITMAP1                     107
#define IDB_BITMAP2                     108
#define IDD_MODIFIER_PANEL              109
#define IDC_CURSOR_VERT_SUB             110
#define IDC_CURSOR_SUB                  111
#define IDC_CURSOR_VERT                 112
#define IDC_CURSOR_ADD                  113
#define IDC_CURSOR_VERT_ADD             114
#define IDD_DEBUG                       115
#define IDM_BONE                        116
#define IDC_MODIFIER_BONES_ADD          1003
#define IDC_MODIFIER_BONES_DEL          1004
#define IDC_MODIFIER_AUTO_APPLY         1005
#define IDC_MODIFIER_AUTO_CLEAR         1006
#define IDC_MODIFIER_RESET              1007
#define IDC_MODIFIER_SELECT_BONE_MENU   1008
#define IDC_MODIFIER_IMAGE              1010
#define IDC_MODIFIER_SELECT_BONE_SCENE  1012
#define IDC_MODIFIER_STATIC_PICK        1015
#define IDC_MODIFIER_STATIC_MANUAL      1016
#define IDC_MODIFIER_STATIC_AUTO        1017
#define IDC_MODIFIER_STATIC_RESET       1018
#define IDC_MODIFIER_STATIC_RESET2      1019
#define IDC_OBJECT_IMAGE                1022
#define IDC_MODIFIER_BONES_DEL_ALL      1024
#define IDC_MODIFIER_BONES_ADD_ALL      1025
#define IDC_MODIFIER_AUTO_OVERWRITE     1026
#define IDC_MODIFIER_SNAPSHOT           1027
#define IDC_MODIFIER_REASSIGN           1027
#define IDC_MODIFIER_AUTO_CLEAR_ALL     1028
#define IDC_MODIFIER_AUTO_APPLY_ALL     1029
#define IDC_MODIFIER_BONE_RELEASE       1030
#define IDC_MODIFIER_ASSIGN_MANUAL      1034
#define IDC_MODIFIER_PICK_NUM           1039
#define IDC_DEBUG_TEXT                  1039
#define IDC_MODIFIER_BONE_SELECTED      1041
#define IDC_FLOAT                       1490
#define IDC_BONE_SELECT_NONE            40002
#define IDC_BONE_SELECT_EXIT            40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
