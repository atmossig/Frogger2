
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : obeimp.cpp
// Purpose : implementation of OBEImport class
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "OBEImport.h"

#include <shlobj.h>
#include <direct.h>

#include "InvKin.h"
#include "NoteTrck.h"

#include "WinCtrlEditLine.h"


// --------------------
// Constants and macros

#define IMPORT_CONFIG_FILE		"OBEImport.cfg"
#define IMPORT_CONFIG_VERSION	1

#define IMPORT_TEXTURE_PATHS	"OBEFile.pth"
#define IMPORT_TEXTURE_SETS		"OBEFile.set"
#define IMPORT_TEXTURE_HEADER	"\n// OBEFile.dle generated texture set configuration file\n\n"

// additional window messages
#define WM_OBEFILE_BASE			(WM_APP+0x100)
#define WM_OBEFILE_KEY_ESC		(WM_OBEFILE_BASE+0)
#define WM_OBEFILE_KEY_RET		(WM_OBEFILE_BASE+1)
#define WM_OBEFILE_KEY_DEL		(WM_OBEFILE_BASE+2)

// opacity maps
#define OPACITYMAP_DIR			"OpacityMaps\\"
#define OPACITYMAP_PREFIX		"om_"
#define OPACITYMAP_POSTFIX		""


// ------------------
// Function templates

// dialog box procedures
static BOOL CALLBACK configDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
static BOOL CALLBACK editTexturePathsDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);


// -----------------
// Types and classes

/* --------------------------------------------------------------------------------
   Function : OBEImport::OBEImport
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

OBEImport::OBEImport()
{
	texNameList = new StringList;
	texturePaths = new StringList;
	nodeTexList = new TexInfList;
	WSObjNodePtr = NULL;
	nameMakerPtr = NULL;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::~OBEImport
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

OBEImport::~OBEImport()
{
	SAFE_DELETE(texNameList)
	SAFE_DELETE(texturePaths)
	SAFE_DELETE(nodeTexList)
	SAFE_DELETE(nameMakerPtr)
	WSObjNodePtr = NULL;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadChunkHead
   Purpose : read obe chunk header and validate
   Parameters : retrieve header pointer
   Returns : header valid - TRUE, else FALSE
   Info : 
*/

int OBEImport::ReadChunkHead(OBE_CHUNK_HEAD *header)
{
	int	verCheck;

	// read obe header
	fread(header, sizeof(OBE_CHUNK_HEAD), 1, fileHandle);
	if (ferror(fileHandle))
		return 0;

	// validate chunk header
	if (header->chunkID > OBECHUNK_INVALID && header->chunkID < OBECHUNK_END)
		return 0;

	// check that we're using the correct header version
	switch (header->chunkID)
	{
		case OBECHUNK_OBJECT:
			verCheck = OBJECT_VER;
			break;
		case OBECHUNK_OBJECTINFO:
			verCheck = OBJECTINFO_VER;
			break;
		case OBECHUNK_MESH:
			verCheck = MESH_VER;
			break;
		case OBECHUNK_MAPPINGICONS:
			verCheck = MAPPING_VER;
			break;
		case OBECHUNK_VIEWPORTS:
			verCheck = VIEWPORTS_VER;
			break;
		case OBECHUNK_ANIMTIME:
			verCheck = ANIMTIME_VER;
			break;
		case OBECHUNK_VERTEXFRAMES:
			verCheck = VERTEXFRAMES_VER;
			break;
		case OBECHUNK_ANIMSEGMENTS:
			verCheck = ANIMSEGMENTS_VER;
			break;
		case OBECHUNK_CONSTRUCTIONGRID:
			verCheck = CONSTRUCTIONGRID_VER;
			break;
		case OBECHUNK_LIGHTINGINFO:
			verCheck = LIGHTINGINFO_VER;
			break;
		case OBECHUNK_SKININFO:
			verCheck = SKININFO_VER;
			break;
		case OBECHUNK_BONE:
			verCheck = SKIN_VER;
			break;
		case OBECHUNK_ANIMNOTES:
			verCheck = ANIMNOTES_VER;
			break;
		case OBECHUNK_POLYDATA:
			verCheck = POLYDATA_VER;
			break;
		case OBECHUNK_PATCH_MESH:
			verCheck = PATCHMESH_VER;
			break;
		case OBECHUNK_END:
			verCheck = END_VER;
			break;
		default:
			DPrintf("Reading chunk type: %s", ChunkType(header->chunkID));
			return 0;
	}
	if (header->chunkVersion > verCheck)
		return 0;

	DPrintf("Reading chunk type: %s", ChunkType(header->chunkID));
	// valid chunk header
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ChunkType
   Purpose : get chunk type string 
   Parameters : chunk type
   Returns : pointer to chunk type string
   Info : 
*/

char *OBEImport::ChunkType(int chType)
{
	switch(chType)
	{
		case OBECHUNK_OBJECT:
			return "Object";
		case OBECHUNK_OBJECTINFO:
			return "Object Infomation";
		case OBECHUNK_MESH:
			return "Mesh";
		case OBECHUNK_MAPPINGICONS:
			return "Mapping Icons";
		case OBECHUNK_VIEWPORTS:
			return "Viewports";
		case OBECHUNK_ANIMTIME:
			return "Animation Timing";
		case OBECHUNK_VERTEXFRAMES:
			return "Vertex Frames";
		case OBECHUNK_ANIMSEGMENTS:
			return "Animation Segments";
		case OBECHUNK_CONSTRUCTIONGRID:
			return "Construction Grid";
		case OBECHUNK_LIGHTINGINFO:
			return "Lighting Infomation";
		case OBECHUNK_SKININFO:
			return "Skin Infomation";
		case OBECHUNK_BONE:
			return "Bone";
		case OBECHUNK_MAXBONE:
			return "MaxBone";
		case OBECHUNK_ANIMNOTES:
			return "Animation Notes";
		case OBECHUNK_POLYDATA:
			return "Polygon Data";
		case OBECHUNK_END:
			return "End Chunk";
	}
	return "*UnKnown*";
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadUserConfigTextureSets
   Purpose : read users configuration texture sets file
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::ReadUserConfigTextureSets()
{
	static TCHAR	tcbuf[_MAX_PATH], tcLine[_MAX_PATH], tcBuf[_MAX_PATH];
	TCHAR			*ap, *bp;;
	FILE			*file;
	TTextureSet		texSet;
	TTexturePath	texPath;
	int				num, l;

	// zero the texture set count
	textureSets.ZeroCount();

	// string together the texture set filename
	_tcscpy(tcbuf, ip->GetDir(APP_PLUGCFG_DIR));
	_tcscat(tcbuf, _T("\\"));
	_tcscat(tcbuf, _T(IMPORT_TEXTURE_SETS));


	// read in the texture sets file
	if ((file = _tfopen(tcbuf, "rt")) == NULL)
	{
		// ** The texture sets configuration file does not exist. Therefore create a default set holding
		// ** all of the old texture paths.

		// create an empty default texture set
		_tcscpy(texSet.ident, _T("Default"));
		texSet.paths.ZeroCount();
		textureSets.Append(1, &texSet);

		// add all of the previously read texture paths
		for (l=0; l<texturePaths->ListLen(); l++)
		{
			texPath.flags = TEXPATHFLAG_ENABLED;
			_tcscpy(texPath.path, _T(texturePaths->GetStr(l)));
			textureSets[0].paths.Append(1, &texPath);
		}
		return;
	}

	// try and parse all of the file lines
	while (feof(file) == 0)
	{
		// read in text line
		if (_fgetts(tcLine, _MAX_PATH, file) == NULL)
			break;
		if (_tcsstr(tcLine, _T("SET =")) != NULL)
		{
			// ** Texture set found

			// extract the set name ident
			tcBuf[0] = 0;
			if ((ap = _tcschr(tcLine, _T('"'))) != NULL)
				if ((bp = _tcschr(_tcsinc(ap), _T('"'))) != NULL)
				{
					ap = _tcsinc(ap);
					for (l=0; ap < bp; l++, ap = _tcsinc(ap))
						tcBuf[l] = *ap;
					tcBuf[l] = 0;
				}

			// valid ident?/l
			if (_tcslen(tcBuf) > 0)
			{
				// initialise the new set before adding
				_tcscpy(texSet.ident, tcBuf);
				texSet.paths.ZeroCount();

				// add the new set
				textureSets.Append(1, &texSet);
			}
		}
		else if (_tcsstr(tcLine, _T("PATH =")) != NULL)
		{
			// ** Texture path found

			// extract the full path string
			tcBuf[0] = 0;
			if ((ap = _tcschr(tcLine, _T('"'))) != NULL)
				if ((bp = _tcschr(_tcsinc(ap), _T('"'))) != NULL)
				{
					ap = _tcsinc(ap);
					for (l=0; ap < bp; l++, ap = _tcsinc(ap))
						tcBuf[l] = *ap;
					tcBuf[l] = 0;
				}

			// valid ident?
			if (_tcslen(tcBuf) > 0)
			{
				// extract the path enable flag. default enabled
				texPath.flags = (_tcsstr(tcLine, _T("ENABLE = FALSE")) != NULL || _tcsstr(tcLine, _T("ENABLE = 0")) != NULL) ? 0 : TEXPATHFLAG_ENABLED;
				// set path name
				_tcscpy(texPath.path, tcBuf);

				// any valid sets to add the string to?
				if ((num = textureSets.Count()) > 0)
					textureSets[num-1].paths.Append(1, &texPath);
			}
		}
	}

	fclose(file);
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::WriteUserConfigTextureSets
   Purpose : write users configuration texture sets file
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::WriteUserConfigTextureSets()
{
	static TCHAR	tcbuf[_MAX_PATH], tcLine[_MAX_PATH], tcBuf[_MAX_PATH];
	FILE			*file;
	int				i, j;
	TTextureSet		*texSetPtr;
	TTexturePath	*texPathPtr;


	// string together the texture set filename
	_tcscpy(tcbuf, ip->GetDir(APP_PLUGCFG_DIR));
	_tcscat(tcbuf, _T("\\"));
	_tcscat(tcbuf, _T(IMPORT_TEXTURE_SETS));

	// open texture set file
	if ((file = _tfopen(tcbuf, "wt")) == NULL)
		return;

	// attach header..
	_stprintf(tcbuf, "%s", _T(IMPORT_TEXTURE_HEADER));
	_fputts(tcbuf, file);
	
	// write all sets and paths contained
	for (i=0; i<textureSets.Count(); i++)
	{
		texSetPtr = textureSets.Addr(i);

		_stprintf(tcbuf, "%s%s%s", _T("SET = \""), texSetPtr->ident, _T("\"\n"));
		_fputts(tcbuf, file);

		for (j=0; j<texSetPtr->paths.Count(); j++)
		{
			texPathPtr = texSetPtr->paths.Addr(j);

			_stprintf(tcbuf, "%s%s%s", _T("PATH = \""), texPathPtr->path, _T("\""));
			_fputts(tcbuf, file);
			if (! (texPathPtr->flags & TEXPATHFLAG_ENABLED))
				_fputts(_T("\t\tENABLE = FALSE"), file);
			_fputts(_T("\n"), file);
		}

		if (i < textureSets.Count()-1)
			_fputts(_T("\n"), file);
	}

	fclose(file);
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadTextureConfig
   Purpose : read users texture configuration file and add to texture paths
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::ReadTextureConfig()
{
	FILE		*configFile;
	char		charBuf[_MAX_PATH];
	char		configFileName[_MAX_PATH];

	// piece together the texture config filename
	strcpy(configFileName, ip->GetDir(APP_PLUGCFG_DIR));
	strcat(configFileName, "\\");
	strcat(configFileName, IMPORT_TEXTURE_PATHS);

	// read in the config file and add all valid texture paths
	if ((configFile = fopen(configFileName, "rt")) == NULL)
		return;
	while (feof(configFile) == 0)
	{
		if (fgets(charBuf, 256, configFile) == NULL)
			break;
		if (feof(configFile) == 0)
		{
			if (strlen(charBuf) > 0)
			{
				charBuf[strlen(charBuf)-1]=0;
				if (strlen(charBuf))
				{
					if (texturePaths->GetIdx(charBuf) == -1)
						texturePaths->Add(charBuf);
				}
			}
		}
	}
	fclose(configFile);
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadConfig
   Purpose : read users configuration file
   Parameters : 
   Returns : 
   Info : 
*/

//	Non-Version:
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		configImportAnimation		; import animations
//		UCHAR		configClearScene			; clear scene in import
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		configShowTextures			; show texture maps in the viewport
//		UCHAR		configImportPerFaceData		; import PerFaceData
//		UCHAR		NULL
//		UINT		NULL
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		NULL
//		UINT		NULL
//		UCHAR		NULL
//		UINIT		configTextureSetIndex		; combo box texture set index
//
// Version:1
//		UCHAR		configImportAnimation		; import animation
//		UCHAR		configImportPerFaceData		; import perfacedata
//		UCHAR		configClearScene;			; clear scene on import
//		UCHAR		configShowTextures;			; show texture maps in viewport
//		UINT		configTextureSetIndex		; combo box texture set index

void OBEImport::ReadConfig()
{
	FILE		*configFile;
	char		configFileName[_MAX_PATH];
	UCHAR		readc;
	UINT		readi, version;

	// piece together the config filename
	strcpy(configFileName, ip->GetDir(APP_PLUGCFG_DIR));
	strcat(configFileName, "\\");
	strcat(configFileName, IMPORT_CONFIG_FILE);

	// set default configuration
	configImportAnimation			= 1;
	configImportPerFaceData			= 0;
	configClearScene				= 1;
	configShowTextures				= 0;
	configTextureSetIndex			= 0;

	// open configuration file
	if ((configFile = fopen(configFileName, "rt")) == NULL)
		return;

	// read first entry.. is this our ident (23 November 2000)?
	version = 0;
	readc = fgetc(configFile);
	if (readc != (00+11+23))
	{
		// old configuration file
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		if ((readc = fgetc(configFile)) != (UCHAR)EOF)
			configImportAnimation = readc;
		if ((readc = fgetc(configFile)) != (UCHAR)EOF)
			configClearScene = readc;
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		if ((readc = fgetc(configFile)) != (UCHAR)EOF)
			configShowTextures = readc;
		if ((readc = fgetc(configFile)) != (UCHAR)EOF)
			configImportPerFaceData = readc;
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		fread(&readi, sizeof(readi), 1, configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		fread(&readi, sizeof(readi), 1, configFile);
		readc = fgetc(configFile);
		if (fread(&readi, sizeof(readi), 1, configFile) == 1)
			configTextureSetIndex = readi;
	}
	else
	{
		// ** New Versioned Configuration File Found

		// read version number
		fread(&version, sizeof(version), 1, configFile);
		switch (version)
		{
		// version:1
		case 1:
			configImportAnimation	= fgetc(configFile);
			configImportPerFaceData = fgetc(configFile);
			configClearScene		= fgetc(configFile);
			configShowTextures		= fgetc(configFile);
			if (fread(&readi, sizeof(readi), 1, configFile) == 1)
				configTextureSetIndex = readi;
			break;
		}
	}

	DPrintf("Read user config file (version %d)", version);

	fclose(configFile);
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::WriteConfig
   Purpose : write users configuration file
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::WriteConfig() 
{
	FILE		*configFile;
	char		configFileName[256];
	UCHAR		writec = 0;
	UINT		version = IMPORT_CONFIG_VERSION;

	// piece together the config filename
	strcpy(configFileName, ip->GetDir(APP_PLUGCFG_DIR));
	strcat(configFileName, "\\");
	strcat(configFileName, IMPORT_CONFIG_FILE);

	// create the configuration file
	if ((configFile = fopen(configFileName, "wt")) == NULL)
		return;

	// write ident entry (23 November 2000)
	fputc(00+11+23, configFile);

	// write current configuration version
	fwrite(&version, sizeof(version), 1, configFile);

	// write configuration
	fputc(configImportAnimation, configFile);
	fputc(configImportPerFaceData, configFile);
	fputc(configClearScene, configFile);
	fputc(configShowTextures, configFile);
	fwrite(&configTextureSetIndex, sizeof(configTextureSetIndex), 1, configFile);

	fclose(configFile);

	DPrintf("Wrote user config file");
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadChunk
   Purpose : read chunk from file
   Parameters : parent node
   Returns : 1 okay, else 0
   Info : 
*/

int	OBEImport::ReadChunk(INode *node)
{
	OBE_CHUNK_HEAD	chunkHeader;

	// read chunk header and set file pointer to next chunk
	fread(&chunkHeader, sizeof(chunkHeader), 1, fileHandle);
	currentFilePos += sizeof(chunkHeader) +  chunkHeader.chunkLength;

	switch (chunkHeader.chunkID)
	{
	// object chunks
	case OBECHUNK_OBJECT:
		break;
	case OBECHUNK_END:
		return READ_END_CHUNK;

	// animation chunks
	case OBECHUNK_ANIMSEGMENTS:
		ReadChunk_AnimSegments();
		break;
	case OBECHUNK_ANIMTIME:
		ReadChunk_AnimTime();
		break;

	// mesh chunk
	case OBECHUNK_MESH:
		ReadChunk_Mesh(node);
		break;

	// hard bone chunk
	case OBECHUNK_BONE_HARD:
		ReadChunk_HardBone(node);
		break;
	}

	// skip to next chunk
	fseek(fileHandle, currentFilePos, SEEK_SET);
	return READ_DATA_CHUNK;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadChunk_AnimSegments
   Purpose : read animation segment chunk from file
   Parameters : 
   Returns : 1 okay, else 0
   Info : fileHandle - current file position
*/

int	OBEImport::ReadChunk_AnimSegments()
{
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadChunk_AnimTime
   Purpose : read animation time chunk from file
   Parameters : 
   Returns : 1 okay, else 0
   Info : fileHandle - current file position
*/

int	OBEImport::ReadChunk_AnimTime()
{
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadChunk_Mesh
   Purpose : read mesh chunk from file
   Parameters : parent node
   Returns : 1 okay, else 0
   Info : fileHandle - current file position
*/

int	OBEImport::ReadChunk_Mesh(INode *node)
{
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadChunk_HardBone
   Purpose : read hard skinned bone chunk from file
   Parameters : 
   Returns : 1 okay, else 0
   Info : fileHandle - current file position
*/

int	OBEImport::ReadChunk_HardBone(INode *node)
{
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ReadFile
   Purpose : open an OBE file
   Parameters : parentNodePtr
   Returns : 
   Info : 
*/

int OBEImport::ReadFile(INode *parentNodePtr)
{
	OBE_CHUNK_HEAD	chunkHead;
	ObeMesh			*obeMeshPtr;
	ObeBone			*obeBonePtr;
	INode			*nodePtr;
	Mesh			*meshPtr;
	ImpNode			*importNode;

	int				noof, ival;
	char			ident[32];
	TAnimSegment	segment;

	Interval		interval;
	LONG 			animLength, framesPerSecond, frameCurrDisp;

	int				chunkDataFilePos, currentFilePos;
	int				i;

	int				skipDataLength, retval;

	char			*genesisDataPtr, *extraDataPtr, *charDataPtr;
	int				genesisDataLength, genesisDataCRC, extraDataLength;

	TPolygonData	*polygonData;
	int				last;

	LONG 			*terData, *NDOData;
	UCHAR			*dualAlphaData;
	UCHAR			a0,a1,a2;
	UFLOAT			ufloat;

	Object			*objRef;
	Modifier		*perFaceMod;
	ModContext		*modContext;
	IDerivedObject	*derivedObjMod;

	PerFaceModData	*perFaceData;
	PerFaceEntry	*perFace;


	// read the chunk header from the open file
	if (ReadChunkHead(&chunkHead) == 0)
		return 0;

	// record the file position before the read
	chunkDataFilePos = ftell(fileHandle);

	// update the progress indicator
	if (progressScaler != 0.f)
		ip->ProgressUpdate((int)((float)ftell(fileHandle)/progressScaler));
	if (ip->GetCancel())
	{
		retval = MessageBox(ip->GetMAXHWnd(), _T("Really Cancel"), _T("Question"), MB_ICONQUESTION | MB_YESNO);
		if (retval == IDNO)
			ip->SetCancel(FALSE);
		else
			// !!!!!!!!!!!
			ip->SetCancel(FALSE);
	}

	// read in the specific chunk
	switch (chunkHead.chunkID)
	{
		// read in animation segments
		case OBECHUNK_ANIMSEGMENTS:

			// number of segments to follow
			fread(&noof, 4, 1, fileHandle);

			segmentTab.SetCount(noof);

			// read in all segments
			for (i=0; i<noof; i++)
			{
				// read ident
				fread(ident, 1, 32, fileHandle);
				ident[31] = 0;
				_tcsncpy(segment.ident, _T(ident), 32);
				// read anim start frame
				fread(&ival, 4, 1, fileHandle);
				segment.start = ival;
				// read end frame
				fread(&ival, 4, 1, fileHandle);
				segment.end = ival;
				// read flags
				fread(&ival, 4, 1, fileHandle);
				segment.flags = ival;
				// read fps
				fread(&ival, 4, 1, fileHandle);
				segment.fps = ival;
				// read custom float
				fread(&ival, 4, 1, fileHandle);
				segment.custom = ival;

				segmentTab[i] = segment;
			}
			break;

		// read in animation time
		case OBECHUNK_ANIMTIME:
			fread(&animLength, sizeof(long), 1, fileHandle);
			fread(&framesPerSecond, sizeof(long), 1, fileHandle);
			fread(&frameCurrDisp, sizeof(long), 1, fileHandle);
			if (configImportAnimation)
			{
				SetFrameRate((int)framesPerSecond);
				interval.Set(1, animLength*GetTicksPerFrame());
				importPtr->SetAnimRange(interval);

				DPrintf("Anim length: %d, Frames per second: %d, Current frame: %d", animLength, framesPerSecond, frameCurrDisp);
			}
			break;

		// read the chunks contained in this object
		case OBECHUNK_OBJECT :
			return READ_DATA_CHUNK;

		// read end
		case OBECHUNK_END:
			return READ_END_CHUNK;

		// read in mesh
		case OBECHUNK_MESH:

			// ** Read In OBE Mesh 

			obeMeshPtr = new ObeMesh;

			// read file into obe mesh
			if (obeMeshPtr->Read(fileHandle, chunkHead.chunkVersion) == 0)
				return READ_ERROR;

			// create our PerFaceData instance if needed
			perFaceData = NULL;
			if (configImportPerFaceData &&
				obeMeshPtr->numPoly > 0 && obeMeshPtr->numVert > 0)
			{
				perFaceData = PerFaceData_CreateData();
				perFaceData->SetDataName(_T("OBE Data"));
			}

			// convert the mesh into a max mesh
			if ((meshPtr = ObeMeshToMesh(obeMeshPtr, perFaceData)) == NULL)
				return READ_ERROR;

			// convert the mesh into a max node
			if ((importNode = ObeMeshToINode(obeMeshPtr, meshPtr)) == NULL)
				return READ_ERROR;
			nodePtr = importNode->GetINode();

			// rebuild hierarchy
			if (parentNodePtr != NULL)
				parentNodePtr->AttachChild(nodePtr, 0);
			else
				objectRootNode = nodePtr;

			// read all this nodes children
			while (ReadFile(nodePtr) == READ_DATA_CHUNK);

			// record the file position after the read
			currentFilePos = ftell(fileHandle);

			// calculate this meshes genesis and extra data lengths
			genesisDataLength = extraDataLength = chunkHead.chunkLength - (currentFilePos - chunkDataFilePos);
			if (chunkHead.chunkVersion >= 8)
				genesisDataLength -= obeMeshPtr->loadNumPolys*4;
			if (chunkHead.chunkVersion >= 9)
				genesisDataLength -= obeMeshPtr->loadNumPolys*4;
			if (chunkHead.chunkVersion >= 10)
				genesisDataLength -= obeMeshPtr->loadNumPolys*36;
			if (chunkHead.chunkVersion >= 11)
				genesisDataLength -= 32;
			extraDataLength -= genesisDataLength;

			// genesis data block
			DPrintf("Found %d bytes of genesis data on '%s'", genesisDataLength, obeMeshPtr->meshName);
			if (genesisDataLength > 0)
			{
				// allocate memory for the genesis data and read in
				genesisDataPtr = (char *)malloc(4+genesisDataLength);		// allow space for crc
				fread(genesisDataPtr+4, genesisDataLength, 1, fileHandle);

				// calculate crc for the genesis data
				genesisDataCRC = UpdateCRCData((genesisDataPtr+4), genesisDataLength);
				(*(int *)genesisDataPtr) = genesisDataCRC;

				// add the genesis data to this nodes appdata chunk
				nodePtr->RemoveAppDataChunk(
								Class_ID(GEOMOBJECT_CLASS_ID, TRIOBJ_CLASS_ID),
								SCENE_IMPORT_CLASS_ID,
								ADID_GENESIS_DATA);
				nodePtr->AddAppDataChunk(
								Class_ID(GEOMOBJECT_CLASS_ID, TRIOBJ_CLASS_ID),
								SCENE_IMPORT_CLASS_ID,
								ADID_GENESIS_DATA,
								4+genesisDataLength, genesisDataPtr);
				DPrintf("Genesis data attached to node '%s'. CRC: 0x%x", obeMeshPtr->meshName, genesisDataCRC);
			}


			// ** Handle Extra Mesh Data Block (Legacy Of Matt Cloy)

			// extra data block
			DPrintf("Found %d bytes of extra data on '%s'", extraDataLength, obeMeshPtr->meshName);
			if (extraDataLength > 0)
			{
				// allocate and read in the extra data block
				extraDataPtr = (char *)malloc(extraDataLength);
				fread(extraDataPtr, extraDataLength, 1, fileHandle);
				charDataPtr = extraDataPtr;

				// ** Save All Terrain Types

				if (chunkHead.chunkVersion >= 8)
				{
					if (perFaceData)
					{
						terData = (LONG *)charDataPtr;
						perFace = NULL;
						for (i=0; i<meshPtr->numFaces; i++)
						{
							perFace = perFaceData->GetNextFace(perFace);
							if (perFace == NULL || (polygonData = (TPolygonData *)perFace->GetData()) == NULL)
								continue;
							polygonData->terFlag = terData[ obeMeshPtr->loadPolyOrder[i]];
						}
					}
					charDataPtr += obeMeshPtr->loadNumPolys*4;			// skip chunk
				}

				// ** Save All NDO Flags

				if (chunkHead.chunkVersion >= 9)
				{
					if (perFaceData)
					{
						NDOData = (LONG *)charDataPtr;
						perFace = NULL;
						for (i=0; i<meshPtr->numFaces; i++)
						{
							perFace = perFaceData->GetNextFace(perFace);
							if (perFace == NULL || (polygonData = (TPolygonData *)perFace->GetData()) == NULL)
								continue;
							polygonData->NDOFlag = NDOData[obeMeshPtr->loadPolyOrder[i]];
						}
					}
					charDataPtr += obeMeshPtr->loadNumPolys*4;			// skip chunk

				}

				// ** Save All Dual Texture Info And Polygon Vertex Gouraud Alphas

				if (chunkHead.chunkVersion >= 10)
				{
					last = -1;										// invalidate last polygon order
					dualAlphaData = (UCHAR *)charDataPtr;
					perFace = NULL;
					for (i=0; i<meshPtr->numFaces; i++)
					{
						perFace = (perFaceData == NULL) ? NULL : perFaceData->GetNextFace(perFace);
						polygonData = (perFace == NULL) ? NULL : (TPolygonData *)perFace->GetData();

						if (polygonData != NULL)
							memcpy(&polygonData->dualTexture, &dualAlphaData[(obeMeshPtr->loadPolyOrder[i]*36)], 32);

						// polygon alpha values
						if (obeMeshPtr->loadPolyOrder[i] == last)
						{
							// this tri poly is the second part of a split quad.. therefore use second part quad alphas
							a0 = dualAlphaData[last*36+32+2];
							a1 = dualAlphaData[last*36+32+3];
							a2 = dualAlphaData[last*36+32+0];

							// save alpha's in OBE data
							if (polygonData != NULL)
							{
								polygonData->vertRGBA[0][3] = a0;
								polygonData->vertRGBA[1][3] = a1;
								polygonData->vertRGBA[2][3] = a2;
							}

							// also need to pack alpha's into max mesh
							ufloat.f = meshPtr->vertCol[i*3+0].x;
							ufloat.f8[3] = a0;
							meshPtr->vertCol[i*3+0].x = ufloat.f;

							ufloat.f = meshPtr->vertCol[i*3+1].x;
							ufloat.f8[3] = a1;
							meshPtr->vertCol[i*3+1].x = ufloat.f;

							ufloat.f = meshPtr->vertCol[i*3+2].x;
							ufloat.f8[3] = a2;
							meshPtr->vertCol[i*3+2].x = ufloat.f;
						}
						else
						{
							last = obeMeshPtr->loadPolyOrder[i];
							a0 = dualAlphaData[last*36+32+0];
							a1 = dualAlphaData[last*36+32+1];
							a2 = dualAlphaData[last*36+32+2];

							// save alpha's in OBE data
							if (polygonData != NULL)
							{
								polygonData->vertRGBA[0][3] = a0;
								polygonData->vertRGBA[1][3] = a1;
								polygonData->vertRGBA[2][3] = a2;
							}

							// also need to pack alpha's into max mesh
							ufloat.f = meshPtr->vertCol[i*3+0].x;
							ufloat.f8[3] = a0;
							meshPtr->vertCol[i*3+0].x = ufloat.f;

							ufloat.f = meshPtr->vertCol[i*3+1].x;
							ufloat.f8[3] = a1;
							meshPtr->vertCol[i*3+1].x = ufloat.f;

							ufloat.f = meshPtr->vertCol[i*3+2].x;
							ufloat.f8[3] = a2;
							meshPtr->vertCol[i*3+2].x = ufloat.f;
						}
					}
					charDataPtr += obeMeshPtr->loadNumPolys*(32+4);		// skip chunk
				}

				// ** Phong Texture Name

				if (chunkHead.chunkVersion >= 11)
				{
					charDataPtr += 32;									// skip chunk
				}

				if ((charDataPtr - extraDataPtr) == extraDataLength)
					DPrintf("Extra data valid");
				else
					DPrintf("Extra data invalid. Data read: %d", extraDataPtr - charDataPtr);

				// release the extra data block
				SAFE_FREE(extraDataPtr);
			}

			// now we have completely finished with our mesh we can attach it to our node
			{
				TriObject *triObject;
				// create a tri object shell to contain our mesh
				triObject = CreateNewTriObject();
				triObject->mesh = *meshPtr;
				// set the object that this node references
				importNode->Reference(triObject);
			}

			// attach a "PerFaceData" modifier to this node mesh
			if (perFaceData)
			{
				perFaceMod = (Modifier *)ip->CreateInstance(OSM_CLASS_ID, PERFACEDATA_CLASS_ID);
				if (perFaceMod == NULL)
				{
					// unable to create our modifier instance.. delete all our mesh face data
					SAFE_DELETE(perFaceData)
				}
				else
				{
					// format this data
					TCHAR		filen[260];
					CPMLevel	*formatInst;
					_tcscpy(filen, ip->GetDir(APP_PLUGCFG_DIR));
					_tcscat(filen, _T("\\JobeData.mft"));
					if ((formatInst = pmLoadLevel(filen)) != NULL)
						perFaceData->SetDataFormat(formatInst, TRUE, _T("Jobe Face Data"));

					// get this nodes object ref and create new reference object
					objRef = nodePtr->GetObjectRef();
					derivedObjMod = CreateDerivedObject(objRef);

					// create our mod context.. (this should be okay to create in this module)
					modContext = PerFaceData_CreateModContext();
					if (modContext != NULL)
					{
						// push our data in the mod context
						modContext->localData = perFaceData;

						// add our modifier to this new object
						derivedObjMod->SetAFlag(A_LOCK_TARGET);
						derivedObjMod->AddModifier(perFaceMod, modContext);
						derivedObjMod->ClearAFlag(A_LOCK_TARGET);

						// use the new object for this node
						nodePtr->SetObjectRef(derivedObjMod);
					}
				}
			}

			// as the modifier is completely cloned on attaching.. we can safely delete our PerFaceData instance
			SAFE_DELETE(perFaceData);

			// delete our mesh instance
			SAFE_DELETE(obeMeshPtr)
			break;

		// read in bone
		case OBECHUNK_BONE:

			obeBonePtr = new ObeBone;

			// read in bone data
			if (obeBonePtr->Read(fileHandle, chunkHead.chunkVersion) == 0)
				return READ_ERROR;

			// create a space warp modifier for our referenced / skinned mesh
			CreateSkinWSMod(obeBonePtr->meshNameRef);

			// convert the obe bone into a max bone node
			if ((nodePtr = ObeBoneToINode(obeBonePtr)) == NULL)
				return READ_ERROR;

			// register skin data in bone
			RegisterBoneVertexAssigns(obeBonePtr, nodePtr);
			// register bone data in referenced mesh node
			RegisterSkinBoneRefs(obeBonePtr->meshNameRef, nodePtr);

			// rebuild hierarchy
			if (parentNodePtr != NULL)
				parentNodePtr->AttachChild(nodePtr, 0);
			else
				objectRootNode = nodePtr;

			// read all this nodes children
			while (ReadFile(nodePtr) == READ_DATA_CHUNK);

			// record the file position after the read
			currentFilePos = ftell(fileHandle);

			// do we need to skip any data spurious data?
			skipDataLength = chunkHead.chunkLength - (currentFilePos - chunkDataFilePos);
			if (skipDataLength != 0)
				fseek(fileHandle, (long)skipDataLength, SEEK_CUR);

			// delete our bone instance
			SAFE_DELETE(obeBonePtr)
			break;

		// skip all other chunk types
		default:
			fseek(fileHandle, (long)chunkHead.chunkLength, SEEK_CUR);
			break;
	}
	return READ_DATA_CHUNK;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ObeMeshToMesh
   Purpose : converts our obe mesh via user options into a max mesh AND adds face
		   : face data along the way
   Parameters : obe mesh pointer
   Returns : max mesh pointer
   Info : 
*/

Mesh *OBEImport::ObeMeshToMesh(ObeMesh *obeMeshPtr, PerFaceModData *perFaceData)
{
	Mesh			*meshPtr;
	int				i, j;
	float			x, y, z;
	TPolygonData	*polygonData;
	PolyType		*polygon;
	PerFaceEntry	*perFace;
	TIME_VALUE_KEY	timeKey;
#if PERFACEDATA_MAPPING_CHANNEL > 1
	TVFace			*mapFace;
#endif
	Face			*fA, *fB;
	VertColor		vc;
	UVVert			uv;
	UINT			ut, vt, pv, id;
	UFLOAT			ufloat;


	// ** The first operation we need to do is convert to OBE mesh into a MAX
	// ** friendly mesh. This just means that we should convert all of the
	// ** polygons into tris. We will need to remember the original order of
	// ** polygons in order to add in the additional data later on.
	
	// since max meshes only support tris we need to convert our obe mesh into tris
	obeMeshPtr->ToTris();

	// create our intial max mesh
	if ((meshPtr = new Mesh) == NULL)
		return NULL;

	// validate all valid selections
	meshPtr->edgeSel.SetSize(obeMeshPtr->numPoly*3);
	meshPtr->faceSel.SetSize(obeMeshPtr->numPoly);
	meshPtr->vertSel.SetSize(obeMeshPtr->numVert);
	meshPtr->vertHide.SetSize(obeMeshPtr->numVert);

	// zero normals built
	meshPtr->normalsBuilt = 0;
#if MAX_RELEASE >= 3000
	meshPtr->normalCount = 0;
#endif

	// set max mesh vertices
	meshPtr->setNumVerts(obeMeshPtr->numVert);
	for (i=0; i<obeMeshPtr->numVert; i++)
	{
		obeMeshPtr->GetVert(i, &x, &y, &z);
		meshPtr->setVert(i, x, z, y);
	}


	// set max mesh faces

	// set number of tri faces
	meshPtr->setNumFaces(obeMeshPtr->numPoly);

	// set gouraud vertices and faces
    meshPtr->setNumVertCol(obeMeshPtr->numPoly*3);
	meshPtr->setNumVCFaces(obeMeshPtr->numPoly);

	// set texture mapping vertices and faces
	meshPtr->setNumTVerts(obeMeshPtr->numPoly*3);
	meshPtr->setNumTVFaces(obeMeshPtr->numPoly);

	// set all faces..
	for (i=0; i<obeMeshPtr->numPoly; i++)
	{
		// *VERY IMPORTANT* - zero smoothing group
		meshPtr->faces[i].smGroup = 0;

		polygon = &obeMeshPtr->polyArray[i];

		// allocate buffer for polygon data
		polygonData = (TPolygonData *)malloc(sizeof(TPolygonData));
		memset(polygonData, 0, sizeof(TPolygonData));

		// save common OBE polygon attributes
		polygonData->polyRGB[0] = polygon->colRGB[0];			// save colour
		polygonData->polyRGB[1] = polygon->colRGB[1];
		polygonData->polyRGB[2] = polygon->colRGB[2];
		polygonData->transMode  = polygon->transMode;			// save transluceny
		polygonData->transValue = polygon->transVal;
		polygonData->gourMode = polygon->gColMode;				// save gouraud mode
		polygonData->uTile = polygon->tileU;					// save UV tiling info
		polygonData->vTile = polygon->tileV;
		polygonData->flags = polygon->flags;					// save flags

		// is this polygon a sprite?
		if (polygon->flags & OBEPOLYFLAG_SPRITE)
		{
			// zero all vertex indices - unsure as to the effect of this
			meshPtr->faces[i].v[0] = meshPtr->faces[i].v[1] = meshPtr->faces[i].v[2] = 0;
			meshPtr->faces[i].flags = EDGE_ALL;					// default: show all edges

			// zero gouraud and texture mapping unique per polygon vertex
			for (j=0; j<3; j++)
			{
				// null gouraud values
				meshPtr->vertCol[i*3+j].x = 255;
				meshPtr->vertCol[i*3+j].y = 255;
				meshPtr->vertCol[i*3+j].z = 255;
				// null texture map uv
				meshPtr->setTVert(i*3+j, 0, 0, 0);
			}

			// set unique indices into vertex colour and texture mapping lists
			meshPtr->vcFace[i].t[0] = meshPtr->tvFace[i].t[0] = i*3+0;
			meshPtr->vcFace[i].t[1] = meshPtr->tvFace[i].t[1] = i*3+1;
			meshPtr->vcFace[i].t[2] = meshPtr->tvFace[i].t[2] = i*3+2;

			// save OBE polygon sprite attributes
			if (polygon->spriteInfoPtr)
			{
				polygon->spriteInfoPtr->xPos.GetKey(0, &timeKey);
				polygonData->sprxPos = timeKey.data;
				polygon->spriteInfoPtr->yPos.GetKey(0, &timeKey);
				polygonData->spryPos = timeKey.data;
				polygon->spriteInfoPtr->zPos.GetKey(0, &timeKey);
				polygonData->sprzPos = timeKey.data;
				polygon->spriteInfoPtr->xSize.GetKey(0, &timeKey);
				polygonData->sprxSize = timeKey.data;
				polygon->spriteInfoPtr->ySize.GetKey(0, &timeKey);
				polygonData->sprySize = timeKey.data;
				polygonData->sprxFlipped = polygon->spriteInfoPtr->xFlipped;
				polygonData->spryFlipped = polygon->spriteInfoPtr->yFlipped;
			}
		}
		else
		{
			// set indices into vertex list
			meshPtr->faces[i].v[0] = polygon->verts[0].vertIndex;
			meshPtr->faces[i].v[1] = polygon->verts[1].vertIndex;
			meshPtr->faces[i].v[2] = polygon->verts[2].vertIndex;
			meshPtr->faces[i].flags = EDGE_ALL;					// default: show all edges

			// set gouraud and texture mapping unique per polygon vertex
			for (j=0; j<3; j++)
			{
				// -- set gouraud vertex colours
				// pack RGBA into R(x) value
				ufloat.f8[0] = polygon->verts[j].gCol[0];
				ufloat.f8[1] = polygon->verts[j].gCol[1];
				ufloat.f8[2] = polygon->verts[j].gCol[2];
				ufloat.f8[3] = polygon->verts[j].gCol[3];
				vc.x = ufloat.f;
				// pack polygon colour R,G or B into G(y) value (top char)
				ufloat.f8[0] = 0;
				ufloat.f8[1] = 0;
				ufloat.f8[2] = 0;
				ufloat.f8[3] = 0;
				switch (j)
				{
				case 0:
					ufloat.f8[0] = polygon->colRGB[0];
					break;
				case 1:
					ufloat.f8[0] = polygon->colRGB[1];
					break;
				case 2:
					ufloat.f8[0] = polygon->colRGB[2];
					break;
				}
				vc.y = ufloat.f;
				// set version number and invalidate texture range for ident into B(z) value
				ufloat.f8[0] = 0;
				ufloat.f8[1] = 0;
				ufloat.f8[2] = PACKED_VERTS_VERSION;
				ufloat.f8[3] = 255;
				vc.z = ufloat.f;

				meshPtr->vertCol[i*3+j] = vc;

				// -- set texture map UVs
				// set U into U(x) value
				uv.x = polygon->verts[j].u;
				// set 1-V into V(y) value
				uv.y = 1.0f - polygon->verts[j].v;
				// pack UVTile, version number and ident into W(z) value
				ut = (UINT) polygon->tileU / 100;
				vt = (UINT) polygon->tileV / 100;
				pv = (UINT)PACKED_VERTS_VERSION;
				id = (UINT)255;
				ufloat.f32 = ((id & 255)<<(6+18)) | ((pv & 63)<<(9+9)) | ((vt & 511)<<(9+0)) | ((ut & 511)<<(0+0));
				uv.z = ufloat.f;

				meshPtr->setTVert(i*3+j, uv);
			}

			// set unique indices into vertex colour and texture mapping lists
			meshPtr->vcFace[i].t[0] = meshPtr->tvFace[i].t[0] = i*3+0;
			meshPtr->vcFace[i].t[1] = meshPtr->tvFace[i].t[1] = i*3+1;
			meshPtr->vcFace[i].t[2] = meshPtr->tvFace[i].t[2] = i*3+2;

			// save OBE polygon vertices attributes
			if (polygon->verts)
				for (j=0; j<3; j++)
				{
					polygonData->vertRGBA[j][0] = polygon->verts[j].gCol[0];
					polygonData->vertRGBA[j][1] = polygon->verts[j].gCol[1];
					polygonData->vertRGBA[j][2] = polygon->verts[j].gCol[2];
					polygonData->vertRGBA[j][3] = 255;			// gouraud alpha loads later from extra chunks
					polygonData->vertLights[j] = polygon->verts[j].lightIntensity;
				}
		}

		// if we are saving per face data..
		if (perFaceData)
		{
			// add our face and set unique ident
			perFace = perFaceData->AddFace();
			if (perFace != NULL)
			{
				perFace->SetIdent(i*3+0, i*3+1, i*3+2);

				// attach polygon data to face
				perFace->SetData(polygonData, sizeof(TPolygonData));
			}
		}

		SAFE_FREE(polygonData);
	}


#if PERFACEDATA_MAPPING_CHANNEL > 1
	// ** If we are building for Max3 we can use one of the 100 texture channels
	// ** to help us store our "per face data".
	// ** We therefore need to setup our mapping channel to store this data.

	if (perFaceData)
	{
		// setup mapping support
		meshPtr->setNumMaps(PERFACEDATA_MAPPING_CHANNEL+1, TRUE);
		meshPtr->setMapSupport(PERFACEDATA_MAPPING_CHANNEL, TRUE);
		meshPtr->setNumMapVerts(PERFACEDATA_MAPPING_CHANNEL, meshPtr->getNumTVerts());

		// initialise our mapping data
		if ((mapFace = meshPtr->mapFaces(PERFACEDATA_MAPPING_CHANNEL)) != NULL)
			for (i=0; i<meshPtr->getNumFaces(); i++)
			{
				mapFace[i].setTVerts(i*3+0, i*3+1, i*3+2);
			}
	}
#endif


	// ** Use the load order polygon infomation and the quad->tri split method to
	// ** determine whether to display a quad or a tri

	// loop through all mesh faces
	for (i=0; i<(meshPtr->getNumFaces()-1); i++)
		if (obeMeshPtr->loadPolyOrder[i] == obeMeshPtr->loadPolyOrder[i+1])
		{
			fA = &meshPtr->faces[i];
			fB = &meshPtr->faces[i+1];
			if (fA->v[0] == fB->v[2] && fA->v[2] == fB->v[0])
			{
				// this pair of faces share an edge.. flag as quad
				fA->setEdgeVisFlags(EDGE_VIS, EDGE_VIS, EDGE_INVIS);
				fB->setEdgeVisFlags(EDGE_VIS, EDGE_VIS, EDGE_INVIS);
			}
		}


	// return the valid max mesh
	return meshPtr;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ObeMeshToINode
   Purpose : converts our obe mesh via user options into a max node
   Parameters : obe mesh pointer, max mesh pointer
   Returns : max node pointer
   Info : 
*/

ImpNode *OBEImport::ObeMeshToINode(ObeMesh *obeMeshPtr, Mesh *meshPtr)
{
	INode			*node;
	Matrix3			tm;
	ImpNode			*importNode;
//	TriObject		*triObject;
	Object			*boneObject;

	int				i, index;
					// animation..
	int				numKeys;
	Control			*nodeTMControl, *posLinControl, *rotLinControl, *sclLinControl;
	IKeyControl		*posKeyControl, *rotKeyControl, *sclKeyControl;
	ILinRotKey		rotKey;
	ILinPoint3Key	posKey;
	ILinScaleKey	sclKey;
					// tetxures
	TexInfNode		*textureInfoPtr;


	// create an import node
	importNode = importPtr->CreateNode();

	// set an identity transform
	tm.IdentityMatrix();
	importNode->SetTransform(0, tm);

	// set the name of this import node
	importNode->SetName(_T(obeMeshPtr->meshName));


	// ** If our mesh doesn't contain any polygons or vertices we should import
	// ** as a bone node.

	// null mesh?
	if (obeMeshPtr->numPoly == 0 && obeMeshPtr->numVert == 0)
	{
		// delete the max mesh as we don't need in any more
		SAFE_DELETE(meshPtr)

		// create a bone helper object to represent our mesh
		boneObject = (Object *)ip->CreateInstance(HELPER_CLASS_ID, Class_ID(BONE_CLASS_ID, 0));
		// set the object that this node references
		importNode->Reference(boneObject);

		// needed as helper objects default off
		node = importNode->GetINode();
		node->ShowBone(1);
	}
//	else
//	{
//		// create a tri object shell to contain our mesh
//		triObject = CreateNewTriObject();
//		triObject->mesh = *meshPtr;
//
//		// set the object that this node references
//		importNode->Reference(triObject);
//	}

	// get the max node from the import node
	node = importNode->GetINode();

	// set name - is this really necessary?
	node->SetName(_T(obeMeshPtr->meshName));

	// add the node into the scene
	importPtr->AddNodeToScene(importNode);

	// record this nodes entry
	meshNodeTab.SetCount(meshNodeTab.Count()+1);
	meshNodeTab[meshNodeTab.Count()-1] = node;

	// should we load the nodes animation?
	if (configImportAnimation)
	{
		// get the nodes base transform controller
		nodeTMControl = node->GetTMController();

		// setup linear sub controller for position, rotate and scale
		posLinControl = (Control *)ip->CreateInstance(CTRL_POSITION_CLASS_ID, Class_ID(LININTERP_POSITION_CLASS_ID, 0));
		nodeTMControl->SetPositionController(posLinControl);
		rotLinControl = (Control *)ip->CreateInstance(CTRL_ROTATION_CLASS_ID, Class_ID(LININTERP_ROTATION_CLASS_ID, 0));
		nodeTMControl->SetRotationController(rotLinControl);
		sclLinControl = (Control *)ip->CreateInstance(CTRL_SCALE_CLASS_ID, Class_ID(LININTERP_SCALE_CLASS_ID, 0));
		nodeTMControl->SetScaleController(sclLinControl);

		// position anim controller
		numKeys = obeMeshPtr->posX.GetNumKeys();
		posKeyControl = GetKeyControlInterface(posLinControl);
		posKeyControl->SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			posKey.time = obeMeshPtr->posX.keyArrayPtr[i].frameNum * GetTicksPerFrame();
			posKey.val.x = obeMeshPtr->posX.keyArrayPtr[i].data;
			posKey.val.z = obeMeshPtr->posY.keyArrayPtr[i].data;
			posKey.val.y = obeMeshPtr->posZ.keyArrayPtr[i].data;
			posKeyControl->SetKey(i, &posKey);
		}
		posKeyControl->SortKeys();

		// rotation anim controller
		numKeys = obeMeshPtr->orientationX.GetNumKeys();
		rotKeyControl = GetKeyControlInterface(rotLinControl);
		rotKeyControl->SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{				
			rotKey.time = obeMeshPtr->orientationX.keyArrayPtr[i].frameNum * GetTicksPerFrame();
			rotKey.val.x = obeMeshPtr->orientationX.keyArrayPtr[i].data;
			rotKey.val.z = obeMeshPtr->orientationY.keyArrayPtr[i].data;
			rotKey.val.y = obeMeshPtr->orientationZ.keyArrayPtr[i].data;
			rotKey.val.w = - obeMeshPtr->orientationW.keyArrayPtr[i].data;
			rotKeyControl->SetKey(i, &rotKey);
		}
		rotKeyControl->SortKeys();

		// scale anim controller
		numKeys = obeMeshPtr->scaleX.GetNumKeys();
		sclKeyControl = GetKeyControlInterface(sclLinControl);
		sclKeyControl->SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			sclKey.time = obeMeshPtr->scaleX.keyArrayPtr[i].frameNum * GetTicksPerFrame();
			sclKey.val.s.x = obeMeshPtr->scaleX.keyArrayPtr[i].data;
			sclKey.val.s.z = obeMeshPtr->scaleY.keyArrayPtr[i].data;
			sclKey.val.s.y = obeMeshPtr->scaleZ.keyArrayPtr[i].data;

			sclKeyControl->SetKey(i, &sclKey);	
		}
		sclKeyControl->SortKeys();
	}

	// does this mesh have any textures?
	for (i=0; i<obeMeshPtr->numPoly; i++)
		if (strlen(obeMeshPtr->polyArray[i].texture) != 0)
		{
			break;
		}
	// textures exist for this object
	if (i < obeMeshPtr->numPoly)
	{
		// record this nodes texture infomation
		textureInfoPtr = new TexInfNode;
		textureInfoPtr->mesh = meshPtr;
		textureInfoPtr->iNode = node;
		textureInfoPtr->faceIdPtr = new int[obeMeshPtr->numPoly];
		textureInfoPtr->numFaces = obeMeshPtr->numPoly;
		// scan all of this nodes textures, adding unknowns
		for (i=0; i<obeMeshPtr->numPoly; i++)
		{
			// which texture does this polygon reference?
			index = texNameList->GetIdx(obeMeshPtr->polyArray[i].texture);
			if (index == -1)
			{
				texNameList->Add(obeMeshPtr->polyArray[i].texture);
				index = texNameList->ListLen() - 1;
			}
			textureInfoPtr->faceIdPtr[i] = index;
		}
		// add this node texture infomation
    	nodeTexList->Add(textureInfoPtr);
	}

	// enable vertex colours in the viewport
	node->SetShadeCVerts(1);

	// return the valid max node
	return importNode;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::LoadAllTextures
   Purpose : load all required textures
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::LoadAllTextures()
{
	TCHAR			textureName[_MAX_PATH];
	int				i, j, found, len;
	StdMat			*mtl;
	BitmapTex		*bmp;
	TTextureSet		*textureSetPtr;
	TTexturePath	*texturePathPtr;


	// validate users texture set
	if (configTextureSetIndex >= (UINT)textureSets.Count())
		return;
	textureSetPtr = textureSets.Addr(configTextureSetIndex);

	// ** Create the texture library for use with this scene. This is really
	// ** just a Multi-Material, which has all the sub-materials assigned a
	// ** texture map on the diffuse channel.

	texLib = NewDefaultMultiMtl();
	if (texLib == NULL)
		return;
	texLib->SetNumSubMtls(texNameList->ListLen());		// set the number of sub materials
	texLib->SetName("Majik's textures");				// set the material name
	MtlBaseLib &mtlList = ip->GetMaterialLibrary();		// get the currently loaded material library
	mtlList.Add(texLib);								// add our materials to the library 

	DPrintf("Loading all required textures");

	// add all of our textures
	for (i=0; i<texNameList->ListLen(); i++)
	{
		// invalid texture name?
		if (texNameList->GetStr(i) == NULL || strlen(texNameList->GetStr(i)) < 3)
			continue;

		// search for this texture..
		found = 0;										// default: cannot fnd texture

		for (j=0; j<textureSetPtr->paths.Count(); j++)
			if ((texturePathPtr = textureSetPtr->paths.Addr(j)) != NULL)
			{
				if (texturePathPtr->flags & TEXPATHFLAG_ENABLED)
				{
					// create potential texture path..
					if ((len = _tcslen(texturePathPtr->path)) > 0)
					{
						// ** Entirely possible for a texture path to already have a directory
						// ** seperator appended.

						// need to append a directory seperator?
						if (texturePathPtr->path[len-1] != _T('\\'))
							_stprintf(textureName, "%s\\%s", textureSetPtr->paths[j].path, texNameList->GetStr(i));
						else
							_stprintf(textureName, "%s%s", textureSetPtr->paths[j].path, texNameList->GetStr(i));

						// does thie texture exist?
						if (GetFileAttributes(textureName) != -1)
						{
							// found texture!
							found = 1;
							break;
						}
					}
				}
			}

		if (found == 0)
		{
			// search failed.. just use the texture name
			_stprintf(textureName, "%s", texNameList->GetStr(i));
		}

		DPrintf("  %s texture '%s'", (found == 0) ? "Cannot find" : "Found", textureName);

		// add texture file into material library
		mtl = NewDefaultStdMat();						// create a new default material for the texture
		bmp = NewDefaultBitmapTex();					// and a new bitmap texture
		bmp->SetMapName(_T(textureName));				// set the texture source

		mtl->SetName(_T(texNameList->GetStr(i)));		// set the materials name
		mtl->SetSubTexmap(ID_DI, bmp);					// attach the texture to the material
		bmp = (BitmapTex *)mtl->GetSubTexmap(ID_DI);	// make sure we have the current ptr 

		mtl->EnableMap(ID_DI, TRUE);					// enable the diffuse (texture) map
		texLib->SetSubMtl(i, mtl);						// add the material to the main material

		// show the texture map inside the viewport?
		if (found && configShowTextures)
			ip->ActivateTexture(bmp, texLib, i);
	}
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::AssignTexturesToNodes
   Purpose : assign all textures to imported nodes
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::AssignTexturesToNodes()
{
	int			i, j;
	INode		*nodePtr;
	Mesh		*meshPtr;
	TexInfNode	*nodeTexturePtr;

	for (i=0; i<nodeTexList->ListLen(); i++)
	{
		nodeTexturePtr = nodeTexList->GetByIndex(i);
		if (nodeTexturePtr)
		{
			nodePtr = nodeTexturePtr->iNode;
			if (nodePtr != NULL)
			{
				// assign the texture library to the node
				nodePtr->SetMtl(texLib);

				// ** Please note that the above function effects the node at the mesh level,
				// ** therefore any previous mesh evaluation for this node is now invalid.

				meshPtr = GetNodeMesh(nodePtr);
				for (j=0; j<meshPtr->numFaces; j++)
					meshPtr->faces[j].flags = ((meshPtr->faces[j].flags & FACE_MATID_MASK) | HAS_TVERTS) | ((DWORD) (nodeTexturePtr->faceIdPtr[j]) << FACE_MATID_SHIFT);
			}
		}
	}
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::SetNoteTrackAnimSegments();
   Purpose : setup the root objects note tracks from the loaded animation segments
   Parameters : 
   Returns : 
   Info : 
*/

void OBEImport::SetNoteTrackAnimSegments()
{
	int				i, noof, start, next, fps;
	DefNoteTrack	*noteTrack;
	TCHAR			charbuf[256], evalbuf[64];
	Interval		animRange;

	// is our object root node defined?
	if (objectRootNode == NULL)
		return;

	// setup a default note track for our node
	noteTrack = (DefNoteTrack *)NewDefaultNoteTrack();
	objectRootNode->AddNoteTrack(noteTrack);

	// count up how many segment keys we actually need
	for (i=0, noof=0; i<segmentTab.Count(); i++)
	{
		// one per anim segment
		noof++;

		// do we need to add an extra note as a segment limiter?
		if ((i+1) < segmentTab.Count())
			next = segmentTab[i+1].start;
		else
		{
			animRange = ip->GetAnimRange();
			next = animRange.End()/GetTicksPerFrame();
		}
		if ((segmentTab[i].end+1) < next)
			noof++;
	}

	// set the number of required notes
	noteTrack->keys.Clear();
	noteTrack->keys.SetCount(noof);

	// add all anim segments as notes..
	for (i=0, noof=0; i<segmentTab.Count(); i++)
	{
		// set anim segment tag
		_tcscpy(charbuf, _T("#ANIMSEG\r\n"));
		// set identifier
		_tcscat(charbuf, segmentTab[i].ident);
		_tcscat(charbuf, _T("\r\n"));
		// set frames per second
		fps = segmentTab[i].fps;
		_stprintf(evalbuf, _T("%d%s"), fps, "fps\r\n");
		_tcscat(charbuf, evalbuf);

		// start frame
		start = segmentTab[i].start * GetTicksPerFrame();

		// add note key
		TSTR note(charbuf);
		noteTrack->keys[noof] = new NoteKey(start, note, 0);
		noof++;

		// do we need to add an extra note as a segment limiter?
		if ((i+1) < segmentTab.Count())
			next = segmentTab[i+1].start;
		else
		{
			animRange = ip->GetAnimRange();
			next = animRange.End()/GetTicksPerFrame();
		}
		if ((segmentTab[i].end+1) < next)
		{
			// add segment limiter
			_tcscpy(charbuf, _T("#ANIMSEGEND\r\n"));
			start = segmentTab[i].end * GetTicksPerFrame();
			TSTR note(charbuf);
			noteTrack->keys[noof] = new NoteKey(start, note, 0);
			noof++;
		}
	}

	// acknowledge the anim segments
	segmentTab.SetCount(0);
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::CreateSkinWSMod
   Purpose : create a world space modifier for our referenced mesh
   Parameters : referenced mesh name pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int OBEImport::CreateSkinWSMod(char * meshRefPtr)
{
	INode			*refNode;
	WSMObject		*WSObj;
	IDerivedObject	*WSDerObj;
	Modifier		*WSMod;

	// has our referenced mesh been loaded yet?
	if ((refNode = GetMeshNode(meshRefPtr)) == NULL)
		return 0;
	// has our referenced mesh already had a skin modifier applied?
	if (IsNodeSkinWSMod(refNode))
		return 1;

	// before we apply the skin modifier we need to create a skin modifier object
	if (WSObjNodePtr == NULL)
	{
		WSObj = NULL;
		if ((WSObj = (WSMObject *)ip->CreateInstance(WSM_OBJECT_CLASS_ID, SKIN_OBJ_CLASS_ID)) == NULL)
			return 0;
		if ((WSObjNodePtr = ip->CreateObjectNode(WSObj)) == NULL)
			return 0;
		DPrintf("Created skin modifier object node");
	}

	// Apply a skin modifier to our mesh to be skinned

	// create WSModifier derived object for referenced node if not already created
	refNode->CreateWSMDerivedObject();

	// get derived object from node
	WSDerObj = NULL;
	if ((WSDerObj = refNode->GetWSMDerivedObject()) == NULL)
		return 0;						// error creating derived object

	// create a space warp modifier
	WSMod = NULL;
	if ((WSMod = ((WSMObject *)WSObjNodePtr->GetObjOrWSMRef())->CreateWSMMod(WSObjNodePtr)) == NULL)
		return 0;						// error creating modifier

	// finally add the modifier to the derived object
	WSDerObj->AddModifier(WSMod);

	DPrintf("Applied skin modifier to mesh: '%s'", meshRefPtr);
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::GetMeshNode
   Purpose : get mesh node from log by name
   Parameters : mesh node name
   Returns : mesh node pointer, NULL error
   Info : 
*/

INode * OBEImport::GetMeshNode(char * namePtr)
{
	int	i;
	INode * node;

	if (namePtr == NULL)
		return NULL;
	for(i=0; i<meshNodeTab.Count(); i++)
		if ((node = meshNodeTab[i]) != NULL)
		{
			if (!_stricmp(namePtr, node->GetName()))
				return node;
		}
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::IsNodeSkinWSMod
   Purpose : as this node a derived skin world space modifier attached?
   Parameters : node pointer
   Returns : 1 - attached, 0 - not attached
   Info : 
*/

int OBEImport::IsNodeSkinWSMod(INode * node)
{
	int				i, j;
	ReferenceTarget	*refTarget;
	IDerivedObject	*WSDerObj;
	Modifier		*mod;

	if (node == NULL)
		return 0;

	// loop around all scene nodes references, looking for derived space warp reference
	for (i=0; i<node->NumRefs(); i++)
	{
		refTarget = node->GetReference(i);
		if (refTarget != NULL && refTarget->ClassID() == Class_ID(WSM_DERIVOB_CLASS_ID, 0))
		{
			WSDerObj = (IDerivedObject *)refTarget;
			for(j=0; j<WSDerObj->NumModifiers(); j++)
			{
				mod = WSDerObj->GetModifier(j);
				if (mod != NULL && mod->SuperClassID() == WSM_CLASS_ID && mod->ClassID() == SKIN_MOD_CLASS_ID)
					return 1;				// skin space warp attached to this node
			}
		}
	}
	// no skin space warp attached to this node
	return 0;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::ObeBoneToINode
   Purpose : converts our obe bone via user options into a max node
   Parameters : obe bone pointer
   Returns : max bone node pointer
   Info : 
*/

INode *OBEImport::ObeBoneToINode(ObeBone *obeBonePtr)
{
	Object			*boneObject;
	ImpNode			*importNode;
	INode			*node;
	Matrix3			tm;
	int				i;
					// animation..
	int				numKeys;
	Control			*nodeTMControl, *posLinControl, *rotLinControl, *sclLinControl;
	IKeyControl		*posKeyControl, *rotKeyControl, *sclKeyControl;
	ILinRotKey		rotKey;
	ILinPoint3Key	posKey;
	ILinScaleKey	sclKey;

	// create a bone helper object
	boneObject = (Object *)ip->CreateInstance(HELPER_CLASS_ID, Class_ID(BONE_CLASS_ID, 0));

	// create an import node to contain our object
	importNode = importPtr->CreateNode();
	// set the object that this node references
	importNode->Reference(boneObject);
	// set the name of this import bone
	importNode->SetName(_T(obeBonePtr->boneName));
	// set an identity transform
	tm.IdentityMatrix();
	importNode->SetTransform(0, tm);

	// get the max node from the import node
	node = importNode->GetINode();
	// set name - is this really necessary?
	node->SetName(_T(obeBonePtr->boneName));

	// should we load the nodes animation?
	if (configImportAnimation)
	{
		// get the nodes base transform controller
		nodeTMControl = node->GetTMController();

		// setup linear sub controller for position, rotate and scale
		posLinControl = (Control *)ip->CreateInstance(CTRL_POSITION_CLASS_ID, Class_ID(LININTERP_POSITION_CLASS_ID, 0));
		nodeTMControl->SetPositionController(posLinControl);
		rotLinControl = (Control *)ip->CreateInstance(CTRL_ROTATION_CLASS_ID, Class_ID(LININTERP_ROTATION_CLASS_ID, 0));
		nodeTMControl->SetRotationController(rotLinControl);
		sclLinControl = (Control *)ip->CreateInstance(CTRL_SCALE_CLASS_ID, Class_ID(LININTERP_SCALE_CLASS_ID, 0));
		nodeTMControl->SetScaleController(sclLinControl);

		// position anim controller
		numKeys = obeBonePtr->posX.GetNumKeys();
		posKeyControl = GetKeyControlInterface(posLinControl);
		posKeyControl->SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			posKey.time = obeBonePtr->posX.keyArrayPtr[i].frameNum * GetTicksPerFrame();
			posKey.val.x = obeBonePtr->posX.keyArrayPtr[i].data;
			posKey.val.z = obeBonePtr->posY.keyArrayPtr[i].data;
			posKey.val.y = obeBonePtr->posZ.keyArrayPtr[i].data;
			posKeyControl->SetKey(i, &posKey);
		}
		posKeyControl->SortKeys();

		// rotation anim controller
		numKeys = obeBonePtr->orientationX.GetNumKeys();
		rotKeyControl = GetKeyControlInterface(rotLinControl);
		rotKeyControl->SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{				
			rotKey.time = obeBonePtr->orientationX.keyArrayPtr[i].frameNum * GetTicksPerFrame();
			rotKey.val.x = obeBonePtr->orientationX.keyArrayPtr[i].data;
			rotKey.val.z = obeBonePtr->orientationY.keyArrayPtr[i].data;
			rotKey.val.y = obeBonePtr->orientationZ.keyArrayPtr[i].data;
			rotKey.val.w = - obeBonePtr->orientationW.keyArrayPtr[i].data;
			rotKeyControl->SetKey(i, &rotKey);
		}
		rotKeyControl->SortKeys();

		// scale anim controller
		numKeys = obeBonePtr->scaleX.GetNumKeys();
		sclKeyControl = GetKeyControlInterface(sclLinControl);
		sclKeyControl->SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			sclKey.time = obeBonePtr->scaleX.keyArrayPtr[i].frameNum * GetTicksPerFrame();
			sclKey.val.s.x = obeBonePtr->scaleX.keyArrayPtr[i].data;
			sclKey.val.s.z = obeBonePtr->scaleY.keyArrayPtr[i].data;
			sclKey.val.s.y = obeBonePtr->scaleZ.keyArrayPtr[i].data;
			sclKeyControl->SetKey(i, &sclKey);	
		}
		sclKeyControl->SortKeys();
	}

	// needed as helper objects default off
	node->ShowBone(1);

	// add the node into the scene
	importPtr->AddNodeToScene(importNode);

	// return the valid max bone node
	return node;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::RegisterBoneVertexAssigns
   Purpose : registers skin data in the bone node
   Parameters : obe bone pointer, bone node pointer
   Returns : 1 - noerror, 0 - error
   Info : the vertices which are assigned to a bone are added as appdata to the bone
		: node, this is then picked up by the skin modifier plugin
*/

int OBEImport::RegisterBoneVertexAssigns(ObeBone * obeBonePtr, INode * nodePtr)
{
	SKIN_DATA_VERTEX	*dataPtr;
	VertexAssign		*assignPtr;
	int					i;

	// no need to register any data if bone as know vedrtex assignments
	if (obeBonePtr->numVertAssigns == 0)
		return 1;					// this is okay

	// allocate and initialise vertex assignment data buffer
	dataPtr = (SKIN_DATA_VERTEX *)malloc(obeBonePtr->numVertAssigns*sizeof(SKIN_DATA_VERTEX));
	for(i=0; i<obeBonePtr->numVertAssigns; i++)
	{
		assignPtr = &obeBonePtr->vertAssignList[i];
		dataPtr[i].idxVert = assignPtr->vertIndex;
		dataPtr[i].boneVec.x = assignPtr->assignList.x->keyArrayPtr[0].data;
		dataPtr[i].boneVec.y = assignPtr->assignList.z->keyArrayPtr[0].data;
		dataPtr[i].boneVec.z = assignPtr->assignList.y->keyArrayPtr[0].data;
	}

	// register vertex assignments to the bone node
	SKINREG_AddSkinData(nodePtr, (DWORD)ADID_SKIN_DATA, (DWORD)obeBonePtr->numVertAssigns*sizeof(SKIN_DATA_VERTEX), (void*)dataPtr);

	// data attached
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEImport::RegisterSkinBoneRefs
   Purpose : register bone referenece with the referenced / skinned mesh
   Parameters : referenced mesh name pointer, bone node pointer
   Returns : 1 - noerror, 0 - error
   Info : the bones which are used by the skin modifier are added to referenced / skinned
		: mesh node, this is then picked up by the skin modifier plugin
*/

int OBEImport::RegisterSkinBoneRefs(char *meshRefPtr, INode *node)
{
	INode			*refNode;
	DWORD			*nodeTab, *newNodeTab;
	AppDataChunk	*dataChunk;
	int				i, noofNodes;

	// get our referenced mesh node to skin
	if ((refNode = GetMeshNode(meshRefPtr)) == NULL)
		return 0;						// cannot find the mesh node

	// try and append this bone to current list
	dataChunk = SKINREG_GetSkinData(refNode, (DWORD)ADID_SKIN_REGISTER);
	if (dataChunk == NULL)
	{
		// our bone node ref list doesn't exist.. create it
		newNodeTab = (DWORD *)malloc(sizeof(DWORD));
		if (newNodeTab != NULL)
		{
			newNodeTab[0] = (DWORD)node;
			noofNodes = 1;
		}
	}
	else
	{
		// extend the node ref list to include this bone
		noofNodes = dataChunk->length / sizeof(DWORD);
		nodeTab = (DWORD *)dataChunk->data;
		newNodeTab = (DWORD *)malloc(sizeof(DWORD)*(noofNodes+1));
		if (newNodeTab)
		{
			for (i=0; i<noofNodes; i++)
				newNodeTab[i] = nodeTab[i];
			newNodeTab[i] = (DWORD)node;

			noofNodes++;

			// current data is now invalid so release it
			SKINREG_RemoveSkinData(refNode, (DWORD)ADID_SKIN_REGISTER);
		}
	}

	// if these still empty, error occurred in allocs
	if (newNodeTab == NULL || noofNodes == 0)
		return 0;

	// add bone node list into referenced node
	SKINREG_AddSkinData(refNode, (DWORD)ADID_SKIN_REGISTER, noofNodes*sizeof(DWORD), (void *)newNodeTab);
	return 1;
}


// --------------------------------------------------------------------------------
// OBEImporter
// --------------------------------------------------------------------------------



/* --------------------------------------------------------------------------------
   Function : OBEImport::DoImport
   Purpose : perform the actual OBE file import
   Parameters : import obe file, import interface pointer, max interface pointer, suppress user prompts
   Returns : 
   Info : 
*/

DWORD WINAPI progressBarImportFunc(LPVOID arg)	{return(0);}

int OBEImport::DoImport(const TCHAR *fileNamePtr, ImpInterface * importPtr, Interface * ip, BOOL suppressPrompts)
{
	static TCHAR	charbuf[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR], name[_MAX_FNAME], ext[_MAX_EXT];
	int				fileLength;
	tm				*newtime;
	time_t			aclock;
	uchar			magic[4] = {'O', 'B', 'E', NULL};
	uchar			check[4];


	// get local time
	time(&aclock);
	newtime = localtime( &aclock );

	DPrintf("");
	DPrintf("===========================================================================");
	DPrintf("OBEFile Importer Plugin Debug Output Log");
	DPrintf("Filename: %s", fileNamePtr);
	DPrintf("%s", asctime(newtime));

	// save max and import interfaces
	this->ip = ip;
	this->importPtr = importPtr;

	// create unique name maker instance
	nameMakerPtr = ip->NewNameMaker();

	// save the import filename
	_tcscpy(importFileName, fileNamePtr);
	_tcslwr(importFileName);

	// initialising CRC table
	InitCRCTable();


	// ** User Configuration

	// read and set the users last configuration
	ReadConfig();

	// ** Reads in the old single set texture paths first. If a multiple texture set configuration file isn't
	// ** found, then a default texture set is created containing all of the contents of the single set.

	ReadTextureConfig();
	ReadUserConfigTextureSets();

	// validate user configuaration
	configTextureSetIndex = ((UINT)textureSets.Count() > 0) ? min(configTextureSetIndex, (UINT)textureSets.Count()-1) : 0;

	// allow user to edit current configuration
	if (suppressPrompts == FALSE &&
		DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_CONFIG_IMPORT), ip->GetMAXHWnd(), (DLGPROC)configDialogProc, (LPARAM)this) != 1)
	{
		// user wants to cancel the import
		DPrintf("User aborted import");
		return 1;
	}

	// show import configurations
	DPrintf("Import config:");
	if (configImportAnimation)
		DPrintf("  Import animation");
	if (configImportPerFaceData)
		DPrintf("  Import PerFaceData");
	if (configClearScene)
		DPrintf("  Clearing scene");
	if (configShowTextures)
		DPrintf("  Showing textures in viewport");

	// writing updated user configuration files
	WriteUserConfigTextureSets();
	WriteConfig();


	// ** Do The Import

	// clear the scene if required
	if (configClearScene && importPtr->NewScene() == 0)
	{
		DPrintf("User aborted import");
		return 1;
	}

	// zero our object root node
	objectRootNode = NULL;

	fileHandle = fopen(fileNamePtr, "rb");
	if (fileHandle == NULL)
	{
		DPrintf("File not found");
		return 0;
	}

	fileLength = _filelength(fileno(fileHandle));
	progressScaler = (float)fileLength / 100.f;
	DPrintf("File length = %d", fileLength);

	_tsplitpath(fileNamePtr, drive, dir, name, ext);
	_stprintf(charbuf, "OBE Import: %s%s", name, ext);
	ip->ProgressStart(charbuf, TRUE, progressBarImportFunc, NULL);

	fread(check, sizeof(uchar), 4, fileHandle);
	if (memcmp(check, magic, 4) != 0)
	{
		DPrintf("Invalid OBE file");
		return 0;
	}

	currentFilePos = ftell(fileHandle);
	while (ReadFile(NULL) == READ_DATA_CHUNK);

	fclose(fileHandle);

	// setup this objects note track with its animation segments
	SetNoteTrackAnimSegments();

	// handle textures if required
	LoadAllTextures();									// load all required texture maps
	AssignTexturesToNodes();							// assign texture maps to all imported nodes

	// close down the progess bar
	ip->ProgressEnd();

	// successfully imported obe file
	DPrintf("\nImport finished");

	return 1;
}


// ********************************************************************************
// Dialog Procedures - 23 November 2000
// ********************************************************************************

/* --------------------------------------------------------------------------------
   Function : configDialogProc
   Purpose : user importer dialog procedure
   Parameters : dialog handle, message, parameter1, parameter2
   Returns : return code
   Info : 
*/

BOOL CALLBACK configDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static	TCHAR	file[MAX_PATH], fileExt[_MAX_EXT], title[MAX_PATH];
	OBEImport		*impInst;
	int				i, index;


	if (uMsg == WM_INITDIALOG)
		SetWindowLong(hwndDlg, GWL_USERDATA, lParam);
	impInst = (OBEImport *)GetWindowLong(hwndDlg, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:

		// set title line text
		_tsplitpath(impInst->importFileName, NULL, NULL, file, fileExt);
		_stprintf(title, "OBEImport - %s%s", file, fileExt);
		SetWindowText(hwndDlg, title);

		// set import options
		CheckDlgButton(hwndDlg, IDC_CONFIG_IMPORT_ANIMATION, impInst->configImportAnimation ? BST_CHECKED : BST_UNCHECKED);
		CheckDlgButton(hwndDlg, IDC_CONFIG_IMPORT_PERFACEDATA, impInst->configImportPerFaceData ? BST_CHECKED : BST_UNCHECKED);
		CheckDlgButton(hwndDlg, IDC_CONFIG_CLEAR_SCENE, impInst->configClearScene ? BST_CHECKED : BST_UNCHECKED);
		CheckDlgButton(hwndDlg, IDC_CONFIG_SHOW_TEXTURES, impInst->configShowTextures ? BST_CHECKED : BST_UNCHECKED);

		// set texture set
		for (i=0; i<impInst->textureSets.Count(); i++)
			SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_ADDSTRING, (WPARAM)0, (LPARAM)impInst->textureSets[i].ident);
		// select our item
		SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_SETCURSEL, (WPARAM)impInst->configTextureSetIndex, (LPARAM)0);
		// write the selection into the texture path
		if ((index = SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_GETCURSEL, 0, 0)) != CB_ERR)
			if (index < impInst->textureSets.Count())
			{
				impInst->configTextureSetIndex = index;
			}

		// default focus to OK button
		wParam = (WPARAM)GetDlgItem(hwndDlg, IDOK);
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		// texture path combo box
		case IDC_CONFIG_TEXTURES_COMBO:
			switch (HIWORD(wParam))
			{
			// selection change
			case CBN_SELCHANGE:
				if ((index = SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_GETCURSEL, 0, 0)) != CB_ERR)
					if (index < impInst->textureSets.Count())
					{
						impInst->configTextureSetIndex = index;
					}
				return TRUE;
			}
			break;

		// select the texture set modify button
		case IDC_CONFIG_TEXTURES_MODIFY:

			// edit texture sets
			DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_CONFIG_EDIT_TEXTURE_PATHS), hwndDlg, (DLGPROC)editTexturePathsDialogProc, (LPARAM)impInst);

			// rebuild the combo box from sets
			SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_RESETCONTENT, 0, 0);
			for (i=0; i<impInst->textureSets.Count(); i++)
				SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_ADDSTRING, 0, (LPARAM)impInst->textureSets[i].ident);

			// validate the texture set index selection
			index = impInst->configTextureSetIndex;
			index = (impInst->textureSets.Count() > 0) ? min(index, impInst->textureSets.Count()-1) : 0;
			index = max(index, 0);
			impInst->configTextureSetIndex = index;

			// set the combo box selection
			SendDlgItemMessage(hwndDlg, IDC_CONFIG_TEXTURES_COMBO, CB_SETCURSEL, (WPARAM)index, 0);
			return TRUE;

		// user accepts input
		case IDOK:

			// get import options
			impInst->configImportAnimation = (UCHAR)IsDlgButtonChecked(hwndDlg, IDC_CONFIG_IMPORT_ANIMATION) ? 1:0;
			impInst->configImportPerFaceData = (UCHAR)IsDlgButtonChecked(hwndDlg, IDC_CONFIG_IMPORT_PERFACEDATA) ? 1:0;
			impInst->configClearScene = (UCHAR)IsDlgButtonChecked(hwndDlg, IDC_CONFIG_CLEAR_SCENE) ? 1:0;
			impInst->configShowTextures = (UCHAR)IsDlgButtonChecked(hwndDlg, IDC_CONFIG_SHOW_TEXTURES) ? 1:0;

			// get texture set
			if ((index = SendDlgItemMessage(hwndDlg, IDC_IMPORT_TEXSET_COMBO, CB_GETCURSEL, 0, 0)) != CB_ERR)
				if (index < impInst->textureSets.Count())
				{
					impInst->configTextureSetIndex = index;
				}

			EndDialog(hwndDlg, 1);
			return TRUE;

		// user rejects input
		case IDCANCEL:	
			EndDialog(hwndDlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}


/* --------------------------------------------------------------------------------
   Function : editTexturePathsDialogProc
   Purpose : edit texture paths dialog procedure
   Parameters : dialog handle, message, parameter1, parameter2
   Returns : return code
   Info : 
*/

static BOOL CALLBACK editTexturePathsDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{
	static CWinCtrlEditLine		*editLineInst = 0;
	static TCHAR				tcbuf[260];
	static int					setIndex;
	OBEImport					*impInst;
	RECT						rc;
	int							index, l, num;
	TTexturePath				texturePath, *texturePathPtr;
	TTextureSet					textureSet, *textureSetPtr;


	if (uMsg == WM_INITDIALOG)
		SetWindowLong(hwndDlg, GWL_USERDATA, lParam);
	impInst = (OBEImport *)GetWindowLong(hwndDlg, GWL_USERDATA);

	switch (uMsg)
	{
	// initialise this dialog box
	case WM_INITDIALOG:

		// set default texture set
		setIndex = impInst->configTextureSetIndex;

		// add all texture sets to the combo box
		for (l=0; l<impInst->textureSets.Count(); l++)
			SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_ADDSTRING, (WPARAM)0, (LPARAM)impInst->textureSets[l].ident);

		// select our selected set.. force a selection change message
		SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_SETCURSEL, (WPARAM)setIndex, (LPARAM)0);
		SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTSET_LIST, CBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTSET_LIST));

		// initialise our edit line control
		editLineInst = new CWinCtrlEditLine;

		// do not set focus
		return FALSE;

	// shutdown this dialog box
	case WM_DESTROY:

		// release our edit line control
		SAFE_DELETE(editLineInst)
		return 0;

	// commands and notifications
	case WM_COMMAND:

		switch (LOWORD(wParam))
		{
		// user accept message
		case IDOK:
			EndDialog(hwndDlg, 1);
			return TRUE;

		// user reject message
		case IDCANCEL:
			EndDialog(hwndDlg, 0);
			return TRUE;


		// ** Edit texture sets

		// texture set combo box message
		case IDC_EDTSET_LIST:

			switch (HIWORD(wParam))
			{
			case CBN_SELCHANGE:

				// clear all set content,,
				SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
				SendDlgItemMessage(hwndDlg, IDC_EDTSET_NAME, LB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

				// user selected a different texture set from the combo box
				if ((index = SendMessage((HWND)lParam, CB_GETCURSEL, 0, 0)) == CB_ERR)
					break;
				if (index >= impInst->textureSets.Count())
					break;
				setIndex = index;

				textureSetPtr = impInst->textureSets.Addr(setIndex);
				// and add all of this sets texture paths
				for (l=0; l<textureSetPtr->paths.Count(); l++)
					SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_ADDSTRING, (WPARAM)0, (LPARAM)textureSetPtr->paths[l].path);
				// clear first selection
				SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_SETCURSEL, (WPARAM)-1, (LPARAM)0);
				// force selection notify
				SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTPATH_LIST, LBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTPATH_LIST));

				// set the texture set name
				SendDlgItemMessage(hwndDlg, IDC_EDTSET_NAME, LB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
				SendDlgItemMessage(hwndDlg, IDC_EDTSET_NAME, LB_ADDSTRING, (WPARAM)0, (LPARAM)textureSetPtr->ident);

				// save the new texture set index
				impInst->configTextureSetIndex = setIndex;

				return 0;
			}
			break;

		// texture set name messages
		case IDC_EDTSET_NAME:

			switch (HIWORD(wParam))
			{
			case LBN_DBLCLK:

				// get the currently selected texture set
				if (setIndex >= impInst->textureSets.Count())
					break;
				textureSetPtr = impInst->textureSets.Addr(setIndex);

				if (SendMessage((HWND)lParam, LB_GETITEMRECT, (WPARAM)0, (LPARAM)&rc) == LB_ERR)
					break;
				InflateRect(&rc, 1, 1);

				// get the name of the new set from the user
				_tcscpy(tcbuf, textureSetPtr->ident);
				if (editLineInst->CreateModal((DWORD)hInstance, MAKEINTRESOURCE(IDD_EMPTY), (DWORD)lParam, &rc, 0, tcbuf) != NULL)
				{
					_tcscpy(textureSetPtr->ident, tcbuf);

					// change the combo box entry
					SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_INSERTSTRING, (WPARAM)setIndex, (LPARAM)tcbuf);
					SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_DELETESTRING, (WPARAM)setIndex+1, (LPARAM)0);

					// re-select our selected set.. force a selection change message
					SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_SETCURSEL, (WPARAM)setIndex, (LPARAM)0);
					SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTSET_LIST, CBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTSET_LIST));

					// redraw all invalidated dialog controls
					UpdateWindow(hwndDlg);

					return 0;
				}
				break;
			}
			break;

		// user pressed the new texture set button
		case IDC_EDTSET_NEW:

			// initialise a null texture set..
			_tcscpy(textureSet.ident, _T("New Texture Set"));
			textureSet.paths.ZeroCount();

			// and append to the texture set
			impInst->textureSets.Append(1, &textureSet);

			// add to the combo box
			if ((index = SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_ADDSTRING, (WPARAM)0, (LPARAM)textureSet.ident)) == CB_ERR)
				break;
			// select the new entry
			SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_SETCURSEL, (WPARAM)index, (LPARAM)0);
			SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTSET_LIST, CBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTSET_LIST));

			return 0;

		// user pressed the delete texture set button
		case IDC_EDTSET_DELETE:

			// check the currently selected texture set
			if (setIndex >= impInst->textureSets.Count())
				break;

			// delete this texture set
			impInst->textureSets[setIndex].paths.ZeroCount();
			impInst->textureSets.Delete(setIndex, 1);

			// delete this set from the combo box
			SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_DELETESTRING, (WPARAM)setIndex, (LPARAM)0);

			num = impInst->textureSets.Count();
			setIndex = (num == 0) ? 0 : min(setIndex, num-1);
			SendDlgItemMessage(hwndDlg, IDC_EDTSET_LIST, CB_SETCURSEL, (WPARAM)setIndex, (LPARAM)0);
			SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTSET_LIST, CBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTSET_LIST));

			return 0;


		// ** Edit texture paths

		// texture path list message
		case IDC_EDTPATH_LIST:

			switch (HIWORD(wParam))
			{
			case LBN_SELCHANGE:

				// default: off
				EnableWindow(GetDlgItem(hwndDlg, IDC_EDTPATH_ENABLE), FALSE);

				// valid texture set?
				if (setIndex >= impInst->textureSets.Count())
					break;
				textureSetPtr = impInst->textureSets.Addr(setIndex);

				// valid texture path?
				index = SendMessage((HWND)lParam, LB_GETCURSEL, 0, 0);
				if (index == LB_ERR)
					break;
				if (index >= textureSetPtr->paths.Count())
					break;
				texturePathPtr = textureSetPtr->paths.Addr(index);

				// set the current path enabled state
				EnableWindow(GetDlgItem(hwndDlg, IDC_EDTPATH_ENABLE), TRUE);
				SendDlgItemMessage(hwndDlg, IDC_EDTPATH_ENABLE, BM_SETCHECK, (WPARAM)(texturePathPtr->flags & TEXPATHFLAG_ENABLED) ? BST_CHECKED : BST_UNCHECKED, (LPARAM)0);
				break;

			case LBN_DBLCLK:

				if (editLineInst == NULL)
					break;

				// get users indexed selection
				index = SendMessage((HWND)lParam, LB_GETCURSEL, 0, 0);
				if (index == LB_ERR)
					break;

				// valid texture set index?
				if (setIndex >= impInst->textureSets.Count())
					break;
				textureSetPtr = impInst->textureSets.Addr(setIndex);

				// initialise edit line window control
				if (SendMessage((HWND)lParam, LB_GETTEXT, (WPARAM)index, (LPARAM)tcbuf) == LB_ERR)
					break;
				if (SendMessage((HWND)lParam, LB_GETITEMRECT, (WPARAM)index, (LPARAM)&rc) == LB_ERR)
					break;
				InflateRect(&rc, 1, 1);

				// get the users new line
				if (editLineInst->CreateModal((DWORD)hInstance, MAKEINTRESOURCE(IDD_EMPTY), (DWORD)lParam, &rc, WCEDITLINE_STYLE_DIRBROWSE, tcbuf) != NULL)
				{
					// ** User entered new edit line

					// save this path in the currently active texture set
					_tcscpy(textureSetPtr->paths[index].path, tcbuf);

					// these two lines simply update the text from the edit line control..!!
					SendMessage((HWND)lParam, LB_INSERTSTRING, (WPARAM)index, (LPARAM)tcbuf);
					SendMessage((HWND)lParam, LB_DELETESTRING, (WPARAM)index+1, (LPARAM)0);

					// validate the last selection
					SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_SETCURSEL, (WPARAM)index, (LPARAM)0);
					// force selection notify
					SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTPATH_LIST, LBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTPATH_LIST));

					// redraw all invalidated dialog controls
					UpdateWindow(hwndDlg);
					return 0;
				}
				break;
			}
			break;

		// user pressed the enable texture button
		case IDC_EDTPATH_ENABLE:

			switch (HIWORD(wParam))
			{
			case BN_CLICKED:

				// valid texture set?
				if (setIndex >= impInst->textureSets.Count())
					break;
				textureSetPtr = impInst->textureSets.Addr(setIndex);

				// valid texture path?
				index = SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_GETCURSEL, 0, 0);
				if (index == LB_ERR)
					break;
				if (index >= textureSetPtr->paths.Count())
					break;
				texturePathPtr = textureSetPtr->paths.Addr(index);

				// copy enable state to texture path
				if (SendMessage((HWND)lParam, BM_GETCHECK, (WPARAM)0, (LPARAM)0) == BST_CHECKED)
					texturePathPtr->flags |= TEXPATHFLAG_ENABLED;
				else
					texturePathPtr->flags &= ~TEXPATHFLAG_ENABLED;

				break;
			}
			break;

		// user pressed the new texture path button
		case IDC_EDTPATH_NEW:

			// get current texture set
			if (setIndex >= impInst->textureSets.Count())
				break;
			textureSetPtr = impInst->textureSets.Addr(setIndex);

			// init a null texture path for this set
			texturePath.flags = TEXPATHFLAG_ENABLED;
			_tcscpy(texturePath.path, _T("New Entry"));

			// append this texture path to both the current texture set and the list box
			textureSetPtr->paths.Append(1, &texturePath);
			if (SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_ADDSTRING, (WPARAM)0, (LPARAM)texturePath.path) == LB_ERR)
				break;

			// now we need to enable the edit line control for this item
			if ((index = SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_GETCOUNT, (WPARAM)0, (LPARAM)0)) == LB_ERR)
				break;
			SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_SETCURSEL, (WPARAM)index-1, (LPARAM)0);
			SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTPATH_LIST, LBN_DBLCLK), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTPATH_LIST));

			return 0;

		// user pressed the delete path button
		case IDC_EDTPATH_DELETE:

			// get current texture path index
			if ((index = SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_GETCURSEL, 0, 0)) == LB_ERR)
				break;

			// delete this path from the currently active texture set
			if (setIndex >= impInst->textureSets.Count())
				break;
			textureSetPtr = impInst->textureSets.Addr(setIndex);
			textureSetPtr->paths.Delete(index, 1);

			// delete this path from the list box
			SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_DELETESTRING, (WPARAM)index, (LPARAM)0);
			num = SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_GETCOUNT, (WPARAM)0, (LPARAM)0);
			index = (num == LB_ERR || num == 0) ? 0 : min(index, num-1);
			SendDlgItemMessage(hwndDlg, IDC_EDTPATH_LIST, LB_SETCURSEL, (WPARAM)index, (LPARAM)0);
			// force selection notify
			SendMessage(hwndDlg, WM_COMMAND, MAKEWPARAM(IDC_EDTPATH_LIST, LBN_SELCHANGE), (LPARAM)GetDlgItem(hwndDlg, IDC_EDTPATH_LIST));
			break;
		}
		break;
	}
	return FALSE;
}


// ********************************************************************************
// Expected Export PlugIn Methods
// ********************************************************************************

/* --------------------------------------------------------------------------------
   Function : OBEImport:: Various library functions demanded by the plugin
   Purpose :
   Parameters :
   Returns : 
   Info : 
*/

int OBEImport::ExtCount()
{
	return 1;
}
const TCHAR* OBEImport::Ext(int i)
{
	if (i != 0)
		return NULL;
	return _T("OBE");
}
const TCHAR *OBEImport::LongDesc()
{
	return _T("ISL Jobe OBE File Importer");
}
const TCHAR *OBEImport::ShortDesc()
{
	return _T("ISL Jobe Importer");
}
const TCHAR *OBEImport::AuthorName()
{
	return _T("J Steele / A Slater");
}
const TCHAR *OBEImport::CopyrightMessage()
{
	return _T("Copyright 1999 Interactive Studios");
}
const TCHAR *OBEImport::OtherMessage1()
{
	return NULL;
}
const TCHAR *OBEImport::OtherMessage2()
{
	return NULL;
}
unsigned int OBEImport::Version()
{
	return 200;						// Version *100 - i.e 1.21 * 100 = 121
}
void OBEImport::ShowAbout(HWND hwnd)
{
}


// --------------------------------------------------------------------------------
// OBE File Importer
// --------------------------------------------------------------------------------
class OBEImpClassDesc : public ClassDesc
{
	public:
		int				IsPublic()							{return 1;}
		void			*Create(BOOL loading = FALSE)		{return new OBEImport();}
		const TCHAR		*ClassName()						{return GetString(IDS_IMPORT_CLASS_NAME);}
		SClass_ID		SuperClassID()						{return SCENE_IMPORT_CLASS_ID;}
		Class_ID		ClassID()							{return OBEIMP_CLASS_ID;}
		const TCHAR		*Category()							{return GetString(IDS_CATEGORY);}
};

// instance of our modifier descriptor
static OBEImpClassDesc	theImpClassDesc;
ClassDesc *GetOBEImpClassDesc()	{return &theImpClassDesc;}
