// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 2000 Interactive Studios Ltd.
//
//    File : PlaceEditor.h
// Purpose : Scenic Placement Editor
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __PLACEEDITOR__H
#define __PLACEEDITOR__H

// obefile exporter extension
#include "OBEExport.h"


// ------------------
// Function templates

// check if the scene is a valid placement editor scene
int PlaceEditor_IsSceneValid(Interface *ip);


// -----------------
// Types and Classes

/* --------------------------------------------------------------------------------
   Class : PlaceEditor
   Purpose : interprets the a Max3.1 scene as a placement editor session
   Info : 
*/

typedef class PlaceEditor
{
	private:
		OBEExport			*exportInst;
		Interface			*ip;

	public:

							PlaceEditor(OBEExport *exportInst);
							~PlaceEditor();

		void				Init();
		void				Shutdown();
		int					DoExport(const TCHAR *filename);

} PlaceEditor;

#endif