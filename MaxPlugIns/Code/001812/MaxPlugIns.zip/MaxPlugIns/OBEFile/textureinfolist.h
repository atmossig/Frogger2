
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : textureinfolist.cpp
// Purpose : implementation of TexInfNode and TexInfList classes
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef _texi_h
#define _texi_h

#include <windows.h>
#include "max.h"


// --------------------------------------------------------------------------------
// TexInfNode class
// --------------------------------------------------------------------------------
class TexInfNode
{
	friend class					TexInfList;

	private:
		TexInfNode					*next;

	public:
		INode						*iNode;
		Mesh						*mesh;
		int							numFaces;
		int							*faceIdPtr;

									// constructor / destructor
									TexInfNode();
									~TexInfNode();
};

// --------------------------------------------------------------------------------
// TexInfList class
// --------------------------------------------------------------------------------
class TexInfList
{
	private:
		TexInfNode					*head;
		TexInfNode					*tail;
		int							numNodes;

	public:
									// constructor / destructor
									TexInfList();
									~TexInfList();

									// add node texture info entry
		int							Add(TexInfNode *node);
									// get current list length
		int							ListLen() { return numNodes; };
		TexInfNode					*GetByIndex(int index);
};

#endif
