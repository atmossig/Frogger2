
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : textureinfolist.cpp
// Purpose : implementation of TexInfNode and TexInfList classes
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "textureinfolist.h"
#include "OBEFile.h"



// --------------------------------------------------------------------------------
// TexInfNode class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : TexInfNode::TexInfNode
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

TexInfNode::TexInfNode()
{
	faceIdPtr = NULL;
}


/* --------------------------------------------------------------------------------
   Function : TexInfNode::~TexInfNode
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

TexInfNode::~TexInfNode()
{
	SAFE_DELETE_ARRAY(faceIdPtr)
}


// --------------------------------------------------------------------------------
// TexInfList class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : TexInfList::TexInfList
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

TexInfList::TexInfList()	
{
	head = NULL;
	tail = NULL;
	numNodes = 0;
};


/* --------------------------------------------------------------------------------
   Function : TexInfList::~TexInfList
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

TexInfList::~TexInfList()
{
	TexInfNode	*next, *curr;
	curr = head;
	while (curr)
	{
		next = curr->next;
		SAFE_DELETE(curr)
		curr = next;
	}
}


/* --------------------------------------------------------------------------------
   Function : TexInfList::Add
   Purpose : add node texture info entry to list
   Parameters : node texture info pointer to add
   Returns : number of entries in the list
   Info : 
*/

int TexInfList::Add(TexInfNode *node)
{
	TexInfNode	*oldTail;
	
	if (head == NULL)
	{
		head = node;
		tail = node;
		head->next = NULL;
	}
	else
	{
		oldTail = tail;
		tail = node;
		oldTail->next = node;
		node->next = NULL;
	}
	numNodes++;
	return numNodes;
}


/* --------------------------------------------------------------------------------
   Function : TexInfList::GetByIndex
   Purpose : get the node texture info entry by index
   Parameters : index into the list
   Returns : valid entry, or NULL for invalid entry
   Info : 
*/

TexInfNode *TexInfList::GetByIndex(int index)
{
	int			i;
	TexInfNode	*curr = head;

	if (index >= numNodes)
		return NULL;
	if (index == 0)
		return curr;
	for (i=0; i<index; i++)
		curr = curr->next;
	return curr;
}