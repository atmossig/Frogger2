
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dle, (c) 2000 Interactive Studios Ltd.
//
//    File : WinCtrlEditLine.cpp
// Purpose : a custom window control to edit a line
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include <string.h>
#include <shlobj.h>

#include "WinCtrlEditLine.h"
#include "DPrintf.h"

// --------------------
// Constants and macros

// ** Use the control mouse click Window message intercept to quit the dialog box on a mouse click
// ** outside the controls area.

// comment out this line, to disable the quit option
#define USE_DIALOG_MOUSECLICK_QUIT


// edit line control window message ident
#define WM_EDITLINE					(WM_APP+0x2000)
// escape and return subclass key messages
#define WM_EDITLINE_KEY_ESCAPE		0x10
#define WM_EDITLINE_KEY_RETURN		0x20
// dialog quit message from above key presses
#define WM_EDITLINE_DIALOG_QUIT		0x30


// ------------------
// Function templates

// window and dialog class dispatches
static LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
static BOOL CALLBACK dialogBoxProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

// edit box sub class procedure
static LRESULT CALLBACK editBoxPreProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


// -----------------
// Types and classes

/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::CWinCtrlEditLine
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

CWinCtrlEditLine::CWinCtrlEditLine()
{
	parent = NULL;
	hwnd = NULL;
	hwndEdit = NULL;
	hwndBrowse = NULL;

	hwndDialog = NULL;
	_tcscpy(dialogInitLine, _T(""));
	SetRectEmpty(&dialogInitRect);
	dialogInitStyles = 0;
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::~CWinCtrlEditLine
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

CWinCtrlEditLine::~CWinCtrlEditLine()
{
	DestroyWindow(hwnd);
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::Create
   Purpose : create our window control
   Parameters : parent/owner window, window size rectangle, stylings, initial string
   Returns : window control handle
   Info : 
*/

HWND CWinCtrlEditLine::Create(HINSTANCE hinst, HWND parent, RECT *rc, int styles, TCHAR *string)
{
    WNDCLASS	wc;
	HFONT		font;

	// already created?
	if (hwnd)
		return hwnd;

	this->parent = parent;
	this->hinst = hinst;

	// register the edit line container window class
	memset(&wc, 0, sizeof(wc));
    wc.style = 0;
    wc.lpfnWndProc = ::WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 4;
    wc.hInstance = hinst;
    wc.hIcon = NULL;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = "CWinCtrlEditLine";
	RegisterClass(&wc);

	// create our window control container
	hwnd = CreateWindowEx(
				0,
				"CWinCtrlEditLine",
				NULL,
				WS_CHILD | WS_BORDER,
				rc->left, rc->top,
				rc->right - rc->left, rc->bottom - rc->top,
				parent, 
				NULL,
				hinst, 
				this);

	// create ourselves a edit box inside the container
	hwndEdit = CreateWindowEx(
				0,
				"EDIT",
				string,
				WS_CHILD | WS_VISIBLE | ES_LEFT,
				0, 0,
				(styles & WCEDITLINE_STYLE_DIRBROWSE) ? (rc->right - rc->left) -20 : rc->right - rc->left, rc->bottom - rc->top,
				hwnd,
				NULL,
				hinst,
				NULL);

	// create ourselves a browse button inside the container
	if (styles & WCEDITLINE_STYLE_DIRBROWSE)
		hwndBrowse = CreateWindowEx(
					0,
					"BUTTON",
					"..",
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_FLAT,
					(rc->right - rc->left) -20, 0,
					20, (rc->bottom - rc->top),
					hwnd,
					NULL,
					hinst,
					NULL);
	else
		hwndBrowse = NULL;

	// subclass the edit box to capture return and escape quit keys
	SetWindowLong(hwndEdit, GWL_USERDATA, GetWindowLong(hwndEdit, GWL_WNDPROC));
	SetWindowLong(hwndEdit, GWL_WNDPROC, (LONG)editBoxPreProc);

	// set the parents font though out
	font = (HFONT)SendMessage(parent, WM_GETFONT, (WPARAM)0, (LPARAM)0);
	SendMessage(hwndEdit, WM_SETFONT, (WPARAM)font, MAKELPARAM((WORD)TRUE, 0));
	SendMessage(hwndBrowse, WM_SETFONT, (WPARAM)font, MAKELPARAM((WORD)TRUE, 0));

	// show windows
	ShowWindow(hwnd, SW_SHOW);

	// highlight all edit box text
	SendMessage(hwndEdit, EM_SETSEL, (WPARAM)0, (LPARAM)-1);
	// set edit box text focus 
	SetFocus(hwndEdit);

	return hwnd;
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::CreateModal
   Purpose : create our window control inside a modal dialog box
   Parameters : instance, resource, parent/owner window, window size rectangle, styles, initial/return string
   Returns : users inputted line or NULL for user quit
   Info : 
*/

TCHAR *CWinCtrlEditLine::CreateModal(DWORD hinst, LPTSTR resource, DWORD parent, RECT *rc, int styles, TCHAR *string)
{
	BOOL	ret;

	// save dialog initialise params
	dialogInitRect = *rc;
	_tcscpy(dialogInitLine, (string != NULL) ? string : _T(""));
	dialogInitStyles = styles;

	// save instance for resource and the immediate parent
	this->hinst = (HINSTANCE)hinst;
	this->parent = (HWND)parent;				// this parent gets over-ridden with the dialog box

	// contain the edit line control within a modal dialog box
	ret = DialogBoxParam((HINSTANCE)hinst, resource, (HWND)parent, (DLGPROC)dialogBoxProc, (LPARAM)this);

	// if successful exit, copy the new line to source
	if (ret == TRUE && string)
		_tcscpy(string, dialogInitLine);

	// return the line or NULL for quit
	return (ret == TRUE) ? string : NULL;
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::Destroy
   Purpose : destroy our window control
   Parameters : 
   Returns : 
   Info : 
*/

void CWinCtrlEditLine::Destroy()
{
	if (hwnd)
		DestroyWindow(hwnd);
	parent = NULL;
	hwnd = NULL;
	hwndEdit = NULL;
	hwndBrowse = NULL;
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::WindowProc
   Purpose : control window procedure
   Parameters : handle, message, first parameter1, second parameter
   Returns : dependant on the message
   Info : 
*/

int CALLBACK browseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
	if (uMsg == BFFM_INITIALIZED)
		SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpData);
	return 0;
}

LRESULT CWinCtrlEditLine::WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    BROWSEINFO		browseInfo;
    LPITEMIDLIST	pidl;
	TCHAR			path[MAX_PATH];

	switch (uMsg)
	{

	case WM_DESTROY:

		this->hwnd = NULL;
		return 0;

	case WM_EDITLINE:

		switch (wParam)
		{
		case WM_EDITLINE_KEY_ESCAPE:
			if (hwndDialog)
				PostMessage(hwndDialog, WM_EDITLINE, WM_EDITLINE_DIALOG_QUIT, (LPARAM)FALSE);
			break;
		case WM_EDITLINE_KEY_RETURN:
			if (hwndDialog)
				PostMessage(hwndDialog, WM_EDITLINE, WM_EDITLINE_DIALOG_QUIT, (LPARAM)TRUE);
			break;
		}
		return 0;

	case WM_COMMAND:

		switch (HIWORD(wParam))
		{
		case BN_CLICKED:

			if ((HWND)lParam != hwndBrowse)
				break;

			// user clicked the browse button
			_tcscpy(path, GetLine());

			browseInfo.hwndOwner = hwnd;
		    browseInfo.pidlRoot = NULL;
			browseInfo.pszDisplayName = path;
			browseInfo.lpszTitle = "Choose Texture Directory";
			browseInfo.ulFlags = BIF_RETURNONLYFSDIRS;
			browseInfo.lpfn = browseCallbackProc;
			browseInfo.lParam = (LPARAM)path;
			browseInfo.iImage = 0;

			// get user path if successful
			pidl = SHBrowseForFolder(&browseInfo);
			if (pidl)
			{
				SHGetPathFromIDList(pidl, path);
				SetLine(path);

				SendMessage(hwndEdit, EM_SETSEL, (WPARAM)0, (LPARAM)-1);
			}

			SetFocus(hwndEdit);
			break;
		}
	}

	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::DialogProc
   Purpose : modal dialog container for our edit control
   Parameters : handle, message, first parameter1, second parameter
   Returns : dependant on the message
   Info : 
*/

BOOL CWinCtrlEditLine::DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static int	quit = 0, init = 0;
	RECT		ebRect;
	POINT		pt;
	RECT		rc;

	switch (uMsg)
	{
	case WM_INITDIALOG:

		// this forces the WM_WINDOWPOSCHANGING messages to be ignored until set
		init = 0;
		// this prevents any WM_WINDOOWPOSCHANGING messages after quit dialog quit
		quit = 0;

		hwndDialog = hwndDlg;

		// get the screen position of the edit line control parent
		GetWindowRect(parent, &ebRect);
		// create our edit line control.. using this dialog for the parent
		Create(hinst, hwndDlg, &dialogInitRect, dialogInitStyles, dialogInitLine);
		// position the control window at this windows origin
		SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		// position this window in the correct place
		SetWindowPos(hwndDlg, NULL, ebRect.left + dialogInitRect.left, ebRect.top + dialogInitRect.top, dialogInitRect.right - dialogInitRect.left, dialogInitRect.bottom - dialogInitRect.top, SWP_NOZORDER);

		// make sure all windows are visible
		ShowWindow(hwndDlg, SW_SHOW);

		// highlight all edit box text
		SendMessage(hwndEdit, EM_SETSEL, (WPARAM)0, (LPARAM)-1);
		// set edit box text focus 
		SetFocus(hwndEdit);

		init = 1;
		// do not set the keyboard focus
		return FALSE;

	case WM_DESTROY:

		quit = 0;
		init = 0;
		hwndDialog = NULL;
		return 0;

	case WM_EDITLINE:

		switch (wParam)
		{
		case WM_EDITLINE_DIALOG_QUIT:

			// if succesful quit, get the users edit line
			if ((BOOL)lParam == TRUE)
				_tcscpy(dialogInitLine, GetLine());

			quit = 1;
			EndDialog(hwndDlg, (BOOL)lParam);
			break;
		}
		return 0;

#ifdef USE_DIALOG_MOUSECLICK_QUIT

	// ** On this machine on this version of Windows, this message seems to get generated for a dialog
	// ** box when the users clicks outside the dialogs active area. It is also called on many other
	// ** occasions also, that is why the 'init' and 'quit' flags are used. If any problems occur with
	// ** this in future, i SHOULD disable it.

	// !! this message seems to be sent if a mouse click occurs outside our window dialog window !!
	case WM_WINDOWPOSCHANGING:

		// ignore this message if qlready quit or still iniitialising
		if (quit == 1 || init == 0)
			break;
		// browse button can cause problems, so for now if browse button active ignore this quit option
		if (hwndBrowse != NULL)
			break;

		// if mouse cursor outside of our window, then we can safely(!) quit
		if (GetCursorPos(&pt) == 0)
			break;
		GetWindowRect(hwndDlg, &rc);
		if (PtInRect(&rc, pt) == 0)
		{
			quit = 1;
			EndDialog(hwndDlg, TRUE);
		}
		return 0;
#endif
	}

	return FALSE;
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::GetLine
   Purpose : get the current edit control line
   Parameters : [pointer to buffer large enough to hold the current line. default: NULL]
   Returns : pointer to line buffer
   Info : 
*/

TCHAR *CWinCtrlEditLine::GetLine(TCHAR *line)
{
	static TCHAR	tcbuf[MAX_PATH];

	if (hwndEdit == NULL)
		return NULL;
	tcbuf[0] = LOBYTE(MAX_PATH-1);
	tcbuf[1] = HIBYTE(MAX_PATH-1);
	SendMessage(hwndEdit, EM_GETLINE, (WPARAM)0, (LPARAM)tcbuf);
	if (line != NULL)
	{
		_tcscpy(line, tcbuf);
		return line;
	}
	return tcbuf;
}


/* --------------------------------------------------------------------------------
   Function : CWinCtrlEditLine::SetLine
   Purpose : set the current edit control line
   Parameters : pointer to line to set
   Returns : 
   Info : 
*/

void CWinCtrlEditLine::SetLine(TCHAR *line)
{
	if (hwndEdit == NULL)
		return;
	SendMessage(hwndEdit, WM_SETTEXT, (WPARAM)0, (LPARAM)line);
}


/* --------------------------------------------------------------------------------
   Function : windowProc
   Purpose : dispatch window messages to class scoped window proc
   Parameters : window handle, message, first parameter, second parameter
   Returns : dependant on the message
   Info : 
*/

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CWinCtrlEditLine	*editLineInst;
	if (uMsg == WM_CREATE)
	{
		editLineInst = (CWinCtrlEditLine *)((CREATESTRUCT *)lParam)->lpCreateParams;
		SetWindowLong(hwnd, GWL_USERDATA, (LONG)editLineInst);
		return editLineInst->WindowProc(hwnd, uMsg, wParam, lParam);
	}
	if (editLineInst = (CWinCtrlEditLine *)GetWindowLong(hwnd, GWL_USERDATA))
	{
		if (uMsg == WM_DESTROY)
			SetWindowLong(hwnd, GWL_USERDATA, 0);
		return editLineInst->WindowProc(hwnd, uMsg, wParam, lParam);
	}
	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}


/* --------------------------------------------------------------------------------
   Function : dialogBoxProc
   Purpose : dispatch dialog box procedure to class scoped dialog proc
   Parameters : dialog handle, message, first parameter, second parameter
   Returns : dependant on the message
   Info : 
*/

static BOOL CALLBACK dialogBoxProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CWinCtrlEditLine	*editLineInst;
	if (uMsg == WM_INITDIALOG)
	{
		editLineInst = (CWinCtrlEditLine *)lParam;
		SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)editLineInst);
		return editLineInst->DialogProc(hwndDlg, uMsg, wParam, lParam);
	}
	if (editLineInst = (CWinCtrlEditLine *)GetWindowLong(hwndDlg, GWL_USERDATA))
	{
		if (uMsg == WM_DESTROY)
			SetWindowLong(hwndDlg, GWL_USERDATA, 0);
		return editLineInst->DialogProc(hwndDlg, uMsg, wParam, lParam);
	}
	return FALSE;
}


/* --------------------------------------------------------------------------------
   Function : editBoxPreProc
   Purpose : edit box window pre-procedure
   Parameters : window handle, message, first parameter, second parameter
   Returns : dependant on the message
   Info : capture escape and return key presses to quit the edit line control
*/

static LRESULT CALLBACK editBoxPreProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HWND	hwndParent;
#ifdef STRICT
	WNDPROC	windowProc;
#else
	FARPROC windowProc;
#endif

#ifdef STRICT
	windowProc = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);
#else
	windowProc = (FARPROC)GetWindowLong(hwnd, GWL_USERDATA);
#endif

	if ((hwndParent = GetParent(hwnd)) == NULL)
		return CallWindowProc(windowProc, hwnd, uMsg, wParam, lParam);

	if (uMsg == WM_DESTROY)
	{
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)windowProc);
		SetWindowLong(hwnd, GWL_USERDATA, (LONG)0);
		return CallWindowProc(windowProc, hwnd, uMsg, wParam, lParam);
	}
	if (uMsg == WM_GETDLGCODE)
		return (DLGC_WANTALLKEYS | CallWindowProc(windowProc, hwnd, uMsg, wParam, lParam));
	if (uMsg == WM_CHAR)
	{
		if ((wParam == VK_RETURN) || (wParam == VK_ESCAPE) || (wParam == VK_UP) || (wParam == VK_DOWN))
			return 0;
		else
			return CallWindowProc(windowProc, hwnd, uMsg, wParam, lParam);
	}
	if (uMsg == WM_KEYDOWN)
	{
		if (wParam == VK_RETURN || wParam == VK_UP || wParam == VK_DOWN)
		{
			PostMessage(hwndParent, WM_EDITLINE, WM_EDITLINE_KEY_RETURN, (LPARAM)hwnd);
			return FALSE;
		}
		if (wParam == VK_ESCAPE)
		{
			PostMessage(hwndParent, WM_EDITLINE, WM_EDITLINE_KEY_ESCAPE, (LPARAM)hwnd);
			return FALSE;
		}
	}

	return CallWindowProc(windowProc, hwnd, uMsg, wParam, lParam);
}
