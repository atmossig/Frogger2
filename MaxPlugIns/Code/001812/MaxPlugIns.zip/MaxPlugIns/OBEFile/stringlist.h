

#ifndef _stringlist_h
#define _stringlist_h

#include <windows.h>


class StringNode
{
public:
	char *string;
	StringNode *next;

	StringNode();
	StringNode(char *);
	~StringNode();

	SetStr(char *);
};



class StringList
{
public:
	StringNode *head, *tail;	
	int numNodes;


	StringList(void);
	~StringList(void);

	Add(char *);
	int ListLen(void) { return numNodes; };
	int GetIdx(char *);
	char *GetStr(int);
	Clear();
};


#endif







		
