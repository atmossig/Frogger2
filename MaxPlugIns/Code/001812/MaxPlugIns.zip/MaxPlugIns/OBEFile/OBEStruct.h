
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : obestruc.cpp
// Purpose : implementation of all obe structures and classes
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef OBESTRUC_H
#define OBESTRUC_H

#include <windows.h>
#include "max.h"
#include "skindata.h"


// --------------------
// Constants and macros

// read/write file return values
#define READ_DATA_CHUNK				 1
#define READ_END_CHUNK				 0
#define READ_ERROR					-1
#define WRITE_ERROR					-2
#define MEM_ALLOC_ERROR				-3

// obe internal flags
#define OBJECT_FROZEN				0x01
#define OBJECT_HIDDEN				0x02
#define GOURAUD_DYNAMIC				0x01
#define GOURAUD_PRELIT				0x02

// obe chunk identifiers
#define OBECHUNK_OBJECT				1
#define OBECHUNK_OBJECTINFO			2
#define OBECHUNK_MESH				3
#define OBECHUNK_MAPPINGICONS		4
#define OBECHUNK_VIEWPORTS			5
#define OBECHUNK_ANIMTIME			6
#define OBECHUNK_VERTEXFRAMES		7
#define OBECHUNK_ANIMSEGMENTS		8
#define OBECHUNK_CONSTRUCTIONGRID	9
#define OBECHUNK_LIGHTINGINFO		10
#define OBECHUNK_SKININFO			13
#define OBECHUNK_SKIN				14
#define OBECHUNK_BONE				OBECHUNK_SKIN
#define OBECHUNK_END				255

// obe polygon flags
#define OBEPOLYFLAG_LIT				0x0001
#define OBEPOLYFLAG_TESSELATOR		0x0002
#define OBEPOLYFLAG_DOUBLESIDED		0x0004
#define OBEPOLYFLAG_MODULATETEXTURE	0x0008
#define OBEPOLYFLAG_SPRITE			0x0010
#define OBEPOLYFLAG_DRAWTHISFACE	0x0020
#define OBEPOLYFLAG_FILTERTEXTURE	0x0040
#define OBEPOLYFLAG_NOCOLLISION		0x0080
#define OBEPOLYFLAG_PHONGTEXTURES	0x0100
#define OBEPOLYFLAG_MAGENTAMASK		0x0200

// object flags
#define OBJFLAG_FROZEN			0x0001
#define OBJFLAG_HIDDEN			0x0002
#define OBJFLAG_INSTANCE		0x0004
#define OBJFLAG_HASTRANSLUCENCY	0x0008
#define OBJFLAG_USEOBJECTCOLOUR	0x0010
#define OBJFLAG_MAGENTAMASK		0x0020
#define OBJFLAG_VERTEXALPHA		0x0040

// translucency modes
#define TRANSLUCENCYMODE_ALPHA			0
#define TRANSLUCENCYMODE_SEMI			1
#define TRANSLUCENCYMODE_ADDITIVE		2
#define TRANSLUCENCYMODE_SUBTRACTIVE	3

// gouraud shading modes
#define GOURAUDMODE_NONE		0
#define GOURAUDMODE_LIGHTING	1
#define GOURAUDMODE_COLOUR		2


// ********************************************************************************
// Experimental chunk
// ********************************************************************************
#define OBECHUNK_MAXBONE			15
#define OBECHUNK_ANIMNOTES			16
#define OBECHUNK_POLYDATA			17
#define OBECHUNK_PATCH_MESH			18
#define OBECHUNK_INVALID			OBECHUNK_POLYDATA

#define OBECHUNK_BONE_SOFT			OBECHUNK_MAXBONE
#define OBECHUNK_BONE_HARD			OBECHUNK_BONE


// obe chunk versions
#define OBJECT_VER					1
#define OBJECTINFO_VER				5
#define MESH_VER				   12					// version 11 == version 12
#define MAPPING_VER					1
#define VIEWPORTS_VER				3
#define ANIMTIME_VER				2
#define VERTEXFRAMES_VER			1
#define ANIMSEGMENTS_VER			3
#define CONSTRUCTIONGRID_VER		1
#define LIGHTINGINFO_VER			1
#define SKININFO_VER				1
#define SKIN_VER					1
#define ANIMNOTES_VER				1
#define BONE_SOFT_VER				1
#define BONE_HARD_VER				SKIN_VER
#define POLYDATA_VER				1
#define PATCHMESH_VER				1
#define END_VER						1

// skin space warp object unique identifier
#ifndef SKIN_OBJ_CLASS_ID
#define SKIN_OBJ_CLASS_ID			Class_ID(0x2eb10ea1, 0x218f40ba)
#endif
// skin space warp modifier unique identifier
#ifndef SKIN_MOD_CLASS_ID
#define SKIN_MOD_CLASS_ID			Class_ID(0x7da56ae2, 0xf6c553c)
#endif

// marco helpers to move through vertex indices
#define VERTEX_INDEX_NEXT(_index_, _numVerts_)			((_index_+1) % _numVerts_)
#define VERTEX_INDEX_PREV(_index_, _numVerts_)			((_index_-1+_numVerts_) % _numVerts_)


// ----------------------
// Structures and Classes

// --------------------------------------------------------------------------------
// Polygon Data Header
// --------------------------------------------------------------------------------
typedef struct
{
	int		sizeSet;						// size of data set
	int		noofSets;						// number of data sets
	int		noofAttribs;					// number of format attributes
} TPolyDataHeader;


// --------------------------------------------------------------------------------
// Polygon Data Format Attribute
// --------------------------------------------------------------------------------
typedef struct
{
	int		type;
	int		offset;
	int		size;
} TPolyDataAttrib;


// --------------------------------------------------------------------------------
// OBE_CHUNK_HEAD structure
// --------------------------------------------------------------------------------
typedef struct
{	
	long	chunkID;						// chunk type ID
	long	chunkVersion;					// version of the chunk format
	long	chunkLength;					// length of the chunk in bytes
} OBE_CHUNK_HEAD;


// --------------------------------------------------------------------------------
// OBE_CHUNK_OBJECT_INFO structure
// --------------------------------------------------------------------------------
typedef struct
{
	char		objectName[32];				// object name
	float		origX;						// origin positin
	float		origY;
	float		origZ;
	long		origVisFlag;				// origin visible flag
	char		saveProgName[32];			// program that saved the file
	time_t		createTime;					// file creation time
	time_t		saveTime;					// file saved time
	float 		normInd;					// length of normal indication displays
	COLORREF	custColour[16];				// colour picker custom colours
	char		userNotes[1024];			// user notes string
	char		currentPath[1024];			// current path string
} OBE_CHUNK_OBJECT_INFO;


// --------------------------------------------------------------------------------
// OBE_CHUNK_SKIP_INFO structure
// --------------------------------------------------------------------------------
typedef struct
{
	long	boneStructSize;					// size of bone structure
	long	vertStructSize;					// size of vertex assign structure
} OBE_CHUNK_SKIN_INFO;


// --------------------------------------------------------------------------------
// TPolygonData structure
// --------------------------------------------------------------------------------
typedef struct
{
	// common data 
	UCHAR		polyRGB[3];							// polygon colour						 0	+ 1*3
	char		transMode;							// transluceny mode						 3	+ 1*1
	char		transValue;							// transluceny value					 4	+ 1*1
	char		gourMode;							// gouraud mode							 5	+ 1*1	+ 2
	long		uTile, vTile;						// UV tiling							 8	+ 4*2
	short		flags;								// polygon flags						16	+ 2*1

	// polygon vertices								
	char		vertLights[3];						// lighting intensity					18	+ 1*3
	UCHAR		vertRGBA[3][4];						// gouraud colours						21	+ 1*12	+ 3

	// sprite data									
	float		sprxPos, spryPos, sprzPos;			// position								36	+ 4*3
	float		sprxSize, sprySize;					// size									48	+ 4*2
	char		sprxFlipped, spryFlipped;			// flipped								56	+ 1*2	+ 2

	// additional data								
	long		terFlag;							// terrain flag							60	+ 4*1
	long		NDOFlag;							// NDO Flag								64	+ 4*1
	char		dualTexture[32];					// dual texture map						68	+ 1*32

} TPolygonData;																			//	100


// --------------------------------------------------------------------------------
// TIME_VALUE_KEY structure
// --------------------------------------------------------------------------------
typedef struct
{
	int		frameNum;
	float	data;
} TIME_VALUE_KEY;


// --------------------------------------------------------------------------------
// TAnimSegment structure
// --------------------------------------------------------------------------------
typedef struct _TAnimSegment
{
	TCHAR		ident[32];
	int			start;
	int			end;
	int			flags;
	int			fps;
	int			custom;
} TAnimSegment;


// --------------------------------------------------------------------------------
// FileBase class
// --------------------------------------------------------------------------------

class FileBase
{
	protected:
		int						errorFlag;
	public:
								FileBase();
								~FileBase();
		int						ReadData(FILE *filePtr, void *dataPtr, int dataLen);
		int						WriteData(FILE *filePtr, void *dataPtr, int daraLen);
		int						IsError();
};


// --------------------------------------------------------------------------------
// AnimVector class
// --------------------------------------------------------------------------------
class AnimVector : public FileBase
{
	public:
		int						numKeys;				// number of keys in the array
		TIME_VALUE_KEY			*keyArrayPtr;			// pointer to the start of the array

								// constructor / destructor
								AnimVector();
								AnimVector(int numKeys);
								~AnimVector();

								// get/set the number of keys in the array
		int						GetNumKeys();
		int						SetNumKeys(int numKeys, int keepFlag=0);

								// searches for a keys index by it's frame num
		int						GetKeyIndex(int frameNum);
								// get/set a key in/from the array
		void					GetKey(int keyIndex, TIME_VALUE_KEY *keyPtr);
		void					SetKey(int keyIndex, TIME_VALUE_KEY *keyPtr);

								// clone anim vector
		int						Clone(AnimVector * cloneAnimVecPtr);

								// read/write key data from/to file
		int						Read(FILE *filePtr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// VertexType class
// --------------------------------------------------------------------------------
class VertexType : public FileBase
{
	public:
		AnimVector				*x;						// vertex x,y,z
		AnimVector				*y;
		AnimVector				*z;
		char					selected;				// selected vertex

								// constructor / destructor
								VertexType();
								~VertexType();

								// read/write vertex data from/to file
		int						Read(FILE *filePtr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// SortList class
// --------------------------------------------------------------------------------
class SortList : public FileBase
{
	protected:
		int						listLen;
		int						*arrayPtr;

	public:
								// constructor / destructor
								SortList();
								SortList(int listLen);
								~SortList();

								// get/set the array length
		int						GetLength();
		int						SetLength(int listLen);

								// get/set an array data item
		int						SetItem(int index, int *data);
		int						GetItem(int index, int *data);

								// clone sortlist
		int						Clone(SortList * cloneSort);

								// read/write sortlist data from/to file
		int						Read(FILE *filePr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// SpriteInfo class
// --------------------------------------------------------------------------------
class SpriteInfo : public FileBase
{
	public:
		AnimVector				xPos;					// sprite positions
		AnimVector				yPos;
		AnimVector				zPos;
		AnimVector				xSize;					// sprite sizes
		AnimVector				ySize;
		char					xFlipped;				// sprite x flipped
		char					yFlipped;				// sprite y flipped

								// constructor / destructor
								SpriteInfo();
								~SpriteInfo();

								// copy to/from sprite info
		int						CopyTo(SpriteInfo *spriteInfoPtr);
		int						CopyFrom(SpriteInfo *spriteInfoPtr);

								// read/write sprite info
		int						Read(FILE *filePtr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// PolyInfo class
// --------------------------------------------------------------------------------
class PolyInfo : public FileBase
{
	public:
		short					vertIndex;				// vertex index
		char					lightIntensity;			// lighting intensity
		float					u;						// texture u coord
		float					v;						// texture v coord
		UCHAR					gCol[4];				// gouraud vertex RGB

								// constrcutor / destructor
								PolyInfo();
								~PolyInfo();

								// copy to/from polygon info
		int						CopyTo(PolyInfo *polyInfoPtr);
		int						CopyFrom(PolyInfo *polyInfoPtr);

								// read/write polygon info
		int						Read(FILE *filePtr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// PolyType class
// --------------------------------------------------------------------------------
class PolyType : public FileBase
{
	public:
		char					texture[32];			// name of the texture being used
		UCHAR					colRGB[3];				// colour of the vertice
		UCHAR					transVal;				// transparancy value
		char					transMode;				// transparancy mode
		char					gColMode;				// gouraud mode
		int						tileU;					// texture u tiling value
		int						tileV;					// texture v titing value
		char					selected;				// poly selected flag
		int						flags;					// poly flags
		int						numVerts;				// number of vertices

		PolyInfo				*verts;					// polygon vertices
		SpriteInfo				*spriteInfoPtr;			// sprite info block

		long					NDOFlag;				// nintendo data object flag	*SAVED IN EXTRA CHUNK*
		long					terFlag;				// terrain flag					*SAVED IN EXTRA CHUNK*
		char					dualTexture[32];		// dual texture name			*SAVED IN EXTRA CHUNK*

								// constructor / destructor
								PolyType();
								PolyType(int numVerts);
								~PolyType();

								// set number of vertices
		int						SetNumVerts(int numVerts);

								// copy to/from polygon
		int						CopyTo(PolyType *polyPtr);
		int						CopyFrom(PolyType *polyPtr);

								// convert quad to two tris and vice-versa
		int						QuadToTwoTris(PolyType *triAPtr, PolyType *triBPtr);
		int						TwoTrisToQuad(PolyType *triAPtr, PolyType *triBPtr);

								// read/write polygon data
		int						Read(FILE *filePtr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// ObeMesh class
// --------------------------------------------------------------------------------
class ObeMesh : public FileBase
{
	public:

		char					meshName[32];			// mesh name

		AnimVector				posX;					// mesh positions
		AnimVector				posY;
		AnimVector				posZ;

		AnimVector				scaleX;					// mesh scales
		AnimVector				scaleY;
		AnimVector				scaleZ;

		AnimVector				orientationX;			// mesh orientation
		AnimVector				orientationY;
		AnimVector				orientationZ;
		AnimVector				orientationW;

		int						numVert;				// number of vertices
		VertexType				*vertArray;				// vertices

		int						numPoly;				// number of polygons
		PolyType				*polyArray;				// polygons

		int						*loadPolyOrder;			// polygon order at load time
		int						loadNumPolys;			// number of polygons at load time

		int						flags;					// flags
		UCHAR					rgb[3];					// colour
		char					gourMode;				// gouraud shading mode
		UCHAR					transValue;				// translucency value
		char					transMode;				// translucency mode
		char					selected;				// selected flag

		SortList				sortList[8];			// sort lists
	
								// constructor / destructor
								ObeMesh();
								~ObeMesh();

								// vertice methods
		int						SetNumVerts(int numVerts);
		int						SetVert(int vertIndex, float x, float y, float z);
		int						GetVert(int vertIndex, float *xyzPtr);
		int						GetVert(int vertIndex, float *xPtr, float *yPtr, float *zPtr);

								// mesh methods
		int						SetNumPolys(int numPolys);
		int						ToTris();

								// mesh read / write
		int						Read(FILE *filePtr, int version);
		int						Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// VertxAssign class
// --------------------------------------------------------------------------------
class VertexAssign : public FileBase
{
	public:
		int						vertIndex;						// index into referenced mesh vertex list
		VertexType				assignList;						// array of vertex assignments
		int						numWeights;						// number of weight assignments
		AnimVector				weightList;						// array of weight assigments

								// constructor / destructor
								VertexAssign();
								~VertexAssign();

								// read / write this
								Read(FILE *filePtr, int version);
								Write(FILE *filePtr);
};


// --------------------------------------------------------------------------------
// ObeBone class
// --------------------------------------------------------------------------------
class ObeBone : public FileBase
{
	public:
		char					boneName[32];					// unique bone name
		char					meshNameRef[32];				// mesh name reference

		int						numVertAssigns;					// number of bone vertex assignments
		VertexAssign			*vertAssignList;				// array of bone vertex assignments

		AnimVector				posX;							// bone positions
		AnimVector				posY;
		AnimVector				posZ;

		AnimVector				scaleX;							// bone positions
		AnimVector				scaleY;
		AnimVector				scaleZ;

		AnimVector				orientationX;					// bone orientation
		AnimVector				orientationY;
		AnimVector				orientationZ;
		AnimVector				orientationW;

								// constructor / destructor
								ObeBone();
								~ObeBone();

								// set number of vertex assignments
		int						SetNumAssigns(int numAssigns);

								// bone read / write
		int						Read(FILE * filePtr, int version);
		int						Write(FILE * file);
};


// --------------------------------------------------------------------------------
// Jobe mesh data structure
// --------------------------------------------------------------------------------
typedef struct
{
	short			meshFlags;
	UCHAR			colourRGB[3];
	char			gouraudMode;
	UCHAR			translucency;
	char			transMode;
	char			meshSelected;
	SortList		sortList[8];
} JOBEMESHDATA;


// --------------------------------------------------------------------------------
// Data carried forward from import
// --------------------------------------------------------------------------------
typedef struct
{
	// unique mesh id
	unsigned long	meshId;				// crc of all polygon index info
	int				meshNumVerts;
	int				meshNumFaces;
	// did user import face data?
	int				importFaceData;
} IMPORTDATA;


// ********************************************************************************
// Experimental Types
// ********************************************************************************

// --------------------------------------------------------------------------------
// ObeMaxBone class
// --------------------------------------------------------------------------------
class ObeMaxBone : public FileBase
{
	public:
		char					name[32];						// unique bone name
		char					meshName[32];					// mesh name reference

		Point3					invRefPos;						// inverse reference position
		Point3					invRefScale;					// inverse reference scale
		Quat					invRefRot;						// inverse reference rotation

		AnimVector				posX;							// position anim
		AnimVector				posY;
		AnimVector				posZ;

		AnimVector				scaleX;							// scale anim
		AnimVector				scaleY;
		AnimVector				scaleZ;

		AnimVector				rotX;							// rotation anim
		AnimVector				rotY;
		AnimVector				rotZ;
		AnimVector				rotW;

		int						noofAssigns;					// number of vertex assignments
		VertexAssign			*assignArray;					// array of vertex assigns

								// constructor / destructor
								ObeMaxBone();
								~ObeMaxBone();

								// set number of vertex assignments
		void					NoofAssigns(int noof);

								// set assignment
		void					Assign(int n, int vertn, float weight);

								// write this
		int						Write(FILE * filePtr);
};

#endif