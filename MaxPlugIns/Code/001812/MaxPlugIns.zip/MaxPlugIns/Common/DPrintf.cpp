

#include "dprintf.h"
#include "max.h"
#include <string.h>


char	filenLog[256];
char	init = 0;

/* --------------------------------------------------------------------------------
   Function : DPrintf_Init
   Purpose : init debug log
   Parameters : debug log filename
   Returns : 
   Info : 
*/

void DPrintf_Init(char *filen)
{
	if (filen == NULL)
		filenLog[0] = 0;
	else
		strcpy(filenLog, filen);
	init = 1;
}


/* --------------------------------------------------------------------------------
   Function : DPrintf
   Purpose : debug print
   Parameters : variable argument list
   Returns : 
   Info : 
*/

void DPrintf(char *format, ...)
{
	static char		outp[1024];
	va_list			argp;
	FILE			*fp;

	va_start(argp, format);
	vsprintf(outp, format, argp);
	va_end(argp);

	// append carriage return
	sprintf(outp,"%s\n", outp);

	// debug window
	DebugPrint("%s", outp);

	// file
	if (init == 1 && (fp = fopen(filenLog, "a")) != NULL)
	{
		fprintf(fp, "%s", outp);
		fclose(fp);
	}
}
