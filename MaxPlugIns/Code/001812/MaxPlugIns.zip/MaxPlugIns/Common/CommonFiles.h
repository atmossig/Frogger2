

#ifndef	__COMMONFILES__H_
#define __COMMONFILES__H_

#include "Max.h"

#include "DPrintf.h"
#include "CRCGen.h"
#include "MaxSkin.h"


extern HINSTANCE hInstance;


// ----------------------------------------------------------------------------
// Our Memory Model
// 
// With Max complaining about memory releases during plugin development, use these
// macros to handle all our memory allocation releases

// release our memory allocations
#define	_RELEASE_ALL_MEMORY

// use these macros throughout the plugin when releasing memory
#ifdef _RELEASE_ALL_MEMORY
#define SAFE_FREE(X)			{ if (X) free((void *)X); (X) = NULL; }
#define SAFE_DELETE(X)			{ if (X) delete (X); (X) = NULL; }
#define SAFE_DELETE_ARRAY(X)	{ if (X) delete [] (X); (X) = NULL; }
#else
#define SAFE_FREE(X)
#define SAFE_DELETE(X)
#define SAFE_DELETE_ARRAY(X)
#endif


// ----------------------------------------------------------------------------
// Max Plugin Home Directory
// 
// This is where all the latest Max plugins live on our network.
// Used when checking for available lastest version

//#define PLUGIN_HOME_PATH	"x:\\TechTeam\\MaxPlugIns"						// back onto the x drive!
#define PLUGIN_HOME_PATH	"\\\\SERVER\\DATA\\TechTeam\\MaxPlugIns"


// ----------------------------------------------------------------------------
// Our Face Data Texture Mapping Channel
// 
// With the release of Max3, 100 Texture and Vertex Mapping Channels were added
// per mesh. We use one of these channels to store our face data.
// For the Max2.5 builds, we are forced to use the standard Texture Channel.

#if MAX_RELEASE >= 3000
#define PERFACEDATA_MAPPING_CHANNEL		2
#else
#define PERFACEDATA_MAPPING_CHANNEL		1
#endif


// ----------------------------------------------------------------------------
// Application Data Chunks
// 
// These define the chunk idents that any ISL Max PlugIn can use for attaching
// extra data to nodes

// genesis data
#define ADID_GENESIS_DATA		0x100					// we use this...

// sprite polygon data
#define ADID_POLYSPRITE_DATA	0x106

// unique mesh id
#define ADID_UNIQUE_ID			0x107

// old
#define ADID_FACEDAT		0x0101
#define ADID_SKIN_REGISTER	0x0102
#define ADID_SKIN_DATA		0x0103
#define ADID_JOBEMESH_DATA	0x0104
#define ADID_IMPORT_DATA	0x0105


/* --------------------------------------------------------------------------------
   Function : GetString
   Purpose : get string from string table resource
   Parameters : string resource id
   Returns : returns string or NULL
   Info : 
*/

TCHAR *GetString(int id);


/* --------------------------------------------------------------------------------
   Function : GetModuleTimeString
   Purpose : get ASCIIZ time from module
   Parameters : 
   Returns : returns coordinated universal time in ASCII
   Info : 
*/

TCHAR *GetModuleTimeString();


/* --------------------------------------------------------------------------------
   Function : CheckModuleLatestVersion
   Purpose : checks if a latest version of this plugin module exits on the network
   Parameters : 
   Returns : -1 - later version exists, 0 - version upto date, 1 - this is later
   Info : 
*/

int CheckModuleLatestVersion();


/* --------------------------------------------------------------------------------
   Function : EnumNodes
   Purpose : enumerate all nodes in the scene, passing a bool function to each
   Parameters : start node pointer, function pointer, node tab pointer
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

// node enumeration returns
#define NENUM_CONTINUE		0
#define NENUM_END			1
#define NENUM_ENDPATH		2

// enum node function type
typedef int (TEnumNodeFunc)(INode *nodePtr, void *context);

int EnumNodes(INode *root, TEnumNodeFunc *funcPtr, void *context = NULL);


/* --------------------------------------------------------------------------------
   Function : EnumNodes
   Purpose : enumerate all nodes in the scene, passing a bool function to each
   Parameters : start node pointer, pre function pointer, context, post function pointer, context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
*/

int EnumNodes(INode *root, TEnumNodeFunc *preFuncPtr, void *preContext, TEnumNodeFunc *postFuncPtr, void *postContext);

#endif
