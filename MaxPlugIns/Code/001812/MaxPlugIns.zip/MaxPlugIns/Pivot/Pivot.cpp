
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part Pivot.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : Pivot.cpp
// Purpose : Implementation of the utility
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "Pivot.h"

// parameter map indices
#define PMUTIL_TRANSFORM_RETAIN	0
#define PMUTIL_SCALE_RETAIN		1
#define PMUTIL_ROTATE_RETAIN	2

// array of parameter map description types
static ParamUIDesc mainParamMap[] =
{
	ParamUIDesc(PMUTIL_TRANSFORM_RETAIN, TYPE_SINGLECHEKBOX, IDC_MAIN_TRANSFORM_RETAIN),
	ParamUIDesc(PMUTIL_SCALE_RETAIN, TYPE_SINGLECHEKBOX, IDC_MAIN_SCALE_RETAIN),
	ParamUIDesc(PMUTIL_ROTATE_RETAIN, TYPE_SINGLECHEKBOX, IDC_MAIN_ROTATE_RETAIN),
};
#define MAIN_PARAM_MAP_LENGTH 3


// --------------------------------------------------------------------------------
// Pivot Class Definition
// --------------------------------------------------------------------------------
class Pivot : public UtilityObj, public IParamArray
{
	public:
		IUtil				*iu;
		Interface			*ip;

		IParamMap			*pmapMain;
		HWND				hMain;

		INode				*node;

		// Methods from UtilityObj
		void				BeginEditParams(Interface *ip, IUtil *iu);
		void				EndEditParams(Interface *ip, IUtil *iu);
		void				SelectionSetChanged(Interface *ip, IUtil *iu);
		void				DeleteThis() {}			// null since we use a single static instance

		// Methods from IParamArray
		BOOL				SetValue(int i, TimeValue t, int v);
		BOOL				GetValue(int i, TimeValue t, int &v, Interval &ivalid);
		BOOL				SetValue(int i, TimeValue t, float v);
		BOOL				GetValue(int i, TimeValue t, float &v, Interval &ivalid);

		// Local methods...
							Pivot();
		void				Init(HWND hWnd);
		void				Destroy(HWND hWnd);
		void				RedrawRollups();
		void				ViewPivot();
		void				ZeroPivot();

		// Local vars..
		int					bRetainTransform;
		int					bRetainScale;
		int					bRetainRotate;
};

// Static instance of the Utility plug-in.
static Pivot thePivot;


// --------------------------------------------------------------------------------
// NodeTMRestore Class Definition
// --------------------------------------------------------------------------------
class NodeTMRestore : public RestoreObj
{
	public:
		Pivot *uo;

		// Constructor
		NodeTMRestore(Pivot *u, INode *n, Matrix3 m, TimeValue t) { }

		// Called when Undo is selected
		void Restore(int isUndo) { }

		// Called when Redo is selected
		void Redo() { }

		// Called to return the size in bytes of this RestoreObj
		int Size() { return sizeof(NodeTMRestore); }
};


// --------------------------------------------------------------------------------
// MainUserDlgProc Class Definition / Implementation
// --------------------------------------------------------------------------------
class MainUserDlgProc : public ParamMapUserDlgProc
{
	public:
		Pivot				*uo;

							MainUserDlgProc(Pivot *u) { uo = u; }
							~MainUserDlgProc() { if (ccImage) ReleaseICustImage(ccImage); ccImage = NULL; if (hImageList) ImageList_Destroy(hImageList); hImageList = NULL; }
		BOOL				DlgProc(TimeValue t, IParamMap *map, HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
		void				DeleteThis() { delete this; }

		ICustImage			*ccImage;
		HIMAGELIST			hImageList;
};


/* --------------------------------------------------------------------------------
   Function : MainUserDlgProc::DlgProc
   Purpose : our main user dialog procedure
   Parameters : current time, parameter map, window handle, message, param1, param2
   Returns : dependant on the message
   Info : 
*/

BOOL MainUserDlgProc::DlgProc(TimeValue t, IParamMap *map, HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HBITMAP		hBMP, hMSK;
	int			ret;

	switch (msg)
	{
	case WM_INITDIALOG:

		// initialise button states
		ret = CheckDlgButton(hWnd, IDC_MAIN_TRANSFORM_RETAIN, uo->bRetainTransform);
		ret = CheckDlgButton(hWnd, IDC_MAIN_SCALE_RETAIN, uo->bRetainScale);
		ret = CheckDlgButton(hWnd, IDC_MAIN_ROTATE_RETAIN, uo->bRetainRotate);

		// init custom image - 84x19 pixels
		if (ccImage = GetICustImage(GetDlgItem(hWnd, IDC_MAIN_IMAGE)))
		{
			if (hImageList = ImageList_Create(86, 21, TRUE, 2, 2))
			{
				hBMP = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_LOGO_IMAGE));
				hMSK = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_LOGO_MASK));
				if (hBMP && hMSK)
				{
					ImageList_Add(hImageList, hBMP, hMSK);
					ccImage->SetImage(hImageList, 0, 86, 21);
				}
				if (hBMP)
					DeleteObject(hBMP);
				if (hMSK)
					DeleteObject(hMSK);
			}
		}
		return TRUE;

	case WM_DESTROY:

		// release images
		if (ccImage)
			ReleaseICustImage(ccImage);
		ccImage = NULL;
		if (hImageList)
			ImageList_Destroy(hImageList);
		hImageList = NULL;
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_MAIN_RESET_PIVOT:
			uo->ZeroPivot();
			uo->ViewPivot();
			return TRUE;

		case IDC_MAIN_TRANSFORM_RETAIN:
			uo->bRetainTransform = (IsDlgButtonChecked(hWnd, IDC_MAIN_TRANSFORM_RETAIN) == BST_CHECKED ) ? 1:0;
			return TRUE;

		case IDC_MAIN_SCALE_RETAIN:
			uo->bRetainScale = (IsDlgButtonChecked(hWnd, IDC_MAIN_SCALE_RETAIN) == BST_CHECKED ) ? 1:0;
			return TRUE;

		case IDC_MAIN_ROTATE_RETAIN:
			uo->bRetainRotate = (IsDlgButtonChecked(hWnd, IDC_MAIN_ROTATE_RETAIN) == BST_CHECKED ) ? 1:0;
			return TRUE;
		}
		break;

	default:
		return FALSE;
	}
	return FALSE; 
}


// --------------------------------------------------------------------------------
// Pivot Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : Pivot::Pivot
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

Pivot::Pivot()
{
	iu = NULL;
	ip = NULL;	

	bRetainTransform = 1;
	bRetainScale = 1;
	bRetainRotate = 1;
}


/* --------------------------------------------------------------------------------
   Function : Pivot::BeginEditParams
   Purpose : called when user wants to edit our utility
   Parameters : valid interface pointer, current utiltiy pointer
   Returns : 
   Info : 
*/

void Pivot::BeginEditParams(Interface *ip, IUtil *iu)
{
	DPrintf("Pivot::BeginEditParams()");

	this->iu = iu;
	this->ip = ip;

	pmapMain = CreateCPParamMap(mainParamMap, MAIN_PARAM_MAP_LENGTH, this, ip, hInstance, MAKEINTRESOURCE(IDD_MAIN), _T("Reset Pivot"), 0);
	pmapMain->SetUserDlgProc(new MainUserDlgProc(this));

	// check current node selection
	SelectionSetChanged(ip, iu);
}


/* --------------------------------------------------------------------------------
   Function : Pivot::EndEditParams
   Purpose : called when user ends editing our utility
   Parameters : valid interface pointer, current utility pointer
   Returns : 
   Info : 
*/

void Pivot::EndEditParams(Interface *ip, IUtil *iu)
{
	DPrintf("Pivot::EndEditParams()");

	if (pmapMain)
	{
		DestroyCPParamMap(pmapMain);
		pmapMain = NULL;
	}

	this->iu = NULL;
	this->ip = NULL;
}


/* --------------------------------------------------------------------------------
   Function : Pivot::SelectionSetChanged
   Purpose : called when the selection set changed
   Parameters : valid interface pointer, current utility pointer
   Returns : 
   Info : 
*/

void Pivot::SelectionSetChanged(Interface *ip, IUtil *iu)
{
	int		flag;

	// get currently selected node OR first node from multiple selection
	node = (flag = !(ip->GetSelNodeCount() < 1)) ? ip->GetSelNode(0) : NULL;

	// enable options
	EnableWindow(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_RESET_PIVOT), flag);

	// draw all dialog pivot infomation
	ViewPivot();
}


/* --------------------------------------------------------------------------------
   Function : Pivot::ViewPivot
   Purpose : draw currently selected nodes pivot infomation into the dialog
   Parameters : 
   Returns : 
   Info : 
*/

void Pivot::ViewPivot()
{
	Point3		offPos(0.f, 0.f, 0.f);
	ScaleValue	offScl(offPos);
	Quat		offRot(0.f, 0.f, 0.f, 1.f);
	float		offAngs[3];
	TCHAR		outp[64];

	// get pivot (object offset) infomation from selected node
	if (node)
	{
		offPos = node->GetObjOffsetPos();
	   	offScl = node->GetObjOffsetScale();
	   	offRot = node->GetObjOffsetRot();
	}

	// set transform display info
   	_stprintf(outp, _T("%.3f"), offPos.x);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_TRANSFORM_X), outp);
   	_stprintf(outp, _T("%.3f"), offPos.y);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_TRANSFORM_Y), outp);
   	_stprintf(outp, _T("%.3f"), offPos.z);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_TRANSFORM_Z), outp);

	// set scale display info
   	_stprintf(outp, _T("%.3f"), offScl.s.x);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_SCALE_X), outp);
   	_stprintf(outp, _T("%.3f"), offScl.s.y);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_SCALE_Y), outp);
   	_stprintf(outp, _T("%.3f"), offScl.s.z);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_SCALE_Z), outp);

	// set rotation display info
   	QuatToEuler(offRot, offAngs);
   	_stprintf(outp, _T("%.3f"), offAngs[0]);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_ROTATE_X), outp);
   	_stprintf(outp, _T("%.3f"), offAngs[1]);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_ROTATE_Y), outp);
   	_stprintf(outp, _T("%.3f"), offAngs[2]);
   	SetWindowText(GetDlgItem(pmapMain->GetHWnd(), IDC_MAIN_ROTATE_Z), outp);
}


/* --------------------------------------------------------------------------------
   Function : Pivot::ZeroPivot
   Purpose : zero the selected nodes pivot
   Parameters : 
   Returns : 
   Info : 
*/

// Zero Nodes Pivot - ( set to identity )
void Pivot::ZeroPivot()
{
	Point3		nullPos(0.f, 0.f, 0.f), offPos(0.f, 0.f, 0.f);
	ScaleValue	nullScale( Point3(1.f, 1.f, 1.f) ), offScale( Point3(1.f, 1.f, 1.f) );
	Quat		nullRot(0.f, 0.f, 0.f, 1.f), offRot(0.f, 0.f, 0.f, 1.f);
	Matrix3		matTrans(1), matScale(1), matRot(1), matFinal(1), matInvFinal(1), matNode(1);

	if (!node )
		return;

	// construct nodes object offset (pivot) matrix
	offPos = bRetainTransform ? node->GetObjOffsetPos() : nullPos;
   	offScale = bRetainScale ? node->GetObjOffsetScale() : nullScale;
   	offRot = bRetainRotate ? node->GetObjOffsetRot() : nullRot;

	matTrans.Translate(offPos);
	offRot.MakeMatrix(matRot);
	matScale.Scale(offScale.s);
	matFinal = (matRot * matScale) * matTrans;		// final pivot matrix
	matInvFinal = Inverse(matFinal);				// final inverse pivot matrix
	
	// current nodes transform matrix
	matNode = node->GetNodeTM(0);
	matNode = matFinal * matNode;					// undo pivot matrix
	node->SetNodeTM(0, matNode);

	// nullify the nodes pivot matrix
	node->SetObjOffsetPos(nullPos);
   	node->SetObjOffsetScale(nullScale);
   	node->SetObjOffsetRot(nullRot);
	return;

	// -------------------------------------------------------------------
	// the below code simply tries to force a pivot reset by transforming
	// all the mesh vertices with the offset transform..
	// ignorance is bliss!!!!
	// this isn't the answer to our problems..

	ObjectState	objectState;
	Object		*object;
	TriObject	*triObject;
	Mesh		*mesh;
	Point3		p, v;
	Quat		q;
	ScaleValue	s;
	Matrix3		offsetMatrix;
	int			i;

	// valid node?
	if (node == NULL)
		return;

	// get the object edit mesh
	objectState = node->EvalWorldState(0);
	object = (Object *)objectState.obj;
	if (object->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)) == 0)
		return;
	triObject = (TriObject *)object->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
	if (triObject != object)
		return;
	mesh = &triObject->mesh;

	// construct the object offset transform matrix
	p = node->GetObjOffsetPos();
	q = node->GetObjOffsetRot();
	s = node->GetObjOffsetScale();
	offsetMatrix.IdentityMatrix();
	offsetMatrix.PreTranslate(p);
	PreRotateMatrix(offsetMatrix, q);
	ApplyScaling(offsetMatrix, s);

	// transform all mesh vertices with pivot transform
	for (i=0; i<mesh->numVerts; i++)
		{
			v = mesh->verts[i];
			v = offsetMatrix * v;
			mesh->verts[i] = v;
		}

	// set the object offset to identity
	p.x = p.y = p.z = 0.0f;
	q.Identity();
	s.s.x = s.s.y = s.s.z = 1.0f;
	s.q.Identity();
	node->SetObjOffsetPos(p);
   	node->SetObjOffsetRot(q);
   	node->SetObjOffsetScale(s);

	return;
}

// From IParamArray

BOOL Pivot::SetValue(int i, TimeValue t, int v)
{
	switch(i)
	{
		case PMUTIL_TRANSFORM_RETAIN:
			bRetainTransform = v;
			break;
		case PMUTIL_SCALE_RETAIN:
			bRetainScale = v;
			break;
		case PMUTIL_ROTATE_RETAIN:
			bRetainRotate = v;
			break;
	}
	return TRUE;
}

BOOL Pivot::GetValue(int i, TimeValue t, int &v, Interval &ivalid)
{
	switch(i)
	{
		case PMUTIL_TRANSFORM_RETAIN:
			v = bRetainTransform;
			break;
		case PMUTIL_SCALE_RETAIN:
			v = bRetainScale;
			break;
		case PMUTIL_ROTATE_RETAIN:
			v = bRetainRotate;
			break;
	}
	return TRUE;
}

BOOL Pivot::SetValue(int i, TimeValue t, float v)
{
//	switch (i)
//	{
//	}
	return TRUE;
}

BOOL Pivot::GetValue(int i, TimeValue t, float &v, Interval &ivalid)
{
	v = 0;
//	switch (i)
//	{
//	}
	return TRUE;
}


// ===============================================================
// Local methods of Pivot
// ===============================================================

void Pivot::Init(HWND hWnd)
{
}

void Pivot::Destroy(HWND hWnd)
{
}

// Make sure all the user interface controls get redrawn
void Pivot::RedrawRollups()
{
	pmapMain->Invalidate();
}


class PivotClassDesc : public ClassDesc
{
	public:
	int 			IsPublic() {return 1;}
	void *			Create(BOOL loading = FALSE) {return &thePivot;}
	const TCHAR *	ClassName() {return GetString(IDS_CLASS_NAME);}
	SClass_ID		SuperClassID() {return UTILITY_CLASS_ID;}
	Class_ID		ClassID() {return PIVOT_CLASS_ID;}
	const TCHAR* 	Category() {return GetString(IDS_CATEGORY);}
};

static PivotClassDesc PivotDesc;
ClassDesc *GetPivotDesc() {return &PivotDesc;}
