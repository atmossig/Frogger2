
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of BlitzUtils.dlu, (c) 2000 Blitz Games Ltd.
//
//    File : BlitzUtils.cpp
// Purpose : Implementation of the utility
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "BlitzUtils.h"

#include "resource.h"


// BlitzUtils class ident
#define BLITZUTILS_CLASS_ID	Class_ID(0xc518801, 0x7ce99bee)

// window message on node selection changed
#define WMU_SELCHANGE	(WM_USER+2048)


// --------------------------------------------------------------------------------
// BlitaUtils Class Definition
// --------------------------------------------------------------------------------
class BlitzUtils : public UtilityObj
{
	public:
		HWND						hPanel;
		IUtil						*iu;
		Interface					*ip;
		
		// methods derived from UtilityObj
		void						BeginEditParams(Interface *ip,IUtil *iu);
		void						EndEditParams(Interface *ip,IUtil *iu);
		void						SelectionSetChanged(Interface *ip, IUtil *iu);

									// write node's soft skin assignments
		int							WriteSoftSkin(INode *node);

		void						Init(HWND hWnd);
		void						Destroy(HWND hWnd);

		void						DeleteThis() {}						// null since we use a single static instance

									// constructor / destructor
									BlitzUtils();
									~BlitzUtils();
};

// single static instance of our class definition
static BlitzUtils theBlitzUtils;

class BlitzUtilsClassDesc:public ClassDesc
{
	public:
		int 			IsPublic()						{return 1;}
		void			*Create(BOOL loading = FALSE)	{return &theBlitzUtils;}
		const TCHAR		*ClassName()					{return GetString(IDS_CLASS_NAME);}
		SClass_ID		SuperClassID()					{return UTILITY_CLASS_ID;}
		Class_ID		ClassID()						{return BLITZUTILS_CLASS_ID;}
		const TCHAR		*Category()						{return GetString(IDS_CATEGORY);}
		void			ResetClassParams(BOOL reset)	{}
};

// instance of our class descriptor
static BlitzUtilsClassDesc BlitzUtilsDesc;
ClassDesc *GetBlitzUtilsDesc() {return &BlitzUtilsDesc;}


// main panel dialog procedure
static BOOL CALLBACK blitzUtilsDialogProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);


// --------------------------------------------------------------------------------
// BlitzUtils Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : BlitzUtils::BlitzUtils
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

BlitzUtils::BlitzUtils()
{
	iu = NULL;
	ip = NULL;	
	hPanel = NULL;
}


/* --------------------------------------------------------------------------------
   Function : BlitzUtils::BlitzUtils
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

BlitzUtils::~BlitzUtils()
{
}


/* --------------------------------------------------------------------------------
   Function : BlitzUtils::BeginEditParams
   Purpose : begin edit parameters
   Parameters : 
   Returns : 
   Info : 
*/

void BlitzUtils::BeginEditParams(Interface *ip,IUtil *iu) 
{
	this->iu = iu;
	this->ip = ip;

	// add our rollup page in the panel
	hPanel = ip->AddRollupPage(hInstance, MAKEINTRESOURCE(IDD_PANEL), ::blitzUtilsDialogProc, GetString(IDS_PARAMS), (LPARAM)this);

	// check for new node selection
	SelectionSetChanged(ip, iu);
}
	

/* --------------------------------------------------------------------------------
   Function : BlitzUtils::EndEditParams
   Purpose : end edit parameters
   Parameters : 
   Returns : 
   Info : 
*/

void BlitzUtils::EndEditParams(Interface *ip,IUtil *iu) 
{
	ip->DeleteRollupPage(hPanel);
	hPanel = NULL;

	this->iu = NULL;
	this->ip = NULL;
}


/* --------------------------------------------------------------------------------
   Function : BlitzUtils::SelectionSetChanged
   Purpose : called when the selection set changed
   Parameters : valid interface pointer, current utility pointer
   Returns : 
   Info : 
*/

void BlitzUtils::SelectionSetChanged(Interface *ip, IUtil *iu)
{
	INode	*node;

	node = (ip->GetSelNodeCount() >= 1) ? ip->GetSelNode(0) : NULL;
	if (hPanel)
		SendMessage(hPanel, WMU_SELCHANGE, 0, 0);
}


/* --------------------------------------------------------------------------------
   Function : BlitzUtils::Init
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void BlitzUtils::Init(HWND hWnd)
{
}


/* --------------------------------------------------------------------------------
   Function : BlitzUtils::Destroy
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

void BlitzUtils::Destroy(HWND hWnd)
{
}


/* --------------------------------------------------------------------------------
   Function : BlitzUtils::WriteSoftSkin
   Purpose : write soft skin assignments
   Parameters : soft skin node pointer
   Returns : 
   Info : 
*/

int BlitzUtils::WriteSoftSkin(INode *node)
{
	BonesDefMod		*mod;

	if ((mod = MaxSkin_GetModifier(ip, node)) == NULL)
		return 0;

//	write all used bones and there indices
//		bone index
//		bone name
//	write all vertices
//		number of bone assignments
//		bone1 weight, bone2 weight, etc..

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : blitzUtilsDialogProc
   Purpose : our panel page window procedure
   Parameters : dialog handle, message, additional message info, additional message info
   Returns : return TRUE if processed message, else FALSE
   Info : 
*/

static BOOL CALLBACK blitzUtilsDialogProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static TCHAR		outp[260], fname[_MAX_FNAME];
	static ICustImage	*image = NULL;
	static HIMAGELIST	imageList = NULL;
	HBITMAP				bitmap, mask;
	int					i, noof;


	switch (msg)
	{
	case WM_INITDIALOG:

		// create custom image list within our dialog
		image = GetICustImage(GetDlgItem(hWnd, IDC_ISLLOGO));
		imageList = ImageList_Create(86, 21, TRUE, 2, 2);
		// load image bitmaps and assign to the image list
		bitmap = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BLITZIMAGE));
		mask = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BLITZMASK));
		ImageList_Add(imageList, bitmap, mask);
		// delete our images
		DeleteObject(mask);
		DeleteObject(bitmap);
		image->SetImage(imageList, 0, 86, 21);

		theBlitzUtils.Init(hWnd);

		// do *not* set keyboard focus
		return FALSE;

	case WM_DESTROY:

		// release images
		if (image)
			ReleaseICustImage(image);
		image = NULL;
		if (imageList)
			ImageList_Destroy(imageList);
		imageList = NULL;

		theBlitzUtils.Destroy(hWnd);
		break;

	case WM_COMMAND:
		break;

	case WMU_SELCHANGE:

		// count number of selected soft skins
		noof = 0;
		for (i=0; i<theBlitzUtils.ip->GetSelNodeCount(); i++)
			if (MaxSkin_IsNode(theBlitzUtils.ip->GetSelNode(i)) == 1)
			{
				noof++;
			}

		// enable / disable selections
		EnableWindow(GetDlgItem(hWnd, IDC_ASSIGNS_IMPORT), (noof > 0) ? TRUE : FALSE);
		EnableWindow(GetDlgItem(hWnd, IDC_ASSIGNS_EXPORT), (noof > 0) ? TRUE : FALSE);
		EnableWindow(GetDlgItem(hWnd, IDC_SELNODENAME), (noof > 0) ? TRUE : FALSE);

		// print node selection name
		if (noof == 0)
			_stprintf(outp, _T("Node: ????"), (lParam != NULL) ? ((INode *)lParam)->GetName() : "???");
		else if (noof == 1)
		{
			for (i=0; i<theBlitzUtils.ip->GetSelNodeCount(); i++)
				if (MaxSkin_IsNode(theBlitzUtils.ip->GetSelNode(i)) == 1)
				{
					_stprintf(outp, _T("Node: %s"), theBlitzUtils.ip->GetSelNode(i)->GetName());
					break;
				}
		}
		else
			_stprintf(outp, _T("Node: *MULTIPLE*"));
		SetWindowText(GetDlgItem(hWnd, IDC_SELNODENAME), outp);
		break;

	case IDC_ASSIGNS_EXPORT:

		// write all selected node's soft skin assigments
		for (i=0; i<theBlitzUtils.ip->GetSelNodeCount(); i++)
			if (MaxSkin_IsNode(theBlitzUtils.ip->GetSelNode(i)) == 1)
			{
				theBlitzUtils.WriteSoftSkin(theBlitzUtils.ip->GetSelNode(i));
			}
		break;

	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_LBUTTONDOWN:
		// pass up rollup mouse messages
		theBlitzUtils.ip->RollupMouseMessage(hWnd, msg, wParam, lParam);
		break;

	default:
		return FALSE;
	}
	return TRUE;
}
