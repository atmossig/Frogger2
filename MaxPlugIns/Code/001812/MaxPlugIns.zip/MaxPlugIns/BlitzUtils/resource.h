//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BlitzUtils.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDD_PANEL                       101
#define IDB_BLITZMASK                   101
#define IDB_BLITZIMAGE                  102
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_ASSIGNS_IMPORT              1003
#define IDC_ASSIGNS_EXPORT              1004
#define IDC_SELNODENAME                 1006
#define IDC_ISLLOGO                     1010
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
