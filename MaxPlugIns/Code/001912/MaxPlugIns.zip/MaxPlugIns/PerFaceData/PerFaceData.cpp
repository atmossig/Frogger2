
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of PerFaceMod.dlm, (c) 2000 Interactive Studios Ltd.
//
//    File : PerFaceData.cpp
// Purpose : Implementation of the modifier
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "PerFaceData.h"

#include "resource.h"


// -------------------
// Macros

// macro helper to compare face idents - return 1 if equal
#define CMPEQUAL_IDENTS(v0,v1,v2, c0,c1,c2)		(v0==c0 && v1==c1 && v2==c2)

// macro helper to get "perfacedata" from currently edited nodes mod context
#define GETPERFACEDATA(_PERFACEDATA_)																\
				ModContextList	mcList;																\
				INodeTab		mcNodes;															\
				int				mcIndex;															\
				ip->GetModContexts(mcList, mcNodes);												\
				for (mcIndex=0; mcIndex<mcList.Count(); mcIndex++)									\
					if ((_PERFACEDATA_ = (PerFaceModData *)mcList[mcIndex]->localData) != NULL)


// -------------------
// Types And Constants

// un-comment to try and rescue all face data changes
//#define RESCUE_DATA_CHANGES

// size of hash table entry
#define HASH_SIZE_ENTRY		50

// sub object selection levels
#define SEL_OBJECT	0
#define SEL_FACE	1
#define SEL_POLY	2

// modifier chunk idents
#define MODCHUNK_SELLEVEL		0x010
#define MODCHUNK_VERSION		0x020

// local data chunk idents
#define LCLCHUNK_FACESEL					0x110
#define LCLCHUNK_UPDATE						0x120
#define LCLCHUNK_NAME						0x130
#define LCLCHUNK_NOOFDATA					0x140
#define LCLCHUNK_DATAENTRY					0x150
#define LCLCHUNK_FORMAT_BEGIN				0x160
#define LCLCHUNK_FORMAT_END					0x170
#define LCLCHUNK_FORMAT_NODE_BEGIN			0x180
#define LCLCHUNK_FORMAT_NODE_END			0x190
#define LCLCHUNK_FORMAT_ATTRIB_STRING		0x1a0
#define LCLCHUNK_FORMAT_ATTRIB_INT			0x1b0
#define LCLCHUNK_FORMAT_ATTRIB_FLOAT		0x1c0
#define LCLCHUNK_FORMAT_ATTRIB_BOOL			0x1d0
#define LCLCHUNK_FORMAT_ATTRIB_ENUMSTRING	0x1e0
#define LCLCHUNK_FORMAT_ATTRIB_ENUMINT		0x1f0
#define LCLCHUNK_FORMAT_ATTRIB_ENUMFLOAT	0x200

// current version level
#define VERSION_LEVEL			2

// set maximum number of steps
#define MAX_SPINNER_STEPS		100

// format data dimensions
#define FRMD_GROUPXP			5					// group within rollup xp
#define FRMD_GROUPYP			8					// group yp
#define FRMD_GROUPWD			153					// group width
#define FRMD_GROUPYO			8					// group offset to next group
#define FRMD_CTRLXP				12					// control within groups xp
#define FRMD_CTRLYP				18					// control yp
#define FRMD_CTRLYI_			28					// control offset to next control
#define FRMD_CTRLYI_CLOSE		20					// control offset to next control (closer than above for related data types)
#define	FRMD_CTRLHT_			17					// control height
#define FRMD_CTRLNAMEWD			50					// control name width
#define FRMD_CTRLENUMXP			FRMD_CTRLXP			// control enumerator xp
#define FRMD_CTRLENUMWD			88					// control enumerator width
#define FRMD_CTRLENUMHT			200					// control enumerator (open combo box) height
#define FRMD_CTRLSTRINGXP		FRMD_CTRLXP			// control string xp
#define FRMD_CTRLSTRINGWD		88					// control string width
#define FRMD_CTRLFLOATXP		FRMD_CTRLXP			// control float xp
#define FRMD_CTRLFLOATWD		73					// control float width
#define FRMD_CTRLINTXP			FRMD_CTRLXP			// control integer xp
#define FRMD_CTRLINTWD			73					// control integer width
#define FRMD_CTRLBOOLXP			FRMD_CTRLXP + 6		// control boolean xp
#define FRMD_CTRLBOOLWD			126					// control boolean width
#define FRMD_CTRLDATAXP			FRMD_CTRLXP + 6		// control data xp
#define FRMD_CTRLDATAWD			126					// control data width
#define FRMD_CTRLCOLOURXP		FRMD_CTRLXP			// control colour xp
#define FRMD_CTRLCOLBIGWD		88					// control colour width
#define FRMD_CTRLCOLSMLWD		66					// control colour width
#define FRMD_CTRLCOLALPWD		22					// control colour alpha width

// format data types
// ** NB: if new data types are editted in any way, we also need to update
// ** dataTypesCompatibilityTable
enum FRMTYPES
{
	FRMTYPE_NULL,
	FRMTYPE_GROUP,
	FRMTYPE_ROLLUP,
	FRMTYPE_STRING,
	FRMTYPE_INT_UCHAR,
	FRMTYPE_INT_SCHAR,
	FRMTYPE_INT_USHORT,
	FRMTYPE_INT_SSHORT,
	FRMTYPE_INT_UINT,
	FRMTYPE_INT_SINT,
	FRMTYPE_FLOAT,
	FRMTYPE_BOOL_UCHAR,
	FRMTYPE_BOOL_USHORT,
	FRMTYPE_BOOL_UINT,
	FRMTYPE_ENUM_UCHAR,
	FRMTYPE_ENUM_USHORT,
	FRMTYPE_ENUM_UINT,
	FRMTYPE_DATA,
	FRMTYPE_COLOUR,

	FRMTYPE_END,
};

// data packet
typedef struct _TData
{
	char	*data;
	int		size;
	int		offset;
} TData;

// data entry
typedef struct _TDataEntry
{
	char	*data;
	int		index;
} TDataEntry;

// data log structure
typedef struct _TDataLog
{
	TDataEntry	*entries;
	int			noof;
	int			size;
	int			offset;
} TDataLog;

// merge data structure
typedef struct _TMergeData
{
	TData		*newData;
	TData		*oldData;
	CPMLevel	*oldFormatInst;
} TMergeData;

// panel data structure
typedef struct _TPanelInfo
{
	class PerFaceMod		*pfMod;
	class PerFaceModData	*pfData;
	class CPMNode			*ruNode;
} TPanelInfo;

// format data structure
typedef struct _TRollupInfo
{
	HWND		parent;
	HFONT		font;
	int			yCur;
	int			controlId;
} TRollupInfo;

// format rollup data structure
typedef struct _TFormatRollup
{
	HWND		hwnd;
} TFormatRollup;

// format group data structure
typedef struct _TFormatGroup
{
	HWND		hwnd;
} TFormatGroup;

// format control structure
typedef struct _TFormatControl
{
	HWND				hwndName;
	union
	{
	HWND				hwndEdit;
	HWND				hwndCombo;
	HWND				hwndBut;
	HWND				hwndStatus;
	HWND				hwndColour;
	};
	union
	{
	HWND				hwndSpin;
	HWND				hwndAlpha;
	};
	ICustEdit			*custEdit;
	ISpinnerControl		*custSpin;
	ICustStatus			*custStatus;
	IColorSwatch		*custColour;
	IColorSwatch		*custAlpha;
	// unique id
	int					controlId;
	// flags
	unsigned int		noColourEditFlag:1;
	unsigned int		noAlphaEditFlag:1;
} TFormatControl;

// search node structure
typedef struct _TSearchNode
{
	char		*ident;
	CPMNode		*node;
} TSearchNode;

// format attribute tags
#define FRMT_ROLLUP		"__ROLLUP_TAG__"
#define FRMT_GROUP		"__GROUP_TAG__"
#define FRMT_CONTROL	"__CONTROL_TAG__"
#define FRMT_REMAP		"__REMAP_TAG__"

// window message on subobject selection changed
#define WMU_SELOLD		(WM_USER+2048)				// old selection
#define WMU_SELNEW		(WM_USER+2049)				// new selection
#define WMU_SELENABLE	(WM_USER+2050)				// enable selection

// unique ident base
#define IDENT_BASE		0x1000

// data size strings
#define DATS_UCHAR		"uchar"
#define DATS_SCHAR		"schar"
#define DATS_USHORT		"ushort"
#define DATS_SSHORT		"sshort"
#define DATS_UINT		"uint"
#define DATS_SINT		"sint"


// ------------------
// Function templates

// ** Support Functions

// return CPMNode nodes data type
static int getNodeDataType(CPMNode *node);

// return this nodes data size
static int getNodeDataSize(CPMNode *node);

// align node data for access
static int alignNodeDataAccess(CPMNode *node, int offset);

// are CPMNode nodes data type compatible?
static int areNodeDataTypesCompatible(CPMNode *node1, CPMNode *node2);

// load data format from Max file
static IOResult loadFormatData(CPMNode *node, ILoad *iload, int version);

// write integer value to data
static void writeData(CPMNode *node, TData *data, int ival);
// write float value to data
static void writeData(CPMNode *node, TData *data, float fval);
// write boolean value to data
static void writeData(CPMNode *node, TData *data, bool bval);
// write string value to data
static void writeData(CPMNode *node, TData *data, char *string, int length);
// write colour value to data
static void writeData(CPMNode *node, TData *data, unsigned char *rgba, int length);

// read integer value from data
static void readData(CPMNode *node, TData *data, int& ival);
// read float value from data
static void readData(CPMNode *node, TData *data, float& fval);
// read boolean value from data
static void readData(CPMNode *node, TData *data, bool& bval);
// read string value from data
static char *readData(CPMNode *node, TData *data, char *string, int length);
// read colour value from data
static unsigned char *readData(CPMNode *node, TData *data, unsigned char *rgba, int length);


// ** Dialog Procedure Callbacks

// main panel
static BOOL CALLBACK Proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// rollup panel
static BOOL CALLBACK procRollupDialog(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);


// ** CPMNode Enumeration Callbacks

// add data types
static int procAddRollup(CPMNode *node, void *context);
static int procAddGroup(CPMNode *node, void *context);
static int procAddControl(CPMNode *node, void *context);
static int procDelRollup(CPMNode *node, void *context);
static int procDelGroup(CPMNode *node, void *context);
static int procDelControl(CPMNode *node, void *context);

// calc control data size
static int procCalcDataSize(CPMNode *node, void *context);

// map defaults to data
static int procMapDefaultsToData(CPMNode *node, void *context);
// map multiple data to controls
static int procMapMultipleDataToControls(CPMNode *node, void *context);
// map controls into multiple data
static int procMapControlsToMultipleData(CPMNode *node, void *context);

// write data format to Max file
static int procPreWriteNodes(CPMNode *node, void *context);
static int procPostWriteNodes(CPMNode *node, void *context);

// enable/disable controls
static int procEnableControls(CPMNode *node, void *context);

// rebuild format data tree incorporating, where possible, from existing
static int procMergeFormatData(CPMNode *node, void *context);
// merge into default data all retained data
static int procMergeInData(CPMNode *node, void *context);
// remove all merge tags
static int procRemoveMergeInfo(CPMNode *node, void *context);

// find node identified by ident attribute
static int procFindNode(CPMNode *node, void *context);

// read data up until our target node is reached
static int procReadDataUntilNode(CPMNode *node, void *context);

// remove all extra non-data nodes from cloned data
static int procTidyClonedData(CPMNode *node, void *context);

// write format data to a file stream
static int procWriteFormatData(CPMNode *node, void *context);

// flag colour swatch control attribute editted within colour swatch node
static int procColourEdit(CPMNode *node, void *context);
// lock alpha component
static int procLockAlpha(CPMNode *node, void *context);

// ** CPMAttrib Enumeration Callbacks

// write attributes to Max file
static int procWriteAttribs(CPMAttrib *attrib, void *context);

// write attributes to file stream
static int procWriteAttribs(CPMAttrib *attrib, void *context);


// --------------------------------------------------------------------------------
// PerFaceMod Class Definition
// --------------------------------------------------------------------------------
class PerFaceMod : public Modifier
{
	public:
		static IObjParam			*ip;						// interface access
		static IParamMap			*pmapParam;					// parameter map
		static SelectModBoxCMode	*selectMode;				// face selection command mode
		static HWND					panelHandle;				// panel dialog handle

		// Parameter block
		IParamBlock					*pblock;					// reference 0

		DWORD						selLevel;					// selection level
		int							version;					// version

		int							justLoadedFlag;				// use this flag to ignore Max's initial NotifyInputChanged call

		// Copy Buffer
		void						*copyBuffer;				// copy buffer
		int							copyBufferFull;				// set if the copy buffer is valid


		// Constructor/Destructor
									PerFaceMod();
									~PerFaceMod();

		// From Modifier
		ChannelMask					ChannelsUsed()			{return OBJ_CHANNELS;}
		ChannelMask					ChannelsChanged()		{return SELECT_CHANNEL|SUBSEL_TYPE_CHANNEL;}
		void						ModifyObject(TimeValue t, ModContext &mc, ObjectState *os, INode *node);
		Class_ID					InputType()				{return defObjectClassID;}
		Interval					LocalValidity(TimeValue t);
		void						NotifyInputChanged(Interval changeInt, PartID partID, RefMessage message, ModContext *mc);
		IOResult					Load(ILoad *iload);
		IOResult					Save(ISave *isave);
		IOResult					SaveLocalData(ISave *isave, LocalModData *pld);
		IOResult					LoadLocalData(ILoad *iload, LocalModData **pld);

		// From BaseObject
		BOOL						ChangeTopology()		{return FALSE;}
		int							GetParamBlockIndex(int id)
															{return id;}
		void						ActivateSubobjSel(int level, XFormModes& modes);
		void						SelectSubComponent(HitRecord *hitRec, BOOL selected, BOOL all, BOOL invert);
		void						SelectAll(int selLevel);
		void						ClearSelection(int selLevel);
		void						InvertSelection(int selLevel);
		int							HitTest(TimeValue t, INode* inode, int type, int crossing, int flags, IPoint2 *p, ViewExp *vpt, ModContext* mc);

		// From ReferenceMaker
		int							NumRefs()				{return 1;}
		RefTargetHandle				GetReference(int i)		{return pblock;}
		void						SetReference(int i, RefTargetHandle rtarg)
															{pblock=(IParamBlock*)rtarg;}
		int							NumSubs()				{return 1;}  
		Animatable					*SubAnim(int i)			{return pblock;}
		TSTR						SubAnimName(int i)		{return GetString(IDS_PARAMS);}

		IParamArray					*GetParamBlock()		{return pblock;}

		// From ReferenceTarget
		RefResult					NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID,  RefMessage message)
															{return REF_SUCCEED;}
		// From Animatable
		void						DeleteThis()			{delete this;}
		void						GetClassName(TSTR& s)	{s = TSTR(GetString(IDS_CLASS_NAME));}
		virtual Class_ID			ClassID()				{return PERFACEDATA_CLASS_ID;}	
		RefTargetHandle				Clone(RemapDir& remap = NoRemap());
		TCHAR						*GetObjectName()		{return GetString(IDS_CLASS_NAME);}
		CreateMouseCallBack*		GetCreateMouseCallBack()
															{return NULL;}
		void						BeginEditParams(IObjParam *ip, ULONG flags,Animatable *prev);
		void						EndEditParams(IObjParam *ip, ULONG flags,Animatable *next);

		// Automatic texture support
		BOOL						HasUVW()				{return TRUE;}
		void						SetGenUVW(BOOL sw)		{if (sw==HasUVW()) return;}

		BOOL						Proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
};


// --------------------------------------------------------------------------------
// PerFaceMod Class Descriptor
// --------------------------------------------------------------------------------
class PerFaceModClassDesc:public ClassDesc
{
	public:
		int 			IsPublic()						{return 1;}
		void			*Create(BOOL loading = FALSE)	{return new PerFaceMod();}
		const TCHAR		*ClassName()					{return GetString(IDS_CLASS_NAME);}
		SClass_ID		SuperClassID()					{return OSM_CLASS_ID;}
		Class_ID		ClassID()						{return PERFACEDATA_CLASS_ID;}
		const TCHAR		*Category()						{return GetString(IDS_CATEGORY);}
		void			ResetClassParams(BOOL reset)	{}
};

// instance of our class descriptor
static PerFaceModClassDesc PerFaceModDesc;
ClassDesc* GetPerFaceModDesc() {return &PerFaceModDesc;}



//TODO: Add Parameter block indices for various parameters
#define PB_SPINNER			0

//TODO: Add ParamUIDesc's for the various parameters
static ParamUIDesc descParam[] = {
	// Spinner
	ParamUIDesc(
		PB_SPINNER,
		EDITTYPE_FLOAT,
		IDC_EDIT,IDC_SPIN,
		0.0f,1000.0f,
		0.1f),	
	}; 	

//TODO: Parameter descriptor length
#define PARAMDESC_LENGTH 1

//TODO: Add ParamBlockDescID's for the various parameters
static ParamBlockDescID descVer1[] = {
	{ TYPE_FLOAT, NULL, TRUE, 0 },	//spinner
	};

#define CURRENT_DESCRIPTOR descVer1

#define PBLOCK_LENGTH	1

#define CURRENT_VERSION	1



// --------------------------------------------------------------------------------
// PerFaceMod Class Implementation
// --------------------------------------------------------------------------------

// max interface
IObjParam			*PerFaceMod::ip = NULL;
// parameter map
IParamMap			*PerFaceMod::pmapParam = NULL;
// selection command mode
SelectModBoxCMode	*PerFaceMod::selectMode = NULL;
// rollup page handle
HWND				PerFaceMod::panelHandle = NULL;


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::PerFaceMod
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceMod::PerFaceMod()
{
	version = VERSION_LEVEL;
	selLevel = SEL_OBJECT;
	pblock = CreateParameterBlock(CURRENT_DESCRIPTOR, PBLOCK_LENGTH, CURRENT_VERSION);
	MakeRefByID(FOREVER, 0, pblock);
	justLoadedFlag = 0;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::~PerFaceMod
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceMod::~PerFaceMod()
{
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::LocalValidity
   Purpose : this method returns the validity interval of the modifier
   Parameters : the anim time to calculate the interval
   Returns : validity interval
   Info : 
*/

Interval PerFaceMod::LocalValidity(TimeValue t)
{
	// if being edited, return NEVER forces a cache to be built after previous modifier
	if (TestAFlag(A_MOD_BEING_EDITED))
		return NEVER;

	// ** As we are not an animated modifier we can return FOREVER. We need to call
	// ** NotifyDependents to cause re-evaluation

	return FOREVER;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::Clone
   Purpose : clone this modifier
   Parameters : remap reference
   Returns : 
   Info : 
*/

RefTargetHandle PerFaceMod::Clone(RemapDir& remap)
{
	PerFaceMod	*newmod;
	newmod = new PerFaceMod();
	if (newmod != NULL)
		newmod->ReplaceReference(0, pblock->Clone(remap));
	return (newmod);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::ModifyObject
   Purpose : entry to modifiers pipeline
   Parameters : modification anim time, reference to this instance's modcontext,
				object flowing through pipeline, node modifying = NULL
   Returns : 
   Info : 
*/

void PerFaceMod::ModifyObject(TimeValue t, ModContext &mc, ObjectState * os, INode *node) 
{
	TriObject		*triObject;
	PerFaceModData	*perFaceData;
	PerFaceEntry	*perFace;
	BitArray		faceSel;
	Interval		valid;
	TVFace			*mapFace;
	int				i;
#ifdef RESCUE_DATA_CHANGES
	int				v0,v1,v2, hits;
	PerFaceEntry	*listPtr;
#endif


	// get tri object flowing down the pipeline
	if (os->obj->IsSubClassOf(triObjectClassID) == FALSE)
		return;
	triObject = (TriObject *)os->obj;
	Mesh &mesh = triObject->mesh;

	// is our data texture map channel supported?
#if MAX_RELEASE >= 3000
	if (mesh.mapSupport(PERFACEDATA_MAPPING_CHANNEL) == FALSE)
#else
	if (mesh.tvFace == NULL)
#endif
	{
		DPrintf("Mapping channel %d invalid", PERFACEDATA_MAPPING_CHANNEL);
		return;
	}


	// ** This part of the modifier manages our cached mesh and its corresponding
	// ** face data. If the data held is invalid, ie. a significant change as been
	// ** registered on the input mesh, we have to update our local data to match
	// ** this change.

	// get this instance of the modifiers local data
	perFaceData = (PerFaceModData *)mc.localData;
	if (perFaceData == NULL)
	{
		// ** No local data attached to this instance of the modifier therefore we can
		// ** assume that this object either wasn't imported OR the modifier had been
		// ** deleted.

		// create local data instance for this object
		mc.localData = perFaceData = new PerFaceModData();
		DPrintf("'PerFaceModData' instance created by modifier");

		// create an entry of face data for all mesh faces
#if PERFACEDATA_MAPPING_CHANNEL == 1
		mapFace = mesh.tvFace;
#else
		mapFace = mesh.mapFaces(PERFACEDATA_MAPPING_CHANNEL);
#endif
		for (i=0; i<mesh.getNumFaces(); i++, mapFace++)
		{
			perFace = perFaceData->AddFace();
			perFace->SetIdent(mapFace->t[0], mapFace->t[1], mapFace->t[2]);
		}
		DPrintf("%d instances of per face data created", mesh.getNumFaces());
	}

	// do we need to update this meshes face data?
	if (justLoadedFlag == 1)
	{
		justLoadedFlag = 0;
		DPrintf("Ignoring Initial NotifyInputChanged Call");
	}
	else if (perFaceData->updateData)
	{
		// ** A change in the input mesh as been registered.

#ifndef RESCUE_DATA_CHANGES
		// ** This could have serious repercussions on the formatting of our data. Therefore, for
		// ** the moment at least, we are going to trash ALL face data

		DPrintf("Deleting Data Format: \"%s\"", perFaceData->GetDataName());

		// clear format data and all face data
		perFaceData->SetDataFormat(NULL);
#else
		// ** Therfore we need to update the associated face data also. Two passes are
		// ** performed on the data. The first pass removes all data for deleted faces.
		// ** While the second pass adds empty entries all for new faces.

		// zero successful hits
		hits = 0;

		// first pass handles all deleted faces
		for (listPtr = perFaceData->faceList->next; listPtr != perFaceData->faceList; listPtr = listPtr->next)
		{
			listPtr->GetIdent(v0,v1,v2);
#if PERFACEDATA_MAPPING_CHANNEL == 1
			mapFace = mesh.tvFace;
#else
			mapFace = mesh.mapFaces(PERFACEDATA_MAPPING_CHANNEL);
#endif
			for (i=0; i<mesh.getNumFaces(); i++, mapFace++)
				if (CMPEQUAL_IDENTS((DWORD)v0,(DWORD)v1,(DWORD)v2, mapFace->t[0],mapFace->t[1],mapFace->t[2]))
				{
					hits++;					// inc face hit
					break;
				}
			if (i == mesh.getNumFaces())
			{
				perFace = listPtr;
				SAFE_DELETE(perFace)
			}
		}

		// if the number of face hits == number of mesh faces, we can skip the second pass..
//		if (hits != mesh.getNumFaces())
		{
			// second pass handles all faces added to mesh
#if PERFACEDATA_MAPPING_CHANNEL == 1
			mapFace = mesh.tvFace;
#else
			mapFace = mesh.mapFaces(PERFACEDATA_MAPPING_CHANNEL);
#endif
			for (i=0; i<mesh.getNumFaces(); i++, mapFace++)
			{
				v0 = mapFace->t[0];
				v1 = mapFace->t[1];
				v2 = mapFace->t[2];
				if (perFaceData->FindFace(v0,v1,v2) == NULL)
				{
					perFace = perFaceData->AddFace();
					perFace->SetIdent(v0,v1,v2);
				}
			}
		}
#endif
	}

	// acknowledge update regardless if any action has been taken or not
	perFaceData->updateData = 0;


	// ** Make sure the mesh of the object flowing through the pipeline is in sync
	// ** with our working cached mesh

	// cache this mesh if not already held
	if (perFaceData->GetMesh() == NULL)
		perFaceData->SetCache(mesh);

	// sync selections
	faceSel = perFaceData->faceSel;
	faceSel.SetSize(mesh.getNumFaces(), TRUE);
	mesh.faceSel = faceSel;
	if (perFaceData->GetMesh())
		perFaceData->GetMesh()->faceSel = faceSel;

	// set mesh display attributes
	switch (selLevel)
	{
		case SEL_OBJECT:
			mesh.selLevel = MESH_OBJECT;
			mesh.ClearDispFlag(DISP_VERTTICKS|DISP_SELVERTS|DISP_SELFACES);
			break;
		case SEL_FACE:
		case SEL_POLY:
			mesh.selLevel = MESH_FACE;
			mesh.SetDispFlag(DISP_SELFACES);
	}

	// update our used / changed channels validity
	valid = FOREVER;
	triObject->UpdateValidity(SELECT_CHAN_NUM, valid);
	triObject->UpdateValidity(GEOM_CHAN_NUM, valid);
	triObject->UpdateValidity(TOPO_CHAN_NUM, valid);
	triObject->UpdateValidity(VERT_COLOR_CHAN_NUM, valid);
	triObject->UpdateValidity(TEXMAP_CHAN_NUM, valid);
	triObject->UpdateValidity(SUBSEL_TYPE_CHAN_NUM, valid);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::BeginEditParams
   Purpose : called when user starts editing our modifier
   Parameters : valid interface pointer, edit flags, previous edit item
   Returns : TRUE we handled message, FALSE we didn't
   Info : rollup dialog callback
*/

void PerFaceMod::BeginEditParams(IObjParam *ip, ULONG flags, Animatable *prev)
{
	static TPanelInfo	pnInfo;
	PerFaceModData		*perFaceData;
	BOOL				enflag;


	this->ip = ip;

	DPrintf("PerFaceMod::BeginEditParams");

	// add our rollup page in the panel
	panelHandle = ip->AddRollupPage(hInstance, MAKEINTRESOURCE(IDD_PANEL), ::Proc, _T("Face Data"), (LPARAM)this);

	// add all of our formatted data rollup pages
	GETPERFACEDATA(perFaceData)
	{
		if (perFaceData->formatInst != NULL)
		{
			pnInfo.pfMod = this;
			pnInfo.pfData = perFaceData;
			pnInfo.ruNode = NULL;
			perFaceData->formatInst->EnumNodes(procAddRollup, &pnInfo, "Rollup");

			// initially disable all our controls
			enflag = FALSE;
			perFaceData->formatInst->EnumNodes(procEnableControls, &enflag);

			// set the initial selection in the controls
			SendMessage(panelHandle, WMU_SELNEW, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);

			// allocate our copy buffer
			copyBuffer = malloc(perFaceData->formatSize);
			copyBufferFull = 0;
		}
	}

	// add our face sub-object selection types
	TSTR subtype1(_T("Triangle")), subtype2(_T("Polygon"));
	const TCHAR	*types[] = {subtype1, subtype2};
	ip->RegisterSubObjectTypes(types, 2);

	// create max selection handler
	selectMode = new SelectModBoxCMode(this, ip);

	// select the subobject selection
	ip->SetSubObjectLevel(selLevel);

	// broadcast our modifier beginning edit
	NotifyDependents(Interval(ip->GetTime(), ip->GetTime()), PART_ALL, REFMSG_BEGIN_EDIT);
	NotifyDependents(Interval(ip->GetTime(), ip->GetTime()), PART_ALL, REFMSG_MOD_DISPLAY_ON);
	SetAFlag(A_MOD_BEING_EDITED);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::EndEditParams
   Purpose : called when user ends editing our modifier
   Parameters : valid interface pointer, edit flags, next edit item
   Returns : 
   Info : 
*/

void PerFaceMod::EndEditParams(IObjParam *ip, ULONG flags, Animatable *next)
{
	PerFaceModData	*perFaceData;

	// remove max selection handler
	ip->DeleteMode(selectMode);
	SAFE_DELETE(selectMode)

	DPrintf("PerFaceMod::EndEditParams");

	// add all of our formatted data rollup pages
	GETPERFACEDATA(perFaceData)
	{
		// make sure we get all user's latest changes
		SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);

		// remove all rollup dialogs
		if (perFaceData->formatInst != NULL)
			perFaceData->formatInst->EnumNodes(procDelRollup, ip, "Rollup");

		// release our copy buffer
		SAFE_FREE(copyBuffer);
		copyBufferFull = 0;
	}

	// remove our page from the panel
	if (panelHandle)
		ip->DeleteRollupPage(panelHandle);
 	panelHandle = NULL;

	// broadcast our modifier ending edit
	NotifyDependents(Interval(ip->GetTime(), ip->GetTime()), PART_ALL, REFMSG_END_EDIT);
	NotifyDependents(Interval(ip->GetTime(), ip->GetTime()), PART_ALL, REFMSG_MOD_DISPLAY_OFF);
	ClearAFlag(A_MOD_BEING_EDITED);

	this->ip = NULL;
}


//TODO: This is the callback object used by ILoad::RegisterPostLoadCallback()
class PerFaceModPostLoadCallback : public PostLoadCallback {
	public:
		ParamBlockPLCB *cb; 
		PerFaceModPostLoadCallback(ParamBlockPLCB *c) {cb = c;}
		//TODO: This method is called when everything has been loaded
		void proc(ILoad *iload) {};
};



/* --------------------------------------------------------------------------------
   Function : PerFaceMod::NotifyInputChanged
   Purpose : method is called when an item in the modifier stack before this modifier
		   : sends a REFMSG_CHANGE message via NotifyDependents()
   Parameters : FOREVER, parts changed, message sent, modifier instance context
   Returns : 
   Info : 
*/

void PerFaceMod::NotifyInputChanged(Interval changeInt, PartID partID, RefMessage message, ModContext *mc)
{
	PerFaceModData	*perFaceData;

	// get our instance of local data from the context
	if ((perFaceData = (PerFaceModData *)mc->localData) == NULL)
		return;

	// need to update our working mesh cache to keep in sync with the input mesh
	perFaceData->FreeCache();

	// if a change in the topology is registered, we need to update our face data
	if (partID & PART_TOPO)
	{
		DPrintf("Change on input mesh registered");
		perFaceData->updateData = 1;
	}
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::Save
   Purpose : save modifier data
   Parameters : Max save pointer
   Returns : IO_OK or IO_ERROR
   Info : 
*/

IOResult PerFaceMod::Save(ISave *isave)
{
	ULONG	nb;
	int		vers;

	// first save the modifier name by calling the base class version
	Modifier::Save(isave);

	// ** Version1

	// save selection level chunk
	isave->BeginChunk(MODCHUNK_SELLEVEL);
	isave->Write(&selLevel, sizeof(selLevel), &nb);
	isave->EndChunk();

	// ** Version2

	vers = VERSION_LEVEL;

	// save current version
	isave->BeginChunk(MODCHUNK_VERSION);
	isave->Write(&vers, sizeof(vers), &nb);
	isave->EndChunk();

	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::Load
   Purpose : load modifier data
   Parameters : Max load pointer
   Returns : IO_OK or IO_ERROR
   Info : 
*/

IOResult PerFaceMod::Load(ILoad *iload)
{
	IOResult	res;
	USHORT		id;
	ULONG		nb;

	// first load the modifier name by calling the base class version
	Modifier::Load(iload);

	// ** As a version number wasn't explicitly saved out in version 1 of this plugin,
	// ** we can safely default the expected version to 1 and any later version of this
	// ** plugin will overwrite with its current version number.

	// default version to 1
	version = 1;

	// load all our chunks
	while (IO_OK == (res = iload->OpenChunk()))
	{
		id = iload->CurChunkID();
		switch (id)
		{
		// load selection level
		case MODCHUNK_SELLEVEL:
			iload->Read(&selLevel, sizeof(selLevel), &nb);
			break;

		// load version.. overwrites the default
		case MODCHUNK_VERSION:
			iload->Read(&version, sizeof(version), &nb);
			break;
		}
		iload->CloseChunk();
	}

	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::SaveLocalData
   Purpose : save local modifier data
   Parameters : Max save pointer
   Returns : IO_OK or IO_ERROR
   Info : 
*/

IOResult PerFaceMod::SaveLocalData(ISave *isave, LocalModData *pld)
{
	ULONG			nb;
	PerFaceModData	*perFaceData;
	PerFaceEntry	*perFace;
	TCHAR			name[64];
	int				noof;

	// cast our local mod data
	perFaceData = (PerFaceModData *)pld;


	// ** Note: This will be called for ALL instances of local data which are in the scene, even
	// ** though only one can be editted at a time. Therefore the WMU_SELOLD should ONLY set data
	// ** if this is the editted data. The current instance of PerFaceData being eddited isn't
	// ** saved, so the MapMultipleControlsToData should only write IF special control tags are
	// ** found.

	// make sure we get all user's latest changes
	if (panelHandle)
		SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);


	// ** Version 1

	// save current face selection
	isave->BeginChunk(LCLCHUNK_FACESEL);
	perFaceData->faceSel.Save(isave);
	isave->EndChunk();

	// save update data
	isave->BeginChunk(LCLCHUNK_UPDATE);
	isave->Write(&perFaceData->updateData, sizeof(perFaceData->updateData), &nb);
	isave->EndChunk();

	// save local data set name
	_stprintf(name, "%s", perFaceData->GetDataName());
	noof = sizeof(name);
	isave->BeginChunk(LCLCHUNK_NAME);
	isave->Write(name, sizeof(name), &nb);
	isave->EndChunk();

	// save number of face entries
	noof = perFaceData->faceList->NoofItems();
	isave->BeginChunk(LCLCHUNK_NOOFDATA);
	isave->Write(&noof, sizeof(noof), &nb);
	isave->EndChunk();

	// save all face entries
	for (perFace = perFaceData->faceList->next; perFace != perFaceData->faceList; perFace = perFace->next)
	{
		isave->BeginChunk(LCLCHUNK_DATAENTRY);
		perFace->Save(isave);
		isave->EndChunk();
	}

	// ** Version 2

	// save data format information
	if (perFaceData->formatInst)
	{
		// format data begin marker
		isave->BeginChunk(LCLCHUNK_FORMAT_BEGIN);
		isave->Write(perFaceData->GetDataName(), 64, &nb);
		isave->EndChunk();

		// save out all format data
		perFaceData->formatInst->EnumNodes(procPreWriteNodes, isave, procPostWriteNodes, isave);

		// format data end marker
		isave->BeginChunk(LCLCHUNK_FORMAT_END);
		isave->EndChunk();
	}

	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::LoadLocalData
   Purpose : load local modifier data
   Parameters : Max load pointer
   Returns : IO_OK or IO_ERROR
   Info : PerFaceMod::version contains this datas version number
*/

IOResult PerFaceMod::LoadLocalData(ILoad *iload, LocalModData **pld)
{
	PerFaceModData	*perFaceData;
	PerFaceEntry	*perFace;
	IOResult		res;
	USHORT			id;
	ULONG			nb;
	TCHAR			name[64];
	int				noof;
	CPMLevel		*formatInst;


	// default: no format data instance
	formatInst = NULL;

	// allocate our load mod instance
	perFaceData = new PerFaceModData();
	*pld = perFaceData;

	noof = 0;						// zero entries

	// load all our local chunks
	while (IO_OK == (res = iload->OpenChunk()))
	{
		id = iload->CurChunkID();
		switch (id)
		{

		// ** Version 1

		// current face selection
		case LCLCHUNK_FACESEL:
			perFaceData->faceSel.Load(iload);
			break;

		// update data flag
		case LCLCHUNK_UPDATE:
			iload->Read(&perFaceData->updateData, sizeof(perFaceData->updateData), &nb);
			break;

		// local data set name
		case LCLCHUNK_NAME:
			iload->Read(name, sizeof(name), &nb);
			perFaceData->SetDataName(name);
			break;

		// number of data entries
		case LCLCHUNK_NOOFDATA:
			iload->Read(&noof, sizeof(noof), &nb);
			break;

		// data entry
		case LCLCHUNK_DATAENTRY:
			perFace = perFaceData->AddFace();
			perFace->Load(iload);
			break;

		// ** Version 2

		// format entry
		case LCLCHUNK_FORMAT_BEGIN:

			iload->Read(name, PMMAX_IDENT_LEN, &nb);
			iload->CloseChunk();

			formatInst = new CPMLevel;
			loadFormatData(formatInst->root, iload, version);

			perFaceData->SetDataFormat(formatInst, TRUE, name);
			break;
		}

		// this chunk as already been closed
		if (id != LCLCHUNK_FORMAT_BEGIN)
		{
			iload->CloseChunk();
		}
	}


	// ** If "OBE Data" has been loaded but hasn't been formatted, we can format the
	// ** data has we know where the format file is kept.

	// make sure the OBE data is formatted
	if (formatInst == NULL && _tcsicmp(perFaceData->GetDataName(), _T("OBE Data")) == NULL)
	{
		TCHAR filen[260];

		_tcscpy(filen, iload->GetDir(APP_PLUGCFG_DIR));
		_tcscat(filen, _T("\\JobeData.mft"));

		if ((formatInst = pmLoadLevel(filen)) != NULL)
			perFaceData->SetDataFormat(formatInst, TRUE, _T("Jobe Face Data"));
	}

	// ** We need to set this flag has Max as the annoying habit of sending a NotifyInputChanged
	// ** straight after we have loaded thereby trashing all of our face data! Luckily the
	// ** modifiers ModifyObject method isn't called until after the Notify so we can use this
	// ** flag to ignore the call.

	// ignore the initial NotifyInputChanged call
	justLoadedFlag = 1;

	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::ActivateSubobjSel
   Purpose : called when user selects sub object
   Parameters : sub-object selection level, 
   Returns : 
   Info : 
*/

void PerFaceMod::ActivateSubobjSel(int level, XFormModes& modes)
{
	PerFaceModData	*perFaceData;

	// save selection level
	selLevel = level;

	// set xform modes only for our face, polygon selections
	if (level == SEL_FACE || level == SEL_POLY)
		modes = XFormModes(NULL, NULL, NULL, NULL, NULL, selectMode);

	// PerFaceData on selection level change..
	GETPERFACEDATA(perFaceData)
	{
		switch (level)
		{
		case SEL_OBJECT:
			if (panelHandle)
				SendMessage(panelHandle, WMU_SELENABLE, (WPARAM)FALSE, (LPARAM)perFaceData);
			break;
		case SEL_FACE:
		case SEL_POLY:
			if (panelHandle)
			{
				SendMessage(panelHandle, WMU_SELENABLE, (WPARAM)TRUE, (LPARAM)perFaceData);
				SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);
			}
			break;
		}
	}

	NotifyDependents(FOREVER, PART_SUBSEL_TYPE|PART_DISPLAY, REFMSG_CHANGE);
	ip->PipeSelLevelChanged();
	NotifyDependents(FOREVER, SELECT_CHANNEL|SUBSEL_TYPE_CHANNEL|DISP_ATTRIB_CHANNEL, REFMSG_CHANGE);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::SelectSubComponent
   Purpose : called when user selects sub object
   Parameters : sub-object selection level, 
   Returns : 
   Info : 
*/

static AdjFaceList *BuildAdjFaceList(Mesh &mesh)
{
	AdjEdgeList	ae(mesh);
	return new AdjFaceList(mesh, ae);
}

void PerFaceMod::SelectSubComponent(HitRecord *hitRec, BOOL selected, BOOL all, BOOL invert)
{
	PerFaceModData	*perFaceData;
	BitArray		newsel;
	Mesh			*mesh;
	HitRecord		*hr;
	AdjFaceList		*adjList;


	// update our cached mesh with the current sub-object selection
	GETPERFACEDATA(perFaceData)
	{
		// is this hit-record within our cached mesh?
		hr = hitRec;
		if (!all && (hr->modContext->localData != perFaceData))
			continue;
		for (; hr != NULL; hr=hr->Next())
			if (hr->modContext->localData == perFaceData)
			{
				break;
			}
		if (hr == NULL)
			continue;

		// get our cached mesh
		if ((mesh = perFaceData->GetMesh()) == NULL)
			break;

		// selection level
		switch (selLevel)
		{
		case SEL_FACE:

			// ** Face Selection

			// get current face selection
			newsel = perFaceData->faceSel;

			// loop through all hits..
			for (; hr != NULL; hr=hr->Next())
			{
				// one of ours?
				if (perFaceData != hr->modContext->localData)
					continue;
				// select / invert face
				newsel.Set(hr->hitInfo, invert ? !mesh->faceSel[hr->hitInfo] : selected);
				// should all object be selected?
				if (!all)
					break;
			}

			// if we are selecting additional faces we need to get the latest user edits
			if (perFaceData->faceSel.NumberSet() > 0 && panelHandle)
				SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);
			break;

		case SEL_POLY:

			// ** Polygon Selection

			// build adjacent edge list from our cached mesh
			adjList = BuildAdjFaceList(*mesh);

			// loop through all hits..
			newsel.SetSize(mesh->numFaces);
			newsel.ClearAll();
			for (; hr != NULL; hr=hr->Next())
			{
				// one of ours?
				if (perFaceData != hr->modContext->localData)
					continue;
				// select polygon which contains our face hit
				mesh->PolyFromFace(hr->hitInfo, newsel, DegToRad(45.0f), FALSE, adjList);
				if (!all)
					break;
			}
			SAFE_DELETE(adjList);

			// invert selection?
			if (invert)
				newsel ^= perFaceData->faceSel;
			// additional selection?
			else if (selected)
				newsel |= perFaceData->faceSel;
			// single selection?
			else
				newsel = perFaceData->faceSel & ~newsel;

			// if we are selecting additional faces we need to get the latest user edits
			if (perFaceData->faceSel.NumberSet() > 0 && panelHandle)
				SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);
			break;
		}

		// set new selection back in cached mesh
		perFaceData->SetFaceSel(newsel);

		// notify dependents of the selection change
		NotifyDependents(FOREVER, PART_SELECT, REFMSG_CHANGE);

		// broadcast selection change to the dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELNEW, (WPARAM)&newsel, (LPARAM)perFaceData);
		break;
	}
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::SelectAll
   Purpose : called to select every element of the given sub-object level
   Parameters : selection level
   Returns : 
   Info : 
*/

void PerFaceMod::SelectAll(int selLevel)
{
	PerFaceModData	*perFaceData;
	BitArray		newsel;

	if (selLevel != SEL_FACE && selLevel != SEL_POLY)
		return;
	GETPERFACEDATA(perFaceData)
	{
		// notify dependents of the selection change
		NotifyDependents(FOREVER, PART_SELECT, REFMSG_CHANGE);

		// get current selection
		newsel = perFaceData->faceSel;

		// broadcast old selection to dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&newsel, (LPARAM)perFaceData);

		// select all faces
		newsel.SetAll();
		perFaceData->SetFaceSel(newsel);

		// broadcast new selection to dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELNEW, (WPARAM)&newsel, (LPARAM)perFaceData);
	}
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::ClearSelection
   Purpose : called to clear the selection for the given sub-object level
   Parameters : selection level
   Returns : 
   Info : 
*/

void PerFaceMod::ClearSelection(int selLevel)
{
	PerFaceModData	*perFaceData;
	BitArray		newsel;

	if (selLevel != SEL_FACE && selLevel != SEL_POLY)
		return;
	GETPERFACEDATA(perFaceData)
	{
		// notify dependents of the selection change
		NotifyDependents(FOREVER, PART_SELECT, REFMSG_CHANGE);

		// get current selection
		newsel = perFaceData->faceSel;

		// broadcast old selection to dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&newsel, (LPARAM)perFaceData);

		// clear all face selections
		newsel.ClearAll();
		perFaceData->SetFaceSel(newsel);

		// broadcast new selection to dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELNEW, (WPARAM)&newsel, (LPARAM)perFaceData);
	}
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::InvertSelection
   Purpose : called to invert the current selection for the given sub-object level
   Parameters : selection level
   Returns : 
   Info : 
*/

void PerFaceMod::InvertSelection(int selLevel)
{
	PerFaceModData	*perFaceData;
	BitArray		newsel, msksel;

	if (selLevel != SEL_FACE && selLevel != SEL_POLY)
		return;
	GETPERFACEDATA(perFaceData)
	{
		// notify dependents of the selection change
		NotifyDependents(FOREVER, PART_SELECT, REFMSG_CHANGE);

		// get current selection
		newsel = perFaceData->faceSel;

		// broadcast old selection to dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELOLD, (WPARAM)&newsel, (LPARAM)perFaceData);

		// invert selection
		msksel = newsel;
		msksel.SetAll();
		newsel ^= msksel;
		perFaceData->SetFaceSel(newsel);

		// broadcast new selection to dialog panel
		if (panelHandle)
			SendMessage(panelHandle, WMU_SELNEW, (WPARAM)&newsel, (LPARAM)perFaceData);
	}
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::HitTest
   Purpose : modifier hit testing
   Parameters : current time, node we're testing against, test type, crossing selection,
			  : test flags, screen point to test, viewport, modifiers mc
   Returns : 
   Info : 
*/

int PerFaceMod::HitTest(TimeValue t, INode * inode, int type, int crossing, int flags, IPoint2 *p, ViewExp *vpt, ModContext* mc)
{
	Interval			valid;
	int					savedLimits, res;
	GraphicsWindow		*gw;
	HitRegion			hr;
	SubObjHitList		hitList;
	Mesh				*mesh;
	MeshSubHitRec		*rec;

	// setup graphics window
	gw = vpt->getGW();
	MakeHitRegion(hr,type, crossing, 4, p);
	gw->setHitRegion(&hr);
	Matrix3 mat = inode->GetObjectTM(t);
	gw->setTransform(mat);	
	gw->setRndLimits(((savedLimits = gw->getRndLimits()) | GW_PICK) & ~GW_ILLUM);
	gw->setRndLimits(gw->getRndLimits() | GW_BACKCULL);	//	gw->setRndLimits(gw->getRndLimits() & ~GW_BACKCULL);
	gw->clearHitCode();

	// is the cached mesh available?
	if (mc->localData != NULL && (mesh = ((PerFaceModData *)mc->localData)->GetMesh()) != NULL)
	{
		// perform subobject hit test on the cached mesh
		res = mesh->SubObjectHitTest(gw, gw->getMaterial(), &hr, flags | SUBHIT_FACES, hitList);
		// log all valid hits
		for (rec = hitList.First(); rec != NULL; rec = rec->Next())
			vpt->LogHit(inode, mc, rec->dist, rec->index, NULL);
	}

	// restore render limits
	gw->setRndLimits(savedLimits);
	return res;	
}


/* --------------------------------------------------------------------------------
   Function : PerFaceMod::Proc
   Purpose : class scoped panel procedure
   Parameters : dialog handle, message, additional message info, additional message info
   Returns : return TRUE if processed message, else FALSE
   Info : 
*/

BOOL PerFaceMod::Proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static HWND			ph;
	static ICustImage	*image = NULL;
	static HIMAGELIST	imageList = NULL;
	HBITMAP				bitmap, mask;
	PerFaceModData		*perFaceData;
	PerFaceEntry		*perFace;
	BitArray			selectBits;
	TSTR				outp;
	int					i, size, noofBits, noofSets;
	TDataLog			dataLog;


	switch (msg)
	{
	case WM_INITDIALOG:

		// ** Initialise Window

		panelHandle = hWnd;

		// ISL logo
		image = GetICustImage(GetDlgItem(hWnd, IDC_ISLLOGO));
		imageList = ImageList_Create(86, 21, TRUE, 2, 2);

		bitmap = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BLITZIMAGE));
		mask = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BLITZMASK));
		ImageList_Add(imageList, bitmap, mask);
		DeleteObject(mask);
		DeleteObject(bitmap);

		image->SetImage(imageList, 0, 86, 21);

		// disable paste button
		EnableWindow(GetDlgItem(panelHandle, IDC_SELECT_PASTE), FALSE);

		// enable current sub-object selection
		SendMessage(hWnd, WMU_SELENABLE, (WPARAM)(selLevel == SEL_FACE || selLevel == SEL_POLY) ? TRUE : FALSE, (LPARAM)NULL);
		break;


	case WM_DESTROY:

		// ** Destroy Window

		// remove custom image
		if (image)
			ReleaseICustImage(image);
		image = NULL;
		if (imageList)
			ImageList_Destroy(imageList);
		imageList = NULL;
		break;


	case WMU_SELENABLE:

		// ** Selection Enabled / Disabled

		// enable / disable fixed windows
		EnableWindow(GetDlgItem(panelHandle, IDC_DATASET_TITLE), (BOOL)wParam);
		EnableWindow(GetDlgItem(panelHandle, IDC_DATASET_NAME), (BOOL)wParam);
		EnableWindow(GetDlgItem(panelHandle, IDC_NUM_SELECTS), (BOOL)wParam);
		EnableWindow(GetDlgItem(panelHandle, IDC_DATA_PTR),	(BOOL)wParam);
		EnableWindow(GetDlgItem(panelHandle, IDC_DATA_SIZE), (BOOL)wParam);
		EnableWindow(GetDlgItem(panelHandle, IDC_RESET_DEFAULTS), (BOOL)wParam);
		EnableWindow(GetDlgItem(panelHandle, IDC_SELECT_COPY), (BOOL)wParam);

		// special case for data paste button
		if ((BOOL)wParam == TRUE && copyBufferFull == 0)
			EnableWindow(GetDlgItem(panelHandle, IDC_SELECT_PASTE), FALSE);
		else
			EnableWindow(GetDlgItem(panelHandle, IDC_SELECT_PASTE), (BOOL)wParam);

		// enable / disable our data controls
		perFaceData = (PerFaceModData *)lParam;
		if (perFaceData && perFaceData->formatInst != NULL)
			perFaceData->formatInst->EnumNodes(procEnableControls, &wParam);
		break;


	case WMU_SELOLD:

		// ** Old Data Selections

		// get old selection bits and PerFaceData instance
		selectBits = *((BitArray *)wParam);
		perFaceData = (PerFaceModData *)lParam;

		// map controls to just released selection data
		if (perFaceData != NULL)
		{
			// allocate maximum data log entries
			dataLog.entries = (TDataEntry *)malloc(selectBits.GetSize() * sizeof(TDataEntry));
			if (dataLog.entries != NULL)
			{
				// log all selected and valid face data sets
				dataLog.noof = 0;
				dataLog.offset = 0;
				dataLog.size = perFaceData->formatSize;

				if ((noofSets = selectBits.NumberSet()) > 0)
				{
					noofBits = selectBits.GetSize();
					perFace = perFaceData->GetNextFace();
					for (i=0; i<noofBits; i++)
						if (perFace != NULL)
						{
							if (selectBits[i])
							{
								if ((dataLog.entries[dataLog.noof].data = (char *)perFace->GetData(size)) != NULL && size == perFaceData->formatSize)
								{
									dataLog.noof++;
								}
								if (--noofSets == 0)
									break;
							}
							perFace = perFaceData->GetNextFace(perFace);
						}
				}

				// map current controls to multiple data
				if (dataLog.noof > 0 && perFaceData->formatInst != NULL)
					perFaceData->formatInst->EnumNodes(procMapControlsToMultipleData, &dataLog);

				// release our data log entries
				SAFE_DELETE(dataLog.entries);
			}
		}
		break;


	case WMU_SELNEW:

		// ** New Data Selections
		
		// get old selection bits and PerFaceData instance
		selectBits = *((BitArray *)wParam);
		perFaceData = (PerFaceModData *)lParam;

		// print data set name
		outp.printf(_T("%s"), perFaceData->GetDataName());
		SetDlgItemText(hWnd, IDC_DATASET_NAME, outp);

		// print current selection info
		if (selectBits.NumberSet() == 1)
		{
			for (i=0; i<selectBits.GetSize(); i++)
				if (selectBits[i])
				{
					break;
				}
			outp.printf(_T("Face %d Selected"), i+1);
		}
		else
			outp.printf(_T("%d Face%s Selected"), selectBits.NumberSet(), (selectBits.NumberSet() != 1) ? "s" : "");
		SetDlgItemText(hWnd, IDC_NUM_SELECTS, outp);

		// map selected data to controls
		if (perFaceData != NULL)
		{
			// allocate maximum data log entries
			dataLog.entries = (TDataEntry *)malloc(selectBits.GetSize() * sizeof(TDataEntry));
			if (dataLog.entries != NULL)
			{
				// log all selected and valid face data sets
				dataLog.noof = 0;
				dataLog.offset = 0;
				dataLog.size = perFaceData->formatSize;

				if ((noofSets = selectBits.NumberSet()) > 0)
				{
					noofBits = selectBits.GetSize();
					perFace = perFaceData->GetNextFace();
					for (i=0; i<noofBits; i++)
						if (perFace != NULL)
						{
							if (selectBits[i])
							{
								if ((dataLog.entries[dataLog.noof].data = (char *)perFace->GetData(size)) != NULL && size == perFaceData->formatSize)
								{
									dataLog.noof++;
								}
								if (--noofSets == 0)
									break;
							}
							perFace = perFaceData->GetNextFace(perFace);
						}
				}

				// map all data to controls
				if (dataLog.noof > 0 && perFaceData->formatInst != NULL)
					perFaceData->formatInst->EnumNodes(procMapMultipleDataToControls, &dataLog);

				// print data size info
				outp.printf(_T("Data Size: %d"), perFaceData->formatSize);
				SetDlgItemText(hWnd, IDC_DATA_SIZE, outp);

				// print data info
				if (dataLog.noof == 1)
					outp.printf(_T("Data Ptr: %#x"), (int)dataLog.entries[0].data);
				else if (dataLog.noof == 0)
					outp.printf(_T("Data Ptr: 0"));
				else
					outp.printf(_T("Data Ptr: MULTIPLE"));
				SetDlgItemText(hWnd, IDC_DATA_PTR, outp);

				// release our data log entries
				SAFE_DELETE(dataLog.entries);
			}
		}
		break;


	case WM_COMMAND:

		// ** Commands

		switch (LOWORD(wParam))
		{
		case IDC_RESET_DEFAULTS:
			{
				// ** Reset Data To Defaults

				PerFaceModData	*perFaceData;
				TData			defaultData;
				int				noof;

				// get instance of PerFaceData
				GETPERFACEDATA(perFaceData)
				{
					if (perFaceData->formatInst != NULL)
					{
						// alloc and generate default data
						defaultData.size = perFaceData->formatSize;
						defaultData.data = (char *)malloc(defaultData.size);
						defaultData.offset = 0;
						perFaceData->formatInst->EnumNodes(procMapDefaultsToData, &defaultData);

						noof = 0;
						// set default data for all selected faces
						for (i=0; i<perFaceData->faceSel.GetSize(); i++)
							if (perFaceData->faceSel[i])
							{
								if ((perFace = perFaceData->GetFace(i)) != NULL)
								{
									perFace->DelData();
									perFace->SetData(defaultData.data, defaultData.size);
									noof++;
								}
							}

						// release default data
						SAFE_FREE(defaultData.data);

						DPrintf("Set default data for %d face%s", noof, (noof != 1) ? "s" : "");

						// need to update the panel with correct data
						SendMessage(hWnd, WMU_SELNEW, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);
					}
				}
			}
			break;


		case IDC_SELECT_COPY:
			{
				// ** Copy Selected Face

				PerFaceModData	*perFaceData;
				int				size;

				// get instance of PerFaceData
				GETPERFACEDATA(perFaceData)
				{
					// any selections?
					if (perFaceData->faceSel.NumberSet() == 0)
						copyBufferFull = 0;
					else
					{
						if (perFaceData->formatInst != NULL)
						{
							// copy the FIRST valid selected polygon
							for (i=0; i<perFaceData->faceSel.GetSize(); i++)
								if (perFaceData->faceSel[i] && (perFace = perFaceData->GetFace(i)) != NULL)
								{
									// copy this polygons data
									perFace->GetData(size);
									if (size == perFaceData->formatSize)
									{
										memcpy(copyBuffer, perFace->GetData(), min(size, perFaceData->formatSize));
										// flag buffer active
										copyBufferFull = 1;

										DPrintf("Copied data from face %d to copy buffer", i);
										break;
									}
								}
						}
					}
				}

				// enable / disable paste button depending on above copy
				EnableWindow(GetDlgItem(panelHandle, IDC_SELECT_PASTE), (copyBufferFull == 1) ? TRUE : FALSE);
			}
			break;


		case IDC_SELECT_PASTE:
			{
				// ** Paste To Selected Faces

				PerFaceModData	*perFaceData;
				int				noof, size;

				// get instance of PerFaceData
				GETPERFACEDATA(perFaceData)
				{
					// any valid data available?
					if (copyBufferFull == 1)
					{
						if (perFaceData->formatInst != NULL)
						{
							noof = 0;
							// paste data into all selected faces
							for (i=0; i<perFaceData->faceSel.GetSize(); i++)
								if (perFaceData->faceSel[i])
								{
									if ((perFace = perFaceData->GetFace(i)) != NULL)
									{
										perFace->GetData(size);
										if (size == perFaceData->formatSize)
										{
											perFace->DelData();
											perFace->SetData(copyBuffer, size);
											noof++;
										}
									}
								}
						
							// any pastes done?
							if (noof > 0)
							{
								DPrintf("Pasted data to %d face%s", noof, (noof != 1) ? "s" : "");

								// need to update the panel with correct data
								SendMessage(hWnd, WMU_SELNEW, (WPARAM)&perFaceData->faceSel, (LPARAM)perFaceData);
							}
						}
					}
				}
			}
			break;
		}
		break;


	default:
		return FALSE;
	}
	return TRUE;
}


// --------------------------------------------------------------------------------
// PerFaceEntry Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::PerFaceEntry
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : root constructor
*/

PerFaceEntry::PerFaceEntry()
{
	// dummy header
	prev = next = this;

	listRoot = this;
	noofItems = 0;

	data = NULL;
	size = 0;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::PerFaceEntry
   Purpose : constructor
   Parameters : root entry
   Returns : 
   Info : 
*/

PerFaceEntry::PerFaceEntry(PerFaceEntry *root)
{
	// append to list
	root->prev->next = this;
	next = root;
	prev = root->prev;
	root->prev = this;

	listRoot = root->listRoot;
	listRoot->noofItems++;
	noofItems = 0;

	data = NULL;
	size = 0;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::~PerFaceEntry
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceEntry::~PerFaceEntry()
{
	// break link
	next->prev = prev;
	prev->next = next;

	if (listRoot != this)
		listRoot->noofItems--;

	SAFE_FREE(data)
	size = 0;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::DeleteAll
   Purpose : delete all entries
   Parameters : 
   Returns : 
   Info : 
*/

void PerFaceEntry::DeleteAll()
{
	while (next != this)
	{
		delete next;
	}
	delete this;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::SetIdent
   Purpose : set this faces unique identity
   Parameters : unique identity values
   Returns : 
   Info : uses texture mapping vertices indexes from the mesh face
*/

void PerFaceEntry::SetIdent(int v0, int v1, int v2)
{
	ident[0] = v0;
	ident[1] = v1;
	ident[2] = v2;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::SetIdent
   Purpose : get this faces unique identity
   Parameters : reference unique identity values
   Returns : 
   Info : 
*/

void PerFaceEntry::GetIdent(int& v0, int& v1, int& v2)
{
	v0 = ident[0];
	v1 = ident[1];
	v2 = ident[2];
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::SetData
   Purpose : set this faces data
   Parameters : pointer and size of data to hold
   Returns : 
   Info : a copy of the data is saved rather than the data instance passed
*/

void PerFaceEntry::SetData(void *newData, int newSize)
{
	SAFE_FREE(data)
	size = 0;
	if (newData && newSize > 0)
		if ((data = malloc(newSize)) != NULL)
		{
			memcpy(data, newData, newSize);
			size = newSize;
		}
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::GetData
   Purpose : get this faces data
   Parameters : size of data held return
   Returns : pointer to the held data
   Info : 
*/

void *PerFaceEntry::GetData(int& outSize)
{
	outSize = size;
	return data;
}

void *PerFaceEntry::GetData()
{
	int	outSize;
	return GetData(outSize);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::DelData
   Purpose : delete this faces data
   Parameters : 
   Returns : 
   Info : 
*/

void PerFaceEntry::DelData()
{
	SetData(NULL, 0);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::Copy
   Purpose : copy from "perFace" entry
   Parameters : pointer and size of data to hold
   Returns : 
   Info : a copy of the data is saved rather than the data instance passed
*/

void PerFaceEntry::Copy(PerFaceEntry *perFace)
{
	// copy unqiue ident
	ident[0] = perFace->ident[0];
	ident[1] = perFace->ident[1];
	ident[2] = perFace->ident[2];
	// copy data
	SetData(perFace->data, perFace->size);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::NoofItems
   Purpose : returns the number of items in this list
   Parameters : 
   Returns : number of items
   Info : 
*/

int PerFaceEntry::NoofItems()
{
	return listRoot->noofItems;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::Save
   Purpose : save ourselves
   Parameters : Max save pointer
   Returns : IO_OK or IO_ERROR
   Info : 
*/

IOResult PerFaceEntry::Save(ISave *isave)
{
	ULONG	nb;
	// ident
	isave->Write(&ident, sizeof(ident), &nb);
	// data size
	isave->Write(&size, sizeof(size), &nb);
	// data
	if (size > 0)
		isave->Write(data, size, &nb);

	return IO_OK;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceEntry::Load
   Purpose : load ourselves
   Parameters : Max load pointer
   Returns : IO_OK or IO_ERROR
   Info : 
*/

IOResult PerFaceEntry::Load(ILoad *iload)
{
	ULONG	nb;

	// ident
	iload->Read(&ident, sizeof(ident), &nb);
	// data size
	iload->Read(&size, sizeof(size), &nb);
	// data
	if (size > 0)
		if (data = malloc(size))
		{
			iload->Read(data, size, &nb);
		}

	return IO_OK;
}


// --------------------------------------------------------------------------------
// PerFaceModData Class Implementation
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PerFaceModData::PerFaceModData
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceModData::PerFaceModData()
{
	// zero mesh cache
	mesh = NULL;
	adjEdgeList = NULL;
	// no update required
	updateData = 0;

	// null name
	_tcscpy(dataName, _T(""));

	// set face list root entry
	faceList = new PerFaceEntry();
	// set data name
	_stprintf(dataName, "%s", _T("Unknown Data"));

	// null format data instance
	formatInst = NULL;
	formatSize = 0;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::~PerFaceModData
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceModData::~PerFaceModData()
{
	// release mesh cache
	FreeCache();
	// delete all faces
	faceList->DeleteAll();
	// delete format data instance
	pmDeleteLevel(formatInst);
	formatSize = 0;
	// zero hash table
	faceHashTab.ZeroCount();
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::Clone
   Purpose : clone this local modifier data
   Parameters : 
   Returns : 
   Info : 
*/

LocalModData *PerFaceModData::Clone()
{
	PerFaceModData	*perFaceData;
	PerFaceEntry	*listPtr, *perFace;
	CPMLevel		*newFormatInst;

	perFaceData = new PerFaceModData();
	perFaceData->updateData = updateData;
	_stprintf(perFaceData->dataName, "%s", dataName);
	for (listPtr = faceList->next; listPtr != faceList; listPtr = listPtr->next)
	{
		perFace = perFaceData->AddFace();
		perFace->Copy(listPtr);
	}

	// clone our format data instance
	newFormatInst = pmCloneLevel(formatInst);
	// remove all extra non-data edit tags from cloned instance
	if (newFormatInst != NULL)
		newFormatInst->EnumNodes(procTidyClonedData);
	// set the new format data
	perFaceData->SetDataFormat(newFormatInst, TRUE, GetDataName());

	return perFaceData;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::AddFace
   Purpose : add face entry
   Parameters : 
   Returns : face added pointer
   Info : 
*/

PerFaceEntry *PerFaceModData::AddFace()
{
	PerFaceEntry	*newFace;

	// create face new entry
	newFace = new PerFaceEntry(faceList);

	// do we need to update the hash table?
	if (((faceList->NoofItems()-1) % HASH_SIZE_ENTRY) == 0)
	{
		faceHashTab.Append(1, &newFace);
	}

	return newFace;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::FindFace
   Purpose : find a face from idents
   Parameters : indents
   Returns : face or NULL
   Info : 
*/

PerFaceEntry *PerFaceModData::FindFace(int v0, int v1, int v2)
{
	PerFaceEntry	*perFace;
	int				c0,c1,c2;

	// search all face entries..
	for (perFace = faceList->next; perFace != faceList; perFace = perFace->next)
	{
		// is this our face?
		perFace->GetIdent(c0, c1, c2);
		if (CMPEQUAL_IDENTS(c0,c1,c2, v0,v1,v2))
		{
			return perFace;
		}
	}
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::GetFace
   Purpose : get face
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceEntry *PerFaceModData::GetFace(int index)
{
	PerFaceEntry	*perFace;
	int				d,m;

	if (index >= faceList->NoofItems())
		return NULL;

	// hash into face table
	d = index / HASH_SIZE_ENTRY;
	m = index % HASH_SIZE_ENTRY;

	if (d < faceHashTab.Count())
	{
		perFace = faceHashTab[d];
		while (--m >= 0)
		{
			perFace = perFace->next;
		}
	}
	else
	{
		perFace = faceList->next;
		while (--index >= 0)
		{
			perFace = perFace->next;
		}
	}
	return perFace;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::GetFace
   Purpose : 
   Parameters : 
   Returns : 
   Info : 
*/

PerFaceEntry *PerFaceModData::GetNextFace(PerFaceEntry *perFace)
{
	if (perFace == NULL)
		return faceList->next;
	return perFace->next;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::SetCache
   Purpose : cache current edit mesh
   Parameters : mesh to cache
   Returns : 
   Info : 
*/

void PerFaceModData::SetCache(Mesh& mesh)
{
	// free current working mesh
	FreeCache();

	// cache this mesh and build edge adjacency list
	this->mesh = new Mesh(mesh);
	this->adjEdgeList = new AdjEdgeList(*this->mesh);

	// sync the mesh face selections
	if (this->mesh != NULL)
		faceSel.SetSize(this->mesh->faceSel.GetSize(), TRUE);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::FreeCache
   Purpose : release mesh cache
   Parameters : 
   Returns : 
   Info : 
*/

void PerFaceModData::FreeCache()
{
	SAFE_DELETE(mesh)
	SAFE_DELETE(adjEdgeList)
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::SetDataName
   Purpose : set name for this data set
   Parameters : data set name
   Returns : 
   Info : 
*/

void PerFaceModData::SetDataName(TCHAR *name)
{
	_stprintf(dataName, "%s", (name != NULL) ? name : _T("Unknown Data"));
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::GetDataName
   Purpose : get the name of this data set
   Parameters : 
   Returns : data set name
   Info : 
*/

TCHAR *PerFaceModData::GetDataName()
{
	return dataName;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceModData::SetDataFormat
   Purpose : format our perfacedata
   Parameters : instance of CPMLevel containg format data,
			  :	[keep current face data flag = FALSE, data name pointer = NULL]
   Returns : 
   Info : 
*/

void PerFaceModData::SetDataFormat(CPMLevel *formatInst, BOOL keepData, TCHAR *name)
{
	TData			defaultData;
	PerFaceEntry	*perFace;

	// delete current data format before saving new
	pmDeleteLevel(this->formatInst);
	this->formatInst = formatInst;

	// calculate the required size of PerFaceData
	defaultData.size = 0;
	if (formatInst != NULL)
		formatInst->EnumNodes(procCalcDataSize, &defaultData.size);
	formatSize = defaultData.size;

	// should we keep the currently set data?
	if (keepData != TRUE)
	{
		// set default data default
		if (formatInst != NULL)
		{
			// create our default data set
			defaultData.data = (char *)malloc(defaultData.size);
			defaultData.offset = 0;
			formatInst->EnumNodes(procMapDefaultsToData, &defaultData);
		}
		else
		{
			// set NULL default data set
			defaultData.data = NULL;
			defaultData.offset = 0;
		}

		// set this data sets name
		SetDataName(name);

		// initialise all face data to defaults
		for (perFace = faceList->next; perFace != faceList; perFace = perFace->next)
		{
			perFace->DelData();
			perFace->SetData(defaultData.data, defaultData.size);
		}
		SAFE_FREE(defaultData.data);
	}
}


// --------------------------------------------------------------------------------
// Exported Functions
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PerFaceData_GetData
   Purpose : get instance of face data for this node
   Parameters : node pointer
   Returns : data instance or NULL
   Info : 
*/

PerFaceModData *PerFaceData_GetData(INode *node)
{
	int				i;
	Object			*objRef;
	IDerivedObject	*derObj;
	Modifier		*mod;
	ModContext		*mc;

	if (node == NULL)
		return NULL;
	// has this nodes object been derived?
	objRef = node->GetObjectRef();
	if (objRef && objRef->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		// can safely cast object as a derived object
		derObj = (IDerivedObject *)objRef;
		// loop around all modifiers searching for the skin class
		for (i=0; i<derObj->NumModifiers(); i++)
		{
			// is this ours?
			mod = derObj->GetModifier(i);
			if (mod->ClassID() == PERFACEDATA_CLASS_ID)
			{
				// our "PerFaceData" modifier found
				mc = derObj->GetModContext(i);
				if (mc && mc->localData)
					return (PerFaceModData *)mc->localData;
			}
		}
	}

	// no face data instance
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceData_GetModContext
   Purpose : get instance of modcontext for this node
   Parameters : node pointer
   Returns : modcontext instance or NULL
   Info : 
*/

ModContext *PerFaceData_GetModContext(INode *node)
{
	int				i;
	Object			*objRef;
	IDerivedObject	*derObj;
	Modifier		*mod;
	ModContext		*mc;

	if (node == NULL)
		return NULL;
	// has this nodes object been derived?
	objRef = node->GetObjectRef();
	if (objRef && objRef->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		// can safely cast object as a derived object
		derObj = (IDerivedObject *)objRef;
		// loop around all modifiers searching for the skin class
		for (i=0; i<derObj->NumModifiers(); i++)
		{
			// is this ours?
			mod = derObj->GetModifier(i);
			if (mod->ClassID() == PERFACEDATA_CLASS_ID)
			{
				// our "PerFaceData" modifier found
				mc = derObj->GetModContext(i);
				return mc;
			}
		}
	}

	// no mod context instance
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceData_CreateData
   Purpose : create instance of modifier data
   Parameters : 
   Returns : data instance
   Info : 
*/

PerFaceModData *PerFaceData_CreateData()
{
	PerFaceModData	*perFaceData;
	perFaceData = new PerFaceModData();
	return perFaceData;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceData_CreateModContext
   Purpose : create instance of modifier context
   Parameters : 
   Returns : mod context
   Info : 
*/

ModContext *PerFaceData_CreateModContext()
{
	ModContext	*mc;
	mc = new ModContext();
	return mc;
}


/* --------------------------------------------------------------------------------
   Function : PerFaceData_FormatData
   Purpose : format nodes perfacedata data
   Parameters : node pointer, data format tree (uses ParseMap structure), [data name pointer]
   Returns : 
   Info : 
*/

void PerFaceData_FormatData(INode *node, CPMLevel *formatInst, TCHAR *name)
{
	PerFaceModData	*perFaceData;

	if (node == NULL || formatInst == NULL)
		return;
	if ((perFaceData = PerFaceData_GetData(node)) == NULL)
		return;
	perFaceData->SetDataFormat(formatInst, FALSE, name);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceData_MergeInFormatData
   Purpose : merge new format data into existing format data
   Parameters : node pointer, data format tree (uses ParseMap structure), [data name pointer]
   Returns : 
   Info : 
*/

void PerFaceData_MergeInFormatData(INode *node, CPMLevel *newFormatInst, TCHAR *name)
{
	PerFaceModData	*perFaceData;
	PerFaceEntry	*perFace;
	TData			oldData, newData;
	TMergeData		mergeData;


	if (node == NULL || newFormatInst == NULL)
		return;
	if ((perFaceData = PerFaceData_GetData(node)) == NULL)
		return;

	// if no existing format data exists.. just set the data
	if (perFaceData->formatInst == NULL)
		PerFaceData_FormatData(node, newFormatInst, name);

	// calculate the required size of our new data
	newData.size = 0;
	newFormatInst->EnumNodes(procCalcDataSize, &newData.size);

	// create a default set of our data
	newData.offset = 0;
	newData.data = (char *)malloc(newData.size);
	newFormatInst->EnumNodes(procMapDefaultsToData, &newData);

	// merge existing and new format trees
	newFormatInst->EnumNodes(procMergeFormatData, perFaceData->formatInst);

	// remap all retained existing face data
	for (perFace = perFaceData->faceList->next; perFace != perFaceData->faceList; perFace = perFace->next)
	{
		// set old data
		oldData.offset = 0;
		oldData.data = (char *)perFace->GetData(oldData.size);

		// set new data
		newData.offset = 0;

		// merge in existing data
		mergeData.newData = &newData;
		mergeData.oldData = &oldData;
		mergeData.oldFormatInst = perFaceData->formatInst;

		newFormatInst->EnumNodes(procMergeInData, &mergeData);

		// delete existing data and set new
		perFace->DelData();
		perFace->SetData(newData.data, newData.size);
	}
	SAFE_FREE(newData.data);

	// remove all merge tags from new format data set
	newFormatInst->EnumNodes(procRemoveMergeInfo);

	// set data format
	perFaceData->SetDataFormat(newFormatInst, TRUE, name);
}


/* --------------------------------------------------------------------------------
   Function : PerFaceData_WriteFormatData
   Purpose : write format data to a file stream
   Parameters : CPMLevel format instance, format data size, file stream context
   Returns : number of valid format attributes written
   Info : 
*/

int PerFaceData_WriteFormatData(CPMLevel *formatInst, int formatSize, FILE *stream)
{
	TData	data;
	int		parms[3];

	if (formatInst == NULL)
		return 0;

	// init data structure
	data.data = NULL;
	data.size = formatSize;
	data.offset = 0;

	// set paramters and write all format data
	parms[0] = (int)stream;						// file stream handle
	parms[1] = (int)&data;						// data structure
	parms[2] = 0;								// zero atrribute count
	formatInst->EnumNodes(procWriteFormatData, parms);

	// return number of valid format attributes written
	return parms[2];
}


// --------------------------------------------------------------------------------
// Format Data Functions And Callbacks
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : Proc
   Purpose : our panel page window procedure
   Parameters : dialog handle, message, additional message info, additional message info
   Returns : return TRUE if processed message, else FALSE
   Info : 
*/

static BOOL CALLBACK Proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	PerFaceMod	*mod;

	if (msg == WM_INITDIALOG)
	{
		mod = (PerFaceMod *)lParam;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)mod);
		return mod->Proc(hWnd, msg, wParam, lParam);
	}
	if (mod = (PerFaceMod *)GetWindowLong(hWnd, GWL_USERDATA))
	{
		if (msg == WM_DESTROY)
			SetWindowLong(hWnd, GWL_USERDATA, 0);
		return mod->Proc(hWnd, msg, wParam, lParam);
	}
	return FALSE;
}


/* --------------------------------------------------------------------------------
   Function : procRollupDialog
   Purpose : rollup dialog panel callback procedure
   Parameters : usual dialog parameters, TPanelInfo context pointer
   Returns : TRUE we handled message, FALSE we didn't
   Info : rollup dialog callback
*/

static BOOL CALLBACK procRollupDialog(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	TPanelInfo		*pnInfo;
	TRollupInfo		ruInfo;
	RECT			rc;


	// get valid context from windows user data
	if (msg != WM_INITDIALOG)
		if ((pnInfo = (TPanelInfo *)GetWindowLong(hWnd, GWL_USERDATA)) == NULL && msg != WM_INITDIALOG)
		{
			return FALSE;
		}

	// parse message
	switch (msg)
	{
	case WM_INITDIALOG:

		// save context in windows user data
		pnInfo = (TPanelInfo *)malloc(sizeof(TPanelInfo));
		pnInfo->pfMod =	((TPanelInfo *)lParam)->pfMod;
		pnInfo->pfData = ((TPanelInfo *)lParam)->pfData;
		pnInfo->ruNode = ((TPanelInfo *)lParam)->ruNode;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)pnInfo);

		// init rollup format information
		ruInfo.parent = hWnd;
		ruInfo.font = (HFONT)SendMessage(hWnd, WM_GETFONT, 0,0);
		ruInfo.yCur = FRMD_GROUPYP;
		ruInfo.controlId = IDENT_BASE;

		// add all of this rollups groups
		pnInfo->ruNode->EnumNodes(procAddGroup, &ruInfo, "Group");

		// re-size this rollup control from the accumulated size
		GetClientRect(hWnd, &rc);
		SetWindowPos(hWnd, NULL, 0,0, rc.right, ruInfo.yCur, SWP_NOMOVE | SWP_NOZORDER);
		break;

	case WM_DESTROY:

		// delete all of our controls
		pnInfo->ruNode->EnumNodes(procDelGroup, NULL, "Group");

		// remove our context user data
		SetWindowLong(hWnd, GWL_USERDATA, 0);
		SAFE_FREE(pnInfo);
		return 0;

	case WM_COMMAND:

		switch (HIWORD(wParam))
		{
		case BN_CLICKED:

			// ** Control Boolean Button Clicked

			// flip this buttons check state
			if (SendMessage((HWND)lParam, BM_GETCHECK, (WPARAM)0, (LPARAM)0) == BST_CHECKED)
				SendMessage((HWND)lParam, BM_SETCHECK, (WPARAM)BST_UNCHECKED, (LPARAM)0);
			else
				SendMessage((HWND)lParam, BM_SETCHECK, (WPARAM)BST_CHECKED, (LPARAM)0);
		}
		break;

	case CC_COLOR_CHANGE:

		// ** User Editting Colour Components

		if (pnInfo->ruNode != NULL)
		{
			// lock alpha component
			pnInfo->ruNode->EnumNodes(procLockAlpha, (void *)LOWORD(wParam));

			// flag user editted colour swatch
			if (HIWORD(wParam) == 1)
				pnInfo->ruNode->EnumNodes(procColourEdit, (void *)LOWORD(wParam));
		}
		break;

	default:
		return FALSE;
	}

	return TRUE;
}


// --------------------------------------------------------------------------------
// Dialog Procedure Callbacks
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : procAddRollup
   Purpose : register and create our rollup dialog panel
   Parameters : CPMNode pointer, TPanelInfo context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procAddRollup(CPMNode *node, void *context)
{
	TFormatRollup	*rollData;
	PerFaceMod		*pfMod;
	TCHAR			title[PMMAX_STRING_LEN];


	// get modifier instance from context
	pfMod  = (PerFaceMod *)((TPanelInfo *)context)->pfMod;

	// set rollup title text
	if (node->GetAttrib("name") != NULL)
		_stprintf(title, _T("%s"), node->GetAttrib("name"));
	else
		_stprintf(title, _T("New Rollup"));

	// save this group node instance in the context data
	((TPanelInfo *)context)->ruNode = node;

	DPrintf("Adding ROLLUP: \"%s\"", node->GetAttrib("name"));

	// add rollup dialog panel
	rollData = (TFormatRollup *)malloc(sizeof(TFormatRollup));
	rollData->hwnd = pfMod->ip->AddRollupPage(hInstance, MAKEINTRESOURCE(IDD_ROLLUP), procRollupDialog, title, (LPARAM)context/*,APPENDROLL_CLOSED*/);
	node->AddAttribData(FRMT_ROLLUP, rollData);

	return PMENUM_END_PATH;
}


/* --------------------------------------------------------------------------------
   Function : procAddGroup
   Purpose : register and create our required groups
   Parameters : CPMNode pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH, TRollupInfo context pointer
   Info : CPMNode enumeration callback
*/

static int procAddGroup(CPMNode *node, void *context)
{
	TRollupInfo		*ruInfo;
	TFormatGroup	*groupData;
	HWND			hwnd;
	TCHAR			title[PMMAX_STRING_LEN];
	int				groupyp;


	// load format info from context
	ruInfo = (TRollupInfo *)context;

	// save the group box pos and set the initial gorup control pos
	groupyp = ruInfo->yCur;
	ruInfo->yCur += FRMD_CTRLYP;

	DPrintf("Adding GROUP: \"%s\"", node->GetAttrib("name"));

	// add all controls to this group
	node->EnumNodes(procAddControl, ruInfo);

	// set group box title text
	if (node->GetAttrib("name") != NULL)
		_stprintf(title, _T("%s"), node->GetAttrib("name"));
	else
		_stprintf(title, _T("New Group"));

	// create our group box around the controls
	hwnd = CreateWindowEx(
				0,
				"BUTTON",
				title,
				WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
				FRMD_GROUPXP, groupyp, FRMD_GROUPWD, ruInfo->yCur - groupyp,
				ruInfo->parent,
				NULL,
				hInstance,
				NULL);
	SendMessage(hwnd, WM_SETFONT, (WPARAM)ruInfo->font, 0);

	// add our creation data to this node for deleting later
	groupData = (TFormatGroup *)malloc(sizeof(TFormatGroup));
	groupData->hwnd = hwnd;
	node->AddAttribData(FRMT_GROUP, groupData);

	// offset to the next group
	ruInfo->yCur += FRMD_GROUPYO;

	// don't look for any more groups below this path
	return PMENUM_END_PATH;
}


/* --------------------------------------------------------------------------------
   Function : procAddControl
   Purpose : register and create our required controls
   Parameters : CPMNode pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH, TRollupInfo context pointer
   Info : CPMNode enumeration callback
*/

static int procAddControl(CPMNode *node, void *context)
{
	static TCHAR	charbuf[128];
	TRollupInfo		*ruInfo;
	TFormatControl	*controlData;
	int				i, ival, imin,imax, r,g,b,a;
	float			fval, fmin,fmax;
	bool			bval, useAlpha;


	// get rollup information
	ruInfo = (TRollupInfo *)context;

	// setup specific dialog controller
	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:

		// ** Integer

		DPrintf("Adding CONTROL INT: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// create our integer control label
		_stprintf(charbuf, _T("%s:"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : "Int");
		controlData->hwndName = CreateWindowEx(
									0,
									"STATIC",
									charbuf,
									WS_CHILD | WS_VISIBLE | SS_LEFT | SS_LEFTNOWORDWRAP,
									FRMD_CTRLINTXP, ruInfo->yCur+1, FRMD_CTRLNAMEWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndName, WM_SETFONT, (WPARAM)ruInfo->font, 0);

		// create our integer edit box using a Max custom control
		controlData->hwndEdit = CreateWindowEx(
									0,
									CUSTEDITWINDOWCLASS,
									NULL,
									WS_CHILD | WS_VISIBLE,
									FRMD_CTRLINTXP + FRMD_CTRLNAMEWD, ruInfo->yCur, FRMD_CTRLINTWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		controlData->custEdit = GetICustEdit(controlData->hwndEdit);

		// set default int value
		if (node->GetAttrib("default", ival) == 0)
			ival = 0;
		controlData->custEdit->SetText(ival);

		if (node->FindAttrib("min") != NULL || node->FindAttrib("max") != NULL || getNodeDataType(node) == FRMTYPE_INT_UCHAR || getNodeDataType(node) == FRMTYPE_INT_SCHAR)
		{
			// create Max spinner control linked to edit box
			controlData->hwndSpin = CreateWindowEx(
										0,
										SPINNERWINDOWCLASS,
										NULL,
										WS_CHILD | WS_VISIBLE,
										FRMD_CTRLINTXP + FRMD_CTRLNAMEWD + FRMD_CTRLINTWD, ruInfo->yCur+1, FRMD_CTRLINTWD, FRMD_CTRLHT_,
										ruInfo->parent,
										NULL,
										hInstance,
										NULL);
			controlData->custSpin = GetISpinner(controlData->hwndSpin);

			// set spinner range
			if (node->GetAttrib("min", imin) == 0)
				imin = 0;
			if (node->GetAttrib("max", imax) == 0)
				imax = 1000;

			// auto limit for UCHAR/CHAR range
			if (node->FindAttrib("min") == NULL && node->FindAttrib("max") == NULL)
			{
				imin = (getNodeDataType(node) == FRMTYPE_INT_SCHAR) ? -128 : 0;
				imax = (getNodeDataType(node) == FRMTYPE_INT_SCHAR) ?  127 : 255;
			}

			controlData->custSpin->SetLimits(imin, imax);
			controlData->custSpin->SetAutoScale(TRUE);

			// set default int value
			if (node->GetAttrib("default", ival) == 0)
				ival = 0;
			controlData->custSpin->SetValue(ival, FALSE);

			// link this spinner control to our int edit box
			controlData->custSpin->LinkToEdit(controlData->hwndEdit, EDITTYPE_INT);
		}

		// save this controls ident
		controlData->controlId = ruInfo->controlId,

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	case FRMTYPE_FLOAT:

		// ** Float

		DPrintf("Adding CONTROL FLOAT: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// create our float control label
		_stprintf(charbuf, _T("%s:"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : "Float");
		controlData->hwndName = CreateWindowEx(
									0,
									"STATIC",
									charbuf,
									WS_CHILD | WS_VISIBLE | SS_LEFT | SS_LEFTNOWORDWRAP,
									FRMD_CTRLFLOATXP, ruInfo->yCur+1, FRMD_CTRLNAMEWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndName, WM_SETFONT, (WPARAM)ruInfo->font, 0);

		// create our float edit box using a Max custom control
		controlData->hwndEdit = CreateWindowEx(
									0,
									CUSTEDITWINDOWCLASS,
									NULL,
									WS_CHILD | WS_VISIBLE,
									FRMD_CTRLFLOATXP + FRMD_CTRLNAMEWD, ruInfo->yCur, FRMD_CTRLFLOATWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		controlData->custEdit = GetICustEdit(controlData->hwndEdit);

		// set default float value
		if (node->GetAttrib("default", fval) == 0)
			fval = 0;
		controlData->custEdit->SetText(fval);

		if (node->FindAttrib("min") != NULL && node->FindAttrib("max") != NULL)
		{
			// create Max spinner control linked to edit box
			controlData->hwndSpin = CreateWindowEx(
										0,
										SPINNERWINDOWCLASS,
										NULL,
										WS_CHILD | WS_VISIBLE,
										FRMD_CTRLFLOATXP + FRMD_CTRLNAMEWD + FRMD_CTRLFLOATWD, ruInfo->yCur+1, FRMD_CTRLFLOATWD, FRMD_CTRLHT_,
										ruInfo->parent,
										NULL,
										hInstance,
										NULL);
			controlData->custSpin = GetISpinner(controlData->hwndSpin);

			// set spinner range
			if (node->GetAttrib("min", fmin) == 0)
				fmin = 0.0f;
			if (node->GetAttrib("max", fmax) == 0)
				fmax = 1.0f;
			controlData->custSpin->SetLimits(fmin, fmax);
			controlData->custSpin->SetAutoScale(TRUE);

			// set default float value
			if (node->GetAttrib("default", fval) == 0)
				fval = 0;
			controlData->custSpin->SetValue(fval, FALSE);

			// link this spinner control to our int edit box
			controlData->custSpin->LinkToEdit(controlData->hwndEdit, EDITTYPE_FLOAT);
		}

		// save this controls ident
		controlData->controlId = ruInfo->controlId,

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	case FRMTYPE_STRING:

		// ** String

		// get this strings length
		ival = PMMAX_STRING_LEN;
		node->GetAttrib("length", ival);

		DPrintf("Adding CONTROL STRING: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// create our string control label
		_stprintf(charbuf, _T("%s:"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : "String");
		controlData->hwndName = CreateWindowEx(
									0,
									"STATIC",
									charbuf,
									WS_CHILD | WS_VISIBLE | SS_LEFT | SS_LEFTNOWORDWRAP,
									FRMD_CTRLSTRINGXP, ruInfo->yCur+1, FRMD_CTRLNAMEWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndName, WM_SETFONT, (WPARAM)ruInfo->font, 0);

		// create our string edit box using a Max custom control
		controlData->hwndEdit = CreateWindowEx(
									0,
									CUSTEDITWINDOWCLASS,
									NULL,
									WS_CHILD | WS_VISIBLE,
									FRMD_CTRLSTRINGXP + FRMD_CTRLNAMEWD, ruInfo->yCur, FRMD_CTRLSTRINGWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		controlData->custEdit = GetICustEdit(controlData->hwndEdit);

		// set default text
		controlData->custEdit->SetText((node->FindAttrib("default") != NULL) ? node->GetAttrib("default") : "");

		// save this controls ident
		controlData->controlId = ruInfo->controlId,

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

		// ** Enumeration

		DPrintf("Adding CONTROL ENUM: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// create our string control label
		_stprintf(charbuf, _T("%s:"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : "String");
		controlData->hwndName = CreateWindowEx(
									0,
									"STATIC",
									charbuf,
									WS_CHILD | WS_VISIBLE | SS_LEFT | SS_LEFTNOWORDWRAP,
									FRMD_CTRLENUMXP, ruInfo->yCur+2, FRMD_CTRLNAMEWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndName, WM_SETFONT, (WPARAM)ruInfo->font, 0);

		// create our enum combo box
		controlData->hwndCombo = CreateWindowEx(
									0,
									"COMBOBOX",
									NULL,
									WS_CHILD | WS_VISIBLE | WS_VSCROLL | CBS_AUTOHSCROLL | CBS_HASSTRINGS | CBS_DROPDOWNLIST,
									FRMD_CTRLENUMXP + FRMD_CTRLNAMEWD, ruInfo->yCur, FRMD_CTRLENUMWD, FRMD_CTRLENUMHT,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndCombo, WM_SETFONT, (WPARAM)ruInfo->font, 0);
		SendMessage(controlData->hwndCombo, CB_RESETCONTENT, 0,0);

		// add type specific content to the combox box
		switch (node->GetAttribType("list"))
		{
		case PMATTRIB_ENUMSTRING:

			// add all strings to combo box
			for (i=0;;i++)
			{
				if (node->GetAttribEnum("list", i) == NULL)
					break;
				SendMessage(controlData->hwndCombo, CB_ADDSTRING, 0, (LPARAM)node->GetAttribEnum("list", i));
			}

			// set the default string selection
			if (node->GetAttrib("default") != NULL)
				SendMessage(controlData->hwndCombo, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)node->GetAttrib("default"));
			break;

		case PMATTRIB_ENUMINT:
			break;
		case PMATTRIB_ENUMFLOAT:
			break;
		}

		// save this controls ident
		controlData->controlId = ruInfo->controlId,

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

		// ** Boolean

		DPrintf("Adding CONTROL BOOL: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// set the button text
		_stprintf(charbuf, _T("%s"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : "New Check Box");

		// create our boolean check box control
		controlData->hwndBut = CreateWindowEx(
									0,
									"BUTTON",
									charbuf,
									WS_CHILD | WS_VISIBLE | BS_3STATE | BS_LEFTTEXT | BS_TEXT | BS_CENTER | BS_PUSHLIKE,
									FRMD_CTRLBOOLXP, ruInfo->yCur, FRMD_CTRLBOOLWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndBut, WM_SETFONT, (WPARAM)ruInfo->font, 0);

		// set default button state
		bval = false;
		node->GetAttrib("default", bval);
		SendMessage(controlData->hwndBut, BM_SETCHECK, (WPARAM)(bval == true) ? BST_CHECKED : BST_UNCHECKED, 0);

		// save this controls ident
		controlData->controlId = ruInfo->controlId,

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	case FRMTYPE_DATA:

		// ** UnEditable Data

		DPrintf("Adding CONTROL DATA: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// create our data status area using a Max custom control
		controlData->hwndStatus = CreateWindowEx(
										0,
										CUSTSTATUSWINDOWCLASS,
										NULL,
										WS_CHILD | WS_VISIBLE,
										FRMD_CTRLDATAXP, ruInfo->yCur, FRMD_CTRLDATAWD, FRMD_CTRLHT_,
										ruInfo->parent,
										NULL,
										hInstance,
										NULL);
		controlData->custStatus = GetICustStatus(controlData->hwndStatus);

		// set the status data text
		ival = 0;
		node->GetAttrib("size", ival);
		_stprintf(charbuf, _T("%s : %d"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : "Data", ival);
		controlData->custStatus->SetText(charbuf);
		controlData->custStatus->SetTextFormat(STATUSTEXT_CENTERED);

		// save this controls ident
		controlData->controlId = ruInfo->controlId,

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	case FRMTYPE_COLOUR:

		// ** Colour

		DPrintf("Adding CONTROL COLOUR: \"%s\"", node->GetAttrib("name"));

		// create our control creation data
		controlData = (TFormatControl *)malloc(sizeof(TFormatControl));
		memset(controlData, 0, sizeof(TFormatControl));

		// should we support alpha component?
		useAlpha = false;
		node->GetAttrib("alpha", useAlpha);

		// create our colour control label
		_stprintf(charbuf, _T("%s:"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : (useAlpha == true) ? _T("RGBA") : _T("RGB"));
		controlData->hwndName = CreateWindowEx(
									0,
									"STATIC",
									charbuf,
									WS_CHILD | WS_VISIBLE | SS_LEFT | SS_LEFTNOWORDWRAP,
									FRMD_CTRLCOLOURXP, ruInfo->yCur+2, FRMD_CTRLNAMEWD, FRMD_CTRLHT_,
									ruInfo->parent,
									NULL,
									hInstance,
									NULL);
		SendMessage(controlData->hwndName, WM_SETFONT, (WPARAM)ruInfo->font, 0);

		// create our colour data swatch using a Max custom control
		ival = (useAlpha == true) ? FRMD_CTRLCOLSMLWD : FRMD_CTRLCOLBIGWD;
		controlData->hwndColour = CreateWindowEx(
									0,
									COLORSWATCHWINDOWCLASS,
									NULL,
									WS_CHILD | WS_VISIBLE,
									FRMD_CTRLCOLOURXP + FRMD_CTRLNAMEWD, ruInfo->yCur, ival, FRMD_CTRLHT_,
									ruInfo->parent,
									(HMENU)ruInfo->controlId,
									hInstance,
									NULL);

		// get default rgb value
		r = g = b = 0;
		node->GetAttribEnum("default", 0, r);
		node->GetAttribEnum("default", 1, g);
		node->GetAttribEnum("default", 2, b);

		// get the edit rgb colour swatch label
		_stprintf(charbuf, _T("%s %s"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : _T(""), _T("RGB"));

		// get instance of colour swatch
		controlData->custColour = GetIColorSwatch(controlData->hwndColour, RGB(r,g,b), charbuf);
		controlData->custColour->SetModal();

		// save this controls ident
		controlData->controlId = ruInfo->controlId;

		// do we need to edit the alpha component?
		if (useAlpha)
		{
			// inc control ident for alpha colour swatch
			ruInfo->controlId++;

			// create our alpha data using a Max custom control
			controlData->hwndAlpha = CreateWindowEx(
										0,
										COLORSWATCHWINDOWCLASS,
										NULL,
										WS_CHILD | WS_VISIBLE,
										FRMD_CTRLCOLOURXP + FRMD_CTRLNAMEWD + FRMD_CTRLCOLSMLWD-1, ruInfo->yCur, FRMD_CTRLCOLALPWD+1, FRMD_CTRLHT_,
										ruInfo->parent,
										(HMENU)ruInfo->controlId,
										hInstance,
										NULL);

			// get default alpha value
			a = 255;
			node->GetAttribEnum("default", 3, a);

			// get the edit alpha colour swatch label
			_stprintf(charbuf, _T("%s %s"), (node->GetAttrib("name") != NULL) ? node->GetAttrib("name") : _T(""), _T("Alpha"));

			// get instance of colour swatch
			controlData->custAlpha = GetIColorSwatch(controlData->hwndAlpha, RGB(a,a,a), charbuf);
			controlData->custAlpha->SetModal();
		}

		// add our creation data to this node for deleting later
		node->AddAttribData(FRMT_CONTROL, controlData);
		break;


	default:

		// ** Unknown
		return PMENUM_CONTINUE;
	}

	// inc to the next controls y position
	bval = false;
	node->GetAttrib("close", bval);
	ruInfo->yCur += (bval == true) ? FRMD_CTRLYI_CLOSE : FRMD_CTRLYI_;

	// inc control ident to allow for controls inbetween
	ruInfo->controlId += 4;

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procDelRollup
   Purpose : delete our previously created rollups
   Parameters : CPMNode pointer, valid interface pointer context
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH, TRollupInfo context pointer
   Info : CPMNode enumeration callback
*/

static int procDelRollup(CPMNode *node, void *context)
{
	TFormatRollup	*rollData;
	IObjParam		*ip;

	ip = (IObjParam *)context;

	DPrintf("Deleting ROLLUP: \"%s\"", node->GetAttrib("name"));

	rollData = (TFormatRollup *)node->GetAttribData(FRMT_ROLLUP);
	if (rollData->hwnd != NULL)
		ip->DeleteRollupPage(rollData->hwnd);
	SAFE_FREE(rollData);
	node->DelAttrib(FRMT_ROLLUP);

	return PMENUM_END_PATH;
}


/* --------------------------------------------------------------------------------
   Function : procDelGroup
   Purpose : delete our previously created groups
   Parameters : CPMNode pointer, NULL context
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH, TRollupInfo context pointer
   Info : CPMNode enumeration callback
*/

static int procDelGroup(CPMNode *node, void *context)
{
	TFormatGroup *groupData;

	groupData = (TFormatGroup *)node->GetAttribData(FRMT_GROUP);
	if (groupData != NULL)
	{
		DPrintf("Deleting GROUP: \"%s\"", node->GetAttrib("name"));

		node->EnumNodes(procDelControl, NULL);
		SAFE_FREE(groupData);
		node->DelAttrib(FRMT_GROUP);
	}

	// only control below this path
	return PMENUM_END_PATH;
}


/* --------------------------------------------------------------------------------
   Function : procDelControl
   Purpose : delete our previously created controls
   Parameters : CPMNode pointer, NULL context
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH, TRollupInfo context pointer
   Info : CPMNode enumeration callback
*/

static int procDelControl(CPMNode *node, void *context)
{
	TFormatControl *controlData;

	controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
	if (controlData != NULL)
	{
		DPrintf("Deleting CONTROL: \"%s\"", node->GetAttrib("name"));

		if (controlData->custEdit != NULL)
			ReleaseICustEdit(controlData->custEdit);
		if (controlData->custSpin != NULL)
			ReleaseISpinner(controlData->custSpin);
		if (controlData->custStatus != NULL)
			ReleaseICustStatus(controlData->custStatus);
		if (controlData->custColour != NULL)
			ReleaseIColorSwatch(controlData->custColour);
		if (controlData->custAlpha != NULL)
			ReleaseIColorSwatch(controlData->custAlpha);
		SAFE_FREE(controlData);
		node->DelAttrib(FRMT_CONTROL);
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procCalcDataSize
   Purpose : calculate size of required data
   Parameters : CPMNode pointer, size int context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procCalcDataSize(CPMNode *node, void *context)
{
	int	offset;

	offset = alignNodeDataAccess(node, *((int *)context));
	offset += getNodeDataSize(node);

	*((int *)context) = offset;

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procMapDefaultsToData
   Purpose : set default data
   Parameters : CPMNode pointer, TData context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procMapDefaultsToData(CPMNode *node, void *context)
{
	TData			*data;
	int				ival, len;
	float			fval;
	bool			bval;
	char			*string;
	unsigned char	rgba[4];


	// get data pointer
	data = (TData *)context;

	// write default values int data
	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:

		// ** Integer

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// write default value
		ival = 0;
		node->GetAttrib("default", ival);
		writeData(node, data, ival);

		// inc data offset
		data->offset += len;
		break;

	case FRMTYPE_FLOAT:

		// ** Float

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// write default value
		fval = 0.0f;
		node->GetAttrib("default", fval);
		writeData(node, data, fval);

		// inc data offset
		data->offset += len;
		break;

	case FRMTYPE_STRING:

		// ** String

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// write default value
		string = node->GetAttrib("default");
		writeData(node, data, string, len);

		// inc data offset
		data->offset += len;
		break;

	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

		// ** Enumeration

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// write default value
		ival = 0;
		string = node->GetAttrib("default");
		if (string != NULL)
			if ((ival = node->FindAttribEnum("list", string)) == -1)
			{
				ival = 0;
			}
		writeData(node, data, ival);

		// inc data offset
		data->offset += len;
		break;

	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

		// ** Boolean

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// write default value
		bval = false;
		node->GetAttrib("default", bval);
		writeData(node, data, bval);

		// inc data offset
		data->offset += len;
		break;

	case FRMTYPE_DATA:

		// ** UnEditable Data

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// inc data offset
		data->offset += len;
		break;

	case FRMTYPE_COLOUR:

		// ** Colour

		// get data length
		len = getNodeDataSize(node);

		// align data access
		data->offset = alignNodeDataAccess(node, data->offset);

		// write default values
		ival = 0;
		node->GetAttribEnum("default", 0, ival);
		rgba[0] = ival;
		ival = 0;
		node->GetAttribEnum("default", 1, ival);
		rgba[1] = ival;
		ival = 0;
		node->GetAttribEnum("default", 2, ival);
		rgba[2] = ival;
		ival = 255;
		node->GetAttribEnum("default", 3, ival);
		rgba[3] = ival;

		bval = false;
		node->GetAttrib("alpha", bval);
		if (bval == true)
			writeData(node, data, rgba, 4);
		else
			writeData(node, data, rgba, 3);

		// inc data offset
		data->offset += len;
	}
	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procMapMultipleDataToControls
   Purpose : map multiple data to controls
   Parameters : CPMNode pointer, TDataLog context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
		: It is entirely possible for this enumeration to be called for data which ISN'T
		: currently been editted, therefore we must ONLY write to data on the special
		: control tags being present within the data's attributes.
*/

static int procMapMultipleDataToControls(CPMNode *node, void *context)
{
	TData			data;
	TDataLog		*dataLog;
	TFormatControl	*controlData;
	int				n, len, ival, isave;
	float			fval, fsave;
	char			*cval, csave[PMMAX_STRING_LEN];
	bool			bval, bsave;
	unsigned char	rgba[4], rgbasave[4];
	COLORREF		colrgb, cola;


	// get data log pointer
	dataLog = (TDataLog *)context;

	// parse data into specified dialog control
	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:

		// ** Integer

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// initialise our single data buffer
		data.size   = dataLog->size;
		data.offset = dataLog->offset;

		// read all ints from raw data
		for (n=0; n < dataLog->noof; n++)
		{
			// load data set n
			data.data = dataLog->entries[n].data;
			// read this sets data
			ival = 0;
			readData(node, &data, ival);
			// if n data.is different from previous data
			if (n > 0 && isave != ival)
				break;						// ..break data read
			isave = ival;
		}
		if (n >= dataLog->noof)
		{
			// set dialog control with shared int value
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL)
			{
				if (controlData->custSpin)
					controlData->custSpin->SetValue(ival, FALSE);
				if (controlData->custEdit)
					controlData->custEdit->SetText(ival);
			}
		}
		else
		{
			// clear the control as multiple datas are different
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL)
			{
				if (controlData->custEdit)
					controlData->custEdit->SetText(_T("_MISMATCH_"));
			}
		}

		// inc next data
		dataLog->offset += len;
		break;

	case FRMTYPE_FLOAT:

		// ** Float

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// initialise our single data buffer
		data.size   = dataLog->size;
		data.offset = dataLog->offset;

		// read all floats from raw data
		for (n=0; n < dataLog->noof; n++)
		{
			// load data set n
			data.data = dataLog->entries[n].data;
			// read this sets data
			fval = 0;
			readData(node, &data, fval);
			// if n data.is different from previous data
			if (n > 0 && fsave != fval)
				break;						// ..break data read
			fsave = fval;
		}
		if (n >= dataLog->noof)
		{
			// set dialog control with shared float value
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL)
			{
				if (controlData->custEdit)
					controlData->custEdit->SetText(fval);
				if (controlData->custSpin)
					controlData->custSpin->SetValue(fval, FALSE);
			}
		}
		else
		{
			// clear the control as multiple datas are different
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL)
			{
				if (controlData->custEdit)
					controlData->custEdit->SetText(_T("_MISMATCH_"));
			}
		}

		// inc next data
		dataLog->offset += len;
		break;

	case FRMTYPE_STRING:

		// ** String

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// initialise our single data buffer
		data.size   = dataLog->size;
		data.offset = dataLog->offset;

		// read all string from raw data
		csave[0] = 0;
		for (n=0; n < dataLog->noof; n++)
		{
			// load data set n
			data.data = dataLog->entries[n].data;
			// read this sets data
			cval = readData(node, &data, (char *)NULL, len);
			// if n data is different from previous data
			if (cval == NULL || (n > 0 && stricmp(csave, cval) != 0))
				break;						// ..break data read
			if (len > 0)
				strncpy(csave, cval, len-1);
		}
		if (n >= dataLog->noof)
		{
			// set dialog control with shared string value
			if (len > 0)
				csave[len-1] = 0;
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL && controlData->custEdit != NULL)
			{
				controlData->custEdit->SetText((cval != NULL) ? cval : "");
			}
		}
		else
		{
			// clear the control as multiple datas are different
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL && controlData->custEdit != NULL)
			{
				controlData->custEdit->SetText(_T("_MISMATCH_"));
			}
		}

		// inc next data
		dataLog->offset += len;
		break;

	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

		// ** Enumeration

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// initialise our single data buffer
		data.size   = dataLog->size;
		data.offset = dataLog->offset;

		// read all enum indices from raw data
		for (n=0; n < dataLog->noof; n++)
		{
			// load data set n
			data.data = dataLog->entries[n].data;
			// read this sets data
			ival = 0;
			readData(node, &data, ival);
			// if n data.is different from previous data
			if (n > 0 && isave != ival)
				break;						// ..break data read
			isave = ival;
		}
		if (n >= dataLog->noof)
		{
			// set dialog control with shared enum index
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL && controlData->hwndCombo != NULL)
			{
				SendMessage(controlData->hwndCombo, CB_SETCURSEL, (WPARAM)ival, 0);
			}
		}
		else
		{
			// clear the control as multiple datas are different
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL && controlData->hwndCombo != NULL)
			{
				SendMessage(controlData->hwndCombo, CB_SETCURSEL, (WPARAM)-1, 0);
			}
		}

		// inc next data
		dataLog->offset += len;
		break;

	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

		// ** Boolean

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// initialise our single data buffer
		data.size   = dataLog->size;
		data.offset = dataLog->offset;

		// read all booleans from raw data
		for (n=0; n < dataLog->noof; n++)
		{
			// load data set n
			data.data = dataLog->entries[n].data;
			// read this sets data
			bval = false;
			readData(node, &data, bval);
			// if n data.is different from previous data
			if (n > 0 && bsave != bval)
				break;						// ..break data read
			bsave = bval;
		}
		if (n >= dataLog->noof)
		{
			// set dialog control with shared boolean value
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL && controlData->hwndBut != NULL)
			{
				SendMessage(controlData->hwndBut, BM_SETCHECK, (WPARAM)(bval == true) ? BST_CHECKED : BST_UNCHECKED, 0);
			}
		}
		else
		{
			// clear the control as multiple datas are different
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL && controlData->hwndBut != NULL)
			{
				SendMessage(controlData->hwndBut, BM_SETCHECK, (WPARAM)BST_INDETERMINATE, 0);
			}
		}

		// inc next data
		dataLog->offset += len;
		break;

	case FRMTYPE_DATA:

		// ** UnEditable Data

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// inc next data
		dataLog->offset += len;
		break;

	case FRMTYPE_COLOUR:

		// ** Colour

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// initialise out single data buffer
		data.size	= dataLog->size;
		data.offset = dataLog->offset;

		// alpha?
		bval = false;
		node->GetAttrib("alpha", bval);
		if (bval == true)
			ival = 4;
		else
			ival = 3;

		// read all colours from raw data
		for (n=0; n < dataLog->noof; n++)
		{
			// load data set n
			data.data = dataLog->entries[n].data;
			// read this sets data
			rgba[0] = rgba[1] = rgba[2] = 0;
			rgba[3] = 255;
			readData(node, &data, rgba, ival);
			if (n > 0 && memcmp(rgbasave, rgba, ival) != 0)
				break;
			memcpy(rgbasave, rgba, ival);
		}
		if (n >= dataLog->noof)
		{
			// set dialog control with shared colour value
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL)
			{
				controlData->noColourEditFlag = controlData->noAlphaEditFlag = 0;
				if (controlData->custColour != NULL)
				{
					colrgb = RGB(rgba[0],rgba[1],rgba[2]);
					controlData->custColour->SetColor(colrgb);
				}
				if (controlData->custAlpha != NULL)
				{
					cola = RGB(rgba[3],rgba[3],rgba[3]);
					controlData->custAlpha->SetColor(cola);
				}
			}
		}
		else
		{
			// set dialog control colour to grey as multiple datas are different
			controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
			if (controlData != NULL)
			{
				controlData->noColourEditFlag = controlData->noAlphaEditFlag = 1;
				colrgb = RGB(128,128,128);
				if (controlData->custColour != NULL)
					controlData->custColour->SetColor(colrgb);
				if (controlData->custAlpha != NULL)
					controlData->custAlpha->SetColor(colrgb);
			}
		}

		// inc next data
		dataLog->offset += len;
		break;

	default:
		break;
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procMapControlsToMultipleData
   Purpose : map controls to multiple data
   Parameters : CPMNode pointer, TDataLog context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procMapControlsToMultipleData(CPMNode *node, void *context)
{
	TData			data;
	TDataLog		*dataLog;
	TFormatControl	*controlData;
	int				n, len, ival;
	float			fval;
	char			string[PMMAX_STRING_LEN];
	bool			bval;
	unsigned char	rgba[4];
	COLORREF		colrgb, cola;


	// get data log pointer
	dataLog = (TDataLog *)context;

	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:

		// ** Integer

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// get this node's control attribute
		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			// can we assume that mis-matched data has NOT been editted?
			bval = false;
			if (controlData->custEdit)
			{
				string[0] = 0;
				controlData->custEdit->GetText(string, _tcslen(_T("_MISMATCH_"))+1);
				if (stricmp("_MISMATCH_", string) == NULL)
				{
					bval = true;
				}
			}
			if (bval == false)
			{
				// initialise our single data buffer
				data.size   = dataLog->size;
				data.offset = dataLog->offset;

				// get valid int value from control
				ival = 0;
				if (controlData->custSpin)
					ival = controlData->custSpin->GetIVal();
				else if (controlData->custEdit)
					ival = controlData->custEdit->GetInt();
				// set int value into all multiple data
				for (n=0; n < dataLog->noof; n++)
				{
					// load data set n and write value
					data.data = dataLog->entries[n].data;
					writeData(node, &data, ival);
				}
			}
		}

		// inc next data
		dataLog->offset += len;
		break;


	case FRMTYPE_FLOAT:

		// ** Float

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// get this node's control attribute
		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			// can we assume that mis-matched data has NOT been editted?
			bval = false;
			if (controlData->custEdit)
			{
				string[0] = 0;
				controlData->custEdit->GetText(string, _tcslen(_T("_MISMATCH_"))+1);
				if (stricmp("_MISMATCH_", string) == NULL)
				{
					bval = true;
				}
			}
			if (bval == false)
			{
				// initialise our single data buffer
				data.size   = dataLog->size;
				data.offset = dataLog->offset;

				// get valid float value from control
				fval = 0;
				if (controlData->custSpin)
					fval = controlData->custSpin->GetFVal();
				else if (controlData->custEdit)
					fval = controlData->custEdit->GetFloat();
				// set int value into all multiple data
				for (n=0; n < dataLog->noof; n++)
				{
					// load data set n and write value
					data.data = dataLog->entries[n].data;
					writeData(node, &data, fval);
				}
			}
		}

		// inc next data
		dataLog->offset += len;
		break;


	case FRMTYPE_STRING:

		// ** String

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// get this node's control attribute
		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			// can we assume that mis-matched data has NOT been editted?
			bval = false;
			if (controlData->custEdit)
			{
				string[0] = 0;
				controlData->custEdit->GetText(string, _tcslen(_T("_MISMATCH_"))+1);
				if (stricmp("_MISMATCH_", string) == NULL)
				{
					bval = true;
				}
			}
			if (bval == false)
			{
				// initialise our single data buffer
				data.size   = dataLog->size;
				data.offset = dataLog->offset;

				// get valid len string from control
				string[0] = 0;
				if (controlData->custEdit != NULL)
					controlData->custEdit->GetText(string, len);
				// set string into all multiple data
				for (n=0; n < dataLog->noof; n++)
				{
					// load data set n and write value
					data.data = dataLog->entries[n].data;
					writeData(node, &data, string, len);
				}
			}
		}

		// inc next data
		dataLog->offset += len;
		break;


	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

		// ** Enumeration

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// get this node's control attribute
		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			// can we assume that mis-matched data has NOT been editted?
			bval = false;
			if (controlData->hwndCombo)
				if (SendMessage(controlData->hwndCombo, CB_GETCURSEL, 0, 0) == CB_ERR)
				{
					bval = true;
				}
			if (bval == false)
			{
				// initialise our single data buffer
				data.size   = dataLog->size;
				data.offset = dataLog->offset;

				// get valid index from control
				if (controlData->hwndCombo)
					ival = SendMessage(controlData->hwndCombo, CB_GETCURSEL, 0, 0);
				// set enum index into all multiple data
				for (n=0; n < dataLog->noof; n++)
				{
					// load data set n and write value
					data.data = dataLog->entries[n].data;
					writeData(node, &data, ival);
				}
			}
		}

		// inc next data
		dataLog->offset += len;
		break;


	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

		// ** Boolean

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// get this node's control attribute
		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			// can we assume that mis-matched data has NOT been editted?
			bval = false;
			if (controlData->hwndBut)
				if (SendMessage(controlData->hwndBut, BM_GETCHECK, 0, 0) == BST_INDETERMINATE)
				{
					bval = true;
				}
			if (bval == false)
			{
				// initialise our single data buffer
				data.size   = dataLog->size;
				data.offset = dataLog->offset;

				// get valid index from control
				bval = false;
				if (controlData->hwndBut)
					bval = (SendMessage(controlData->hwndBut, BM_GETCHECK, 0, 0) == BST_CHECKED) ? true : false;
				// set boolean value into all multiple data
				for (n=0; n < dataLog->noof; n++)
				{
					// load data set n and write value
					data.data = dataLog->entries[n].data;
					writeData(node, &data, bval);
				}
			}
		}

		// inc next data
		dataLog->offset += len;
		break;


	case FRMTYPE_DATA:

		// ** UnEditable Data

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// inc next data
		dataLog->offset += len;
		break;


	case FRMTYPE_COLOUR:

		// ** Colour Data

		// get data length
		len = getNodeDataSize(node);

		// align data access
		dataLog->offset = alignNodeDataAccess(node, dataLog->offset);

		// get this node's control attribute
		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			// can we assume that mis-matched data has not been editted?
			if (controlData->noColourEditFlag == 1 && controlData->noAlphaEditFlag == 1)
			{
				// ** Do NOT acknowledge this mis-matched state!!
			}
			else
			{
				// initialise our single data buffer
				data.size   = dataLog->size;
				data.offset = dataLog->offset;

				// alpha?
				bval = false;
				node->GetAttrib("alpha", bval);
				if (bval == true)
					ival = 4;
				else
					ival = 3;

				// write out editted colour value
				if (controlData->noColourEditFlag == 0 && controlData->noAlphaEditFlag == 0)
				{
					// ** Both colour and alpha swatches were editted

					// read in both colour and alpha values
					colrgb = RGB(0,0,0);
					if (controlData->custColour != NULL)
						colrgb = controlData->custColour->GetColor();
					cola = RGB(255,0,0);
					if (controlData->custAlpha != NULL)
						cola = controlData->custAlpha->GetColor();

					// create colour list
					rgba[0] = (unsigned char)GetRValue(colrgb);
					rgba[1] = (unsigned char)GetGValue(colrgb);
					rgba[2] = (unsigned char)GetBValue(colrgb);
					rgba[3] = (unsigned char)GetRValue(cola);

					// set colour value into all multiple data
					for (n=0; n < dataLog->noof; n++)
					{
						// load data set n and write value
						data.data = dataLog->entries[n].data;
						writeData(node, &data, rgba, ival);
					}
				}
				else if (controlData->noColourEditFlag == 0 && controlData->noAlphaEditFlag == 1)
				{
					// ** Colour swatch editted only

					// read in colour value
					colrgb = RGB(0,0,0);
					if (controlData->custColour != NULL)
						colrgb = controlData->custColour->GetColor();

					// create colour list (safe to can ignore alpha)
					rgba[0] = (unsigned char)GetRValue(colrgb);
					rgba[1] = (unsigned char)GetGValue(colrgb);
					rgba[2] = (unsigned char)GetBValue(colrgb);

					// set colour value into all multiple data
					for (n=0; n < dataLog->noof; n++)
					{
						// need to write out rgb only
						data.data = dataLog->entries[n].data;
						writeData(node, &data, rgba, 3);
					}
				}
				else
				{
					// ** Alpha swatch editted only

					// read in alpha value
					cola = RGB(255,0,0);
					if (controlData->custAlpha != NULL)
						cola = controlData->custAlpha->GetColor();

					// create colour list
					rgba[0] = rgba[1] = rgba[2] = 0;
					rgba[3] = (unsigned char)GetRValue(cola);

					// set colour value into all multiple data
					for (n=0; n < dataLog->noof; n++)
					{
						// read in colour and merge in with alpha value
						data.data = dataLog->entries[n].data;
						readData(node, &data, rgba, 3);
						writeData(node, &data, rgba, ival);
					}
				}
			}
		}

		// inc next data
		dataLog->offset += len;
		break;


	default:
		break;
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procPreWriteNodes / procPostWriteNodes
   Purpose : write data format to Max file
   Parameters : CPMNode pointer, Max ISave handle
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

// ** procPreWriteNodes
// ** the nodes are saved out in tree order.. so this is the begin part

static int procPreWriteNodes(CPMNode *node, void *context)
{
	ISave	*isave;
	ULONG	nb;

	// get Max save handle
	isave = (ISave *)context;

	// save specific node data
	if (getNodeDataType(node) != FRMTYPE_NULL)
	{
		// write node begin and unique type name
		isave->BeginChunk(LCLCHUNK_FORMAT_NODE_BEGIN);
		isave->Write(node->type, sizeof(node->type), &nb);
		isave->EndChunk();

		// save all of this nodes attributes
		node->EnumAttribs(procWriteAttribs, isave);
	}

	return PMENUM_CONTINUE;
}

// ** procPostWriteNodes
// ** the nodes are saved out in tree order.. so this is the end part

static int procPostWriteNodes(CPMNode *node, void *context)
{
	ISave *isave;

	// get Max save handle
	isave = (ISave *)context;

	// save specific node data
	if (getNodeDataType(node) != FRMTYPE_NULL)
	{
		// write node end
		isave->BeginChunk(LCLCHUNK_FORMAT_NODE_END);
		isave->EndChunk();
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procEnableControls
   Purpose : enable / disable all data controls
   Parameters : CPMNode pointer, BOOL enable / disable flag
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procEnableControls(CPMNode *node, void *context)
{
	BOOL			flag;
	TFormatControl	*controlData;
	TFormatGroup	*groupData;


	// get enable flag
	flag = *((BOOL *)context);

	// enable specific node type
	switch (getNodeDataType(node))
	{
	case FRMTYPE_GROUP:

		// ** Group

		groupData = (TFormatGroup *)node->GetAttribData(FRMT_GROUP);
		if (groupData != NULL)
		{
			if (groupData->hwnd != NULL)
				EnableWindow(groupData->hwnd, flag);
		}
		break;

	case FRMTYPE_STRING:
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:
	case FRMTYPE_FLOAT:

		// ** Value

		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			if (controlData->hwndName != NULL)
				EnableWindow(controlData->hwndName, flag);

			if (controlData->custEdit != NULL)
				controlData->custEdit->Enable(flag);
			if (controlData->custSpin != NULL)
				controlData->custSpin->Enable(flag);
		}
		break;

	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

		// ** Boolean

		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			if (controlData->hwndBut != NULL)
				EnableWindow(controlData->hwndBut, flag);
		}
		break;

	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

		// ** Enumerator

		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			if (controlData->hwndName != NULL)
				EnableWindow(controlData->hwndName, flag);
			if (controlData->hwndCombo != NULL)
				EnableWindow(controlData->hwndCombo, flag);
		}
		break;

	case FRMTYPE_DATA:

		// ** Data

		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			if (controlData->custStatus != NULL)
				controlData->custStatus->Enable(flag);
		}
		break;

	case FRMTYPE_COLOUR:

		// ** Colour

		controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
		if (controlData != NULL)
		{
			if (controlData->hwndName != NULL)
				EnableWindow(controlData->hwndName, flag);
			if (controlData->custColour != NULL)
				controlData->custColour->Enable(flag);
			if (controlData->custAlpha != NULL)
				controlData->custAlpha->Enable(flag);
		}
		break;
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procMergeFormatData
   Purpose : rebuild format data tree incorporating, where possible, from existing
   Parameters : CPMNode pointer, existing CPMLevel context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procMergeFormatData(CPMNode *node, void *context)
{
	CPMLevel		*oldFormatInst;
	TSearchNode		searchNode;


	// get existing format data instance
	oldFormatInst = (CPMLevel *)context;

	// search for matching node in modifiers existing data format set
	if ((searchNode.ident = node->GetAttrib("ident")) != NULL)
	{
		searchNode.node = NULL;
		oldFormatInst->EnumNodes(procFindNode, &searchNode);
		if (searchNode.node != NULL)
		{
			// ** Matching Node Found
			// **
			// ** This node exists within the modifiers existing data set, therefore we
			// ** need to retain the data from the existing set if both data types are
			// ** compatible

			// are matching data types compatible?
			if (areNodeDataTypesCompatible(node, searchNode.node) == 1)
			{
				// drop an indentifier attribute in our new format data to remap existing data
				node->AddAttrib(FRMT_REMAP, (int)searchNode.node);
			}
		}
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procMergeInData
   Purpose : merge into default data all retained data
   Parameters : CPMNode pointer, TMergeData context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procMergeInData(CPMNode *node, void *context)
{
	TMergeData		*mergeData;
	CPMNode			*oldNode;
	int				size, oldSize, parms[2], ival;
	char			string[PMMAX_STRING_LEN];
	bool			bval;
	float			fval;
	unsigned char	rgba[4];


	// get merge data info pointer
	mergeData = (TMergeData *)context;

	// get merge data node, if exists?
	oldNode = NULL;
	node->GetAttrib(FRMT_REMAP, (int&)oldNode);

	if (oldNode != NULL)
	{
		// read old data up until our node
		parms[0] = (int)mergeData->oldData;
		parms[1] = (int)oldNode;
		mergeData->oldData->offset = 0;
		mergeData->oldFormatInst->EnumNodes(procReadDataUntilNode, parms);

		// ** Merge In Data

		switch (getNodeDataType(oldNode))
		{
		case FRMTYPE_STRING:

			// ** String

			// can only convert to data of same type
			switch (getNodeDataType(node))
			{
			case FRMTYPE_STRING:

				// read in old data string
				size = getNodeDataSize(oldNode);
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);
				if (readData(oldNode, mergeData->oldData, string, size) != NULL)
				{
					// merge string into our new data
					size = getNodeDataSize(node);
					mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
					writeData(node, mergeData->newData, string, size);
				}
				break;
			}
			break;


		case FRMTYPE_INT_UCHAR:
		case FRMTYPE_INT_SCHAR:
		case FRMTYPE_INT_USHORT:
		case FRMTYPE_INT_SSHORT:
		case FRMTYPE_INT_UINT:
		case FRMTYPE_INT_SINT:

			// ** Integer Value

			// filter out incompatible conversion types
			switch (getNodeDataType(node))
			{
			case FRMTYPE_INT_UCHAR:
			case FRMTYPE_INT_SCHAR:
			case FRMTYPE_INT_USHORT:
			case FRMTYPE_INT_SSHORT:
			case FRMTYPE_INT_UINT:
			case FRMTYPE_INT_SINT:
			case FRMTYPE_FLOAT:
			case FRMTYPE_ENUM_UCHAR:
			case FRMTYPE_ENUM_USHORT:
			case FRMTYPE_ENUM_UINT:

				// read in old data integer value
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);
				readData(oldNode, mergeData->oldData, ival);

				// merge integer into our new data
				mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
				if (getNodeDataType(node) == FRMTYPE_FLOAT)
				{
					fval = (float)ival;
					writeData(node, mergeData->newData, fval);
				}
				else
					writeData(node, mergeData->newData, ival);
				break;
			}
			break;


		case FRMTYPE_FLOAT:

			// ** Float Value

			// filter out incompatible conversion types
			switch (getNodeDataType(node))
			{
			case FRMTYPE_INT_UCHAR:
			case FRMTYPE_INT_SCHAR:
			case FRMTYPE_INT_USHORT:
			case FRMTYPE_INT_SSHORT:
			case FRMTYPE_INT_UINT:
			case FRMTYPE_INT_SINT:
			case FRMTYPE_FLOAT:
			case FRMTYPE_ENUM_UCHAR:
			case FRMTYPE_ENUM_USHORT:
			case FRMTYPE_ENUM_UINT:

				// read in old data float value
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);
				readData(oldNode, mergeData->oldData, fval);

				// merge float into our new data
				mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
				if (getNodeDataType(node) != FRMTYPE_FLOAT)
				{
					ival = (int)fval;
					writeData(node, mergeData->newData, ival);
				}
				else
					writeData(node, mergeData->newData, fval);
				break;
			}
			break;


		case FRMTYPE_BOOL_UCHAR:
		case FRMTYPE_BOOL_USHORT:
		case FRMTYPE_BOOL_UINT:

			// ** Boolean Value

			// can only convert to data of same type
			switch (getNodeDataType(node))
			{
			case FRMTYPE_BOOL_UCHAR:
			case FRMTYPE_BOOL_USHORT:
			case FRMTYPE_BOOL_UINT:

				// read in old bool
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);
				readData(oldNode, mergeData->oldData, bval);

				// merge bool into our new data
				size = getNodeDataSize(node);
				mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
				writeData(node, mergeData->newData, bval);
				break;
			}
			break;


		case FRMTYPE_ENUM_UCHAR:
		case FRMTYPE_ENUM_USHORT:
		case FRMTYPE_ENUM_UINT:

			// ** Enumerator Value

			// filter out incompatible conversion types
			switch (getNodeDataType(node))
			{
			case FRMTYPE_INT_UCHAR:
			case FRMTYPE_INT_SCHAR:
			case FRMTYPE_INT_USHORT:
			case FRMTYPE_INT_SSHORT:
			case FRMTYPE_INT_UINT:
			case FRMTYPE_INT_SINT:
			case FRMTYPE_FLOAT:
			case FRMTYPE_ENUM_UCHAR:
			case FRMTYPE_ENUM_USHORT:
			case FRMTYPE_ENUM_UINT:

				// read in old data enum value
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);
				readData(oldNode, mergeData->oldData, ival);

				// merge enum into our new data
				mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
				if (getNodeDataType(node) == FRMTYPE_FLOAT)
				{
					fval = (float)ival;
					writeData(node, mergeData->newData, fval);
				}
				else
					writeData(node, mergeData->newData, ival);
				break;
			}
			break;


		case FRMTYPE_DATA:

			// ** Data

			// filter out incompatible conversion types
			switch (getNodeDataType(node))
			{
			case FRMTYPE_DATA:

				// read in old data
				oldSize = getNodeDataSize(oldNode);
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);

				// align new data write
				size = getNodeDataSize(node);
				mergeData->oldData->offset = alignNodeDataAccess(node, mergeData->oldData->offset);

				// clear new data and merge in what we can from the old
				memset(mergeData->newData->data + mergeData->newData->offset, 0, size);
				memcpy(mergeData->newData->data + mergeData->newData->offset, mergeData->oldData->data + mergeData->oldData->offset, min(size, oldSize));
				break;
			}
			break;


		case FRMTYPE_COLOUR:

			// ** Colour Value

			// filter out incompatible conversion types
			switch (getNodeDataType(node))
			{
			case FRMTYPE_COLOUR:

				// read in old data colour value
				bval = false;
				oldNode->GetAttrib("alpha", bval);
				if (bval == true)
					ival = 4;
				else
					ival = 3;
				mergeData->oldData->offset = alignNodeDataAccess(oldNode, mergeData->oldData->offset);
				readData(oldNode, mergeData->oldData, rgba, ival);

				// merge colour value into our new data
				if (ival > 3)				// if old alpha doesn't exist.. only write rgb and use existing (default) alpha, if needed
				{
					bval = false;
					node->GetAttrib("alpha", bval);
					if (bval == true)
						ival = 4;
					else
						ival = 3;
				}
				mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
				writeData(node, mergeData->newData, rgba, ival);
			}
			break;
		}
	}

	// skip this nodes data
	size = getNodeDataSize(node);
	mergeData->newData->offset = alignNodeDataAccess(node, mergeData->newData->offset);
	mergeData->newData->offset += size;

	return PMENUM_CONTINUE;
}

/* --------------------------------------------------------------------------------
   Function : procRemoveMergeTags
   Purpose : remove all merge tags
   Parameters : CPMNode pointer, NULL context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procRemoveMergeInfo(CPMNode *node, void *context)
{
	// remove remap attribute from node
	node->DelAttrib(FRMT_REMAP);

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procFindNode
   Purpose : find node identified by ident attribute
   Parameters : CPMNode pointer, TSearchNode context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procFindNode(CPMNode *node, void *context)
{
	TSearchNode	*searchNode;
	char		*ident;

	// get search node structure pointer
	searchNode = (TSearchNode *)context;

	// if ident attribute exists and match.. this is our node
	if ((ident = node->GetAttrib("ident")) != NULL)
		if (stricmp(searchNode->ident, ident) == 0)
		{
			// save this node and terminate search
			searchNode->node = node;
			return PMENUM_END;
		}
	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procReadDataUntilNode
   Purpose : read data up until our target node is reached
   Parameters : CPMNode pointer, parms[2] context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procReadDataUntilNode(CPMNode *node, void *context)
{
	TData	*data;
	CPMNode	*targetNode;
	int		size;

	// get parameters
	data = (TData *)((int *)context)[0];
	targetNode = (CPMNode *)((int *)context)[1];

	// at our target node?
	if (node == targetNode)
		return PMENUM_END;

	// size data length
	size = getNodeDataSize(node);

	// align data access
	data->offset = alignNodeDataAccess(node, data->offset);

	// next data
	data->offset += size;

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procTidyClonedData
   Purpose : remove all extra non-data nodes from cloned data
   Parameters : CPMNode pointer, NULL context pointer
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procTidyClonedData(CPMNode *node, void *context)
{
	// ** Note:
	// ** This deletes all of the extra tag attributes that are used when editting
	// ** our face data. Therefore this should ONLY be called on the cloned data.

	// delete dialog control attributes
	node->DelAttrib(FRMT_ROLLUP);
	node->DelAttrib(FRMT_GROUP);
	node->DelAttrib(FRMT_CONTROL);

	// delete remap attribute
	node->DelAttrib(FRMT_REMAP);

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procWriteFormatData
   Purpose : write format data to a file stream
   Parameters : CPMNode pointer, parms[3] context pointer [0]FILE*, [1]TData*, int noof
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procWriteFormatData(CPMNode *node, void *context)
{
	char	charbuf[PMMAX_IDENT_LEN];
	TData	*data;
	FILE	*stream;
	int		size, type;


	// get params from context
	stream = (FILE *)((int *)context)[0];
	data = (TData *)((int *)context)[1];

	// write valid format data
	type = getNodeDataType(node);
	switch (type)
	{
	case FRMTYPE_STRING:

	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:

	case FRMTYPE_FLOAT:

	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

	case FRMTYPE_DATA:

	case FRMTYPE_COLOUR:

		// ** For Valid Data Types Only

		// get ident
		memset(charbuf, 0, sizeof(charbuf));
		if (node->FindAttrib("ident") != NULL)
			strncpy(charbuf, node->GetAttrib("ident"), sizeof(charbuf)-1);

		// get size and data offset
		size = getNodeDataSize(node);
		data->offset = alignNodeDataAccess(node, data->offset);

		// write all
		fwrite(charbuf, sizeof(charbuf), 1, stream);
		fwrite(&type, sizeof(type), 1, stream);
		fwrite(&size, sizeof(size), 1, stream);
		fwrite(&data->offset, sizeof(data->offset), 1, stream);

		data->offset += size;

		// inc write count
		((int *)context)[2]++;
		break;
	}

	return PMENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : procColourEdit
   Purpose : flag colour swatch control attribute editted within colour swatch node
   Parameters : CPMNode pointer, int control ident context
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procColourEdit(CPMNode *node, void *context)
{
	TFormatControl	*controlData;

	controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
	if (controlData != NULL)
	{
		// ** Located Our Colour Swatch Node

		// acknowledge colour edit occurred?
		if (controlData->custColour != NULL && controlData->controlId == (int)context)
			controlData->noColourEditFlag = 0;

		// acknowledge alpha edit occurred?
		if (controlData->custAlpha != NULL && (controlData->controlId+1) == (int)context)
			controlData->noAlphaEditFlag = 0;
	}

	return PMENUM_CONTINUE;
}



/* --------------------------------------------------------------------------------
   Function : procLockAlpha
   Purpose : lock alpha component to user red value
   Parameters : CPMNode pointer, wParam context LOWORD controlId, 
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMNode enumeration callback
*/

static int procLockAlpha(CPMNode *node, void *context)
{
	TFormatControl	*controlData;
	int				col, red;

	controlData = (TFormatControl *)node->GetAttribData(FRMT_CONTROL);
	// ** alpha colour swatch control id == colour swatch control id + 1
	if (controlData != NULL && controlData->custAlpha != NULL && (controlData->controlId+1) == (int)context)
	{
		// ** Located Our Alpha Swatch Node

		// lock alpha to current red component
		col = controlData->custAlpha->GetColor();
		red = GetRValue(col);
		controlData->custAlpha->SetColor(RGB(red,red,red));

		return PMENUM_END;
	}

	return PMENUM_CONTINUE;
}


// --------------------------------------------------------------------------------
// Format Data Attribute Callbacks
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : procWriteAttribs
   Purpose : write data format to Max file
   Parameters : CPMNode pointer, Max ISave handle
   Returns : PMENUM_CONTINUE, PMENUM_END, PMENM_END_PATH
   Info : CPMAttrib enumeration callback
*/

static int procWriteAttribs(CPMAttrib *attrib, void *context)
{
	ISave	*isave;
	ULONG	nb;
	int		n;

	// ignore this attribute if it was created by the modifier editor
	if (stricmp(attrib->ident, FRMT_ROLLUP) == 0)
		return PMENUM_CONTINUE;
	if (stricmp(attrib->ident, FRMT_GROUP) == 0)
		return PMENUM_CONTINUE;
	if (stricmp(attrib->ident, FRMT_CONTROL) == 0)
		return PMENUM_CONTINUE;

	// get Max save handle
	isave = (ISave *)context;

	// save specific attribute
	switch (attrib->type)
	{
	case PMATTRIB_STRING:

		// write string
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_STRING);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(attrib->string, sizeof(attrib->string), &nb);
		isave->EndChunk();
		break;

	case PMATTRIB_INT:

		// write integer
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_INT);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(&attrib->ival, sizeof(attrib->ival), &nb);
		isave->EndChunk();
		break;

	case PMATTRIB_FLOAT:

		// write float
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_FLOAT);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(&attrib->fval, sizeof(attrib->fval), &nb);
		isave->EndChunk();
		break;

	case PMATTRIB_BOOL:

		// write boolean
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_BOOL);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(&attrib->bval, sizeof(attrib->bval), &nb);
		isave->EndChunk();
		break;

	case PMATTRIB_ENUMSTRING:

		// write string enumerations
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_ENUMSTRING);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(&attrib->enoof, sizeof(attrib->enoof), &nb);
		for (n=0; n<attrib->enoof; n++)
			isave->Write(attrib->estrings + n*PMMAX_STRING_LEN, PMMAX_STRING_LEN, &nb);
		isave->EndChunk();
		break;

	case PMATTRIB_ENUMINT:

		// write integer enumerations
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_ENUMINT);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(&attrib->enoof, sizeof(attrib->enoof), &nb);
		for (n=0; n<attrib->enoof; n++)
			isave->Write(&attrib->eivals[n], sizeof(attrib->ival), &nb);
		isave->EndChunk();
		break;

	case PMATTRIB_ENUMFLOAT:

		// write float enumerations
		isave->BeginChunk(LCLCHUNK_FORMAT_ATTRIB_ENUMFLOAT);
		isave->Write(attrib->ident, sizeof(attrib->ident), &nb);
		isave->Write(&attrib->enoof, sizeof(attrib->enoof), &nb);
		for (n=0; n<attrib->enoof; n++)
			isave->Write(&attrib->efvals[n], sizeof(attrib->fval), &nb);
		isave->EndChunk();
		break;
	}

	return PMENUM_CONTINUE;
}


// --------------------------------------------------------------------------------
// Support Functions
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : loadFormatData
   Purpose : load format data from Max file
   Parameters : node instance, Max load handle, version number
   Returns : IO_OK or IO_ERROR
   Info : 
*/

static IOResult loadFormatData(CPMNode *node, ILoad *iload, int version)
{
	CPMNode			*newNode, emptyNode;
	CPMAttrib		emptyAttrib;
	IOResult		res;
	USHORT			id;
	ULONG			nb;
	int				noof;


	while (IO_OK == (res = iload->OpenChunk()))
	{
		id = iload->CurChunkID();
		switch (id)
		{

		// ** Format Chunks

		case LCLCHUNK_FORMAT_END:

			// end format data..
			iload->CloseChunk();
			return IO_OK;

		// ** Node Chunks

		case LCLCHUNK_FORMAT_NODE_BEGIN:

			// create new node as child of parent node
			newNode = new CPMNode(node);

			// read the unique type
			iload->Read(emptyNode.type, sizeof(emptyNode.type), &nb);
			iload->CloseChunk();

			newNode->SetType(emptyNode.type);

			// load this nodes data
			loadFormatData(newNode, iload, version);
			break;

		case LCLCHUNK_FORMAT_NODE_END:

			// close this chunk and return to parent node
			iload->CloseChunk();
			return IO_OK;

		// ** Attribute Chunks

		case LCLCHUNK_FORMAT_ATTRIB_STRING:

			// read string
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(emptyAttrib.string, sizeof(emptyAttrib.string), &nb);
			iload->CloseChunk();

			// add attribute
			node->AddAttrib(emptyAttrib.ident, emptyAttrib.string);
			break;

		case LCLCHUNK_FORMAT_ATTRIB_INT:

			// read integer
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(&emptyAttrib.ival, sizeof(emptyAttrib.ival), &nb);
			iload->CloseChunk();

			// add attribute
			node->AddAttrib(emptyAttrib.ident, emptyAttrib.ival);
			break;

		case LCLCHUNK_FORMAT_ATTRIB_FLOAT:

			// read float
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(&emptyAttrib.fval, sizeof(emptyAttrib.fval), &nb);
			iload->CloseChunk();

			// add attribute
			node->AddAttrib(emptyAttrib.ident, emptyAttrib.fval);
			break;

		case LCLCHUNK_FORMAT_ATTRIB_BOOL:

			// read boolean
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(&emptyAttrib.bval, sizeof(emptyAttrib.bval), &nb);
			iload->CloseChunk();

			// add attribute
			node->AddAttrib(emptyAttrib.ident, emptyAttrib.bval);
			break;

		case LCLCHUNK_FORMAT_ATTRIB_ENUMSTRING:

			// read string enumeration
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(&noof, sizeof(emptyAttrib.enoof), &nb);

			// add all attributes
			while (noof--)
			{
				iload->Read(emptyAttrib.string, sizeof(emptyAttrib.string), &nb);
				node->AddAttribEnum(emptyAttrib.ident, emptyAttrib.string);
			}
			iload->CloseChunk();
			break;

		case LCLCHUNK_FORMAT_ATTRIB_ENUMINT:

			// read int enumeration
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(&noof, sizeof(emptyAttrib.enoof), &nb);

			// add all attributes
			while (noof--)
			{
				iload->Read(&emptyAttrib.ival, sizeof(emptyAttrib.ival), &nb);
				node->AddAttribEnum(emptyAttrib.ident, emptyAttrib.ival);
			}
			iload->CloseChunk();
			break;

		case LCLCHUNK_FORMAT_ATTRIB_ENUMFLOAT:

			// read float enumeration
			iload->Read(emptyAttrib.ident, sizeof(emptyAttrib.ident), &nb);
			iload->Read(&noof, sizeof(emptyAttrib.enoof), &nb);

			// add all attributes
			while (noof--)
			{
				iload->Read(&emptyAttrib.fval, sizeof(emptyAttrib.fval), &nb);
				node->AddAttribEnum(emptyAttrib.ident, emptyAttrib.fval);
			}
			iload->CloseChunk();
			break;

		// ** Unknown Chunks

		default:
			iload->CloseChunk();
			break;
		}
	}
	return res;
}


/* --------------------------------------------------------------------------------
   Function : getNodeDataType
   Purpose : return this nodes data type
   Parameters : CPMNode instance pointer
   Returns : FRMTYPES
   Info : 
*/

static int getNodeDataType(CPMNode *node)
{
	if (stricmp(node->type, "Rollup") == NULL)
		return FRMTYPE_ROLLUP;
	else if (stricmp(node->type, "Group") == NULL)
		return FRMTYPE_GROUP;
	else if (stricmp(node->type, "Int") == NULL)
	{
		// get more specific integer type
		if (node->GetAttrib("type") != NULL)
		{
			if (stricmp(node->GetAttrib("type"), DATS_UCHAR) == 0)
				return FRMTYPE_INT_UCHAR;
			if (stricmp(node->GetAttrib("type"), DATS_SCHAR) == 0)
				return FRMTYPE_INT_SCHAR;
			if (stricmp(node->GetAttrib("type"), DATS_USHORT) == 0)
				return FRMTYPE_INT_USHORT;
			if (stricmp(node->GetAttrib("type"), DATS_SSHORT) == 0)
				return FRMTYPE_INT_SSHORT;
			if (stricmp(node->GetAttrib("type"), DATS_UINT) == 0)
				return FRMTYPE_INT_UINT;
			if (stricmp(node->GetAttrib("type"), DATS_SINT) == 0)
				return FRMTYPE_INT_SINT;
		}
		return FRMTYPE_INT_SINT;
	}
	else if (stricmp(node->type, "Float") == NULL)
		return FRMTYPE_FLOAT;
	else if (stricmp(node->type, "String") == NULL)
		return FRMTYPE_STRING;
	else if (stricmp(node->type, "Enum") == NULL)
	{
		// get more specific enumerator type
		if (node->GetAttrib("type") != NULL)
		{
			if (stricmp(node->GetAttrib("type"), DATS_UCHAR) == 0)
				return FRMTYPE_ENUM_UCHAR;
			if (stricmp(node->GetAttrib("type"), DATS_USHORT) == 0)
				return FRMTYPE_ENUM_USHORT;
			if (stricmp(node->GetAttrib("type"), DATS_UINT) == 0)
				return FRMTYPE_ENUM_UINT;
		}
		return FRMTYPE_ENUM_UINT;
	}
	else if (stricmp(node->type, "BOOL") == NULL)
	{
		// get more specific boolean type
		if (node->GetAttrib("type") != NULL)
		{
			if (stricmp(node->GetAttrib("type"), DATS_UCHAR) == 0)
				return FRMTYPE_BOOL_UCHAR;
			if (stricmp(node->GetAttrib("type"), DATS_USHORT) == 0)
				return FRMTYPE_BOOL_USHORT;
			if (stricmp(node->GetAttrib("type"), DATS_UINT) == 0)
				return FRMTYPE_BOOL_UINT;
		}
		return FRMTYPE_BOOL_UCHAR;
	}
	else if (stricmp(node->type, "Data") == NULL)
		return FRMTYPE_DATA;
	else if (stricmp(node->type, "Colour") == NULL)
		return FRMTYPE_COLOUR;

	// unknown
	return FRMTYPE_NULL;
}


/* --------------------------------------------------------------------------------
   Function : getNodeDataSize
   Purpose : get data size of this node
   Parameters : CPMNode pointer
   Returns : size of node
   Info : 
*/

static int getNodeDataSize(CPMNode *node)
{
	bool	bval;
	int		size;

	switch (getNodeDataType(node))
	{

	case FRMTYPE_STRING:
		size = PMMAX_STRING_LEN;
		node->GetAttrib("length", size);
		break;

	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
		size = sizeof(char);
		break;
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
		size = sizeof(short);
		break;
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:
		size = sizeof(int);
		break;

	case FRMTYPE_FLOAT:
		size = sizeof(float);
		break;

	case FRMTYPE_BOOL_UCHAR:
		size = sizeof(unsigned char);
		break;
	case FRMTYPE_BOOL_USHORT:
		size = sizeof(unsigned short);
		break;
	case FRMTYPE_BOOL_UINT:
		size = sizeof(unsigned int);
		break;

	case FRMTYPE_ENUM_UCHAR:
		size = sizeof(unsigned char);
		break;
	case FRMTYPE_ENUM_USHORT:
		size = sizeof(unsigned short);
		break;
	case FRMTYPE_ENUM_UINT:
		size = sizeof(unsigned int);
		break;

	case FRMTYPE_DATA:
		size = 0;
		node->GetAttrib("size", size);
		break;

	case FRMTYPE_COLOUR:
		bval = false;
		node->GetAttrib("alpha", bval);
		if (bval == true)
			size = 4;
		else
			size = 3;
		break;

	default:
		size = 0;
		break;
	}

	return size;
}


/* --------------------------------------------------------------------------------
   Function : alignNodeDataAccess
   Purpose : align node data for access
   Parameters : CPMNode pointer, current offset
   Returns : aligned node data offset
   Info : 
*/

static int alignNodeDataAccess(CPMNode *node, int offset)
{
	int	size;

	size = getNodeDataSize(node);

	// alignment
	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_INT_SCHAR:
	case FRMTYPE_INT_USHORT:
	case FRMTYPE_INT_SSHORT:
	case FRMTYPE_INT_UINT:
	case FRMTYPE_INT_SINT:

	case FRMTYPE_FLOAT:

	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_BOOL_UINT:

	case FRMTYPE_ENUM_UCHAR:
	case FRMTYPE_ENUM_USHORT:
	case FRMTYPE_ENUM_UINT:

		// align to next &-size boundary
		if (size > 0)
			offset = (offset + (size-1)) & -size;
		break;
	}

	return offset;
}


/* --------------------------------------------------------------------------------
   Function : areNodeDataTypesCompatible
   Purpose : return if this node pairs data types are compatible
   Parameters : CPMNode pointer1, CPMNode pointer2
   Returns : 1 compatible, else 0
   Info : 
*/

// node data types compatibility table
static unsigned char dataTypesCompatibilityTable[FRMTYPE_END][FRMTYPE_END] =
//	 N G R S I I I I I I F B B B E E E D C
{	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},		// FRMTYPE_NULL,
	{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},		// FRMTYPE_GROUP,
	{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},		// FRMTYPE_ROLLUP,
	{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},		// FRMTYPE_STRING,
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_INT_UCHAR,
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_INT_SCHAR,
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_INT_USHORT
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_INT_SSHORT
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_INT_UINT
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_INT_SINT
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_FLOAT
	{0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0},		// FRMTYPE_BOOL_UCHAR
	{0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0},		// FRMTYPE_BOOL_USHORT
	{0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0},		// FRMTYPE_BOOL_UINT
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_ENUM_UCHAR
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_ENUM_USHORT
	{0,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0},		// FRMTYPE_ENUM_UINT
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0},		// FRMTYPE_DATA
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},		// FRMTYPE_COLOUR
};

static int areNodeDataTypesCompatible(CPMNode *node1, CPMNode *node2)
{
	int	oldType, newType;
	
	if (node1 == NULL || node2 == NULL)
		return 0;
	oldType = getNodeDataType(node1);
	newType = getNodeDataType(node2);
	return (int)dataTypesCompatibilityTable[oldType][newType];
}


/* --------------------------------------------------------------------------------
   Function : writeData
   Purpose : write integer value into node data
   Parameters : CPMNode pointer, TData pointer, integer value
   Returns : 
   Info : 
*/

static void writeData(CPMNode *node, TData *data, int ival)
{
	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_ENUM_UCHAR:
		if ((data->offset + sizeof(unsigned char)) <= data->size)
		{
			*((unsigned char *)(data->data + data->offset)) = (unsigned char)ival;
		}
		break;
	case FRMTYPE_INT_SCHAR:
		if ((data->offset + sizeof(char)) <= data->size)
		{
			*((char *)(data->data + data->offset)) = (char)ival;
		}
		break;

	case FRMTYPE_INT_USHORT:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_ENUM_USHORT:
		if ((data->offset + sizeof(unsigned short)) <= data->size)
		{
			*((unsigned short *)(data->data + data->offset)) = (unsigned short)ival;
		}
		break;
	case FRMTYPE_INT_SSHORT:
		if ((data->offset + sizeof(short)) <= data->size)
		{
			*((short *)(data->data + data->offset)) = (short)ival;
		}
		break;

	case FRMTYPE_INT_UINT:
	case FRMTYPE_BOOL_UINT:
	case FRMTYPE_ENUM_UINT:
		if ((data->offset + sizeof(unsigned int)) <= data->size)
		{
			*((unsigned int *)(data->data + data->offset)) = (unsigned int)ival;
		}
		break;
	case FRMTYPE_INT_SINT:
		if ((data->offset + sizeof(int)) <= data->size)
		{
			*((int *)(data->data + data->offset)) = (int)ival;
		}
		break;
	}
}


/* --------------------------------------------------------------------------------
   Function : writeData
   Purpose : write float value into node data
   Parameters : CPMNode pointer, TData pointer, float value
   Returns : 
   Info : 
*/

static void writeData(CPMNode *node, TData *data, float fval)
{
	if ((data->offset + sizeof(float)) <= data->size)
	{
		*((float *)(data->data + data->offset)) = fval;
	}
}


/* --------------------------------------------------------------------------------
   Function : writeData
   Purpose : write boolean value into nodes data
   Parameters : CPMNode pointer, TData pointer, boolean value
   Returns : 
   Info : 
*/

static void writeData(CPMNode *node, TData *data, bool bval)
{
	int ival;

	ival = (bval == true) ? 1 : 0;
	writeData(node, data, ival);
}


/* --------------------------------------------------------------------------------
   Function : writeData
   Purpose : write string value into node data
   Parameters : CPMNode pointer, TData pointer, string pointer, max length
   Returns : 
   Info : 
*/

static void writeData(CPMNode *node, TData *data, char *string, int length)
{
	if ((data->offset + length) <= data->size && length > 0)
	{
		memset(data->data + data->offset, 0, length);
		if (string != NULL)
			strncpy(data->data + data->offset, string, length-1);
	}
}


/* --------------------------------------------------------------------------------
   Function : writeData
   Purpose : write colour rgba value into node data
   Parameters : CPMNode pointer, TData pointer, rgba pointer, colour length
   Returns : 
   Info : 
*/

static void writeData(CPMNode *node, TData *data, unsigned char *rgba, int length)
{
	if ((data->offset + length) <= data->size && length > 0)
	{
		memset(data->data + data->offset, 0, length);
		if (rgba != NULL)
			memcpy(data->data + data->offset, rgba, length);
	}
}


/* --------------------------------------------------------------------------------
   Function : readData
   Purpose : read integer value from node data
   Parameters : CPMNode pointer, TData pointer, integer reference
   Returns : 
   Info : 
*/

static void readData(CPMNode *node, TData *data, int& ival)
{
	switch (getNodeDataType(node))
	{
	case FRMTYPE_INT_UCHAR:
	case FRMTYPE_BOOL_UCHAR:
	case FRMTYPE_ENUM_UCHAR:
		if ((data->offset + sizeof(unsigned char)) <= data->size)
		{
			ival = (int)*((unsigned char *)(data->data + data->offset));
		}
		break;
	case FRMTYPE_INT_SCHAR:
		if ((data->offset + sizeof(char)) <= data->size)
		{
			ival = (int)*((char *)(data->data + data->offset));
		}
		break;

	case FRMTYPE_INT_USHORT:
	case FRMTYPE_BOOL_USHORT:
	case FRMTYPE_ENUM_USHORT:
		if ((data->offset + sizeof(unsigned short)) <= data->size)
		{
			ival = (int)*((unsigned short *)(data->data + data->offset));
		}
		break;
	case FRMTYPE_INT_SSHORT:
		if ((data->offset + sizeof(short)) <= data->size)
		{
			ival = (int)*((short *)(data->data + data->offset));
		}
		break;

	case FRMTYPE_INT_UINT:
	case FRMTYPE_BOOL_UINT:
	case FRMTYPE_ENUM_UINT:
		if ((data->offset + sizeof(unsigned int)) <= data->size)
		{
			ival = (int)*((unsigned int *)(data->data + data->offset));
		}
		break;
	case FRMTYPE_INT_SINT:
		if ((data->offset + sizeof(int)) <= data->size)
		{
			ival = (int)*((int *)(data->data + data->offset));
		}
		break;
	}
}


/* --------------------------------------------------------------------------------
   Function : readData
   Purpose : read float value from node data
   Parameters : CPMNode pointer, TData pointer, float reference
   Returns : 
   Info : 
*/

static void readData(CPMNode *node, TData *data, float& fval)
{
	if ((data->offset + sizeof(float)) <= data->size)
	{
		fval = (float)*((float *)(data->data + data->offset));
	}
}


/* --------------------------------------------------------------------------------
   Function : readData
   Purpose : read boolean value from node data
   Parameters : CPMNode pointer, TData pointer, boolean reference
   Returns : 
   Info : 
*/

static void readData(CPMNode *node, TData *data, bool& bval)
{
	int	ival;

	readData(node, data, ival);
	bval = (ival == 1) ? true : false;
}


/* --------------------------------------------------------------------------------
   Function : readData
   Purpose : read string value from node data
   Parameters : CPMNode pointer, TData pointer, string buffer, max string length
   Returns : string pointer
   Info : 
*/

static char *readData(CPMNode *node, TData *data, char *string, int length)
{
	if ((data->offset + length) <= data->size)
	{
		if (string == NULL)
			return (char *)(data->data + data->offset);
		else
		{
			strncpy(string, (char *)data->data + data->offset, length);
			return string;
		}
	}
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : readData
   Purpose : read colour value from node data
   Parameters : CPMNode pointer, TData pointer, rgba pointer, colour length
   Returns : rgba pointer
   Info : 
*/

static unsigned char *readData(CPMNode *node, TData *data, unsigned char *rgba, int length)
{
	if ((data->offset + length) <= data->size)
	{
		if (rgba == NULL)
			return (unsigned char *)(data->data + data->offset);
		else
		{
			memcpy(rgba, data->data + data->offset, length);
			return rgba;
		}
	}
	return NULL;
}
