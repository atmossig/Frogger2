
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of PerFaceData.dlm, (c) 2000 Interactive Studios Ltd.
//
//    File : PerFaceData.h
// Purpose : Header
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __PERFACEDATA__H
#define __PERFACEDATA__H

#define DLLEXPORT	__declspec( dllexport )

#include "Max.h"
#include "istdplug.h"
#if MAX_RELEASE >= 3000
#include "iparamb2.h"
#include "iparamm2.h"
#else
#include "iparamb.h"
#include "iparamm.h"
#endif
#include "modstack.h"
#include "meshadj.h"

#include "CommonFiles.h"
#include "ParseMap.h"

#define PERFACEDATA_CLASS_ID	Class_ID(0x5e95489a, 0x3e167c8)


// --------------------------------------------------------------------------------
// Class PerFaceEntry Definition : Face Entry
// --------------------------------------------------------------------------------
class DLLEXPORT PerFaceEntry
{
	protected:
		PerFaceEntry				*listRoot;					// root instance pointer
		int							noofItems;					// #items in the list (only valid on the root item)

	private:
		int							ident[3];					// unique face id
		int							size;						// size of data held
		void						*data;						// data pointer

	public:
		PerFaceEntry				*next, *prev;				// link list

									PerFaceEntry();
									PerFaceEntry(PerFaceEntry *root);
									~PerFaceEntry();

									// delete all entries
		void						DeleteAll();
									// return number of items from this list
		int							NoofItems();

									// set this faces unique identity
		void						SetIdent(int v0, int v1, int v2);
									// get this faces unique identity
		void						GetIdent(int& v0, int& v1, int& v2);

									// set this faces data
		void						SetData(void *data, int size);
									// get this faces data
		void						*GetData(int& outSize);
		void						*GetData();

									// delete this faces data
		void						DelData();

									// copy from "perFace" entry
		void						Copy(PerFaceEntry *perFace);

									// IO methods
		IOResult					Save(ISave *isave);
		IOResult					Load(ILoad *iload);
};


// --------------------------------------------------------------------------------
// Class PerFaceModData: Local Modifier Data for each instance
// --------------------------------------------------------------------------------
class PerFaceModData : public LocalModData
{
	private:
		Mesh						*mesh;
		AdjEdgeList					*adjEdgeList;

	public:
		TCHAR						dataName[PMMAX_IDENT_LEN];
		PerFaceEntry				*faceList;
		BitArray					faceSel;
		int							updateData;
		CPMLevel					*formatInst;
		int							formatSize;

		Tab<PerFaceEntry *>			faceHashTab;

		DLLEXPORT					PerFaceModData();
									PerFaceModData(PerFaceModData *perFaceData);
									~PerFaceModData();

		LocalModData				*Clone();

									// add face entry
		DLLEXPORT PerFaceEntry		*AddFace();
									// find face from idents
		DLLEXPORT PerFaceEntry		*FindFace(int v0, int v1, int v2);

									// sequential access
		DLLEXPORT PerFaceEntry		*GetFace(int index = 0);
		DLLEXPORT PerFaceEntry		*GetNextFace(PerFaceEntry *perFace = NULL);

		DLLEXPORT void				SetDataName(TCHAR *string);
		DLLEXPORT TCHAR				*GetDataName();

		void						SetCache(Mesh& mesh);
		void						FreeCache();
		Mesh						*GetMesh()				{ return mesh; }
		AdjEdgeList					*GetAdjEdgeList()		{ return adjEdgeList; }

		void						SetFaceSel(BitArray& set) { faceSel = set; if (mesh) mesh->faceSel = set; }

									// set data format
		DLLEXPORT void				SetDataFormat(CPMLevel *formatInst, BOOL keepData = FALSE, TCHAR *name = NULL);
};



/* --------------------------------------------------------------------------------
   Function : PerFaceData_GetData
   Purpose : get instance of face data for this node
   Parameters : node pointer
   Returns : data instance or NULL
   Info : 
*/

DLLEXPORT PerFaceModData *PerFaceData_GetData(INode *node);


/* --------------------------------------------------------------------------------
   Function : PerFaceData_GetModContext
   Purpose : get instance of modcontext for this node
   Parameters : node pointer
   Returns : modcontext instance or NULL
   Info : 
*/

DLLEXPORT ModContext *PerFaceData_GetModContext(INode *node);


/* --------------------------------------------------------------------------------
   Function : PerFaceData_CreateData
   Purpose : create instance of modifier data
   Parameters : 
   Returns : data instance
   Info : 
*/

DLLEXPORT PerFaceModData *PerFaceData_CreateData();


/* --------------------------------------------------------------------------------
   Function : PerFaceData_CreateModContext
   Purpose : create instance of modifier context
   Parameters : 
   Returns : mod context
   Info : 
*/

DLLEXPORT ModContext *PerFaceData_CreateModContext();


/* --------------------------------------------------------------------------------
   Function : PerFaceData_FormatData
   Purpose : format nodes perfacedata data
   Parameters : node pointer, data format tree (uses ParseMap structure), [data name pointer]
   Returns : 
   Info : 
*/

DLLEXPORT void PerFaceData_FormatData(INode *node, CPMLevel *formatInst, TCHAR *name = NULL);


/* --------------------------------------------------------------------------------
   Function : PerFaceData_MergeInFormatData
   Purpose : merge new format data into existing format data
   Parameters : node pointer, new data format tree (uses ParseMap structure), [data name pointer]
   Returns : 
   Info : 
*/

DLLEXPORT void PerFaceData_MergeInFormatData(INode *node, CPMLevel *newFormatInst, TCHAR *name = NULL);


/* --------------------------------------------------------------------------------
   Function : PerFaceData_WriteFormatData
   Purpose : write format data to a file stream
   Parameters : CPMLevel format instance, format data size, file stream context
   Returns : number of valid format attributes written
   Info : 
*/

DLLEXPORT int PerFaceData_WriteFormatData(CPMLevel *formatInst, int formatSize, FILE *stream);

#endif // __PERFACEDATA__H
