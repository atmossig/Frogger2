

float step_size = 0.1f;
float m[4][4];
float dx,dy,dz;
float ddx,ddy,ddz;
float dddx,dddy,dddz;

void RenderAFD(Vector3d p[4])
{
	v0 = p[0];
	v1 = p[0];

	// call initially and if step size changes
	CreateMatrix()
	// call initially and if step size changes or points have moved
	CreateDerivatives()

	for (float i=step_size; i<(1.0f-step_size);i+= step_size)
	{
		v1.x += dx;
		v1.y += dy;
		v1.z += dz;
		dx += ddx;
		dy += ddy;
		dz += ddz;
		ddx += dddx;
		ddy += dddy;
		ddz += dddz;

		v0..v1

		v0 = v1;
	}
}


void CreateMatrix()
{
	float k = step_size;

	// row0 is identity
	m[0][0] = 1.0f;
	m[0][1] = 0.0f;
	m[0][2] = 0.0f;
	m[0][3] = 0.0f;

	// row1 is 1st derivative
	m[1][0] = -(k*k*k) + (3.0f*k*k) - (3.0f*k);
	m[1][1] = (3.0f*k*k*k) - (6.0f*k*k) + (3.0f*k);
	m[1][2] = -(3.0f*k*k*k) + (3.0f*k*k);
	m[1][3] = (k*k*k);

	// row2 is 2nd derivative
	m[2][0] = -(6.0f*k*k*k) + (6.0f*k*k);
	m[2][1] = (18.0f*k*k*k) - (12.0f*k*k);
	m[2][2] = -(18.0f*k*k*k) + (6.0f*k*k);
	m[2][3] = (6.0f*k*k*k);

	// row3 is 3rd derivative
	m[3][0] = -(6.0f*k*k*k);
	m[3][1] = (18.0f*k*k*k);
	m[3][2] = -(18.0f*k*k*k);
	m[3][3] = (6.0f*k*k*k);
}

void CreateDerivatives()
{
	  // create 1st derivatives
	  dx = m[1][0] * p[0].x + m[1][1] * p[1].x + m[1][2] * p[2].x + m[1][3] * p[3].x;
	  dx = m[1][0] * p[0].y + m[1][1] * p[1].y + m[1][2] * p[2].y + m[1][3] * p[3].y;
	  dx = m[1][0] * p[0].z + m[1][1] * p[1].z + m[1][2] * p[2].z + m[1][3] * p[3].z;
	 // create 2nd derivatives
	 ddx = m[2][0] * p[0].x + m[2][1] * p[1].x + m[2][2] * p[2].x + m[2][3] * p[3].x;
	 ddx = m[2][0] * p[0].y + m[2][1] * p[1].y + m[2][2] * p[2].y + m[2][3] * p[3].y;
	 ddx = m[2][0] * p[0].z + m[2][1] * p[1].z + m[2][2] * p[2].z + m[2][3] * p[3].z;
	// create 3rd derivatives
	dddx = m[3][0] * p[0].x + m[3][1] * p[1].x + m[3][2] * p[2].x + m[3][3] * p[3].x;
	dddx = m[3][0] * p[0].y + m[3][1] * p[1].y + m[3][2] * p[2].y + m[3][3] * p[3].y;
	dddx = m[3][0] * p[0].z + m[3][1] * p[1].z + m[3][2] * p[2].z + m[3][3] * p[3].z;

}