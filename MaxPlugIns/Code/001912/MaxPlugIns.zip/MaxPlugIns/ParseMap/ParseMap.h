// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 2000 Interactive Studios Ltd.
//
//    File : ParseMap.h
// Purpose : map file parser header
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __PARSEMAP__H
#define __PARSEMAP__H


// --------------------
// Constants and macros

// level level modes
#define PMLOAD_FILE		1
#define PMLOAD_MEMORY	2

// map file access modes
#define PMMODE_READ_FILE	1
#define PMMODE_READ_MEMORY	2
#define PMMODE_WRITE		3

// node enumeration returns
#define PMENUM_CONTINUE		0
#define PMENUM_END			1
#define PMENUM_END_PATH		2

// maximum lengths
#define PMMAX_IDENT_LEN		64
#define PMMAX_STRING_LEN	128

// attribute types
enum PMATTRIBS
{
	PMATTRIB_NULL,
	PMATTRIB_STRING,
	PMATTRIB_INT,
	PMATTRIB_FLOAT,
	PMATTRIB_BOOL,
	PMATTRIB_ENUMSTRING,
	PMATTRIB_ENUMINT,
	PMATTRIB_ENUMFLOAT,
	PMATTRIB_DATA,
};


// -----------------
// Types and classes

// enumerate node function callback type
typedef int (TPMEnumNodeFunc)(class CPMNode *node, void *context);

// enumerate node attribute function callback type
typedef int (TPMEnumAttribFunc)(class CPMAttrib *attrib, void *context);

// file buffer structure
typedef struct _TPMFile
{
	_TPMFile()
	{
		buf = NULL;
		fp = NULL;
		mode = 0;
	}
	char	filename[260];
	char	*buf, *sp, *ep;
	int		mode;
	FILE	*fp;
} TPMFile;


// attribute class [linked list]
typedef class CPMAttrib
{
	public:
									// linked list vars
		CPMAttrib					*prev, *next;

									// attribute identifier
		char						ident[PMMAX_IDENT_LEN];

									// attribute type
		int							type;

									// attributes
		union
		{
		char						string[PMMAX_STRING_LEN];				// string
		int							ival;									// integer
		float						fval;									// float
		bool						bval;									// boolean
		int							enoof;									// noof enumerations
		int							datn;									// data size
		};

		union
		{
		char						*estrings;								// enumeration strings
		int							*eivals;								// enumeration ints
		float						*efvals;								// enumeration floats
		void						*datp;									// data pointer
		};

									// constructor / destructor
									CPMAttrib();
									CPMAttrib(CPMAttrib *root);
									~CPMAttrib();

									// find attribute from ident [lowercase comparison]
		CPMAttrib					*Find(char *ident);

									// delete all attributes
		void						DeleteAll();

									// clone attribute
		void						Clone(CPMAttrib *attrib);

} CPMAttrib;


// node class [tree structure]
typedef class CPMNode
{
	public:
									// tree vars
		CPMNode						*parent;
		CPMNode						*prev, *next;
		CPMNode						*children;

									// node identification and unique name
		char						type[PMMAX_IDENT_LEN];

									// this nodes attributes
		CPMAttrib					*attribs;

									CPMNode();
									CPMNode(CPMNode *parentNode);
									~CPMNode();

									// read and create map file using this node as root
		int							Read(TPMFile *file);
									// write map file from this node including all children
		int							Write(TPMFile *file);

									// set node type
		void						SetType(char *type);

									// makes the specified node a child of this node.
		void						AttachChild(CPMNode *child);

									// add attributes to node
		void						AddAttrib(char *ident, char *string);
		void						AddAttrib(char *ident, int ival);
		void						AddAttrib(char *ident, float fval);
		void						AddAttrib(char *ident, bool bval);

									// add attribute enumerations to node
		void						AddAttribEnum(char *ident, char *string);
		void						AddAttribEnum(char *ident, int ival);
		void						AddAttribEnum(char *ident, float fval);

									// add data attribute to node
		int							AddAttribData(char *ident, void *data, int size = 0);

									// get attribute from node
		char						*GetAttrib(char *ident);
		int							GetAttrib(char *ident, int& ival);
		int							GetAttrib(char *ident, float& fval);
		int							GetAttrib(char *ident, bool& bval);

									// get attribute enumeration from node
		char						*GetAttribEnum(char *ident, int ei);
		int							GetAttribEnum(char *ident, int ei, int& ival);
		int							GetAttribEnum(char *ident, int ei, float& fval);

									// get number of enumerations from node
		int							GetAttribEnumNoof(char *ident, int& noof);

									// get data attribute from node
		void						*GetAttribData(char *ident, int *size = NULL);

									// get attribute type
		int							GetAttribType(char *ident);

									// find attribute
		CPMAttrib					*FindAttrib(char *ident);

									// find index of enumeration string
		int							FindAttribEnum(char *ident, char *string);

									// delete attribute
		int							DelAttrib(char *ident);

									// enumerate this nodes attributes with context callback function
		int							EnumAttribs(TPMEnumAttribFunc *funcPtr, void *context = NULL);

									// enumerate nodes with context callback functions
		int							EnumNodes(TPMEnumNodeFunc *preFuncPtr, void *preContext, TPMEnumNodeFunc *postFuncPtr, void *postContext, char *type = NULL);
		int							EnumNodes(TPMEnumNodeFunc *funcPtr, void *context = NULL, char *type = NULL);

									// clone node
		void						Clone(CPMNode *node);

} CPMNode;


// level
typedef class CPMLevel
{
	public:
		CPMNode						*root;

									CPMLevel();
									~CPMLevel();

		void						Read(TPMFile *stream);
		void						Write(TPMFile *stream);

									// enumerate nodes with context callback functions
		int							EnumNodes(TPMEnumNodeFunc *preFuncPtr, void *preContext, TPMEnumNodeFunc *postFuncPtr, void *postContext, char *type = NULL);
		int							EnumNodes(TPMEnumNodeFunc *funcPtr, void *context = NULL, char *type = NULL);

									// clone level
		void						Clone(CPMLevel *level);

} CPMLevel;


/* --------------------------------------------------------------------------------
   Function : pmLoadLevel
   Purpose : load in level objects
   Parameters : filename or file memory stream pointer,
				file input type [PMLOAD_FILE, PMLOAD_MEMORY]. default = file,
				file length if loadType == PMLOAD_MEMORY. default = 0
   Returns : instance of level class or NULL if failed
   Info : 
*/

CPMLevel *pmLoadLevel(char *fileIn, int loadType = PMLOAD_FILE, int fileLen = 0);


/* --------------------------------------------------------------------------------
   Function : pmDeleteLevel
   Purpose : delete previously loaded level
   Parameters : level class pointer, (from pmLoadLevel function)
   Returns : 
   Info : 
*/

void pmDeleteLevel(CPMLevel *level);


/* --------------------------------------------------------------------------------
   Function : pmCloneLevel
   Purpose : clone a new instance of this level
   Parameters : level class pointer
   Returns : pointer to cloned level instance
   Info : 
*/

CPMLevel *pmCloneLevel(CPMLevel *level);


/* --------------------------------------------------------------------------------
   Function : pmOpenFile
   Purpose : open level file into file struct
   Parameters : filename or file memory stream pointer,
				mode [PMMODE_READ_FILE = read file, PMMODE_READ_MEMORY = read memory, PMMODE_WRITE = write],
				file length if mode == PMMODE_READ_MEMORY. default = 0
   Returns : file struct pointer, or NULL if fail
   Info : 
*/

TPMFile	*pmOpenFile(char *fileIn, int mode = PMMODE_READ_FILE, int fileLen = 0);


/* --------------------------------------------------------------------------------
   Function : pmCloseFile
   Purpose : close previously open file structure
   Parameters : file struct pointer [returned from pmOpenFile]
   Returns : 
   Info : 
*/

void pmCloseFile(TPMFile *file);

#endif