//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by pivot.rc
//
#define IDS_CLASS_NAME                  1
#define IDS_CATEGORY                    2
#define IDS_LIBDESCRIPTION              3
#define IDD_DIALOG1                     101
#define IDD_MAIN                        101
#define IDB_LOGO_IMAGE                  107
#define IDB_LOGO_MASK                   108
#define IDC_MAIN_RESET_PIVOT            1000
#define IDC_MAIN_STATIC_TRANSFORM       1001
#define IDC_MAIN_STATIC_TRANSFORM_X     1002
#define IDC_MAIN_STATIC_SCALE           1003
#define IDC_MAIN_STATIC_SCALE_X         1004
#define IDC_MAIN_TRANSFORM_X            1005
#define IDC_MAIN_STATIC_TRANSFORM_Y     1006
#define IDC_MAIN_TRANSFORM_Y            1007
#define IDC_MAIN_STATIC_TRANSFORM_Z     1008
#define IDC_MAIN_TRANSFORM_Z            1009
#define IDC_MAIN_SCALE_X                1010
#define IDC_MAIN_STATIC_SCALE_Y         1011
#define IDC_MAIN_SCALE_Y                1012
#define IDC_MAIN_STATIC_SCALE_Z         1013
#define IDC_MAIN_SCALE_Z                1014
#define IDC_MAIN_STATIC_ROTATE          1015
#define IDC_MAIN_STATIC_ROTATE_X        1016
#define IDC_MAIN_ROTATE_X               1017
#define IDC_MAIN_STATIC_ROTATE_Y        1018
#define IDC_MAIN_ROTATE_Y               1019
#define IDC_MAIN_STATIC_ROTATE_Z        1020
#define IDC_MAIN_ROTATE_Z               1021
#define IDC_MAIN_IMAGE                  1022
#define IDC_MAIN_ROTATE_RETAIN          1023
#define IDC_MAIN_SCALE_RETAIN           1024
#define IDC_MAIN_TRANSFORM_RETAIN       1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
