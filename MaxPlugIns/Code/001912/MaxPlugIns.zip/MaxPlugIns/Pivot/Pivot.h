/**********************************************************************
 *<
	FILE: pivot.h

	DESCRIPTION:	Template Utility

	CREATED BY:

	HISTORY:

 *>	Copyright (c) 1997, All Rights Reserved.
 **********************************************************************/

#ifndef __PIVOT__H
#define __PIVOT__H

#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#if MAX_RELEASE >= 3000
#include "iparamb2.h"
#include "iparamm2.h"
#else
#include "iparamb.h"
#include "iparamm.h"
#endif

#include "utilapi.h"

#include "CommonFiles.h"

#define PIVOT_CLASS_ID	Class_ID(0x5b1cda0d, 0x40399208)

#endif // __PIVOT__H
