
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : obeexp.cpp
// Purpose : implementation of OBEExport class
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include <time.h>

#include "OBEExport.h"

#include "MAXSkin.h"
#include "InvKin.h"
#include "NoteTrck.h"

#include "PlaceEditor.h"


// --------------------
// Constants and macros

// un-comment to include my experimental code
//#define EXPORT_PATCHES

// comment out to stop ANIM_NOTES chunks being exported. Should only do this when Gizmo understands what NODE_ANIM_COMMANDS are
#define USE_OLD_ANIM_NOTES


#define EXPORT_CONFIG_FILE		"OBEExport.cfg"
#define EXPORT_CONFIG_VERSION	1

// macro helper to determine if a texture name is valid
#define ISTEXTURENAMEVALID(_namePtr_)		(_namePtr_ == NULL || HIWORD(((DWORD)_namePtr_)) == 0) ? 0 : 1

// OBE PerFaceData Names
#define OBEDATANAME1	_T("OBE Data")
#define OBEDATANAME2	_T("JobeData")

// node types
#define NTYPE_NULL			0
#define NTYPE_MESH			1
#define NTYPE_BONE_HARD		2
#define NTYPE_BONE_SOFT		3


// ------------------
// Function templates

// dialog box procedures
static BOOL CALLBACK configDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam);
static BOOL CALLBACK duplicateTexturesDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam);

// node enumeration callback. collate all skin mesh nodes from the scene
static int collateAllSkinNodes(INode *node, void *context);

// node enumeration callback.
static int preWriteNode(INode *node, void *context);
// node enumeration callback.
static int postWriteNode(INode *node, void *context);

// write animation segment chunk enum callback
static int writeChunk_AnimSegments(INode *node, void *context);

// write note chunk enum callback
static int writeChunk_AnimNotes(INode *node, void *context);
static void loadLine(TCHAR *cp, TCHAR *ep, TCHAR *lbuf);
static char *nextLine(TCHAR *cp, TCHAR *ep);
static void loadCommand(TCHAR *lbuf, TCHAR *comp, TCHAR *argp);

// hard skin functions
static int HardSkin_IsNode(INode *node);
static SkinData *HardSkin_GetData(INode *node);
static INode *HardSkin_FindRootBone(INode *node, Interface *ip);
static int HardSkin_IsBone(OBEExport *exportInst, INode *node);


// -----------------
// Types and classes

// world chunk enum callback struct
typedef struct _TEnumWorld
{
	OBEExport	*exportInst;
	INodeTab	*nodeTabPtr;
} TEnumWorld;

// hijack this useful structure
#define TEnumNodeTab	TEnumWorld

// enumeration stack info stack
typedef struct _TEnumExportInfo
{
	class OBEExport		*exportInst;
	INodeTab			*excludeNodeTab;
	Stack<int>			*stackNodeType;
} TEnumExportInfo;


/* --------------------------------------------------------------------------------
   Function : OBEExport::OBEExport
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

OBEExport::OBEExport()
{
	fileHandle = NULL;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::OBEExport
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

OBEExport::~OBEExport()
{
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::DoExport
   Purpose : perform the actual OBE file export
   Parameters : import obe file, import interface pointer, max interface pointer, suppress user prompts
   Returns : 
   Info : 
*/

// count all scene nodes enum callback
static int countSceneNodes(INode *nodePtr, void *context)	{((int *)context)[0]++; return NENUM_CONTINUE;}

int OBEExport::DoExport(const TCHAR *fileNamePtr, ExpInterface *exportPtr, Interface *ip, BOOL suppressPrompts
#if MAX_RELEASE >= 3000
, unsigned long options
#endif
)
{
	int						nodeNum;
	PlaceEditor				*editorInst;
	tm						*newtime;
	time_t					aclock;

	// get local time
	time(&aclock);
	newtime = localtime( &aclock );

	DPrintf("");
	DPrintf("===========================================================================");
	DPrintf("OBEFile Exporter Plugin Debug Output Log");
	DPrintf("Filename: %s", fileNamePtr);
	DPrintf("%s", asctime(newtime));

	// save max and export interfaces
	this->ip = ip;
	this->exportPtr = exportPtr;

	// save the export filename
	_tcscpy(exportFileName, fileNamePtr);
	_tcslwr(exportFileName);

	// count all scene nodes
	nodeNum = -1;
	EnumNodes(ip->GetRootNode(), ::countSceneNodes, &nodeNum);
	if (nodeNum <= 0)
	{
		DPrintf("Nothing to export. Aborting");
		return 1;
	}

	// init our CRC table
	InitCRCTable();

#ifdef EXPORT_PATCHES
	ExportPatches();
	return 1;
#endif

	// ** User Configuration

	// read and set the users last configuration
	ReadConfig();

	// allow user to edit current configuration
	if (suppressPrompts == FALSE &&
		DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_CONFIG_EXPORT), ip->GetMAXHWnd(), (DLGPROC)configDialogProc, (LPARAM)this) != 1)
	{
		// user wants to abort the export
		DPrintf("User aborted export");
		return 1;
	}

	// show export configurations
	DPrintf("Export config:");
	if (configExportAnimation)
		DPrintf("  Export animation");
	if (configExportPerFaceData)
		DPrintf("  Export \"PerFaceData\" modifier data and format. (obe data)");
	if (configCopyUsedTextures)
		DPrintf("  Copy all used textures to directory %s", configCopyUsedTexturePath);
	if (configEvalKeysToLinear && configExportAnimation)
		DPrintf("  Evaluate all keyframes as linear");

	// writing updated user configuration file
	WriteConfig();


	// ** Do The Export

	// regular export or as a Placement Editor scene?
	if (GET_MAX_RELEASE(Get3DSMAXVersion()) >= 3000 && PlaceEditor_IsSceneValid(ip) == 1)
	{
		// ** Placement Editor Export

		DPrintf("\nPlacement Editor Export");

		editorInst = new PlaceEditor(this);
		editorInst->Init();
		if (editorInst->DoExport(fileNamePtr) == 0)
			DPrintf("Error with Placement Editor Scene");
		editorInst->Shutdown();
		SAFE_DELETE(editorInst)
	}
	else
	{
		// ** Regular OBE Export

		DPrintf("\nRegular OBE Export");

		// export our obe file using scene root for root node
		if (DoExportRoot(fileNamePtr, ip->GetRootNode()) == 0)
			return 0;
	}

	// successfully exported obe file
	DPrintf("\nExport finished");

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::ExportOBEFile
   Purpose : export OBE file from given root node
   Parameters : OBE filename, root node, [node exclusion table = NULL]
   Returns : 0 - error, 1 - success
   Info : 
*/

int OBEExport::DoExportRoot(const TCHAR *fileNamePtr, INode *root, INodeTab *excludeNodeTab)
{
	int						i, objectPos;
	INodeTab				skinNodeTab;
	TEnumExportInfo			exportInfo;
	Stack<int>				stackNodeType;


	DPrintf("\nOBEFile '%s'", fileNamePtr);

	// clear export vars
	objectRootNode = NULL;							// clear object root node
	hardSkinDataValid = 0;							// clear hard skin data
	hardSkinData = NULL;
	hardSkinMeshNode = NULL;
	softSkinMeshNode = NULL;						// clear soft skin data
	usedTextures.ZeroCount();						// zero all used texture maps
	maxPolyOrder.ZeroCount();						// zero max mesh polygon order

	// open our export file
	fileHandle = fopen(fileNamePtr, "wb");
	if (fileHandle == NULL)
	{
		DPrintf("Cannot create export file. Aborting");
		return 0;
	}

	// write file ident
	fputc('O', fileHandle); fputc('B', fileHandle); fputc('E', fileHandle); fputc(0, fileHandle);

	// write the start of the object chunk
	objectPos = BeginWriteChunk(OBECHUNK_OBJECT, OBJECT_VER);

	// write all animation chunks
	WriteChunk_AnimTime();
	EnumNodes(root, ::writeChunk_AnimSegments, this);
#ifdef USE_OLD_ANIM_NOTES
	EnumNodes(root, ::writeChunk_AnimNotes, this);
#endif

	// enumerate all scene skin mesh nodes
	EnumNodes(root, collateAllSkinNodes, &skinNodeTab);

	// clear node type stack
	stackNodeType.Clear();

	// clear class export info stacks
	stackFilePos.Clear();
	stackObe.Clear();

	// set export information struct
	exportInfo.exportInst = this;									// access export class
	exportInfo.excludeNodeTab = NULL;								// no node exlusions
	exportInfo.stackNodeType = &stackNodeType;						// set node type stack

	// assume root is a mesh node hierarchy, so set as object root
	objectRootNode = root;

	// export skin node chunks
	for (i=0; i<skinNodeTab.Count(); i++)
	{
		// validate skin data types
		if (MaxSkin_IsNode(skinNodeTab[i]) == 1)
		{
			softSkinMeshNode = skinNodeTab[i];
			objectRootNode = MaxSkin_FindRootBone(skinNodeTab[i], ip);
		}
		else if (HardSkin_IsNode(skinNodeTab[i]) == 1)
		{
			hardSkinMeshNode = skinNodeTab[i];
			hardSkinData = HardSkin_GetData(hardSkinMeshNode);
			hardSkinDataValid = (hardSkinData->GetBones() && hardSkinData->GetAssigns()) ? 1:0;
			objectRootNode = HardSkin_FindRootBone(skinNodeTab[i], ip);
		}

		// write skin mesh chunk
		EnumNodes(skinNodeTab[i], ::preWriteNode, &exportInfo, ::postWriteNode, &exportInfo);
	}


	// ** Write All Other Scene Nodes

	// append all function exclusion nodes onto skin mesh nodes
	if (excludeNodeTab != NULL)
		for (i=0; i<excludeNodeTab->Count(); i++)
		{
			skinNodeTab.Append(1, excludeNodeTab->Addr(i));
		}

	// set exclusion nodes to function exclusions node plus skin mesh nodes
	exportInfo.excludeNodeTab = &skinNodeTab;

	// write all other recognised node chunks to our obe file
	if (objectRootNode != NULL)
		EnumNodes(objectRootNode, ::preWriteNode, &exportInfo, ::postWriteNode, &exportInfo);

	// terminate the obe object chunk
	EndWriteChunk(objectPos);

	// terminate the obe file
	EndWriteChunk(BeginWriteChunk(OBECHUNK_END, END_VER));

	// close file
	fclose(fileHandle);
	fileHandle = NULL;

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : collateAllSkinNodes
   Purpose : node enumeration callback. collate all skin mesh nodes from the scene
   Parameters : node pointer, INodeTab pointer
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateAllSkinNodes(INode *node, void *context)
{
	INodeTab	*nodeTabPtr;

	if (node == NULL)
		return NENUM_END;

	if (HardSkin_IsNode(node) == 1 || MaxSkin_IsNode(node) == 1)
	{
		nodeTabPtr = (INodeTab *)context;
		nodeTabPtr->Append(1, &node);
	}
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::preWriteNode
   Purpose : node enumeration callback.
   Parameters : node pointer, TEnumExportInfo pointer
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int preWriteNode(INode *node, void *context)
{
	TEnumExportInfo		*exportInfo;
	int					i, type;
	ObjectState			objstate;


	exportInfo = (TEnumExportInfo *)context;

	// default: node unknown type
	type = NTYPE_NULL;

	// do we need to exclude any nodes?
	if (exportInfo->excludeNodeTab != NULL)
	{
		for (i=0; i<exportInfo->excludeNodeTab->Count(); i++)
			if (node == *(exportInfo->excludeNodeTab->Addr(i)))
			{
				// ** If our export node is in the node exclusion list then we should terminate
				// ** this current enum search path.

				// terminate this enum path
				return NENUM_ENDPATH;
			}
	}

	TCHAR *name = node->GetName();

	// determine if this node can actually be exported?
	objstate = node->EvalWorldState(0);
	if ((objstate.obj == NULL) ||
		(!((objstate.obj->SuperClassID() == GEOMOBJECT_CLASS_ID && objstate.obj->ClassID() != Class_ID(TARGET_CLASS_ID, 0)) || exportInfo->exportInst->IsNodeBone(node) == 1)))
	{
		exportInfo->stackNodeType->Push(&type);
		return NENUM_CONTINUE;
	}

	// determine our node type?
	type = NTYPE_MESH;										// now default node type to mesh
	if (exportInfo->exportInst->IsNodeBone(node))
	{
		if (MaxSkin_IsBone(exportInfo->exportInst->ip, node))
			type = NTYPE_BONE_SOFT;
		else if (HardSkin_IsBone(exportInfo->exportInst, node))
			type = NTYPE_BONE_HARD;
		else
		{
			// ** This bone is certainly unknown by the hard skin system, but it could be
			// ** a "terminator" node from the soft skin system. If it is we should ignore
			// ** the bone otherwise we should export in as a null mesh.

			// if there is a soft skin in the scene and this bone's parent is a soft skin node..
			if (exportInfo->exportInst->softSkinMeshNode != NULL &&
				MaxSkin_IsBone(exportInfo->exportInst->ip, node->GetParentNode()) == 1)
			{
				// then it is probably a soft skin terminator node
				DPrintf("Bone '%s' soft bone terminator", node->GetName());
				type = NTYPE_NULL;
			}

			// ** Otherwise export bone as a NULL mesh
		}
	}

	// register node type
	exportInfo->stackNodeType->Push(&type);
	switch (type)
	{
		case NTYPE_NULL:
			break;
		case NTYPE_MESH:
			exportInfo->exportInst->preWriteChunk_Mesh(node);
			break;
		case NTYPE_BONE_HARD:
			exportInfo->exportInst->preWriteChunk_HardBone(node);
			break;
		case NTYPE_BONE_SOFT:
			exportInfo->exportInst->preWriteChunk_SoftBone(node);
			break;
	}
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : postWriteNode
   Purpose : node enumeration callback. 
   Parameters : node pointer, TEnumExportInfo pointer
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int postWriteNode(INode *node, void *context)
{
	TEnumExportInfo		*exportInfo;
	int					type;

	TCHAR *name = node->GetName();

	exportInfo = (TEnumExportInfo *)context;

	exportInfo->stackNodeType->Pop(&type);
	switch (type)
	{
		case NTYPE_NULL:
			break;
		case NTYPE_MESH:
			exportInfo->exportInst->postWriteChunk_Mesh(node);
			break;
		case NTYPE_BONE_HARD:
			exportInfo->exportInst->postWriteChunk_HardBone(node);
			break;
		case NTYPE_BONE_SOFT:
			exportInfo->exportInst->postWriteChunk_SoftBone(node);
			break;
	}
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::preWriteChunk_Mesh
   Purpose : pre-node write mesh chunk
   Parameters : node, soft skin mesh flag
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::preWriteChunk_Mesh(INode *node)
{
	int			ret, pos;
	ObeMesh		*mesh;

	// write open mesh chunk
	pos = BeginWriteChunk(OBECHUNK_MESH, MESH_VER);
	stackFilePos.Push(&pos);

	// convert max node to obe mesh
	ret = NodeToObeMesh(node, mesh = new ObeMesh);
	// write obe mesh and "PerFaceData" format and data
	if (ret)
	{
		if (MaxSkin_IsNode(node) == 1)
		{
			// ** We have to make sure that the obe skin mesh contains NO keyed animation data
			// ** apart from on the zero reference frame. The reference frame should contain
			// ** the transform space the skin modifier is applied in.
			// ** Note: usually the skin space is equal to the skins transform at frame zero!!

			TIME_VALUE_KEY	timeKey;
			Point3			rp, rs;
			Quat			rr;

			// decompose the skin node zero frame transform into skin space prs
			DecomposeMatrix(node->GetNodeTM(0), rp,rr,rs);

			// frame zero is the reference frame
			timeKey.frameNum = 0;

			// position
			mesh->posX.SetNumKeys(1);
			mesh->posY.SetNumKeys(1);
			mesh->posZ.SetNumKeys(1);

			timeKey.data = rp.x;
			mesh->posX.SetKey(0, &timeKey);
			timeKey.data = rp.z;
			mesh->posY.SetKey(0, &timeKey);
			timeKey.data = rp.y;
			mesh->posZ.SetKey(0, &timeKey);

			// rotation
			mesh->orientationX.SetNumKeys(1);
			mesh->orientationY.SetNumKeys(1);
			mesh->orientationZ.SetNumKeys(1);
			mesh->orientationW.SetNumKeys(1);

			timeKey.data = rr.x;
			mesh->orientationX.SetKey(0, &timeKey);
			timeKey.data = rr.z;
			mesh->orientationY.SetKey(0, &timeKey);
			timeKey.data = rr.y;
			mesh->orientationZ.SetKey(0, &timeKey);
			timeKey.data = -rr.w;
			mesh->orientationW.SetKey(0, &timeKey);

			// scale
			mesh->scaleX.SetNumKeys(1);
			mesh->scaleY.SetNumKeys(1);
			mesh->scaleZ.SetNumKeys(1);

			timeKey.data = rs.x;
			mesh->scaleX.SetKey(0, &timeKey);
			timeKey.data = rs.z;
			mesh->scaleY.SetKey(0, &timeKey);
			timeKey.data = rs.y;
			mesh->scaleZ.SetKey(0, &timeKey);
		}

		mesh->Write(fileHandle);

		DPrintf("Mesh '%s' wrote %d polygons, %d vertices", node->GetName(), mesh->numPoly, mesh->numVert);

		if (configExportPerFaceData)
			WriteChunk_PerFaceData(node);

		WriteChunk_NodeAnimCommands(node);
	}

	// push our obe mesh as we need later
	stackObe.Push((void **)&mesh);

	return ret;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::postWriteChunk_Mesh
   Purpose : post-node write mesh chunk
   Parameters : node
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::postWriteChunk_Mesh(INode *node)
{
	ObeMesh		*mesh;
	int			pos;

	// terminate this mesh path
	EndWriteChunk(BeginWriteChunk(OBECHUNK_END, END_VER));

	// write this meshes additional polygon data
	stackObe.Pop((void **)&mesh);
	WriteExtraMeshData(mesh);

	// now we can safely delete our mesh
	SAFE_DELETE(mesh);

	// finally fix up our meshes chunk
	stackFilePos.Pop(&pos);
	EndWriteChunk(pos);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::preWriteChunk_Mesh
   Purpose : pre-node write soft bone chunk
   Parameters : node
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::preWriteChunk_SoftBone(INode *node)
{
	int			ret, pos;
	ObeMaxBone	*obeBone;


	// write open soft bone chunk
	pos = BeginWriteChunk(OBECHUNK_BONE_SOFT, BONE_SOFT_VER);
	stackFilePos.Push(&pos);

	// convert max node to obe soft bone
	ret = NodeToObeMaxBone(node, obeBone = new ObeMaxBone);
	// write obe soft bone
	if (ret)
	{
		obeBone->Write(fileHandle);
		DPrintf("Bone '%s' wrote %d soft vertex assignments", node->GetName(), obeBone->noofAssigns);

		WriteChunk_NodeAnimCommands(node);
	}

	// push our obe soft bone as we may need it later
	stackObe.Push((void **)&obeBone);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::postWriteChunk_Mesh
   Purpose : post-node write soft bone chunk
   Parameters : node
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::postWriteChunk_SoftBone(INode *node)
{
	ObeMaxBone	*obeBone;
	int			pos;

	// terminate this bone path
	EndWriteChunk(BeginWriteChunk(OBECHUNK_END, END_VER));

	// now we can safely delete our soft bone
	stackObe.Pop((void **)&obeBone);
	SAFE_DELETE(obeBone);

	// finally fix up our soft bone chunk
	stackFilePos.Pop(&pos);
	EndWriteChunk(pos);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::preWriteChunk_Mesh
   Purpose : pre-node write soft bone chunk
   Parameters : node
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::preWriteChunk_HardBone(INode *node)
{
	int			ret, pos;
	ObeBone		*obeBone;

	// write open mesh chunk
	pos = BeginWriteChunk(OBECHUNK_BONE_HARD, BONE_HARD_VER);
	stackFilePos.Push(&pos);

	// convert max node to obe hard bone
	ret = NodeToObeBone(node, obeBone = new ObeBone);
	// write obe hard bone
	if (ret)
	{
		obeBone->Write(fileHandle);
		DPrintf("Bone '%s' wrote %d hard vertex assignments", node->GetName(), obeBone->numVertAssigns);

		WriteChunk_NodeAnimCommands(node);
	}

	// push our obe hard mesh as we may need it later
	stackObe.Push((void **)&obeBone);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::preWriteChunk_Mesh
   Purpose : post-node write soft bone chunk
   Parameters : node
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::postWriteChunk_HardBone(INode *node)
{
	ObeBone		*obeBone;
	int			pos;

	// terminate this hard bone path
	EndWriteChunk(BeginWriteChunk(OBECHUNK_END, END_VER));

	// now we can safely delete our hard bone
	stackObe.Pop((void **)&obeBone);
	SAFE_DELETE(obeBone);

	// finally fix up our hard bones chunk
	stackFilePos.Pop(&pos);
	EndWriteChunk(pos);

	return 1;
}


// --------------------------------------------------------------------------------
// INode To OBE Type Convertors
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : OBEExport::NodeToObeMesh
   Purpose : convert a MAX node class into an OBE Mesh class
   Parameters : node, OBE mesh, soft skin flag
   Returns : 1 - okay, 0 - error
   Info : 
*/

int OBEExport::NodeToObeMesh(INode *node, ObeMesh *obeMesh)
{
	static TCHAR	texPath[_MAX_PATH], texName[_MAX_FNAME], texExt[_MAX_EXT];
	Mesh			*maxMesh;
	int				deleteMesh, noof, i,j, index;
	Matrix3			mat;
	Point3			pos, scale;
	Quat			rot;
	PerFaceModData	*perFaceData;
	MultiMtl		*multiMtl;
	Mtl				*polyMtl;
	PolyType		*polygon;
	TVFace			*mapFace;
	PerFaceEntry	*perFace;
	TPolygonData	*polygonData;
	SpriteInfo		*spriteData;
	TIME_VALUE_KEY	timeKey;
	BitmapTex		*polyMap;
	TCHAR			*mapName;
	Color			matColour;
	TTexturePath	texturePath;
	TVFace			*vsFace;
	float			u,v;
	UFLOAT			ufloat;
	BOOL			pkflag;
	UINT			ut, vt, pv, id;

	
	// either get the MAX mesh from the inode or create a proxy mesh
	deleteMesh = 0;
	if ((maxMesh = GetNodeMesh(node)) == NULL)
	{
		maxMesh = new Mesh;
		deleteMesh = 1;
	}

	// set mesh name from the Max node name
	strncpy(obeMesh->meshName, (char *)node->GetName(), sizeof(obeMesh->meshName));
	obeMesh->meshName[sizeof(obeMesh->meshName)-1] = 0;


	// ** Export Vertices

	// vertices
	noof = maxMesh->getNumVerts();
	obeMesh->SetNumVerts(noof);

	// ** As the OBE format hasn't got any concept of the Object-Offset (Pivot) transform
	// ** which MAX uses, we have to remove this transform directly from the vertices
	// ** themselves before exporting.

	// construct the object-offfset (pivot) transformation matrix
	mat.IdentityMatrix();
	mat.PreTranslate(node->GetObjOffsetPos());
	PreRotateMatrix(mat, node->GetObjOffsetRot());
	ApplyScaling(mat, node->GetObjOffsetScale());

	// ** If we are exporting a soft skinned mesh, we need to make sure that the skin mesh
	// ** is at the origin of its root bone

	if (MaxSkin_IsNode(node) == 1 && objectRootNode != NULL)
		mat = mat * Inverse(objectRootNode->GetNodeTM(TimeValue(0)));

	// build all vertices
	for (i=0; i<noof; i++)
	{
		pos = mat * maxMesh->getVert(i);
		obeMesh->SetVert(i, pos.x, pos.z, pos.y);
	}


	// ** Export Polygons (Faces)

	// get possible instance of Obe "PerFaceData" from this max node
	perFaceData = PerFaceData_GetData(node);
	if (perFaceData != NULL && _tcsicmp(perFaceData->GetDataName(), OBEDATANAME1) != 0 && _tcsicmp(perFaceData->GetDataName(), OBEDATANAME2) != 0)
	{
		// unknown data instance
		perFaceData = NULL;
	}

	// get this nodes material assignment. Only multi-material recognised
	multiMtl = (MultiMtl *)node->GetMtl();
	if (multiMtl && multiMtl->ClassID() != Class_ID(MULTI_CLASS_ID, 0))
		multiMtl = NULL;

	// polygons
	noof = maxMesh->getNumFaces();
	obeMesh->SetNumPolys(noof);

	// build all polygons
	for (i=0; i<noof; i++)
	{
		polygon = &obeMesh->polyArray[i];

		// ** Though polygon sprites don't contain vertices they are still allocated in
		// ** the OBE mesh for simplicity and consistency. The vertices are simply ignored
		// ** at write time.

		// make triangle face
		polygon->SetNumVerts(3);
		polygon->verts[0].vertIndex = (short)maxMesh->faces[i].v[0];
		polygon->verts[1].vertIndex = (short)maxMesh->faces[i].v[1];
		polygon->verts[2].vertIndex = (short)maxMesh->faces[i].v[2];

		// find OBE face data from the "PerFaceData"
#if PERFACEDATA_MAPPING_CHANNEL == 1
		mapFace = maxMesh->tvFace;
#else
		mapFace = maxMesh->mapFaces(PERFACEDATA_MAPPING_CHANNEL);
#endif
		perFace = (perFaceData != NULL && mapFace != NULL) ? perFaceData->FindFace(mapFace[i].t[0], mapFace[i].t[1], mapFace[i].t[2]) : NULL;
		polygonData = (perFace != NULL) ? (TPolygonData *)perFace->GetData() : NULL;
		if (polygonData)
		{
			// restore common OBE polygon attributes
			polygon->colRGB[0] = polygonData->polyRGB[0];			// save colour
			polygon->colRGB[1] = polygonData->polyRGB[1];
			polygon->colRGB[2] = polygonData->polyRGB[2];
			polygon->transMode = polygonData->transMode;			// save transluceny
			polygon->transVal = polygonData->transValue;
			polygon->gColMode = polygonData->gourMode;				// save gouraud mode
			polygon->tileU = polygonData->uTile;					// save UV tiling info
			polygon->tileV = polygonData->vTile;
			polygon->flags = polygonData->flags;					// save flags

			// restore additional OBE data
			polygon->NDOFlag = polygonData->NDOFlag;				// nintendo data object flag
			polygon->terFlag = polygonData->terFlag;				// terrain flag
			memcpy(polygon->dualTexture, polygonData->dualTexture, sizeof(polygon->dualTexture));	// dual texture name

			// restore specific OBE data
			if (polygonData->flags & OBEPOLYFLAG_SPRITE)
			{
				// restore OBE sprite attributes
				spriteData = new SpriteInfo();

				timeKey.frameNum = 0;								// no sprite animation
				timeKey.data = polygonData->sprxPos;				// xpos
				spriteData->xPos.SetNumKeys(1);
				spriteData->xPos.SetKey(0, &timeKey);
				timeKey.data = polygonData->spryPos;				// ypos
				spriteData->yPos.SetNumKeys(1);
				spriteData->yPos.SetKey(0, &timeKey);
				timeKey.data = polygonData->sprzPos;				// zpos
				spriteData->zPos.SetNumKeys(1);
				spriteData->zPos.SetKey(0, &timeKey);
				timeKey.data = polygonData->sprxSize;				// xsize
				spriteData->xSize.SetNumKeys(1);
				spriteData->xSize.SetKey(0, &timeKey);
				timeKey.data = polygonData->sprySize;				// ysize
				spriteData->ySize.SetNumKeys(1);
				spriteData->ySize.SetKey(0, &timeKey);

				spriteData->xFlipped = polygonData->sprxFlipped;	// flipped
				spriteData->yFlipped = polygonData->spryFlipped;

				SAFE_DELETE(polygon->spriteInfoPtr);
				polygon->spriteInfoPtr = spriteData;
			}
			else
				// restore OBE polygon vertices attributes
				for (j=0; j<3; j++)
				{
					polygon->verts[j].gCol[0] = polygonData->vertRGBA[j][0];		// gouraud vertex
					polygon->verts[j].gCol[1] = polygonData->vertRGBA[j][1];
					polygon->verts[j].gCol[2] = polygonData->vertRGBA[j][2];
					polygon->verts[j].gCol[3] = polygonData->vertRGBA[j][3];
					polygon->verts[j].lightIntensity = polygonData->vertLights[j];	// lighting intensity vertex
				}
		}

		// save texture map from Max
		if (multiMtl)
		{
			// determine which sub material this face uses;
			index = maxMesh->faces[i].flags >> FACE_MATID_SHIFT;
			index = index % multiMtl->NumSubMtls();
			polyMtl = multiMtl->GetSubMtl(index);

			// diffuse texture map is ours!!
			polyMap = (BitmapTex *)polyMtl->GetSubTexmap(ID_DI);
			if (polyMap)
			{
				mapName = polyMap->GetMapName();
				if (ISTEXTURENAMEVALID(mapName))
				{
					// do we need to log this used texture map for export?
					if (configCopyUsedTextures)
					{
						// has this texture map already been logged?
						int found = 0;
						for (j=0; j < usedTextures.Count(); j++)
							if (_tcsicmp(usedTextures[j].path, mapName) == NULL)
							{
								found = 1;
								break;
							}
						if (found == 0)
						{
							// log this texture map name
							texturePath.flags = 0;
							_tcscpy(texturePath.path, mapName);
							usedTextures.Append(1, &texturePath);
						}
					}

					// set OBE texture map name
					_tcscpy(texPath, mapName);
					_tsplitpath(texPath, NULL, NULL, texName, texExt);
					_tcscat(texName, texExt);
					_stprintf(polygon->texture, texName);
				}
			}
			else
			{
				// ** No texture map exists for this polygon. Therefore we can assume that the user
				// ** has set a material colour for this polygons colour.

				// if material colour available and no OBE data available.. grab diffuse colour for polygon colour
				if (polyMtl != NULL && polygonData == NULL)
				{
					matColour = polyMtl->GetDiffuse();
					polygon->colRGB[0] = (UCHAR) ((float)matColour.r * 255.0f);
					polygon->colRGB[1] = (UCHAR) ((float)matColour.g * 255.0f);
					polygon->colRGB[2] = (UCHAR) ((float)matColour.b * 255.0f);
				}
			}
		}

		// save texture map UVs from Max mesh
		if (maxMesh->tvFace && maxMesh->tVerts)
		{
			vsFace = &maxMesh->tvFace[i];
			for (j=0; j<3; j++)
			{
				if (vsFace && vsFace->t[j] < (DWORD)maxMesh->getNumTVerts())
				{
					// ** When UVs are imported from OBE files the UV tile information, version number
					// ** and ident are packed into the free W(z) float value. The ident value of 255
					// ** in the MSB of the float forces the float out of range for any possibility of
					// ** a potential valid UV value.

					// ** Version 1 & 2 supported

					// unpack UVTile, version number and ident from W(z) value
					ufloat.f = maxMesh->tVerts[vsFace->t[j]].z;
					ut = (ufloat.f32>>(0+0)) & 511;					// u tile / 100
					vt = (ufloat.f32>>(9+0)) & 511;					// v tile / 100
					pv = (ufloat.f32>>(9+9)) & 63;					// pack version
					id = (ufloat.f32>>(6+18)) & 255;				// ident

					pkflag = FALSE;

					// is this our indent?
					if (id == 255)
					{
						switch (pv)
						{
						// version 1 & 2
						case 1:
						case 2:
							polygon->tileU = (int)ut * 100;
							polygon->tileV = (int)vt * 100;
							polygon->verts[j].u = maxMesh->tVerts[vsFace->t[j]].x;
							polygon->verts[j].v = 1.0f - maxMesh->tVerts[vsFace->t[j]].y;

							pkflag = TRUE;
							break;
						}
					}
					// have we already dealt with the UV pair?
					if (pkflag == FALSE)
					{
						// default to old way of exporting
						u = maxMesh->tVerts[vsFace->t[j]].x;
						polygon->verts[j].u = u / ((float)polygon->tileU / 1000.0f);
						v = maxMesh->tVerts[vsFace->t[j]].y;
						polygon->verts[j].v = 1.f - (v / ((float)polygon->tileV / 1000.0f));
					}
				}
			}
    	}

		// if no OBE "PerFaceData" is available then we may as well use Max's internal gouraud colours
		if (polygonData == NULL && maxMesh->vcFace != NULL && maxMesh->vertCol != NULL)
		{
			vsFace = &maxMesh->vcFace[i];
			for (j=0; j<3; j++)
			{
				if (vsFace && vsFace->t[j] < (DWORD)maxMesh->getNumVertCol())
				{
					// ** When gouraud RGB are imported from OBE files the RGB are packed into the R(x)
					// ** component value. The version number and ident are packed into the B(z) value.

					// ** Version 1 & 2 supported

					// version and ident from B(z) RGB
					ufloat.f = maxMesh->vertCol[vsFace->t[j]].z;

					pkflag = FALSE;

					// is this our indent?
					if (ufloat.f8[3] == 255)
					{
						switch (ufloat.f8[2])
						{
						// version 1
						case 1:
							// read gouraud colours
							ufloat.f = maxMesh->vertCol[vsFace->t[j]].x;
							polygon->verts[j].gCol[0] = ufloat.f8[0];
							polygon->verts[j].gCol[1] = ufloat.f8[1];
							polygon->verts[j].gCol[2] = ufloat.f8[2];
							polygon->verts[j].gCol[3] = ufloat.f8[3];

							pkflag = TRUE;
							break;

						// version 2
						case 2:
							// read gouraud colours
							ufloat.f = maxMesh->vertCol[vsFace->t[j]].x;
							polygon->verts[j].gCol[0] = ufloat.f8[0];
							polygon->verts[j].gCol[1] = ufloat.f8[1];
							polygon->verts[j].gCol[2] = ufloat.f8[2];
							polygon->verts[j].gCol[3] = ufloat.f8[3];
							// read polygon colour
							ufloat.f = maxMesh->vertCol[vsFace->t[j]].y;
							switch (j)
							{
							case 0:
								polygon->colRGB[0] = ufloat.f8[0];
								break;
							case 1:
								polygon->colRGB[1] = ufloat.f8[0];
								break;
							case 2:
								polygon->colRGB[2] = ufloat.f8[0];
								break;
							}
							pkflag = TRUE;
							break;
						}
					}

					// have we already dealt with the RGB value?
					if (pkflag == FALSE)
					{
						// default to old way of exporting RGB value
						polygon->verts[j].gCol[0] = (UCHAR)(maxMesh->vertCol[vsFace->t[j]].x * 255.0f);
						polygon->verts[j].gCol[1] = (UCHAR)(maxMesh->vertCol[vsFace->t[j]].y * 255.0f);
						polygon->verts[j].gCol[2] = (UCHAR)(maxMesh->vertCol[vsFace->t[j]].z * 255.0f);
					}
				}
			}
		}
	}


	// ** Animation

	// use transform from frame zero if no keys frames available
	mat = node->GetNodeTM(TimeValue(0));
	mat = mat * Inverse(node->GetParentTM(TimeValue(0)));
	DecomposeMatrix(mat, pos, rot, scale);

	// ** If this node is the root object in the hierarchy, then we multiply the current matrix
	// ** by the inverse of it's reference position to put it relative to zero. Why dont't we just
	// ** force the matrix to identity? 
	// ** This is only really used when exporting Placement Editor bank objects as they could be
	// ** anywhere in the scene, and keeping everything a the origin is at least safe and consistent

	Matrix3 offsetMatrix(TRUE);
	if (objectRootNode == node)
		offsetMatrix = Inverse(node->GetNodeTM(TimeValue(0)));

	// set OBE mesh position, rotation and scale animations
	ExportAnimPos(node, obeMesh->posX, obeMesh->posY, obeMesh->posZ, pos, offsetMatrix);
	ExportAnimRot(node, obeMesh->orientationX, obeMesh->orientationY, obeMesh->orientationZ, obeMesh->orientationW, rot);
	ExportAnimScale(node, obeMesh->scaleX, obeMesh->scaleY, obeMesh->scaleZ, scale);


	// ** Re-Construct OBE quads from Max edge information
	ToQuads(obeMesh, node);


	// need to delete our max mesh
	if (deleteMesh == 1)
	{
		SAFE_DELETE(maxMesh);
	}

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::NodeToObeBone
   Purpose : converts max node via user options into an obe bone
   Parameters : max node, obe hard bone
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int OBEExport::NodeToObeBone(INode *node, ObeBone *obeBone)
{
	int				i, j, index, noof;
	SkinVertAssign	*assign;
	TIME_VALUE_KEY	timeKey;
	Matrix3			mat;
	Point3			pos, scale;
	Quat			rot;


	// valid data
	if (hardSkinDataValid == NULL || hardSkinMeshNode == NULL || IsNodeBone(node) == 0)
		return 0;
	// valid skinning bone
	if ((index = hardSkinData->GetBones()->GetIndex(node)) == -1)
		return 0;
	// valid bone reference
	if (hardSkinData->GetBones()->GetBone(index) == NULL)
		return 0;


	// set bone name
	strncpy(obeBone->boneName, node->GetName(), sizeof(obeBone->boneName));
	obeBone->boneName[sizeof(obeBone->boneName)-1] = 0;

	// set skin reference name
	strncpy(obeBone->meshNameRef, hardSkinMeshNode->GetName(), sizeof(obeBone->meshNameRef));
	obeBone->meshNameRef[sizeof(obeBone->meshNameRef)-1] = 0;


	// ** Vertex Assignments

	// vertex assignments
	noof = hardSkinData->GetAssigns()->CountAssigns(index);
	obeBone->SetNumAssigns(noof);

	// copy all this bones assignments
	for (i=0, j=0; j<noof; i++)
		if ((assign = hardSkinData->GetAssigns()->GetAssign(i)) != NULL)
		{
			if (assign->idxBoneRef == index)
			{
				obeBone->vertAssignList[j].vertIndex = i;
				timeKey.frameNum = 0;
				timeKey.data = assign->vec.x;
				obeBone->vertAssignList[j].assignList.x->SetKey(0, &timeKey);
				timeKey.data = assign->vec.y;
				obeBone->vertAssignList[j].assignList.z->SetKey(0, &timeKey);
				timeKey.data = assign->vec.z;
				obeBone->vertAssignList[j].assignList.y->SetKey(0, &timeKey);
				j++;
			}
		}


	// ** Animation

	// use transform from frame zero if no keys frames available
	mat = node->GetNodeTM(TimeValue(0));
	mat = mat * Inverse(node->GetParentTM(TimeValue(0)));
	DecomposeMatrix(mat, pos, rot, scale);

	// export all transform anims
	ExportAnimPos(node, obeBone->posX, obeBone->posY, obeBone->posZ, pos);
	ExportAnimRot(node, obeBone->orientationX, obeBone->orientationY, obeBone->orientationZ, obeBone->orientationW, rot);
	ExportAnimScale(node, obeBone->scaleX, obeBone->scaleY, obeBone->scaleZ, scale);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::NodeToObeMaxBone
   Purpose : converts max bone into an obe max bone
   Parameters : max node, obe bone pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

typedef struct _TBoneAssign
{
	int		vertIndex;
	float	influence;
} TBoneAssign;

int OBEExport::NodeToObeMaxBone(INode *node, ObeMaxBone *obeBone)
{
	BonesDefMod					*modifier;
	BoneModData					*modData;
	int							i, j, index, count;
	Point3						pos, scale;
	Quat						rot;
	Matrix3						mat;
	VertexInfluenceListClass	*vertexInfo;
	Tab<TBoneAssign>			assignTab;


	// does a max skin modifier exist in the scene?
	if ((modifier = MaxSkin_GetModifier(ip)) == NULL)
		return 0;
	// does valid local mod data exist for this modifier?
	if ((modData = MaxSkin_GetModData(ip)) == NULL)
		return 0;

	// is the modifier aware of this max bone?
	for (i=0; i<modifier->BoneData.Count(); i++)
		if (modifier->BoneData[i].Node != NULL && modifier->BoneData[i].Node == node)
		{
			break;
		}
	if (i >= modifier->BoneData.Count())
		return 0;
	index = i;

	// set name of this max bone
	strncpy(obeBone->name, node->GetName(), sizeof(obeBone->name));
	obeBone->name[sizeof(obeBone->name)-1];

	// set name of mesh this bone references
	strncpy(obeBone->meshName, (softSkinMeshNode != NULL) ? (char *)softSkinMeshNode->GetName() : "", sizeof(obeBone->name));
	obeBone->meshName[sizeof(obeBone->meshName)-1];


	// ** Here we breakdown the bone's inverse reference matrix into PRS for the obe
	// ** file. The reference matrix defines the local space for the bone to transform
	// ** in. Usually this is simply the inverse of frame zero (the reference frame).
	// ** Although Max seems prefers to use matrix of the bone when it is added to the
	// ** modifier. This matrix is explicitily carried around internally and even saved
	// ** out. For this reason we also have to have an explicit reference matrix.

	// load the bone's internal inverse reference matrix for consistency!!
	mat = modifier->BoneData[index].tm;

	// decompose the inverse reference matrix into PRS
	DecomposeMatrix(mat, pos, rot, scale);

	// save position
	obeBone->invRefPos.x = pos.x;
	obeBone->invRefPos.y = pos.z;
	obeBone->invRefPos.z = pos.y;
	// save rotation
	obeBone->invRefRot.x = rot.x;
	obeBone->invRefRot.y = rot.z;
	obeBone->invRefRot.z = rot.y;
	obeBone->invRefRot.w = -rot.w;
	// save scale 
	obeBone->invRefScale.x = scale.x;
	obeBone->invRefScale.y = scale.z;
	obeBone->invRefScale.z = scale.y;


	// ** Weighted Vertex Assignments

	// zero count
	assignTab.ZeroCount();

	// determine how many vertex assignments for this bone?
	for (i=0; i<modData->VertexDataCount; i++)
		for (j=0; j<modData->VertexData[i]->d.Count(); j++)
		{
			vertexInfo = modData->VertexData[i]->d.Addr(j);
			if (vertexInfo->Bones < modifier->BoneData.Count() && modifier->BoneData[vertexInfo->Bones].Node == node)
			{
				count = assignTab.Count();
				assignTab.SetCount(count+1);
				assignTab[count].vertIndex = i;
				assignTab[count].influence = modifier->RetrieveNormalizedWeight(modData, i, j);
			}
		}

	// set number of assignments for this bone
	obeBone->NoofAssigns(assignTab.Count());
	for (i=0; i<obeBone->noofAssigns; i++)
		obeBone->Assign(i, assignTab[i].vertIndex, assignTab[i].influence);


	// ** Animation

	// use transform from frame zero if no keys frames available
	mat = node->GetNodeTM(TimeValue(0));
	mat = mat * Inverse(node->GetParentTM(TimeValue(0)));
	DecomposeMatrix(mat, pos, rot, scale);

	// ** If this node is the root object in the hierarchy, then we multiply the current matrix
	// ** by the inverse of it's reference position to put it relative to zero. Why dont't we just
	// ** force the matrix to identity? 
	// ** This is only really used when exporting Placement Editor bank objects as they could be
	// ** anywhere in the scene, and keeping everything a the origin is at least safe and consistent

	Matrix3 offsetMatrix(TRUE);
	if (objectRootNode == node)
		offsetMatrix = Inverse(node->GetNodeTM(TimeValue(0)));

	// set OBE soft bone position, rotation and scale animations
	ExportAnimPos(node, obeBone->posX, obeBone->posY, obeBone->posZ, pos, offsetMatrix);
	ExportAnimRot(node, obeBone->rotX, obeBone->rotY, obeBone->rotZ, obeBone->rotW, rot);
	ExportAnimScale(node, obeBone->scaleX, obeBone->scaleY, obeBone->scaleZ, scale);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::ExportAnimPos
   Purpose : export linear key frame position animation from node
   Parameters : node pointer, refs pos x,y,z, reference to ref position, offset matrix
   Returns : 
   Info : 
*/

void OBEExport::ExportAnimPos(INode *nodePtr, AnimVector& posX, AnimVector& posY, AnimVector& posZ, Point3& refPos, Matrix3& offsetMatrix)
{
	int				i, numKeys;
	Control			*nodeTMControl, *posLinControl;
	IKeyControl		*posKeyControl;
	ILinPoint3Key	posKey;
	TIME_VALUE_KEY	timeKey;


	// base transform controller
	nodeTMControl = nodePtr->GetTMController();
	if (nodeTMControl == NULL)
		return;

	// linear position controller
	numKeys = 0;
	posLinControl = nodeTMControl->GetPositionController();
	if (posLinControl &&
		posLinControl->SuperClassID() == CTRL_POSITION_CLASS_ID &&
		posLinControl->ClassID() == Class_ID(LININTERP_POSITION_CLASS_ID, 0))
	{
		posKeyControl = GetKeyControlInterface(posLinControl);
		if (posKeyControl)
			numKeys = posKeyControl->GetNumKeys();
	}
	else
	{
		DPrintf("Node '%s' invalid position controller", nodePtr->GetName());
	}
	if (configExportAnimation && numKeys > 0)
	{
		posX.SetNumKeys(numKeys);
		posY.SetNumKeys(numKeys);
		posZ.SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			posKeyControl->GetKey(i, &posKey);
			timeKey.frameNum = posKey.time / GetTicksPerFrame();

			Point3 p = posKey.val * offsetMatrix;
			timeKey.data = p.x;
			posX.SetKey(i, &timeKey);
			timeKey.data = p.z;
			posY.SetKey(i, &timeKey);
			timeKey.data = p.y;
			posZ.SetKey(i, &timeKey);
		}
	}
	else
	{
		posX.SetNumKeys(1);
		posY.SetNumKeys(1);
		posZ.SetNumKeys(1);
		timeKey.frameNum = 0;

		Point3 p = refPos * offsetMatrix;
		timeKey.data = p.x;
		posX.SetKey(0, &timeKey);
		timeKey.data = p.z;
		posY.SetKey(0, &timeKey);
		timeKey.data = p.y;
		posZ.SetKey(0, &timeKey);
	}

	if (configExportAnimation && numKeys>0)
		DPrintf("Node '%s' %d position key%s", nodePtr->GetName(), numKeys, (numKeys != 1) ? "s":"");
	else
		DPrintf("Node '%s' reference position key", nodePtr->GetName());
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::ExportAnimRot
   Purpose : export linear key frame rotation animation from node
   Parameters : node pointer, refs rot x,y,z, reference to ref rot
   Returns : 
   Info : 
*/

void OBEExport::ExportAnimRot(INode * nodePtr, AnimVector & rotX, AnimVector & rotY, AnimVector & rotZ, AnimVector & rotW, Quat & refRot)
{
	int				i, numKeys;
	Control			*nodeTMControl, *rotLinControl;
	IKeyControl		*rotKeyControl;
	ILinRotKey		rotKey;
	TIME_VALUE_KEY	timeKey;

	// base transform controller
	nodeTMControl = nodePtr->GetTMController();
	if (nodeTMControl == NULL)
		return;

	// linear rotation controller
	numKeys = 0;
	rotLinControl = nodeTMControl->GetRotationController();
	if (rotLinControl &&
		rotLinControl->SuperClassID() == CTRL_ROTATION_CLASS_ID &&
		rotLinControl->ClassID() == Class_ID(LININTERP_ROTATION_CLASS_ID, 0))
	{
		rotKeyControl = GetKeyControlInterface(rotLinControl);
		if (rotKeyControl)
			numKeys = rotKeyControl->GetNumKeys();
	}
	else
	{
		DPrintf("Node '%s' invalid rotation controller", nodePtr->GetName());
	}
	if (configExportAnimation && numKeys > 0)
	{
		rotX.SetNumKeys(numKeys);
		rotY.SetNumKeys(numKeys);
		rotZ.SetNumKeys(numKeys);
		rotW.SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			rotKeyControl->GetKey(i, &rotKey);
			timeKey.frameNum = rotKey.time / GetTicksPerFrame();
			timeKey.data = rotKey.val.x;
			rotX.SetKey(i, &timeKey);
			timeKey.data = rotKey.val.z;
			rotY.SetKey(i, &timeKey);
			timeKey.data = rotKey.val.y;
			rotZ.SetKey(i, &timeKey);
			timeKey.data = -rotKey.val.w;
			rotW.SetKey(i, &timeKey);
		}
	}
	else
	{
		rotX.SetNumKeys(1);
		rotY.SetNumKeys(1);
		rotZ.SetNumKeys(1);
		rotW.SetNumKeys(1);
		timeKey.frameNum = 0;
		timeKey.data = refRot.x;
		rotX.SetKey(0, &timeKey);
		timeKey.data = refRot.z;
		rotY.SetKey(0, &timeKey);
		timeKey.data = refRot.y;
		rotZ.SetKey(0, &timeKey);
		timeKey.data = -refRot.w;
		rotW.SetKey(0, &timeKey);
	}

	if (configExportAnimation && numKeys>0)
		DPrintf("Node '%s' %d rotation key%s", nodePtr->GetName(), numKeys, (numKeys != 1) ? "s":"");
	else
		DPrintf("Node '%s' reference rotation key", nodePtr->GetName());
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::ExportAnimScale
   Purpose : export linear key frame scale animation from node
   Parameters : node pointer, refs scl x,y,z, reference to ref scl
   Returns : 
   Info : 
*/

void OBEExport::ExportAnimScale(INode * nodePtr, AnimVector & scaleX, AnimVector & scaleY, AnimVector & scaleZ, Point3 & refScale)
{
	int				i, numKeys;
	Control			*nodeTMControl, *scaleLinControl;
	IKeyControl		*scaleKeyControl;
	ILinScaleKey	scaleKey;
	TIME_VALUE_KEY	timeKey;

	// base transform controller
	nodeTMControl = nodePtr->GetTMController();
	if (nodeTMControl == NULL)
		return;

	// linear scale controller
	scaleLinControl = nodeTMControl->GetScaleController();
	if (scaleLinControl &&
		scaleLinControl->SuperClassID() == CTRL_SCALE_CLASS_ID &&
		scaleLinControl->ClassID() == Class_ID(LININTERP_SCALE_CLASS_ID, 0))
	{
		scaleKeyControl = GetKeyControlInterface(scaleLinControl);
		if (scaleKeyControl)
			numKeys = scaleKeyControl->GetNumKeys();
	}
	else
	{
		DPrintf("Node '%s' invalid scale controller", nodePtr->GetName());
	}
	if (configExportAnimation && numKeys > 0)
	{
		scaleX.SetNumKeys(numKeys);
		scaleY.SetNumKeys(numKeys);
		scaleZ.SetNumKeys(numKeys);
		for (i=0; i<numKeys; i++)
		{
			scaleKeyControl->GetKey(i, &scaleKey);
			timeKey.frameNum = scaleKey.time / GetTicksPerFrame();
			timeKey.data = scaleKey.val.s.x;
			scaleX.SetKey(i, &timeKey);
			timeKey.data = scaleKey.val.s.z;
			scaleY.SetKey(i, &timeKey);
			timeKey.data = scaleKey.val.s.y;
			scaleZ.SetKey(i, &timeKey);
		}
	}
	else
	{
		scaleX.SetNumKeys(1);
		scaleY.SetNumKeys(1);
		scaleZ.SetNumKeys(1);
		timeKey.frameNum = 0;
		timeKey.data = refScale.x;
		scaleX.SetKey(0, &timeKey);
		timeKey.data = refScale.z;
		scaleY.SetKey(0, &timeKey);
		timeKey.data = refScale.y;
		scaleZ.SetKey(0, &timeKey);
	}

	if (configExportAnimation && numKeys>0)
		DPrintf("Node '%s' %d scale key%s", nodePtr->GetName(), numKeys, (numKeys != 1) ? "s":"");
	else
		DPrintf("Node '%s' reference scale key", nodePtr->GetName());
}


// --------------------------------------------------------------------------------
// User Configuration
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : OBEExport::ReadConfig
   Purpose : read users configuration file
   Parameters : 
   Returns : 
   Info : 
*/

//	Non-Version:
//		UCHAR		NULL
//		UCHAR		configExportAnimation		; export animation
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		configExportPerFaceData		; export face data from modifier
//		UCHAR		NULL
//		UCHAR		NULL
//		UCHAR		configWriteParamsIK			; write inverse kinematic params to seperate file
//		UCHAR		NULL
//		UCHAR		configCopyUsedTextures		; copy all used texture maps to directory
//
//	Version:1
//		UCHAR		configExportAnimation		; export animation
//		UCHAR		configExportPerFaceData		; export PerFaceData modifier data (obe data)
//		UCHAR		configEvalKeysToLinear		; evaluate animation keys as linear
//		UCHAR		configCopyUsedTextures		; copy all used texture maps to..
//		TCHAR[260]	configCopyUsedTexturePath	; ..this directory

void OBEExport::ReadConfig()
{
	FILE		*configFile;
	char		configFileName[MAX_PATH];
	UCHAR		readc;
	UINT		version;

	// piece together the config filename
	strcpy(configFileName, ip->GetDir(APP_PLUGCFG_DIR));
	strcat(configFileName, "\\");
	strcat(configFileName, EXPORT_CONFIG_FILE);

	// set default configuration
	configExportAnimation		= 1;
	configExportPerFaceData		= 1;
	configEvalKeysToLinear		= 0;
	configCopyUsedTextures		= 0;
	_tcscpy(configCopyUsedTexturePath, _T(""));

	// open configuration file
	if ((configFile = fopen(configFileName, "rt")) == NULL)
		return;

	// read first entry.. is this our ident (23 November 2000)?
	version = 0;
	readc = fgetc(configFile);
	if (readc != (00+11+23))
	{
		// old configuration file
		configExportAnimation = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		if ((readc = fgetc(configFile)) != (UCHAR)EOF)
			configExportPerFaceData = readc;
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		readc = fgetc(configFile);
		if ((readc = fgetc(configFile)) != (UCHAR)EOF)
			configCopyUsedTextures = readc;
	}
	else
	{
		// ** New Versioned Configuration File Found

		// read version number
		fread(&version, sizeof(version), 1, configFile);
		switch (version)
		{
		// version:1
		case 1:
			configExportAnimation	= fgetc(configFile);
			configExportPerFaceData	= fgetc(configFile);
			configEvalKeysToLinear	= fgetc(configFile);
			configCopyUsedTextures	= fgetc(configFile);
			fread(configCopyUsedTexturePath, sizeof(TCHAR), sizeof(configCopyUsedTexturePath), configFile);
			break;
		}
	}

	DPrintf("Read user config file (version %d)", version);

	fclose(configFile);
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteConfig
   Purpose : write users configuration file
   Parameters : 
   Returns : 
   Info : 
*/

void OBEExport::WriteConfig()
{
	FILE		*configFile;
	char		configFileName[256];
	UCHAR		writec = 0;
	UINT		version = EXPORT_CONFIG_VERSION;

	// piece together the config filename
	strcpy(configFileName, ip->GetDir(APP_PLUGCFG_DIR));
	strcat(configFileName, "\\");
	strcat(configFileName, EXPORT_CONFIG_FILE);

	// create the configuration file
	if ((configFile = fopen(configFileName, "wt")) == NULL)
		return;

	// write ident entry (23 November 2000)
	fputc(00+11+23, configFile);

	// write current configuration version
	fwrite(&version, sizeof(version), 1, configFile);

	// write configuration
	fputc(configExportAnimation, configFile);
	fputc(configExportPerFaceData, configFile);
	fputc(configEvalKeysToLinear, configFile);
	fputc(configCopyUsedTextures, configFile);
	fwrite(configCopyUsedTexturePath, sizeof(TCHAR), sizeof(configCopyUsedTexturePath), configFile);

	fclose(configFile);

	DPrintf("Wrote user config file");
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::IsNodeBone
   Purpose : is the node a valid max helper bone
   Parameters : 
   Returns : 1 - bone, 0 - not bone
   Info : 
*/

int OBEExport::IsNodeBone(INode *nodePtr)
{
	Object	*object;
	if (nodePtr == NULL)
		return 0;
	object = nodePtr->GetObjectRef();
	if (! (object && object->SuperClassID() == HELPER_CLASS_ID && object->ClassID() == Class_ID(BONE_CLASS_ID, 0)))
		return 0;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteChunk_AnimTime
   Purpose : write the animation time chunk
   Parameters : 
   Returns : 
   Info : 
*/

void OBEExport::WriteChunk_AnimTime()
{
	Interval	interval;
	int			pos, n,r,z;

	pos = BeginWriteChunk(OBECHUNK_ANIMTIME, ANIMTIME_VER);

	interval = ip->GetAnimRange();
	n = (int)interval.End() / GetTicksPerFrame();
	fwrite(&n, 4, 1, fileHandle);
	r = (int)GetFrameRate();
	fwrite(&r, 4, 1, fileHandle);
	z = 0;
	fwrite(&z, 4, 1, fileHandle);

	EndWriteChunk(pos);

	DPrintf("Animation Time %d frame%s, %d fps", n, n == 1 ? "" : "s", r);
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteExtraMeshData
   Purpose : write the extra obe mesh data
   Parameters : obe mesh pointer
   Returns : 
   Info : 
*/

void OBEExport::WriteExtraMeshData(ObeMesh *obeMesh)
{
	UCHAR	phong[32], alpha;
	int		i, j;

	// terrain flags
	for (i=0; i<obeMesh->numPoly; i++)
		fwrite(&obeMesh->polyArray[i].terFlag, 4, 1, fileHandle);

	// NDO flags
	for (i=0; i<obeMesh->numPoly; i++)
		fwrite(&obeMesh->polyArray[i].NDOFlag, 4, 1, fileHandle);

	// dual texture and..
	alpha = 255;
	for (i=0; i<obeMesh->numPoly; i++)
	{
		fwrite(obeMesh->polyArray[i].dualTexture, 32, 1, fileHandle);
		// ..vertex alphas
		for (j=0; j<4; j++)
		{
			if (j<obeMesh->polyArray[i].numVerts)
				fwrite(&obeMesh->polyArray[i].verts[j].gCol[3], 1, 1, fileHandle);
			else
				fwrite(&alpha, 1, 1, fileHandle);
		}
	}

	// null phong texture
	memset(phong, 0, 32);
	fwrite(&phong, 32, 1, fileHandle);
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::ReadNodeNoteTracks
   Purpose : read in this nodes note tracks
   Parameters : node pointer
   Returns : 
   Info : 
*/

void OBEExport::ReadNodeNoteTracks(INode * nodePtr)
{
	static Class_ID		DefNoteTrackClassID(NOTETRACK_CLASS_ID, 0);
	int					noofNotes, i, j;
	NoteTrack			*trackPtr;
	NoteKey				*notePtr;

	noofNotes = nodePtr->NumNoteTracks();
	if (noofNotes > 0)
		DPrintf("Node '%s' notes", (char *)nodePtr->GetName());
	for (i=0; i<noofNotes; i++)
		if ((trackPtr = nodePtr->GetNoteTrack(i)) != NULL && (trackPtr->ClassID() == DefNoteTrackClassID))
		{
			// valid track note for this node
			DefNoteTrack &noteTrack = *(DefNoteTrack *)trackPtr;
			DPrintf(" track %d", i);
			for (j=0; j<noteTrack.keys.Count(); j++)
				if ((notePtr = noteTrack.keys[j]) != NULL)
				{
					// display note..
					DPrintf("  frame: %d  text: %s", notePtr->time/GetTicksPerFrame(), notePtr->note);
				}
		}
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::ToQuads
   Purpose : optimise OBE mesh to quads
   Parameters : OBE mesh pointer, MAX node pointer
   Returns : 
   Info : - uses edge data within MAX mesh to determine if tris can be merged into quads
		: - will also have to remap perfacedata
*/

// is there a common vertex edge and invisible edge between these faces?
// returns indices of end of common edge for faces a and b
int commonEdge(Face *fa, Face *fb, int& a, int &b)
{
	int i,j, as[2],bs[2];

	for (i=0; i<3; i++)
	{
		as[0] = fa->v[i];
		as[1] = fa->v[VERTEX_INDEX_NEXT(i,3)];

		for (j=0; j<3; j++)
		{
			bs[0] = fb->v[j];
			bs[1] = fb->v[VERTEX_INDEX_NEXT(j,3)];

			if (as[0] == bs[1] && as[1] == bs[0])
			{
				// fa,fb share a common vertex edge.. but do they share an invisible edge?
				if (!fa->getEdgeVis(i) && !fb->getEdgeVis(j))
				{
					a = VERTEX_INDEX_NEXT(i,3);
					b = VERTEX_INDEX_NEXT(j,3);
					return 1;
				}
			}
		}
	}
	return 0;
}

void OBEExport::ToQuads(ObeMesh *obeMesh, INode *node)
{
	Mesh			*maxMesh;
	Face			*fa, *fb;
	PolyType		*newPolyArray, quad;
	BitArray		polyDoneFlags;
	int				i,j, newPolyNum, ia,ib;
	TPolyEntry		polyEntry;


	maxMesh = GetNodeMesh(node);
	if (maxMesh == NULL || maxMesh->getNumFaces() == 0)
		return;
	if (maxMesh->getNumFaces() != obeMesh->numPoly)
		return;

	maxPolyOrder.ZeroCount();

	newPolyNum = 0;
	newPolyArray = new PolyType[obeMesh->numPoly];

	polyDoneFlags.SetSize(obeMesh->numPoly);
	polyDoneFlags.ClearAll();

	for (i=0; i<maxMesh->getNumFaces(); i++)
	{
		if (polyDoneFlags[i] == 1)
			continue;
		fa = &maxMesh->faces[i];

		// 
		for (j=i+1; j<maxMesh->getNumFaces(); j++)
		{
			if (polyDoneFlags[j] == 1)
				continue;
			fb = &maxMesh->faces[j];

			// does face fa share an invisible edge with another face?
			if (commonEdge(fa,fb, ia,ib) == 1)
				break;
		}
		if (j < maxMesh->getNumFaces())
		{
			// merge tri i,j to form quad.. copy to new
			{
				PolyType *pa, *pb;
				pa = &obeMesh->polyArray[i];
				pb = &obeMesh->polyArray[j];

				// copy all polygon info across
				strcpy(quad.texture, pa->texture);
				quad.colRGB[0] = pa->colRGB[0];
				quad.colRGB[1] = pa->colRGB[1];
				quad.colRGB[2] = pa->colRGB[2];
				quad.transVal  = pa->transVal;
				quad.transMode = pa->transMode;
				quad.gColMode = pa->gColMode;
				quad.tileU = pa->tileU;
				quad.tileV = pa->tileV;
				quad.selected = pa->selected;
				quad.flags = pa->flags;
				quad.NDOFlag = pa->NDOFlag;			
				quad.terFlag = pa->terFlag;
				memcpy(quad.dualTexture, pa->dualTexture, 32);

				quad.SetNumVerts(4);
				quad.verts[0].CopyFrom(&pa->verts[ia]);
				quad.verts[1].CopyFrom(&pa->verts[VERTEX_INDEX_NEXT(ia,3)]);
				quad.verts[2].CopyFrom(&pb->verts[ib]);
				quad.verts[3].CopyFrom(&pb->verts[VERTEX_INDEX_NEXT(ib,3)]);
			}
			newPolyArray[newPolyNum].CopyFrom(&quad);
			newPolyNum++;

			polyEntry.noof = 2;
			polyEntry.tris[0] = i;
			polyEntry.tris[1] = j;
			maxPolyOrder.Append(1, &polyEntry);


			// we have finished with this face
			polyDoneFlags.Set(j);
		}
		else
		{
			// copy this tri to new
			newPolyArray[newPolyNum].CopyFrom(&obeMesh->polyArray[i]);
			newPolyNum++;

			polyEntry.noof = 1;
			polyEntry.tris[0] = i;
			maxPolyOrder.Append(1, &polyEntry);

		}

		// we have finished with this face
		polyDoneFlags.Set(i);
	}

	DPrintf("Mesh '%s' converted into %d quad%s from %d tris", obeMesh->meshName, newPolyNum, (newPolyNum == 1) ? "":"s", obeMesh->numPoly);

	// copy new polygon list across to obe mesh
	obeMesh->SetNumPolys(newPolyNum);
	for (i=0; i<newPolyNum; i++)
		obeMesh->polyArray[i].CopyFrom(&newPolyArray[i]);

	SAFE_DELETE_ARRAY(newPolyArray)
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteChunk_AnimSegments
   Purpose : write anim segments chunk from this object
   Parameters : node pointer
   Returns : 
   Info : this routine is a enum node callback
*/

static int writeChunk_AnimSegments(INode *node, void *context)
{
	return ((OBEExport *)context)->WriteChunk_AnimSegments(node);
}

int OBEExport::WriteChunk_AnimSegments(INode *nodePtr)
{
	static Class_ID		DefNoteTrackClassID(NOTETRACK_CLASS_ID, 0);
	int					noofTracks, noof, i, ival, fpPos, fpCurPos;
	NoteTrack			*trackPtr;
	NoteKey				*note, *noteNext;
	DefNoteTrack		*noteTrack;
	char				ident[32];
	TCHAR				*charPtrA, *charPtrB;
	int					charLen;
	Interval			interval;

	// get number of note tracks for this node
	if ((noofTracks = nodePtr->NumNoteTracks()) == 0)
		return NENUM_CONTINUE;

	// search for valid animation segment note track
	while (noofTracks--)
		if ((trackPtr = nodePtr->GetNoteTrack(noofTracks)) != NULL && (trackPtr->ClassID() == DefNoteTrackClassID))
		{
			// can safely recast this to a note track
			noteTrack = (DefNoteTrack *)trackPtr;

			// is this the animation segments track?
			if (noteTrack->keys.Count() == 0)
				continue;
			if ((note = noteTrack->keys[0]) == NULL || _tcsstr(note->note, _T("#ANIMSEG")) == NULL)
				continue;

			// ** Valid #ANIMSEG note track found
			// ** - all track notes apply to entire object

			noof = 0;

			// write anim segments chunk
			fpPos = BeginWriteChunk(OBECHUNK_ANIMSEGMENTS, ANIMSEGMENTS_VER);

			// write number of animation segments
			fwrite(&noof, 4, 1, fileHandle);			// noof unknown at this time

			// write all anim segments
			for (i=0; i<noteTrack->keys.Count(); i++)
				if ((note = noteTrack->keys[i]) != NULL && _tcsstr(note->note, _T("#ANIMSEG")) != NULL)
				{
					if (_tcsstr(note->note, _T("#ANIMSEGEND")) != NULL)
						continue;

					// write note ident name
					strncpy(ident, "", 32);
					charPtrA = _tcsstr(note->note, _T("\r\n"));
					charPtrB = (charPtrA != NULL) ? _tcsstr(charPtrA+2, _T("\r\n")) : NULL;
					charPtrA += _tcslen(_T("\r\n"));
					charLen = min(32-1,((charPtrB != NULL) ? charPtrB - charPtrA : 0));
					strncpy(ident, charPtrA, charLen);
					ident[charLen] = 0;
					fwrite(ident, 1, 32, fileHandle);

					// write start frame
					ival = note->time/GetTicksPerFrame();
					fwrite(&ival, 4, 1, fileHandle);

					// write end frame
					if ((i+1) < noteTrack->keys.Count() && (noteNext = noteTrack->keys[i+1]) != NULL)
					{
						ival = noteNext->time/GetTicksPerFrame();
						// if next note is a new segment marker.. drop frame as markers inclusive
						if (_tcsstr(noteNext->note, _T("#ANIMSEGEND")) == NULL)
							ival = max(0, ival-1);
						fwrite(&ival, 4, 1, fileHandle);
					}
					else
					{
						// use scene animation range as segment terminator
						interval = ip->GetAnimRange();
						ival = max(0, (int)((float)interval.End()/(float)GetTicksPerFrame())-1);
						fwrite(&ival, 4, 1, fileHandle);
					}

					// write zero flags
					ival = 0;
					fwrite(&ival, 4, 1, fileHandle);

					// write segment FPS
					ival = 30;								// default: 30fps
					charPtrA = note->note;
					charPtrB = _tcsstr(charPtrB, _T("fps"));
					if (charPtrB != NULL)
					{
						while (charPtrB >= charPtrA && _istdigit(*(charPtrB-1)))
							charPtrB--;
						if (_istdigit(*charPtrB))
							ival = _ttoi(charPtrB);
					}
					fwrite(&ival, 4, 1, fileHandle);

					// write zero custom float
					ival = 0;
					fwrite(&ival, 4, 1, fileHandle);

					noof++;
				}


			// fix up file with the correct number of animation segments written
			fpCurPos = (int)ftell(fileHandle);
			fseek(fileHandle, fpPos, SEEK_SET);
			fwrite(&noof, 4, 1, fileHandle);
			fseek(fileHandle, fpCurPos, SEEK_SET);

			EndWriteChunk(fpPos);

			DPrintf("Animation Segments %d segment%s", noof, noof == 1 ? "" : "s");

			// valid animation segments wrote
			return NENUM_END;
		}
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteChunk_NodeAnimCommands
   Purpose : write anim note commands chunk from this node
   Parameters : node pointer
   Returns : 
   Info : The note tracks are stored in Max ascending frame time order
*/

void OBEExport::WriteChunk_NodeAnimCommands(INode *node)
{
	static Class_ID		DefNoteTrackClassID(NOTETRACK_CLASS_ID, 0);
	static TCHAR		lbuf[256], com[32], arg[128];
	char				name[32];
	int					pos, noofPos, curPos, noofTracks, i, fn, noof;
	NoteTrack			*trackPtr;
	NoteKey				*note;
	DefNoteTrack		*noteTrack;
	TCHAR				*np, *ep;


	if ((noofTracks = node->NumNoteTracks()) == 0)
		return;

	pos = BeginWriteChunk(OBECHUNK_NODE_ANIM_COMMANDS, NODEANIMCOMMANDS_VER);

	// zero note command count
	noof = 0;

	// write zero notes written (fill in later)
	noofPos = ftell(fileHandle);
	fwrite(&noof, sizeof(noof), 1, fileHandle);

	// write this nodes name
	strncpy(name, (char *)node->GetName(), sizeof(name));
	name[sizeof(name)-1] = 0;
	fwrite(name, 1, sizeof(name), fileHandle);

	// search for all valid animation note command tracks
	while (noofTracks--)
	{
		if ((trackPtr = node->GetNoteTrack(noofTracks)) != NULL && (trackPtr->ClassID() == DefNoteTrackClassID))
		{
			noteTrack = (DefNoteTrack *)trackPtr;

			for (i=0; i<noteTrack->keys.Count(); i++)
			{
				if ((note = noteTrack->keys[i]) != NULL)
				{
					// ** Parse this note track for valid commands and write them all out

					// load note start and end pos
					np = note->note;
					ep = note->note + _tcslen(np);

					// check all potential note commands
					while (np < ep)
					{
						// load line from char stream and bump to next
						::loadLine(np, ep, lbuf);
						np = ::nextLine(np, ep);

						// load command into buffers
						com[0] = 0;
						arg[0] = 0;
						loadCommand(lbuf, com, arg);

						// valid command?
						if (_tcslen(com) == 0)
							continue;
						// already dealt with animation segment..
						if (_tcsstr(com, _T("ANIMSEG")) != NULL)
							continue;

						// write command frame
						fn = note->time / GetTicksPerFrame();
						fwrite(&fn, sizeof(fn), 1, fileHandle);

						// write command string
						fwrite(com, 1, sizeof(com), fileHandle);

						// write command argument
						fwrite(arg, 1, sizeof(arg), fileHandle);

						// bump number of notes written
						noof++;
					}
				}
			}
		}
	}

	// write correct number of note commands written
	curPos = ftell(fileHandle);
	fseek(fileHandle, noofPos, SEEK_SET);
	fwrite(&noof, 4, 1, fileHandle);
	fseek(fileHandle, curPos, SEEK_SET);

	EndWriteChunk(pos);

	DPrintf("Node '%s' wrote %d animation note command%s", node->GetName(), noof, noof != 1 ? "s":"");
}


/* --------------------------------------------------------------------------------
   Function : loadLine
   Purpose : load a line of text from the char stream
   Parameters : current char pointer, end char stream pointer, text line to load
   Returns : 
   Info : 
*/

static void loadLine(TCHAR *cp, TCHAR *ep, TCHAR *lbuf)
{
	while (cp < ep)
	{
		if (*cp == 0x0a || *cp == 0x0d)
			break;
		*lbuf++ = *cp++;
	}
	*lbuf = 0;
}


/* --------------------------------------------------------------------------------
   Function : nextLine
   Purpose : return the next line from the char stream
   Parameters : current char pointer, end char stream pointer
   Returns : pointer to next char line
   Info : 
*/

static char *nextLine(TCHAR *cp, TCHAR *ep)
{
	while (cp < ep)
	{
		if (*cp == 0x0a || *cp == 0x0d)
			break;
		cp++;
	}
	if (*(cp+1) == 0x0a || *(cp+1) == 0x0d)
		return cp+2;
	return cp+1;
}


/*	--------------------------------------------------------------------------------
	Function : loadCommand
	Purpose : load command from line pointer into command and argument pointer
	Parameters : line pointer, command pointer, argument pointer
	Returns : 
	Info : 
*/

static void loadCommand(TCHAR *lp, TCHAR *cp, TCHAR *ap)
{
	TCHAR	c, *ep, *p1, *p2;

	// get end of line
	ep = lp + _tcslen(lp);
	if (ep == lp)
		return;

	// is this a valid command
	if (*lp != '#')
		return;
	lp++;

	// extract command
	while (lp < ep)
	{
		c = *lp++;
		if (c == _T(' '))
			break;
		if (c == _T('"'))
		{
			lp--;
			break;
		}
		*cp++ = c;
	}
	*cp = 0;

	// extract argument enclosed within quotes
	p1 = _tcschr(lp, _T('"'));
	if (p1)
		p2 = _tcschr(p1+1, _T('"'));
	if (p1 && p2 && (p2-p1) > 1)
	{
		*p2 = 0;
		_tcscpy(ap, p1+1);
	}
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteChunk_AnimNotes
   Purpose : write note chunk from this object
   Parameters : node pointer
   Returns : 
   Info : this routine is a enum node callback
*/

static int writeChunk_AnimNotes(INode *node, void *context)
{
	return ((OBEExport *)context)->WriteChunk_AnimNotes(node);
}

int OBEExport::WriteChunk_AnimNotes(INode *nodePtr)
{
	static Class_ID		DefNoteTrackClassID(NOTETRACK_CLASS_ID, 0);
	TCHAR				lbuf[256], com[32], arg[128];

	int					pos, cur, noofTracks, i, fn, noof;
	NoteTrack			*trackPtr;
	NoteKey				*note;
	DefNoteTrack		*noteTrack;
	TCHAR				*np, *ep;


	// get number of note tracks for this node
	if ((noofTracks = nodePtr->NumNoteTracks()) == 0)
		return NENUM_CONTINUE;

	noof = 0;

	// search for valid animation segment note track
	while (noofTracks--)
		if ((trackPtr = nodePtr->GetNoteTrack(noofTracks)) != NULL && (trackPtr->ClassID() == DefNoteTrackClassID))
		{
			// can safely recast this to a note track
			noteTrack = (DefNoteTrack *)trackPtr;

			for (i=0; i<noteTrack->keys.Count(); i++)
				if ((note = noteTrack->keys[i]) != NULL)
				{
					// ** Parse this note track for valid commands and write them all out

					// load note start and end pos
					np = note->note;
					ep = note->note + _tcslen(np);
					// check all potential note commands
					while (np < ep)
					{
						// load line from char stream and bump to next
						::loadLine(np, ep, lbuf);
						np = ::nextLine(np, ep);

						// load command into buffers
						com[0] = 0;
						arg[0] = 0;
						loadCommand(lbuf, com, arg);

						// valid command?
						if (_tcslen(com) == 0)
							continue;
						// already dealt with animation segment..
						if (_tcsstr(com, _T("ANIMSEG")) != NULL)
							continue;

						// initial entry?
						if (noof == 0)
						{
							// begin notes chunk
							pos = BeginWriteChunk(OBECHUNK_ANIMNOTES, ANIMNOTES_VER);
							fwrite(&noof, 4, 1, fileHandle);
						}

						// write command frame
						fn = note->time / GetTicksPerFrame();
						fwrite(&fn, 4, 1, fileHandle);

						// write command string
						fwrite(com, 1, sizeof(com), fileHandle);

						// write command argument
						fwrite(arg, 1, sizeof(arg), fileHandle);

						// bump number of notes written
						noof++;
					}
				}
		}

	// end notes chunk
	if (noof > 0)
	{
		EndWriteChunk(pos);

		// write correct number of notes written
		cur = ftell(fileHandle);
		fseek(fileHandle, pos, SEEK_SET);
		fwrite(&noof, 4, 1, fileHandle);
		fseek(fileHandle, cur, SEEK_SET);

		DPrintf("Animation Notes %d note%s", noof, noof == 1 ? "" : "s");
	}

	return NENUM_END;
}


/* --------------------------------------------------------------------------------
   Function : OBEExport::WriteChunk_PerFaceData
   Purpose : write polygon and format data chunk
   Parameters : node pointer
   Returns : 
   Info : Jobe data will be exported here even though it as been exported higher up!
*/

void OBEExport::WriteChunk_PerFaceData(INode *node)
{
	PerFaceModData	*perFaceData;
	PerFaceEntry	*perFace;
	int				pos, noof, noofPos, curPos, size, i;


	if ((perFaceData = PerFaceData_GetData(node)) == NULL)
		return;
	if (perFaceData->formatInst == NULL)
		return;


	// begin data format chunk
	pos = BeginWriteChunk(OBECHUNK_POLYDATA, POLYDATA_VER);


	// ** Write Data Format Information

	// write out format data name and size
	fwrite(&perFaceData->dataName, sizeof(perFaceData->dataName), 1, fileHandle);
	fwrite(&perFaceData->formatSize, sizeof(perFaceData->formatSize), 1, fileHandle);

	// write zero format attributes. (fill in later)
	noof = 0;
	noofPos = ftell(fileHandle);
	fwrite(&noof, sizeof(noof), 1, fileHandle);

	// write all valid format attributes
	noof = PerFaceData_WriteFormatData(perFaceData->formatInst, perFaceData->formatSize, fileHandle);

	// re-write number of valid format attributes
	curPos = ftell(fileHandle);
	fseek(fileHandle, noofPos, SEEK_SET);
	fwrite(&noof, sizeof(noof), 1, fileHandle);
	fseek(fileHandle, curPos, SEEK_SET);


	// ** Write Face Data Entries

	// ** The problem here is that OBE files can contain both triangle and quad polygons,
	// ** whilst the PerFaceData modifier, just like a Max mesh, uses triangles only.
	// ** Fortunately when i convert the OBE into quads i record all relevant information
	// ** to be able to perform the same merge on the PerFaceData before exporting.

	// write zero face data entries (fill in later)
	noof = 0;
	noofPos = ftell(fileHandle);
	fwrite(&noof, sizeof(noof), 1, fileHandle);

	// write all face data entries
	for (i=0; i < min(maxPolyOrder.Count(), perFaceData->faceList->NoofItems()); i++)
	{
		// maxTriOrder contains entries of TTriEntry. Only write the first tri from each entry
		if ((perFace = perFaceData->GetFace(maxPolyOrder[i].tris[0])) != NULL)
		{
			perFace->GetData(size);
			fwrite(perFace->GetData(), 1, size, fileHandle);

			noof++;
		}
	}

	// now we can write the actual number of face data entries written
	curPos = ftell(fileHandle);
	fseek(fileHandle, noofPos, SEEK_SET);
	fwrite(&noof, sizeof(noof), 1, fileHandle);
	fseek(fileHandle, curPos, SEEK_SET);

	// end data format chunk
	EndWriteChunk(pos);

	DPrintf("Node '%s' wrote PerFaceData name '%s', size %d, entries %d", node->GetName(), perFaceData->dataName, perFaceData->formatSize, noof);
}


/*	--------------------------------------------------------------------------------
	Function : BeginWriteChunk
	Purpose : begin a new OBE chunk
	Parameters : chunk ident, version
	Returns : current io handle position
	Info : this function should always be paired with EndWriteChunk
*/

int OBEExport::BeginWriteChunk(int chunkid, int version)
{
	long	zero = 0;
	fwrite(&chunkid, 1, sizeof(long), fileHandle);
	fwrite(&version, 1, sizeof(long), fileHandle);
	fwrite(&zero, 1, sizeof(long), fileHandle);
	return ftell(fileHandle);
}


/*	--------------------------------------------------------------------------------
	Function : EndWriteChunk
	Purpose : ends an OBE chunk
	Parameters : io handle position
	Returns : 
	Info : this function is the complement function of BeginWriteChunk
*/

void OBEExport::EndWriteChunk(int pos)
{
	long cur, len;
	cur = ftell(fileHandle);
	len = cur-pos;
	fseek(fileHandle, pos-4, SEEK_SET);
	fwrite(&len, 1, sizeof(long), fileHandle);
	fseek(fileHandle, cur, SEEK_SET);
}


/*	--------------------------------------------------------------------------------
	Function : OBEExport::WriteTextureMaps
	Purpose : write out all texture maps to directory path
	Parameters : texture map directory path pointer, reference to table of texture maps
	Returns : 
	Info : 
*/

void OBEExport::WriteTextureMaps(TCHAR *path, Tab<TTexturePath>& textures)
{
	static TCHAR		newfile[MAX_PATH], fname[_MAX_FNAME], ext[_MAX_EXT];
	int					i, j;
	Tab<TTexturePath>	duplicates;

	// search for duplicate texture file names
	duplicates.ZeroCount();
	for (i=0; i<textures.Count(); i++)
		for (j=i+1; j<textures.Count(); j++)
			if (_tcsicmp(textures[i].path, textures[j].path) == NULL)
			{
				duplicates.Append(1, textures.Addr(i));
			}

	// copy all texture maps to common path
	for (i=0, j=0; i<textures.Count(); i++)
	{
		_tsplitpath(textures[i].path, NULL, NULL, fname, ext);
		_stprintf(newfile, "%s\\%s%s", path, fname, ext);
		if (CopyFile(textures[i].path, newfile, FALSE) != 0)
		{
			DPrintf("Map '%s%s' copied", fname, ext);
			j++;
		}
		else
			DPrintf("Map '%s%s' file copy error from '%s'", fname, ext, textures[i].path);
	}

//	// show user all duplicate textures found
//	if (duplicates.Count() > 0)
//		DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DUPLICATE_TEXTURES), ip->GetMAXHWnd(), (DLGPROC)duplicateTexturesDialogProc, (LPARAM)&duplicates);
}


// ********************************************************************************
// Experimental Methods
// ********************************************************************************

/* --------------------------------------------------------------------------------
   Function : OBEExport::ExportPAtches
   Purpose : write out an unknown object to file
   Parameters : filename, unknown object node
   Returns : 1 - file exported, 0 - error!
   Info : 
*/

int OBEExport::ExportPatches()
{
	INode			*root, *node;
	Object			*object;
	PatchObject		*patchObject;
	PatchMesh		*patchMesh;
	int				i,j, deletePatch, objectPos,patchPos, noof;
	char			ident[32];
	char			obeHeader[4] = "OBE";

	DPrintf("Using Experimental Routines\n");

	root = ip->GetRootNode();
	if (root != NULL)
	{
		// open the file for writing
		if ((fileHandle = fopen(exportFileName, "wb"))==NULL)
			return 0;

		// write OBE header
		fwrite(obeHeader, 1, 4, fileHandle);

		// begin object chunk
		objectPos = BeginWriteChunk(OBECHUNK_OBJECT, OBJECT_VER);

		DPrintf("Exporting Patch Meshes,,");

		// export all nodes we are interested in from the scene
		for (i=0; i<root->NumberOfChildren(); i++)
		{
			node = root->GetChildNode(i);

			// patch object?
			object = (Object *)node->EvalWorldState(0).obj;
			if (object->CanConvertToType(Class_ID(PATCHOBJ_CLASS_ID, 0)) != 0)
			{
				// get patch object from object or convert to patch object type
				patchObject = (PatchObject *)object->ConvertToType(0, Class_ID(PATCHOBJ_CLASS_ID, 0));
				deletePatch = object != patchObject;		// if converted we need to delete when finished with it

				// get patch mesh
				patchMesh = &patchObject->patch;

				// ** Export Patch

				// begin patch chunk
				patchPos = BeginWriteChunk(OBECHUNK_PATCH_MESH, PATCHMESH_VER);

				// write patch node name
				noof = min(strlen(node->GetName()), 31);
				strncpy(ident, node->GetName(), noof);
				ident[noof] = 0;
				fwrite(ident, sizeof(char), sizeof(ident)/sizeof(char), fileHandle);

				DPrintf("Found \"%s\" -> %d patches, %d Vertices, %d Vectors", ident, patchMesh->numPatches, patchMesh->numVerts, patchMesh->numVecs);

				// write all patch vertices
				noof = patchMesh->numVerts;
				fwrite(&noof, sizeof(noof), 1, fileHandle);
				for (j=0; j<noof; j++)
				{
					fwrite(&patchMesh->verts[j].p.x, sizeof(float), 1, fileHandle);
					fwrite(&patchMesh->verts[j].p.z, sizeof(float), 1, fileHandle);
					fwrite(&patchMesh->verts[j].p.y, sizeof(float), 1, fileHandle);
				}

				// write all patch vectors
				noof = patchMesh->numVecs;
				fwrite(&noof, sizeof(noof), 1, fileHandle);
				for (j=0; j<noof; j++)
				{
					// write vector
					fwrite(&patchMesh->vecs[j].p.x, sizeof(float), 1, fileHandle);
					fwrite(&patchMesh->vecs[j].p.z, sizeof(float), 1, fileHandle);
					fwrite(&patchMesh->vecs[j].p.y, sizeof(float), 1, fileHandle);
					// write flags
					fwrite(&patchMesh->vecs[j].flags, sizeof(DWORD), 1, fileHandle);
				}

				// write all patches
				noof = patchMesh->numPatches;
				fwrite(&noof, sizeof(noof), 1, fileHandle);
				for (j=0; j<noof; j++)
				{
					// write patch type (tri or quad)
					fwrite(&patchMesh->patches[j].type, sizeof(DWORD), 1, fileHandle);
					// write all patch corner vertex indices
					fwrite(&patchMesh->patches[j].v, sizeof(int), 4, fileHandle);
					// write all patch exterior vectors
					fwrite(&patchMesh->patches[j].vec, sizeof(int), 8, fileHandle);
					// write all patch interior vectors
					fwrite(&patchMesh->patches[j].interior, sizeof(int), 4, fileHandle);
				}

				// end patch chunk
				EndWriteChunk(patchPos);

				// need to delete patch object?
				if (deletePatch)
				{
					SAFE_DELETE(patchObject);
				}
			}
		}

		// end object chunk
		EndWriteChunk(objectPos);

		// terminate the obe file
		EndWriteChunk(BeginWriteChunk(OBECHUNK_END, END_VER));

		// close the file
		fclose(fileHandle);
	}

	return 1;
}


// ********************************************************************************
// Hard Skin Methods
// ********************************************************************************

/* --------------------------------------------------------------------------------
   Function : HardSkin_IsNode
   Purpose : determine if this node as an hard skin modifier attached
   Parameters : node pointer
   Returns : 1 - max skin modifer attached, 0 - not found
   Info : 
*/

static int HardSkin_IsNode(INode *node)
{
	if (HardSkin_GetData(node) == NULL)
		return 0;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : HardSkin_GetData
   Purpose : get hard skin data from node
   Parameters : node pointer
   Returns : skin data pointer or NULL
   Info : 
*/

static SkinData *HardSkin_GetData(INode *node)
{
	int					l, i;
	ReferenceTarget		*ref;
	Modifier			*mod;
	ModContext			*mc;

	for (l=0; l<node->NumRefs() ;l++)
		// is there a derived space warp modifier reference on this node?
		if ((ref = node->GetReference(l)) != NULL && ref->ClassID() == Class_ID(WSM_DERIVOB_CLASS_ID,0))
		{
			for (i=0; i < ((IDerivedObject *)ref)->NumModifiers(); i++)
			{
				// is this a skin modifier?
				mod = ((IDerivedObject *)ref)->GetModifier(i);
				if (mod && mod->SuperClassID() == WSM_CLASS_ID && mod->ClassID() == SKIN_MOD_CLASS_ID)
				{
					// get modcontext from modifier, as this is where skin data hangs from
					mc = ((IDerivedObject *)ref)->GetModContext(i);
					if (mc != NULL)
					{
						// valid modcontext, any skin data attached?
						if( mc->localData )
							return (SkinData *)mc->localData;
					}
				}
			}
		}
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : HardSkin_FindRootBone
   Purpose : get the root bone of the skinned mesh node
   Parameters : skinned mesh node pointer, max interface pointer
   Returns : root bone pointer or NULL
   Info : 
*/

static INode *HardSkin_FindRootBone(INode *node, Interface *ip)
{
	SkinData	*skinData;
	INode		*root;
	int			l;

	if (node == NULL || (skinData = HardSkin_GetData(node)) == 0)
		return NULL;

	if (skinData->GetBones() == NULL)
		return NULL;
	for (l=0; l < skinData->GetBones()->Count(); l++)
		if ((root = (skinData->GetBones()->GetBone(l))->node) != NULL)
		{
			if (root->GetParentNode() == ip->GetRootNode())
			{
				break;
			}
		}
	return (l < skinData->GetBones()->Count()) ? root : NULL;
}


/* --------------------------------------------------------------------------------
   Function : HardSkin_IsBone
   Purpose : determine if this node is a valid hard skinned bone
   Parameters : OBEExport instance pointer, node pointer
   Returns : 1 - hard skinned bone node, else 0
   Info : 
*/

static int HardSkin_IsBone(OBEExport *exportInst, INode *node)
{
	int	index;

	if (exportInst->hardSkinDataValid == 0 || exportInst->hardSkinData == NULL || exportInst->hardSkinMeshNode == NULL)
		return 0;
	if (exportInst->hardSkinData->GetBones() == NULL)
		return NULL;
	if ((index = exportInst->hardSkinData->GetBones()->GetIndex(node)) == -1)
		return 0;
	if (exportInst->hardSkinData->GetBones()->GetBone(index) == NULL)
		return 0;
	return 1;
}


// ********************************************************************************
// Dialog Procedures - 23 November 2000
// ********************************************************************************

/* --------------------------------------------------------------------------------
   Function : configDialogProc
   Purpose : user exporter dialog procedure
   Parameters : dialog handle, message, parameter1, parameter2
   Returns : return code
   Info : 
*/

static BOOL CALLBACK configDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{
	static TCHAR	file[MAX_PATH], fileExt[_MAX_EXT], title[MAX_PATH];
	OBEExport		*expInst;


	if (uMsg == WM_INITDIALOG)
		SetWindowLong(hwndDlg, GWL_USERDATA, lParam);
	expInst = (OBEExport *)GetWindowLong(hwndDlg, GWL_USERDATA);

	switch (uMsg)
	{
	case WM_INITDIALOG:

		// set title line text
		_tsplitpath(expInst->exportFileName, NULL, NULL, file, fileExt);
		_stprintf(title, "OBEExport - %s%s", file, fileExt);
		SetWindowText(hwndDlg, title);

		// set export options
		CheckDlgButton(hwndDlg, IDC_CONFIG_EXPORT_ANIMATION, expInst->configExportAnimation ? BST_CHECKED : BST_UNCHECKED);
		CheckDlgButton(hwndDlg, IDC_CONFIG_EXPORT_PERFACEDATA, expInst->configExportPerFaceData ? BST_CHECKED : BST_UNCHECKED);

		// set used texture options
		CheckDlgButton(hwndDlg, IDC_CONFIG_COPY_TEXTURES, expInst->configCopyUsedTextures ? BST_CHECKED : BST_UNCHECKED);
		EnableWindow(GetDlgItem(hwndDlg, IDC_CONFIG_COPY_TEXTURE_PATH), expInst->configCopyUsedTextures ? TRUE : FALSE);

		// set experimental options
		CheckDlgButton(hwndDlg, IDC_CONFIG_EVAL_KEYS, expInst->configEvalKeysToLinear ? BST_CHECKED : BST_UNCHECKED);
		EnableWindow(GetDlgItem(hwndDlg, IDC_CONFIG_EVAL_KEYS), expInst->configExportAnimation ? TRUE : FALSE);

		// default focus to OK button
		wParam = (WPARAM)GetDlgItem(hwndDlg, IDOK);
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		// user accepts input
		case IDOK:

			// get export options
			expInst->configExportAnimation = (UCHAR)(IsDlgButtonChecked(hwndDlg, IDC_CONFIG_EXPORT_ANIMATION)) ? 1:0;
			expInst->configExportPerFaceData = (UCHAR)(IsDlgButtonChecked(hwndDlg, IDC_CONFIG_EXPORT_PERFACEDATA)) ? 1:0;

			// get texture options
			expInst->configCopyUsedTextures = (UCHAR)(IsDlgButtonChecked(hwndDlg, IDC_CONFIG_COPY_TEXTURES)) ? 1:0;

			// get experimental options
			expInst->configEvalKeysToLinear = (UCHAR)(IsDlgButtonChecked(hwndDlg, IDC_CONFIG_EVAL_KEYS)) ? 1:0;

			EndDialog(hwndDlg, 1);
			return TRUE;

		// user rejects input
		case IDCANCEL :
			EndDialog(hwndDlg, -1);
			return TRUE;

		// user toggled copy texture maps check box
		case IDC_CONFIG_COPY_TEXTURES:
			EnableWindow(GetDlgItem(hwndDlg, IDC_CONFIG_COPY_TEXTURE_PATH), (IsDlgButtonChecked(hwndDlg, IDC_CONFIG_COPY_TEXTURES) == BST_CHECKED) ? TRUE : FALSE);
			return TRUE;

		// user toggled export animation check box
		case IDC_CONFIG_EXPORT_ANIMATION:
			EnableWindow(GetDlgItem(hwndDlg, IDC_CONFIG_EVAL_KEYS), (IsDlgButtonChecked(hwndDlg, LOWORD(wParam)) == BST_CHECKED) ? TRUE : FALSE);
			return TRUE;
		}
		break;
	}
	return FALSE;
}


/* --------------------------------------------------------------------------------
   Function : duplicateTexturesDialogProc
   Purpose : duplicate texture map dialog procedure
   Parameters : dialog handle, message, parameter1, parameter2
   Returns : return code
   Info : 
*/

static BOOL CALLBACK duplicateTexturesDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{
	Tab<TTexturePath>	*duplicates;
	TTexturePath		*texturePathPtr;
	int					i;
	RECT				rc1, rc2;

	if (uMsg == WM_INITDIALOG)
		SetWindowLong(hwndDlg, GWL_USERDATA, lParam);
	if ((duplicates = (Tab<TTexturePath> *)GetWindowLong(hwndDlg, GWL_USERDATA)) == NULL)
		return FALSE;

	switch(uMsg)
	{
		case WM_INITDIALOG:

			// centre window
			GetWindowRect(hwndDlg, &rc1);
			GetWindowRect(GetParent(hwndDlg), &rc2);
			SetWindowPos(hwndDlg, NULL, rc2.left+(((rc2.right-rc2.left)-(rc1.right-rc1.left))>>1), rc2.top+(((rc2.bottom-rc2.top)-(rc1.bottom-rc1.top))>>1), 0, 0, SWP_NOZORDER | SWP_NOSIZE);

			// add all duplicate textures to list box
			for (i=0; i < duplicates->Count(); i++)
				if ((texturePathPtr = duplicates->Addr(i)) != NULL)
				{
					SendDlgItemMessage(hwndDlg, IDC_DUPTEX_LIST, LB_ADDSTRING, (WPARAM)0, (LPARAM)texturePathPtr->path);
				}

			// set the keyboard focus onto the "close" button
			SetFocus(GetDlgItem(hwndDlg, IDCLOSE));
			return FALSE;

		case WM_COMMAND:

			switch(LOWORD(wParam))
			{
			case IDCLOSE:

				EndDialog(hwndDlg, 1);
				return TRUE;
			}
			return 0;
	}
	return FALSE;
}


// ********************************************************************************
// Expected Export PlugIn Methods
// ********************************************************************************

/* --------------------------------------------------------------------------------
   Function : OBEExport:: Various library functions demanded by the plugin
   Purpose :
   Parameters :
   Returns : 
   Info : 
*/

int OBEExport::ExtCount()
{
	return 1;
}
const TCHAR* OBEExport::Ext(int i)
{
	if (i != 0)
		return NULL;
	return _T("OBE");
}
const TCHAR *OBEExport::LongDesc()
{
	return _T("ISL Jobe OBE File Exporter");
}
const TCHAR *OBEExport::ShortDesc()
{
	return _T("ISL OBE Export");
}
const TCHAR *OBEExport::AuthorName()
{
	return _T("J Steele / A Slater");
}
const TCHAR *OBEExport::CopyrightMessage()
{
	return _T("Copyright 1999 Interactive Studios");
}
const TCHAR *OBEExport::OtherMessage1()
{
	return NULL;
}
const TCHAR *OBEExport::OtherMessage2()
{
	return NULL;
}
unsigned int OBEExport::Version()
{
	return 200;						// Version *100 - i.e 1.21 * 100 = 121
}
void OBEExport::ShowAbout(HWND hwnd)
{
}
#if MAX_RELEASE >= 3000
// respond to support option query..
BOOL OBEExport::SupportsOptions(int ext, DWORD options)
{
	if (options == SCENE_EXPORT_SELECTED)
	{
		// only export selected nodes?
		return FALSE;
	}
	return FALSE;
}
#endif


// --------------------------------------------------------------------------------
// OBE File Exporter
// --------------------------------------------------------------------------------
class OBEExpClassDesc : public ClassDesc
{
	public:
		int				IsPublic()							{return 1;}
		void			*Create(BOOL loading = FALSE)		{return new OBEExport();}
		const TCHAR		*ClassName()						{return GetString(IDS_EXPORT_CLASS_NAME);}
		SClass_ID		SuperClassID()						{return SCENE_EXPORT_CLASS_ID;}
		Class_ID		ClassID()							{return OBEEXP_CLASS_ID;}
		const TCHAR		*Category()							{return GetString(IDS_CATEGORY);}
};

// instance of our object descriptor
static OBEExpClassDesc	theExpClassDesc;
ClassDesc *GetOBEExpClassDesc() {return &theExpClassDesc;}
