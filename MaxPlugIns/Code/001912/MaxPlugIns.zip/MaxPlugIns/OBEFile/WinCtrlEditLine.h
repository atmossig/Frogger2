
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dle, (c) 2000 Interactive Studios Ltd.
//
//    File : WinCtrlEditLine.cpp
// Purpose : a custom window control to edit a line
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __WINCTRLEDITLINE__H
#define __WINCTRLEDITLINE__H

#include <windows.h>
#include <tchar.h>


// --------------------
// Constants and macros

// creation stylings
#define	WCEDITLINE_STYLE_DIRBROWSE		(1<<0)						// enable directory browse button


// -----------------
// Types and Classes

/* --------------------------------------------------------------------------------
   Class : CWinCtrlEditLine
   Purpose : custom edit browse line window control
   Info : 
*/

typedef class CWinCtrlEditLine
{
	private:
		HWND					parent;								// parent window handle
		HWND					hwnd;								// window handle
		HWND					hwndEdit, hwndBrowse;				// edit box and browse button window handles
		HINSTANCE				hinst;								// instance

		HWND					hwndDialog;							// dialog handle
		RECT					dialogInitRect;						// dialog initialise rectangular dimensions
		TCHAR					dialogInitLine[MAX_PATH];			// dialog initialise line pointer
		int						dialogInitStyles;					// dialog initialise stylings

	public:

								// constructor / destructor
								CWinCtrlEditLine();
								~CWinCtrlEditLine();

								// create our window control
		HWND					Create(HINSTANCE hinst, HWND parent, RECT *rc, int styles = WCEDITLINE_STYLE_DIRBROWSE, TCHAR *string = NULL);

								// create modal window control
								// ** for some reason, using HINSTANCE and HWND seems to cause link error therefore these are passed as DWORDs
		TCHAR					*CreateModal(DWORD hinst, LPTSTR resource, DWORD parent, RECT *rc, int styles, TCHAR *string);

								// destroy our window control
		void					Destroy();

								// class scoped window / dialog procedures
		LRESULT					WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
		BOOL					DialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

								// is the control active?
		int						IsActive() {return hwnd != NULL;}

								// get current edit line from control
		TCHAR					*GetLine(TCHAR *line = NULL);

								// set current edit line
		void					SetLine(TCHAR *line);

} CWinCtrlEditLine;

#endif	// __WINCTRLEDITLINE__H
