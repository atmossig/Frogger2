
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : InvKin.cpp
// Purpose : Export / Import Inverse Kinematic Parameters
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "InvKin.h"
#include "interpik.h"

// IK Parameter block size
#define	PARAM_BLOCK_SIZE	(32 + 1 + ((1+1+1+1+4)*2) + ((4+((1+1+1+1+4+4+4+4+4)*3))*2))


/* --------------------------------------------------------------------------------
   Function : GetIKPFilen
   Purpose : create our IK full filenane from the exported OBE filename
   Parameters : node pointer, OBE filename pointer
   Returns : 
   Info : 
*/

TCHAR *GetIKPFilen(TCHAR *OBEFilen)
{
	static TCHAR	path[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR], name[_MAX_FNAME], ext[_MAX_EXT];

	if (OBEFilen == NULL)
		return NULL;

	_tcscpy(path, OBEFilen);
	_tsplitpath(path, drive, dir, name, ext);
	_stprintf(path, "%s%s%s.IKP", drive, dir, name);
	return path;
}


/* --------------------------------------------------------------------------------
   Function : InvKin_ImportParams
   Purpose : import nodes IK parameters
   Parameters : node pointer, OBE filename pointer
   Returns : 
   Info : 
*/

void InvKin_ImportParams(INode *node, TCHAR *OBEFilen)
{
	TCHAR			*filen;
	FILE			*fileHandle;
	UCHAR			*fileBuf, *fp, flag;
	int				fileLen;
	Control			*controller;
	JointParams		*jointParams;
	float			value;
	int				i, j;


	filen = GetIKPFilen(OBEFilen);
	if (filen == NULL || node == NULL)
		return;
	if ((fileHandle = fopen(filen, "rb")) == NULL)
		return;

	fseek(fileHandle, 0, SEEK_END);
	fileLen = ftell(fileHandle);
	fseek(fileHandle, 0, SEEK_SET);

	fileBuf = (UCHAR *)malloc(fileLen);
	if (fileBuf == NULL)
	{
		fclose(fileHandle);
		return;
	}
	fread(fileBuf, 1, fileLen, fileHandle);
	fclose(fileHandle);

	// search for IK parameter block for this node
	for (fp = fileBuf; fp < (fileBuf+fileLen); fp += PARAM_BLOCK_SIZE)
		if (stricmp((char *)node->GetName(), (char *)fp) == NULL)
		{
			break;
		}
	if (fp >= (fileBuf+fileLen))
	{
		SAFE_FREE(fileBuf)
		return;
	}

	// skip block name
	fp += 32;

	// Object Parameters

	// terminator flag
	flag = *((UCHAR *)fp);
	if (flag)
		node->SetAFlag(A_INODE_IK_TERMINATOR);
	fp += 1;

	// position bind flag
	flag = *((UCHAR *)fp);
	if (flag)
		node->SetAFlag(A_INODE_IK_POS_PINNED);
	fp += 1;

	// position x axis flag
	flag = *((UCHAR *)fp);
	node->SetTaskAxisState(0, 0, flag);
	fp += 1;
	// position y axis flag
	flag = *((UCHAR *)fp);
	node->SetTaskAxisState(0, 1, flag);
	fp += 1;
	// position z axis flag
	flag = *((UCHAR *)fp);
	node->SetTaskAxisState(0, 2, flag);
	fp += 1;

	// position weight
	value = *((float *)fp);
	node->SetPosTaskWeight(value);
	fp += 4;

	// rotation bind flag
	flag = *((UCHAR *)fp);
	if (flag)
		node->SetAFlag(A_INODE_IK_ROT_PINNED);
	fp += 1;

	// rotation x axis flag
	flag = *((UCHAR *)fp);
	node->SetTaskAxisState(1, 0, flag);
	fp += 1;
	// rotation y axis flag
	flag = *((UCHAR *)fp);
	node->SetTaskAxisState(1, 1, flag);
	fp += 1;
	// rotation z axis flag
	flag = *((UCHAR *)fp);
	node->SetTaskAxisState(1, 2, flag);
	fp += 1;

	// rotation weight
	value = *((float *)fp);
	node->SetRotTaskWeight(value);
	fp += 4;


	// Joints

	// load both controllers
	for (i=0; i<2; i++)
	{
		// get nodes position or rotation controller
		controller  = (i==0) ? node->GetTMController()->GetPositionController() : node->GetTMController()->GetRotationController();

		// create instance of MAX Joint Position or Rotation Parameters
		jointParams = new JointParams((i==0) ? JNT_POS : JNT_ROT);

		// edit scale value
		value = *((float *)fp);
		jointParams->scale = value;
		fp += 4;

		// read in all 3 degrees of freedom
		for (j=0; j<3; j++)
		{
			// active flag
			flag = *((UCHAR *)fp);
			jointParams->SetActive(j, flag ? TRUE : FALSE);
			fp += 1;
			// limited flag
			flag = *((UCHAR *)fp);
			jointParams->SetLimited(j, flag ? TRUE : FALSE);
			fp += 1;
			// ease flag
			flag = *((UCHAR *)fp);
			jointParams->SetEase(j, flag ? TRUE : FALSE);
			fp += 1;
			// spring flag
			flag = *((UCHAR *)fp);
			jointParams->SetSpring(j, flag ? TRUE : FALSE);
			fp += 1;

			// minimum value
			value = *((float *)fp);
			jointParams->min[j] = value;
			fp += 4;
			// maximum value
			value = *((float *)fp);
			jointParams->max[j] = value;
			fp += 4;

			// damping value
			value = *((float *)fp);
			jointParams->damping[j] = value;
			fp += 4;

			// spring value
			value = *((float *)fp);
			jointParams->spring[j] = value;
			fp += 4;
			// stens value
			value = *((float *)fp);
			jointParams->stens[j] = value;
			fp += 4;
		}

		// set joint in nodes controller
		controller->SetProperty(PROPID_JOINTPARAMS, jointParams);

		// if returned instance != our instance, property handler copied data... therefore we should delete ours
		if ((JointParams *)controller->GetProperty(PROPID_JOINTPARAMS) != jointParams)
		{
			SAFE_DELETE(jointParams);
		}
	}

	// delete our file buffer
	SAFE_FREE(fileBuf)
}


/* --------------------------------------------------------------------------------
   Function : InvKin_ExportParams
   Purpose : import nodes IK parameters
   Parameters : node pointer, OBE filename pointer
   Returns : 
   Info : 
*/

void InvKin_ExportParams(INode *node, TCHAR *OBEFilen)
{
	char			name[32];
	TCHAR			*filen;
	FILE			*fileHandle;
	Control			*controller;
	JointParams		*jointParams;
	UCHAR			flag;
	float			value;
	int				i, j;


	filen = GetIKPFilen(OBEFilen);
	if (filen == NULL || node == NULL)
		return;
	if ((fileHandle = fopen(filen, "ab")) == NULL)
		return;

	// write node name
	strcpy(name, (char *)node->GetName());
	fwrite(name, 1, 32, fileHandle);

	// Object Parameters

	// terminator flag
	flag = (node->TestAFlag(A_INODE_IK_TERMINATOR)) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);

	// position bind flag
	flag = (node->TestAFlag(A_INODE_IK_POS_PINNED)) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);

	// position x axis flag
	flag = (node->GetTaskAxisState(0, 0) == TRUE) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);
	// position y axis flag
	flag = (node->GetTaskAxisState(0, 1) == TRUE) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);
	// position z axis flag
	flag = (node->GetTaskAxisState(0, 2) == TRUE) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);

	// position weight
	value = node->GetPosTaskWeight();
	fwrite(&value, 4, 1, fileHandle);

	// rotation bind flag
	flag = (node->TestAFlag(A_INODE_IK_ROT_PINNED)) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);

	// rotation x axis flag
	flag = (node->GetTaskAxisState(1, 0) == TRUE) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);
	// rotation y axis flag
	flag = (node->GetTaskAxisState(1, 1) == TRUE) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);
	// rotation z axis flag
	flag = (node->GetTaskAxisState(1, 2) == TRUE) ? 1:0;
	fwrite(&flag, 1, 1, fileHandle);

	// rotation weight
	value = node->GetRotTaskWeight();
	fwrite(&value, 4, 1, fileHandle);


	// Joints

	for (i=0; i<2; i++)
	{
		// get nodes position or rotation controller
		controller  = (i==0) ? node->GetTMController()->GetPositionController() : node->GetTMController()->GetRotationController();

		// get controllers instance of joint parameters..
		jointParams = (JointParams *)controller->GetProperty(PROPID_JOINTPARAMS);
		if (jointParams == NULL)
		{
			// ** This node controller has no joint parameters stored, so
			// ** we create a default set just to export data from.

			// create temporary instance of MAX Joint Position or Rotation Parameters
			jointParams = new JointParams((i==0) ? JNT_POS : JNT_ROT);
		}

		// write edit scale value
		value = jointParams->scale;
		fwrite(&value, 4, 1, fileHandle);

		// write all our 3 degrees of freedom
		for (j=0; j<3; j++)
		{
			// active flag
			flag = ((j < jointParams->dofs) && (jointParams->Active(j) == TRUE)) ? 1:0;
			fwrite(&flag, 1, 1, fileHandle);
			// limited flag
			flag = ((j < jointParams->dofs) && (jointParams->Limited(j) == TRUE)) ? 1:0;
			fwrite(&flag, 1, 1, fileHandle);
			// ease flag
			flag = ((j < jointParams->dofs) && (jointParams->Ease(j) == TRUE)) ? 1:0;
			fwrite(&flag, 1, 1, fileHandle);
			// spring flag
			flag = ((j < jointParams->dofs) && (jointParams->Spring(j) == TRUE)) ? 1:0;
			fwrite(&flag, 1, 1, fileHandle);

			// minimum value
			value = (j < jointParams->dofs) ? jointParams->min[j] : 0.f;
			fwrite(&value, 4, 1, fileHandle);
			// maximum value
			value = (j < jointParams->dofs) ? jointParams->max[j] : 0.f;
			fwrite(&value, 4, 1, fileHandle);

			// damping value
			value = (j < jointParams->dofs) ? jointParams->damping[j] : 0.f;
			fwrite(&value, 4, 1, fileHandle);

			// spring value
			value = (j < jointParams->dofs) ? jointParams->spring[j] : 0.f;
			fwrite(&value, 4, 1, fileHandle);
			// stens value
			value = (j < jointParams->dofs) ? jointParams->stens[j] : 0.f;
			fwrite(&value, 4, 1, fileHandle);
		}

		// need to delete our temporary instance?
		if (controller->GetProperty(PROPID_JOINTPARAMS) == NULL)
		{
			SAFE_DELETE(jointParams)
		}
	}

	// close the file stream
	fclose(fileHandle);

	DPrintf("IK Parameters wrote for node '%s' to file '%s'", (char *)node->GetName(), filen);
}


/* --------------------------------------------------------------------------------
   Function : InvKin_Delete
   Purpose : delete IK parameters file
   Parameters : OBE filename pointer
   Returns : 
   Info : 
*/

void InvKin_Delete(TCHAR *OBEFilen)
{
	TCHAR	*filen;

	filen = GetIKPFilen(OBEFilen);
	if (filen == NULL)
		return;
	remove(filen);
}
