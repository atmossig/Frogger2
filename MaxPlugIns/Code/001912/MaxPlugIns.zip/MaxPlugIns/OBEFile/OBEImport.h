
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : OBEImport.h
// Purpose : OBE File Import class
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __OBEIMPORT__H
#define __OBEIMPORT__H

#include "OBEFile.h"
#include "PerFaceData.h"


// --------------------
// Constants and macros

// import plugin class ident
#define OBEIMP_CLASS_ID		Class_ID(0x5acb0bc9, 0x1a7426b2)

// TTexturePath structure flags
#define	TEXPATHFLAG_ENABLED		(1<<0)					// this texture path is enabled


// -----------------
// Types and Classes

/* --------------------------------------------------------------------------------
   Class : OBEImport
   Purpose : 
   Info : 
*/

class OBEImport : public SceneImport
{
	public:

		// interface pointers
		Interface				*ip;											// max interface
		ImpInterface			*importPtr;										// import interface

		NameMaker				*nameMakerPtr;									// unique name maker

		// current configuration
		UCHAR					configImportAnimation;							// import animation
		UCHAR					configImportPerFaceData;						// import PerFaceData
		UCHAR					configClearScene;								// clear scene on import
		UCHAR					configShowTextures;								// show texture maps in viewport
		UINT					configTextureSetIndex;							// combo box texture set index
	
		// import file
		TCHAR					importFileName[260];							// filename
		FILE					*fileHandle;									// file handle
		int						currentFilePos;									// current file position


		// textures
		StringList				*texNameList;			// list of texture names
		StringList				*texturePaths;			// texture paths from cfg file
		MultiMtl				*texLib;				// multi material that stores all of out textures
		TexInfList				*nodeTexList;			// list of nodes that have textures 

		// progress bar
		float					progressScaler;			// progress bar scaler

		// skinning
		OBE_CHUNK_SKIN_INFO		skinInfo;				// skin info header
		INode					*WSObjNodePtr;			// world space object node pointer
		Tab<INode *>			meshNodeTab;			// mesh node log table

		// animation segments
		Tab<TAnimSegment>		segmentTab;				// animation segment buffer
		INode					*objectRootNode;		// our object root node

		// texture path sets
		Tab<TTextureSet>		textureSets;

								// OBEImport constructor
								OBEImport();
								// OBEImport destructor
								~OBEImport();

		// SceneImport Methods
								// number of filename extensions supported by the importer
		int						ExtCount();
								// returns the 'i-th' supperted file extension
		const TCHAR				*Ext(int i);
								// returns a long ASCII description of the filetype
		const TCHAR				*LongDesc();
								// returns a short ASCII description of the filetype
		const TCHAR				*ShortDesc();
								// returns the ASCII authors name
		const TCHAR				*AuthorName();
								// returns the ASCII copyright message
		const TCHAR				*CopyrightMessage();
								// returns other messages
		const TCHAR				*OtherMessage1();
		const TCHAR				*OtherMessage2();
								// returns the plugin version number
		unsigned int			Version();
								// allows the plugin to show its about box
		void					ShowAbout(HWND hWnd);
								// performs the actual file import
		int						DoImport(const TCHAR *fileNamePtr, ImpInterface * importPtr, Interface * maxPtr, BOOL suppressPrompts);

		// OBEImport Methods
								// read/write user configuration file
		void					ReadConfig();
		void					WriteConfig();

								// read/write users configuration texture sets file
		void					ReadUserConfigTextureSets();
		void					WriteUserConfigTextureSets();

								// read old user texture configuration file
		void					ReadTextureConfig();

								// read file chunk
		int						ReadChunk(INode *parentNode);

								// read chunk: animation segments
		int						ReadChunk_AnimSegments();
								// read chunk: animation time
		int						ReadChunk_AnimTime();
								// read chunk: node animation commands
		int						ReadChunk_NodeAnimCommands(INode *node);
								// read chunk: mesh
		int						ReadChunk_Mesh(INode *node);
								// read chunk: hard skinned bone
		int						ReadChunk_HardBone(INode *node);


								// read in file
		int						ReadFile(INode *parentNodePtr);
								// read obe chunk header
		int						ReadChunkHead(OBE_CHUNK_HEAD *headerPtr);
								// determine chunk type
		char					*ChunkType(int chunkType);

								// convert an obe mesh into a max mesh - adding face data along the way
		Mesh					*ObeMeshToMesh(ObeMesh *oMesh, PerFaceModData *perFaceData = NULL);

								// convert an obe mesh into a max node
		ImpNode					*ObeMeshToINode(ObeMesh *obeMeshPtr, Mesh *meshPtr);

								// load all used textures
		void					LoadAllTextures();
								// assign texture maps to imported nodes
		void					AssignTexturesToNodes();


								// set the note track from the loaded anim segments
		void					SetNoteTrackAnimSegments();

		// Skin Methods
								// get mesh node from the mesh node log
		INode					*GetMeshNode(char * namePtr);

								// create instance of space warp modifier
		int						CreateSkinWSMod(char * meshRefPtr);
								// as this node a derived skin world space modifier attached?
		int						IsNodeSkinWSMod(INode * node);

								// create bone node
		INode					*ObeBoneToINode(ObeBone *obeBonePtr);

								// register a bones vertex assignments in the bone node
		int						RegisterBoneVertexAssigns(ObeBone * obeBonePtr, INode * nodePtr);
								// register a bone in the referenced / skinned mesh node
		int						RegisterSkinBoneRefs(char * meshRefPtr, INode * node);
};

#endif