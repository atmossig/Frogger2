// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 2000 Interactive Studios Ltd.
//
//    File : PlaceEditor.cpp
// Purpose : Scenic Placement Editor
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// ** 
// ** Notes:
// ** 
// ** Using the editor:
// **  1. A mesh level is loaded into Max.
// **  2. Objects are merged / imported into the scene to form an object bank. These objects may be skin
// **     or hierarchy based, have animations and node attributes.
// **  3. These objects are then "instanced" and added as children onto the mesh level. Additional attributes
// **     may be added to these objects.
// ** 
// ** Exporting the scene:
// **  1. When the scene is exported, all of the bank objects are saved out as individual obe files along with
// **     their attributes.
// **  2. The mesh level is then exported along with all child nodes, excluding the instanced objects, as a
// **     complete obe file.
// **  3. A text based placement map file is then created which contains all instanced objects from the level
// **     containing standard PRS information and additional attribute information.
// **
// ** 7th December 2000
// ** Added camera functionality.
// **


#include <direct.h>

#include "PlaceEditor.h"
#include "ParseMap.h"
#include "MaxSkin.h"


// --------------------
// Constants and macros


// -----------------
// Types and classes

// object instance enum callback struct
typedef struct _TEnumObjInst
{
	INodeTab	*bankTabPtr, *instTabPtr;
} TEnumObjInst;

// find camera target node camera enum callback struct
typedef struct _TEnumFindTarget
{
	INode		*targetNode;
	INode		*node;
} TEnumFindTarget;


// -------
// Globals


// ------------------
// Function templates

// enum callback. find world object node
static int findWorldNode(INode *node, void *context);
// enum callback. collate all bank objects
static int collateAllBankObjects(INode *node, void *context);
// enum callback. collate all instances of bank objects
static int collateAllInstanceObjects(INode *node, void *context);
// enum callback. collate all camera objects
static int collateAllCameraObjects(INode *node, void *context);
// enum callback. find a camera nodes target node
static int findCameraTargetNode(INode *node, void *context);
// enum callback. collate all light objects
static int collateAllLightObjects(INode *node, void *context);
// enum callback. find a light nodes target node
static int findLightTargetNode(INode *node, void *context);

// example load LOM file
static int exampleLoadLOMFile(char *filename);



/* --------------------------------------------------------------------------------
   Function : PlaceEditor_IsSceneValid
   Purpose : checks if the scene is a valid placement editor scene
   Parameters : 
   Returns : 1 placement editor scene, else 0
   Info : 
*/

// check if the scene is a valid placement editor scene
int PlaceEditor_IsSceneValid(Interface *ip)
{
	INode	*worldNode;

	if (ip == NULL)
		return 0;

	// find the world node from the scene
	worldNode = NULL;
	EnumNodes(ip->GetRootNode(), findWorldNode, &worldNode);
	return (worldNode != NULL) ? 1 : 0;
}


/* --------------------------------------------------------------------------------
   Function : PlaceEditor::PlaceEditor
   Purpose : constructor
   Parameters : scene exporter class instance
   Returns : 
   Info : 
*/

PlaceEditor::PlaceEditor(OBEExport *exportInst)
{
	this->exportInst = exportInst;
	this->ip = NULL;
}


/* --------------------------------------------------------------------------------
   Function : PlaceEditor::~PlaceEditor
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

PlaceEditor::~PlaceEditor()
{
	this->ip = NULL;
	this->exportInst = NULL;
}


/* --------------------------------------------------------------------------------
   Function : PlaceEditor::Init
   Purpose : initialise
   Parameters : 
   Returns : 
   Info : 
*/

void PlaceEditor::Init()
{
	// save the max interface pointer
	ip = exportInst->ip;
}


/* --------------------------------------------------------------------------------
   Function : PlaceEditor::Shutdown
   Purpose : shutdown
   Parameters : 
   Returns : 
   Info : 
*/

void PlaceEditor::Shutdown()
{
	// invalidate max pointer
	ip = NULL;
}


/* --------------------------------------------------------------------------------
   Function : PlaceEditor::DoExport
   Purpose : export this editor session
   Parameters : file name
   Returns : 0 - error, 1 - success
   Info : 
*/

static DWORD WINAPI progressBarProc(LPVOID arg) {return 0;}

int PlaceEditor::DoExport(const TCHAR *filename)
{
	static TCHAR		path[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR], fname[_MAX_FNAME], ext[_MAX_EXT];
	INode				*worldNode;
	INodeTab			bankNodeTab, instNodeTab, cameraNodeTab, lightNodeTab;
	TEnumObjInst		enumObjInst;
	int					i,j,k, num;
	bool				useAnim;
						
	float				progressScale;
	int					progressCount;
						
	CPMLevel			*levelMap;
	CPMNode				*levelObj, *worldObj, *object, *instanceObj, *animObj;
	TPMFile				*file;
	TSTR				props;
						
	Point3				rp, rs;
	Quat				rr;
						
	DWORD				dirAttribs;
						
	Matrix3				tm;
	INode				*root;

	Tab<TTexturePath>	usedTextures;

	Object				*objref;
	CameraState			camstate;
	LightState			lightstate;
	Interval			valid;
	TEnumFindTarget		enumFindTarget;
	TimeValue			timeVal, timeInc;


	// split up the full filename path
	_tsplitpath(filename, drive, dir, fname, ext);


	// ** Create our directory structure:
	// **
	// **	fname
	// **		objects
	// **			gossamer.obe
	// **			taz.obe
	// **			tree.obe
	// **			tree2.obe
	// **		world.obe
	// **		fname.lom
	// **		textures [exportInst->configExportTextures == 1]

	// try and create our fname level dir
	_stprintf(path, "%s%s%s", drive, dir, fname);

	dirAttribs = GetFileAttributes(path);
	if (!((dirAttribs != -1 && dirAttribs & FILE_ATTRIBUTE_DIRECTORY) || _mkdir(path) == 0))
	{
		DPrintf("Cannot create level directory");
		return 0;
	}

	// try and create our fname / objects dir
	_stprintf(path, "%s%s%s%s", drive, dir, fname, _T("\\objects"));

	dirAttribs = GetFileAttributes(path);
	if (!((dirAttribs != -1 && dirAttribs & FILE_ATTRIBUTE_DIRECTORY) || _mkdir(path) == 0))
	{
		DPrintf("Cannot create objects directory");
		return 0;
	}

	if (exportInst->configCopyUsedTextures)
	{
		// try and create our fname / textures dir
		_stprintf(path, "%s%s%s%s", drive, dir, fname, _T("\\textures"));

		dirAttribs = GetFileAttributes(path);
		if (!((dirAttribs != -1 && dirAttribs & FILE_ATTRIBUTE_DIRECTORY) || _mkdir(path) == 0))
		{
			DPrintf("Cannot create textures directory");
			return 0;
		}
	}


	// find the world node from the scene
	worldNode = NULL;
	EnumNodes(ip->GetRootNode(), findWorldNode, &worldNode);

	// collate all bank objects from the scene
	bankNodeTab.ZeroCount();
	EnumNodes(ip->GetRootNode(), collateAllBankObjects, &bankNodeTab);

	// collate all instance objects from the scene
	instNodeTab.ZeroCount();
	if (worldNode != NULL)
	{
		enumObjInst.bankTabPtr = &bankNodeTab;
		enumObjInst.instTabPtr = &instNodeTab;
		EnumNodes(worldNode, collateAllInstanceObjects, &enumObjInst);
	}

	// collate all cameras from the scene
	cameraNodeTab.ZeroCount();
	EnumNodes(ip->GetRootNode(), collateAllCameraObjects, &cameraNodeTab);

	// collate all lights from the scene
	lightNodeTab.ZeroCount();
	EnumNodes(ip->GetRootNode(), collateAllLightObjects, &lightNodeTab);

	// calculate progress bar
	num = bankNodeTab.Count() + instNodeTab.Count() + cameraNodeTab.Count() + lightNodeTab.Count() + (worldNode != NULL) ? 1 : 0;
	progressScale = (float)num / 100.0f;
	progressCount = 0;

	_stprintf(path, "OBE Editor Export: %s%s", fname, ext);
	ip->ProgressStart(path, TRUE, progressBarProc, NULL);


	// zero total common textures for all OBEs
	usedTextures.ZeroCount();

	// export the world node
	if (worldNode != NULL)
	{
		_stprintf(path, "%s%s%s%s%s", drive, dir, fname, _T("\\world"), ext);
		exportInst->DoExportRoot(path, worldNode, &instNodeTab);

		// append all used world node textures onto total used textures
		for (i=0; i<exportInst->usedTextures.Count(); i++)
			usedTextures.Append(1, exportInst->usedTextures.Addr(i));

		// update progress bar
		progressCount++;
		if (progressScale != 0.0f)
			ip->ProgressUpdate((int)((float)progressCount/progressScale));
	}

	// export all bank nodes as seperate obes
	for (i=0; i<bankNodeTab.Count(); i++)
	{
		_stprintf(path, "%s%s%s%s%s%s", drive, dir, fname, _T("\\objects\\"), bankNodeTab[i]->GetName(), ext);
		exportInst->DoExportRoot(path, bankNodeTab[i]);

		// append all bank node textures onto total used textures
		for (j=0; j<exportInst->usedTextures.Count(); j++)
			usedTextures.Append(1, exportInst->usedTextures.Addr(j));

		// update progress bar
		progressCount++;
		if (progressScale != 0.0f)
			ip->ProgressUpdate((int)((float)progressCount/progressScale));
	}


	// ** This is where we create our level map of objects in the scene and
	// ** save out the file

	// create instance of level map
	levelMap = new CPMLevel;

	// create level map file from max scene
	levelObj = new CPMNode(levelMap->root);

	levelObj->SetType("Level");
	levelObj->AddAttrib("Name", (char *)fname);


	// ** Add World Object To Level

	// add world object
	if (worldNode != NULL)
	{
		worldObj = new CPMNode(levelObj);
		worldObj->SetType("World");

		worldObj->AddAttrib("Name", "world");

		// decompose this node instance zero frame transform
		DecomposeMatrix(worldNode->GetNodeTM(0), rp,rr,rs);

		// write position
		worldObj->AddAttrib("PosX", rp.x);
		worldObj->AddAttrib("PosY", rp.z);
		worldObj->AddAttrib("PosZ", rp.y);

		// write rotation
		worldObj->AddAttrib("RotX", rr.x);
		worldObj->AddAttrib("RotY", rr.z);
		worldObj->AddAttrib("RotZ", rr.y);
		worldObj->AddAttrib("RotW", -rr.w);

		// write scale
		worldObj->AddAttrib("SclX", rs.x);
		worldObj->AddAttrib("SclY", rs.z);
		worldObj->AddAttrib("SclZ", rs.y);

		// ** Write the world nodes attributes

		// get properties
		worldNode->GetUserPropBuffer(props);

		// use property stream as file buffer
		file = pmOpenFile((char *)props, PMMODE_READ_MEMORY, strlen((char *)props));
		worldObj->Read(file);
		pmCloseFile(file);
	}


	// ** Add All Bank Objects To Level

	// add all bank objects
	for (i=0; i < bankNodeTab.Count(); i++)
	{
		object = new CPMNode(levelObj);

		object->SetType("Object");
		object->AddAttrib("Name", bankNodeTab[i]->GetName());

		// convert this nodes property stream into attributes for this object
		bankNodeTab[i]->GetUserPropBuffer(props);
		// use property stream as file buffer
		file = pmOpenFile((char *)props, PMMODE_READ_MEMORY, strlen((char *)props));
		object->Read(file);
		pmCloseFile(file);

		// loop around all instances looking for this nodes instances
		for (j=0; j < instNodeTab.Count(); j++)
			if (bankNodeTab[i]->GetObjectRef() == instNodeTab[j]->GetObjectRef())
			{
				instanceObj = new CPMNode(object);

				instanceObj->SetType("Instance");
				instanceObj->AddAttrib("Name", instNodeTab[j]->GetName());


				// ** Write this node instances PRS for frame 0. This could be interpreted
				// ** as the objects starting position. Note: the nodes objectTM is used.

				// get the objects frame zero node transform matrix (not including the object offset)
				tm = instNodeTab[j]->GetNodeTM(TimeValue(0));

				// ** If this object is an instance of a soft skinned mesh, we need to offset
				// ** the object from the skinned root bone. This is because the skinned mesh
				// ** instance origin is at the root bone which in turn should always be at
				// ** identity.

				// is this object soft skinned?
				if (MaxSkin_IsNode(instNodeTab[j]) == 1)
					if ((root = MaxSkin_FindRootBone(instNodeTab[j], ip)) != NULL)
					{
						// offset the skin from the root bone
						tm = tm * root->GetNodeTM(0);
					}

				// decompose the transform matrix into PRS
				DecomposeMatrix(tm, rp,rr,rs);

				// write position
				instanceObj->AddAttrib("PosX", rp.x);
				instanceObj->AddAttrib("PosY", rp.z);
				instanceObj->AddAttrib("PosZ", rp.y);

				// write rotation
				instanceObj->AddAttrib("RotX", rr.x);
				instanceObj->AddAttrib("RotY", rr.z);
				instanceObj->AddAttrib("RotZ", rr.y);
				instanceObj->AddAttrib("RotW", -rr.w);

				// write scale
				instanceObj->AddAttrib("SclX", rs.x);
				instanceObj->AddAttrib("SclY", rs.z);
				instanceObj->AddAttrib("SclZ", rs.y);


				// ** Write this node instances attributes from its properties.

				// get properties
				instNodeTab[j]->GetUserPropBuffer(props);

				// use property stream as file buffer
				file = pmOpenFile((char *)props, PMMODE_READ_MEMORY, strlen((char *)props));
				instanceObj->Read(file);
				pmCloseFile(file);


				// ** This Nodes Animation Stream
				// ** If this instance contains an animation controller and the "UseAnim" attribute is set we
				// ** should export all of the animated key frames.

				useAnim = false;
				instanceObj->GetAttrib("UseAnim", useAnim);
				if (useAnim == true)
				{
					Control			*nodeTMControl;
					int				numKeys;

					// ** Position Transform Controller

					// base controller
					if ((nodeTMControl = instNodeTab[j]->GetTMController()) != NULL)
					{
						Control			*posLinControl;
						IKeyControl		*posKeyControl;
						ILinPoint3Key	posKey;

						// linear position controller
						numKeys = 0;
						posLinControl = nodeTMControl->GetPositionController();
						if (posLinControl && posLinControl->SuperClassID() == CTRL_POSITION_CLASS_ID &&	posLinControl->ClassID() == Class_ID(LININTERP_POSITION_CLASS_ID, 0))
						{
							posKeyControl = GetKeyControlInterface(posLinControl);
							if (posKeyControl)
								numKeys = posKeyControl->GetNumKeys();
						}
						if (numKeys > 1)
						{
							// create our position anim stream object
							animObj = new CPMNode(instanceObj);
							animObj->SetType("AnimStream");
							animObj->AddAttrib("Name", "Pos");

							// extract all key frames
							for (k=0; k<numKeys; k++)
							{
								posKeyControl->GetKey(k, &posKey);
								// frame time
								animObj->AddAttrib("FrNum", posKey.time / GetTicksPerFrame());
								// position xyz
								animObj->AddAttrib("X", posKey.val.x);
								animObj->AddAttrib("Y", posKey.val.z);
								animObj->AddAttrib("Z", posKey.val.y);
							}
						}
					}


					// ** Rotation Transform Controller

					// base controller
					if ((nodeTMControl = instNodeTab[j]->GetTMController()) != NULL)
					{
						Control			*rotLinControl;
						IKeyControl		*rotKeyControl;
						ILinRotKey		rotKey;

						// linear rotation controller
						numKeys = 0;
						rotLinControl = nodeTMControl->GetRotationController();
						if (rotLinControl && rotLinControl->SuperClassID() == CTRL_ROTATION_CLASS_ID && rotLinControl->ClassID() == Class_ID(LININTERP_ROTATION_CLASS_ID, 0))
						{
							rotKeyControl = GetKeyControlInterface(rotLinControl);
							if (rotKeyControl)
								numKeys = rotKeyControl->GetNumKeys();
						}
						if (numKeys > 1)
						{
							// create our rotation anim stream object
							animObj = new CPMNode(instanceObj);
							animObj->SetType("AnimStream");
							animObj->AddAttrib("Name", "Rot");

							// extract all key frames
							for (k=0; k<numKeys; k++)
							{
								rotKeyControl->GetKey(k, &rotKey);
								// frame time
								animObj->AddAttrib("FrNum", rotKey.time / GetTicksPerFrame());
								// rotation xyzw
								animObj->AddAttrib("X",  rotKey.val.x);
								animObj->AddAttrib("Y",  rotKey.val.z);
								animObj->AddAttrib("Z",  rotKey.val.y);
								animObj->AddAttrib("W", -rotKey.val.w);
							}
						}
					}


					// ** Scale Transform Controller

					// base controller
					if ((nodeTMControl = instNodeTab[j]->GetTMController()) != NULL)
					{
						Control			*scaleLinControl;
						IKeyControl		*scaleKeyControl;
						ILinScaleKey	scaleKey;

						// linear position controller
						numKeys = 0;
						scaleLinControl = nodeTMControl->GetScaleController();
						if (scaleLinControl && scaleLinControl->SuperClassID() == CTRL_SCALE_CLASS_ID && scaleLinControl->ClassID() == Class_ID(LININTERP_SCALE_CLASS_ID, 0))
						{
							scaleKeyControl = GetKeyControlInterface(scaleLinControl);
							if (scaleKeyControl)
								numKeys = scaleKeyControl->GetNumKeys();
						}
						if (numKeys > 1)
						{
							// create our scale anim stream object
							animObj = new CPMNode(instanceObj);
							animObj->SetType("AnimStream");
							animObj->AddAttrib("Name", "Scl");

							// extract all key frames
							for (k=0; k<numKeys; k++)
							{
								scaleKeyControl->GetKey(k, &scaleKey);
								// frame time
								animObj->AddAttrib("FrNum", scaleKey.time / GetTicksPerFrame());
								// position xyz
								animObj->AddAttrib("X", scaleKey.val.s.x);
								animObj->AddAttrib("Y", scaleKey.val.s.z);
								animObj->AddAttrib("Z", scaleKey.val.s.y);
							}
						}
					}
				}


				// update progress bar
				progressCount++;
				if (progressScale != 0.0f)
					ip->ProgressUpdate((int)((float)progressCount/progressScale));
			}
	}

	
	// ** Add All Camera Objects to To Level

	// add all camera objects
	for (i=0; i < cameraNodeTab.Count(); i++)
	{
		object = new CPMNode(levelObj);

		object->SetType("Camera");
		object->AddAttrib("Name", cameraNodeTab[i]->GetName());


		// convert this nodes property stream into attributes for this object
		cameraNodeTab[i]->GetUserPropBuffer(props);

		// use property stream as file buffer
		file = pmOpenFile((char *)props, PMMODE_READ_MEMORY, strlen((char *)props));
		object->Read(file);
		pmCloseFile(file);


		// get this camera node's internal object reference
		objref = cameraNodeTab[i]->GetObjectRef();

		// fill camera state structure
		if (((CameraObject *)objref)->EvalCameraState(TimeValue(0), valid, &camstate) != REF_SUCCEED)
			memset(&camstate, 0, sizeof(camstate));

		// find a target camera's target node
		enumFindTarget.node = cameraNodeTab[i];
		enumFindTarget.targetNode = NULL;
		if (((GenCamera *)objref)->Type() == TARGETED_CAMERA)
			EnumNodes(ip->GetRootNode(), findCameraTargetNode, &enumFindTarget);

		// write camera type
		if (((GenCamera *)objref)->Type() == FREE_CAMERA)
			object->AddAttrib("Type", "Free");
		else if (((GenCamera *)objref)->Type() == TARGETED_CAMERA)
			object->AddAttrib("Type", "Target");


		// get the objects frame zero node transform matrix (not including the object offset)
		tm = cameraNodeTab[i]->GetNodeTM(TimeValue(0));
		DecomposeMatrix(tm, rp,rr,rs);

		// write position
		object->AddAttrib("PosX", rp.x);
		object->AddAttrib("PosY", rp.z);
		object->AddAttrib("PosZ", rp.y);

		// write rotation
		object->AddAttrib("RotX", rr.x);
		object->AddAttrib("RotY", rr.z);
		object->AddAttrib("RotZ", rr.y);
		object->AddAttrib("RotW", -rr.w);

		// write specific camera type attributes
		if (((GenCamera *)objref)->Type() == FREE_CAMERA)
		{
			// free camera distance
			object->AddAttrib("Dolly", camstate.tdist);
		}
		else if (((GenCamera *)objref)->Type() == TARGETED_CAMERA && enumFindTarget.targetNode != NULL)
		{
			// target camera transform

			// get the objects frame zero node transform matrix (not including the object offset)
			tm = enumFindTarget.targetNode->GetNodeTM(TimeValue(0));
			DecomposeMatrix(tm, rp,rr,rs);

			// write position
			object->AddAttrib("TarPosX", rp.x);
			object->AddAttrib("TarPosY", rp.z);
			object->AddAttrib("TarPosZ", rp.y);
		}

		// FOV in radians
		object->AddAttrib("FOV", camstate.fov);


		// ** All Animation Streams

		// get number of frames
		num = (int)(ip->GetAnimRange()).End() / GetTicksPerFrame();
		timeInc = (ip->GetAnimRange()).End() / num;

		// camera position anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "Pos");
		for (j=0; j<num; j++)
		{
			// get the objects frame zero node transform matrix (not including the object offset)
			tm = cameraNodeTab[i]->GetNodeTM(timeVal);
			DecomposeMatrix(tm, rp,rr,rs);

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("PosX", rp.x);
			animObj->AddAttrib("PosY", rp.z);
			animObj->AddAttrib("PosZ", rp.y);

			timeVal += timeInc;
		}

		// camera rotation anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "Rot");
		for (j=0; j<num; j++)
		{
			// get the objects frame zero node transform matrix (not including the object offset)
			tm = cameraNodeTab[i]->GetNodeTM(timeVal);
			DecomposeMatrix(tm, rp,rr,rs);

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write rotation
			animObj->AddAttrib("RotX", rr.x);
			animObj->AddAttrib("RotY", rr.z);
			animObj->AddAttrib("RotZ", rr.y);
			animObj->AddAttrib("RotW", -rr.w);

			timeVal += timeInc;
		}

		// write specific camera type animation streams
		if (((GenCamera *)objref)->Type() == FREE_CAMERA)
		{
			// dolly anim stream
			timeVal = 0;
			animObj = new CPMNode(object);
			animObj->SetType("AnimStream");
			animObj->AddAttrib("Name", "Dolly");
			for (j=0; j<num; j++)
			{
				// fill camera state structure from current time
				if (((CameraObject *)objref)->EvalCameraState(timeVal, valid, &camstate) != REF_SUCCEED)
					memset(&camstate, 0, sizeof(camstate));

				// frame time
				animObj->AddAttrib("FrNum", j);
				// write dolly
				animObj->AddAttrib("Dolly", camstate.tdist);

				timeVal += timeInc;
			}
		}
		else if (((GenCamera *)objref)->Type() == TARGETED_CAMERA && enumFindTarget.targetNode != NULL)
		{
			// target position anim stream
			timeVal = 0;
			animObj = new CPMNode(object);
			animObj->SetType("AnimStream");
			animObj->AddAttrib("Name", "TarPos");
			for (j=0; j<num; j++)
			{
				// get the objects frame zero node transform matrix (not including the object offset)
				tm = enumFindTarget.targetNode->GetNodeTM(timeVal);
				DecomposeMatrix(tm, rp,rr,rs);

				// frame time
				animObj->AddAttrib("FrNum", j);
				// write position
				animObj->AddAttrib("TarPosX", rp.x);
				animObj->AddAttrib("TarPosY", rp.z);
				animObj->AddAttrib("TarPosZ", rp.y);

				timeVal += timeInc;
			}
		}

		// camera FOV anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "FOV");
		for (j=0; j<num; j++)
		{
			// fill camera state structure from current time
			if (((CameraObject *)objref)->EvalCameraState(timeVal, valid, &camstate) != REF_SUCCEED)
				memset(&camstate, 0, sizeof(camstate));

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("FOV", camstate.fov);

			timeVal += timeInc;
		}


		// update progress bar
		progressCount++;
		if (progressScale != 0.0f)
			ip->ProgressUpdate((int)((float)progressCount/progressScale));
	}


	// ** Add All Light Objects To Level

	// add all light objects
	for (i=0; i < lightNodeTab.Count(); i++)
	{
		object = new CPMNode(levelObj);

		object->SetType("Light");
		object->AddAttrib("Name", lightNodeTab[i]->GetName());


		// convert this nodes property stream into attributes for this object
		lightNodeTab[i]->GetUserPropBuffer(props);

		// use property stream as file buffer
		file = pmOpenFile((char *)props, PMMODE_READ_MEMORY, strlen((char *)props));
		object->Read(file);
		pmCloseFile(file);


		// get this light node's internal object reference
		objref = lightNodeTab[i]->GetObjectRef();

		// fill light state structure
		if (((LightObject *)objref)->EvalLightState(TimeValue(0), valid, &lightstate) != REF_SUCCEED)
			memset(&lightstate, 0, sizeof(lightstate));

		// find a target light's target node
		enumFindTarget.node = lightNodeTab[i];
		enumFindTarget.targetNode = NULL;
		if (((GenLight *)objref)->Type() == TSPOT_LIGHT)
			EnumNodes(ip->GetRootNode(), findLightTargetNode, &enumFindTarget);

		// write light type
		if (((GenLight *)objref)->Type() == OMNI_LIGHT)
			object->AddAttrib("Type", "Ambient");
		else if (((GenLight *)objref)->Type() == TSPOT_LIGHT)
			object->AddAttrib("Type", "Spot Target");
		else if (((GenLight *)objref)->Type() == FSPOT_LIGHT)
			object->AddAttrib("Type", "Spot Free");

		// get the objects frame zero node transform matrix (not including the object offset)
		tm = lightNodeTab[i]->GetNodeTM(TimeValue(0));
		DecomposeMatrix(tm, rp,rr,rs);

		// write position
		object->AddAttrib("PosX", rp.x);
		object->AddAttrib("PosY", rp.z);
		object->AddAttrib("PosZ", rp.y);

		// write rotation
		object->AddAttrib("RotX", rr.x);
		object->AddAttrib("RotY", rr.z);
		object->AddAttrib("RotZ", rr.y);
		object->AddAttrib("RotW", -rr.w);

		// write specific light type attributes
		if (((GenLight *)objref)->Type() == FSPOT_LIGHT)
		{
			// free spot light target distance
			object->AddAttrib("TarDist", ((LightObject *)objref)->GetTDist(TimeValue(0)));
		}
		else if (((GenLight *)objref)->Type() == TSPOT_LIGHT && enumFindTarget.targetNode != NULL)
		{
			// target light transform

			// get the objects frame zero node transform matrix (not including the object offset)
			tm = enumFindTarget.targetNode->GetNodeTM(TimeValue(0));
			DecomposeMatrix(tm, rp,rr,rs);

			// write position
			object->AddAttrib("TarPosX", rp.x);
			object->AddAttrib("TarPosY", rp.z);
			object->AddAttrib("TarPosZ", rp.y);
		}

		// light colour RGB
		object->AddAttrib("R", (int)(lightstate.color.r * 255.0f));
		object->AddAttrib("G", (int)(lightstate.color.g * 255.0f));
		object->AddAttrib("B", (int)(lightstate.color.b * 255.0f));

		// light intensity
		object->AddAttrib("Intensity", lightstate.intens);


		// ** All Animation Streams

		// get number of frames
		num = (int)(ip->GetAnimRange()).End() / GetTicksPerFrame();
		timeInc = (ip->GetAnimRange()).End() / num;

		// light position anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "Pos");
		for (j=0; j<num; j++)
		{
			// get the objects frame zero node transform matrix (not including the object offset)
			tm = lightNodeTab[i]->GetNodeTM(timeVal);
			DecomposeMatrix(tm, rp,rr,rs);

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("PosX", rp.x);
			animObj->AddAttrib("PosY", rp.z);
			animObj->AddAttrib("PosZ", rp.y);

			timeVal += timeInc;
		}

		// write specific light type animation streams
		if (((GenLight *)objref)->Type() == FSPOT_LIGHT)
		{
			// dolly anim stream
			timeVal = 0;
			animObj = new CPMNode(object);
			animObj->SetType("AnimStream");
			animObj->AddAttrib("Name", "TarDist");
			for (j=0; j<num; j++)
			{
				// frame time
				animObj->AddAttrib("FrNum", j);
				// write target distance
				animObj->AddAttrib("TarDist", ((LightObject *)objref)->GetTDist(timeVal));

				timeVal += timeInc;
			}
		}
		else if (((GenLight *)objref)->Type() == TSPOT_LIGHT && enumFindTarget.targetNode != NULL)
		{
			// target position anim stream
			timeVal = 0;
			animObj = new CPMNode(object);
			animObj->SetType("AnimStream");
			animObj->AddAttrib("Name", "TarPos");
			for (j=0; j<num; j++)
			{
				// get the objects frame zero node transform matrix (not including the object offset)
				tm = enumFindTarget.targetNode->GetNodeTM(timeVal);
				DecomposeMatrix(tm, rp,rr,rs);

				// frame time
				animObj->AddAttrib("FrNum", j);
				// write position
				animObj->AddAttrib("TarPosX", rp.x);
				animObj->AddAttrib("TarPosY", rp.z);
				animObj->AddAttrib("TarPosZ", rp.y);

				timeVal += timeInc;
			}
		}

		// light colour R anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "R");
		for (j=0; j<num; j++)
		{
			// fill light state structure from current time
			if (((LightObject *)objref)->EvalLightState(timeVal, valid, &lightstate) != REF_SUCCEED)
				memset(&lightstate, 0, sizeof(lightstate));

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("R", (int)(lightstate.color.r * 255.0f));

			timeVal += timeInc;
		}

		// light colour G anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "G");
		for (j=0; j<num; j++)
		{
			// fill light state structure from current time
			if (((LightObject *)objref)->EvalLightState(timeVal, valid, &lightstate) != REF_SUCCEED)
				memset(&lightstate, 0, sizeof(lightstate));

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("G", (int)(lightstate.color.g * 255.0f));

			timeVal += timeInc;
		}

		// light colour B anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "B");
		for (j=0; j<num; j++)
		{
			// fill light state structure from current time
			if (((LightObject *)objref)->EvalLightState(timeVal, valid, &lightstate) != REF_SUCCEED)
				memset(&lightstate, 0, sizeof(lightstate));

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("B", (int)(lightstate.color.b * 255.0f));

			timeVal += timeInc;
		}

		// light intensity anim stream
		timeVal = 0;
		animObj = new CPMNode(object);
		animObj->SetType("AnimStream");
		animObj->AddAttrib("Name", "Intensity");
		for (j=0; j<num; j++)
		{
			// fill light state structure from current time
			if (((LightObject *)objref)->EvalLightState(timeVal, valid, &lightstate) != REF_SUCCEED)
				memset(&lightstate, 0, sizeof(lightstate));

			// frame time
			animObj->AddAttrib("FrNum", j);
			// write position
			animObj->AddAttrib("Intensity", lightstate.intens);

			timeVal += timeInc;
		}


		// update progress bar
		progressCount++;
		if (progressScale != 0.0f)
			ip->ProgressUpdate((int)((float)progressCount/progressScale));
	}


	// save the level object map out
	_stprintf(path, "%s%s%s%s%s%s", drive, dir, fname, _T("\\"), fname, _T(".LOM"));
	DPrintf("\nLOMFile '%s'", path);

	if ((file = pmOpenFile((char *)path, PMMODE_WRITE)) != NULL)
	{
		levelMap->Write(file);
		pmCloseFile(file);
	}

	// finshed with the level map
	SAFE_DELETE(levelMap)


	// save all of the used texture maps
	if (exportInst->configCopyUsedTextures)
	{
		_stprintf(path, "%s%s%s%s", drive, dir, fname, _T("\\textures"));
		DPrintf("\nTexture Maps '%s'", path);
		exportInst->WriteTextureMaps(path, usedTextures);
	}


	// close down the progess bar
	ip->ProgressEnd();

	// zero our node tabs
	instNodeTab.ZeroCount();
	bankNodeTab.ZeroCount();

	// ** To allow the artist to quickly select a file for output rather than typing
	// ** in the name all of the time, a dummy OBE file is created and saved out

	// use export filename
	exportInst->DoExportRoot((char *)filename, NULL);

//	// ** Example Of Loading File
//	_stprintf(path, "%s%s%s%s%s%s", drive, dir, fname, _T("\\"), fname, _T(".LOM"));
//	exampleLoadLOMFile((char *)path);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : findWorldNode
   Purpose : node enumeration callback. find world object node
   Parameters : node pointer, pointer to world node pointer
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int findWorldNode(INode *node, void *context)
{
	TSTR props;

	if (node == NULL)
		return NENUM_END;

	// is this node a world object?
	node->GetUserPropBuffer(props);
	if (_tcsstr(props, _T("MAXPROP")) != NULL && _tcsstr(props, _T("_WORLD")) != NULL)
	{
		*((INode **)context) = node;
		return NENUM_END;
	}

	// continue search
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : collateAllBankObjects
   Purpose : node enumeration callback. collate all bank objects from the scene
   Parameters : node pointer, INodeTab pointer
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateAllBankObjects(INode *node, void *context)
{
	TSTR			props;
	INodeTab		*nodeTabPtr;

	if (node == NULL)
		return NENUM_END;

	// is this node a bank object?
	node->GetUserPropBuffer(props);
	if (_tcsstr(props, _T("MAXPROP")) != NULL && _tcsstr(props, _T("_BANK_OBJECT")) != NULL)
	{
		nodeTabPtr = (INodeTab *)context;
		nodeTabPtr->Append(1, &node);
		return NENUM_ENDPATH;
	}

	// continue search
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : collateAllInstanceObjects
   Purpose : node enumeration callback. collate all instances of bank objects from the scene
   Parameters : node pointer, 
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateAllInstanceObjects(INode *node, void *context)
{
	TEnumObjInst	*enumObjInst;
	int				l;

	enumObjInst = (TEnumObjInst *)context;

	// spin around all of the bank objects checking if this node is a valid instance object
	for (l=0; l < enumObjInst->bankTabPtr->Count(); l++)
		if (node->GetObjectRef() == (*(enumObjInst->bankTabPtr->Addr(l)))->GetObjectRef())
		{
			enumObjInst->instTabPtr->Append(1, &node);

			// ** Since all child nodes of this node also belong to the instance object we can
			// ** safely terminate this search path here.

			return NENUM_ENDPATH;
		}

	// continue search
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : collateAllCameraObjects
   Purpose : node enumeration callback. collate all cameras from the scene
   Parameters : node pointer, INodeTab context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateAllCameraObjects(INode *node, void *context)
{
	INodeTab	*nodeTabPtr;
	Object		*object;

	nodeTabPtr = (INodeTab *)context;

	object = node->GetObjectRef();
	if (object && object->SuperClassID() == CAMERA_CLASS_ID &&
		// free or target camera?
		(object->ClassID() == Class_ID(SIMPLE_CAM_CLASS_ID, 0) || object->ClassID() == Class_ID(LOOKAT_CAM_CLASS_ID, 0)))
	{
		// ** For Target camera objects the target node isn't logged. The target
		// ** node isn't classed as a CAMERA_CLASS_ID.

		nodeTabPtr->Append(1, &node);
	}

	// continue search
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : findCameraTargetNode
   Purpose : node enumeration callback. find a camera nodes target node
   Parameters : node pointer, TEnumFindTarget context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int findCameraTargetNode(INode *node, void *context)
{
	static TCHAR	name[260];
	TEnumFindTarget	*enumFindCam;

	enumFindCam = (TEnumFindTarget *)context;

	// camera target is usually called [cameraNode Name].target by default
	// (this isn't the most elegant way of finding this put it will do for now. Just need to let
	//  the artists know).
	_stprintf(name, "%s.%s", enumFindCam->node->GetName(), _T("target"));
	if (_tcsicmp(name, node->GetName()) == 0)
	{
		enumFindCam->targetNode = node;
		return NENUM_END;
	}

	// continue search
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : collateAllLightObjects
   Purpose : node enumeration callback. collate all light from the scene
   Parameters : node pointer, INodeTab context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateAllLightObjects(INode *node, void *context)
{
	INodeTab	*nodeTabPtr;
	Object		*object;

	nodeTabPtr = (INodeTab *)context;

	object = node->GetObjectRef();
	if (object && object->SuperClassID() == LIGHT_CLASS_ID &&
		// onmi(ambient),  spot(target) and free spot lights
		(object->ClassID() == Class_ID(OMNI_LIGHT_CLASS_ID, 0) || object->ClassID() == Class_ID(SPOT_LIGHT_CLASS_ID, 0) || object->ClassID() == Class_ID(FSPOT_LIGHT_CLASS_ID, 0)))
	{
		// ** For Target light objects the target node isn't logged. The target
		// ** node isn't classed as a LIGHT_CLASS_ID.

		nodeTabPtr->Append(1, &node);
	}

	// continue search
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : findLightTargetNode
   Purpose : node enumeration callback. find a light nodes target node
   Parameters : node pointer, TEnumFindTarget context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int findLightTargetNode(INode *node, void *context)
{
	static TCHAR	name[260];
	TEnumFindTarget	*enumFindLight;

	enumFindLight = (TEnumFindTarget *)context;

	// light target is usually called [lightNode Name].target by default
	// (this isn't the most elegant way of finding this put it will do for now. Just need to let
	//  the artists know).
	_stprintf(name, "%s.%s", enumFindLight->node->GetName(), _T("target"));
	if (_tcsicmp(name, node->GetName()) == 0)
	{
		enumFindLight->targetNode = node;
		return NENUM_END;
	}

	// continue search
	return NENUM_CONTINUE;
}


// **** Example Routines **********************************************************

/* --------------------------------------------------------------------------------
   Function : collateObjectInstances
   Purpose : node enumeration callback. collate all "Instance" nodes in this branch
   Parameters : node class pointer, context [float *]
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateObjectInstances(CPMNode *node, void *context)
{
	float	*transVecs;

	transVecs = (float *)context;

	// get position vector from this node
	if (!node->GetAttrib("PosX", transVecs[0]))
		transVecs[0] = 0.f;
	if (!node->GetAttrib("PosY", transVecs[1]))
		transVecs[1] = 0.f;
	if (!node->GetAttrib("PosZ", transVecs[2]))
		transVecs[2] = 0.f;

	// get rotation vector from this node
	if (!node->GetAttrib("RotX", transVecs[4]))
		transVecs[4] = 0.f;
	if (!node->GetAttrib("RotY", transVecs[5]))
		transVecs[5] = 0.f;
	if (!node->GetAttrib("RotZ", transVecs[6]))
		transVecs[6] = 0.f;
	if (!node->GetAttrib("RotW", transVecs[7]))
		transVecs[7] = 0.f;

	// get scale vector from this node
	if (!node->GetAttrib("SclX", transVecs[8]))
		transVecs[8] = 0.f;
	if (!node->GetAttrib("SclY", transVecs[9]))
		transVecs[9] = 0.f;
	if (!node->GetAttrib("SclZ", transVecs[10]))
		transVecs[10] = 0.f;

	// check all nodes on this branch
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : collateObjectsNodes
   Purpose : node enumeration callback. collate all "Object" nodes in the level tree
   Parameters : node class pointer, context [int *]
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
   Info : 
*/

static int collateObjectsNodes(CPMNode *node, void *context)
{
	char	*string;
	float	transVecs[3+4+3];

	// count this object node
	((int *)context)[0]++;

	// get "Name" attribute from this string
	string = node->GetAttrib("NaMe");				// case insensitive
	// string == NULL - error!


	// ** We may now want to check for instances of this object, which
	// ** we know are children below this node.

	// collate all instances of this object node
	node->EnumNodes(collateObjectInstances, transVecs, "Instance");


	// ** Since we know that no other "Object" nodes are below this one, we
	// ** can instruct the enumeration to end this hierachy path.

	// terminate this enumeration path
	return NENUM_ENDPATH;
}


/* --------------------------------------------------------------------------------
   Function : exampleLoadLOMFile
   Purpose : example of how load and use a .lom file
   Parameters : pointer to .lom file name
   Returns : 1 - okay, 0 - error
   Info : 
*/

static int exampleLoadLOMFile(char *filename)
{
	CPMLevel	*levelInst;
	int			noofObjs;


	// ** Load our Level Object Map file. If succesful an pointer to an instance
	// ** of a level class is returned. This class essentially holds our map file
	// ** in a tree structure. Methods are supplied to enumerate the tree.

	// load our Level Object Map file.
	if ((levelInst = pmLoadLevel(filename)) == NULL)
	{
		// !file error!
		return 0;
	}


	// ** All access to the tree is done through enumerated callbacks. (If you prefer
	// ** to access the tree through loops, let me know and i'll add the required
	// ** methods for you.)

	// this methods is used to enumerate every "Object" node in our level tree
	// (if the last parameter is omitted, every node is visited)
	noofObjs = 0;
	levelInst->EnumNodes(collateObjectsNodes, &noofObjs, "Object");

	// delete our level instance
	pmDeleteLevel(levelInst);

	return 1;
}
