
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : OBEExport.h
// Purpose : OBE File Export class
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __OBEEXPORT__H
#define __OBEEXPORT__H

#include "OBEFile.h"
#include "PerFaceData.h"

#define	OBEEXP_CLASS_ID		Class_ID(0x4c99506b, 0x33a80606)


// -----------------
// Types and Classes

// max polygon order
typedef struct _TPolyEntry
{
	int	noof;						// noof tris which make up this polygon
	int	tris[16];					// indices of tris which make up this polygon
} TPolyEntry;


// --------------------------------------------------------------------------------
// OBEImport class
// --------------------------------------------------------------------------------
class OBEExport : public SceneExport
{
	public:

		// interface pointers
		Interface				*ip;											// max interface
		ExpInterface			*exportPtr;										// export interface

		// current configuration
		UCHAR					configExportAnimation;							// export animation
		UCHAR					configExportPerFaceData;						// export "PerFaceData" data and format
		UCHAR					configEvalKeysToLinear;							// evaluate animation key controllers as linear
		UCHAR					configCopyUsedTextures;							// copy used texture maps to common directory
		TCHAR					configCopyUsedTexturePath[260];					// used texture path

		// export file
		TCHAR					exportFileName[260];							// filename
		FILE					*fileHandle;									// file handle

		// export stacks
		Stack<int>				stackFilePos;									// file position stack
		Stack<void *>			stackObe;										// obe resource stack

		// scene vars
		INode					*objectRootNode;								// object root node
		INode					*softSkinMeshNode;								// soft skinning mesh node
		INode					*hardSkinMeshNode;								// node that the skin modifier is applied to
		SkinData				*hardSkinData;									// instance of scene skin data
		int						hardSkinDataValid;								// skin data valid flag

		Tab<TTexturePath>		usedTextures;									// used texture maps for exporting

		Tab<TPolyEntry>			maxPolyOrder;									// max mesh polygon order list. used when converting mesh into quads


		// progress bar
		float					progressScaler;			// progress bar scaler
		int						progressNodeCount;		// progress node count



								// OBEExport constructor 
								OBEExport();
								// OBEExport destructor
								~OBEExport();

		// SceneImport Methods
								// number of filename extensions supported by the importer
		int						ExtCount();
								// returns the 'i-th' supperted file extension
		const TCHAR				*Ext(int i);
								// returns a long ASCII description of the filetype
		const TCHAR				*LongDesc();
								// returns a short ASCII description of the filetype
		const TCHAR				*ShortDesc();
								// returns the ASCII authors name
		const TCHAR				*AuthorName();
								// returns the ASCII copyright message
		const TCHAR				*CopyrightMessage();
								// returns other messages
		const TCHAR				*OtherMessage1();
		const TCHAR				*OtherMessage2();
								// returns the plugin version number
		unsigned int			Version();
								// allows the plugin to show its about box
		void					ShowAbout(HWND hWnd);

								// performs the actual file import
#if MAX_RELEASE >= 3000
		int						DoExport(const TCHAR *fileNamePtr, ExpInterface *exportPtr, Interface *ip, BOOL suppressPrompts, unsigned long options);
#else
		int						DoExport(const TCHAR *fileNamePtr, ExpInterface *exportPtr, Interface *ip, BOOL suppressPrompts);
#endif

#if MAX_RELEASE >= 3000
								// are all option bits supported?
		BOOL					SupportsOptions(int ext, DWORD options);
#endif

		// OBEExport Methods

								// export an OBE file from root node
		int						DoExportRoot(const TCHAR *fileNamePtr, INode *root, INodeTab *excludeNodeTab = NULL);

								// read / write user configuration file
		void					ReadConfig();
		void					WriteConfig();

								// begin a new OBE chunk
		int						BeginWriteChunk(int chunkid, int version);
								// ends an OBE chunk
		void					EndWriteChunk(int pos);

								// write animation time chunk
		void					WriteChunk_AnimTime();

								// write animation segments chunk
		int						WriteChunk_AnimSegments(INode *node);

								// write animation notes chunk
		int						WriteChunk_AnimNotes(INode *nodePtr);

								// write anim note commands chunk
		void					WriteChunk_NodeAnimCommands(INode *node);

								// write "PerFaceData" modifier data and format data
		void					WriteChunk_PerFaceData(INode *node);

								// pre/post write mesh chunk
		int						preWriteChunk_Mesh(INode *node);
		int						postWriteChunk_Mesh(INode *node);

								// pre/post write hard bone chunk
		int						preWriteChunk_HardBone(INode *node);
		int						postWriteChunk_HardBone(INode *node);

								// pre/post write soft bone chunk
		int						preWriteChunk_SoftBone(INode *node);
		int						postWriteChunk_SoftBone(INode *node);

								// identify node
		int						IsNodeBone(INode *nodePtr);

								// convert node to obe mesh
		int						NodeToObeMesh(INode *node, ObeMesh *obeMeshPtr);
								// convert node to obe bone
		int						NodeToObeBone(INode *node, ObeBone *obeBonePtr);
								// convert node to an obe max mesh
		int						NodeToObeMaxBone(INode *nodePtr, ObeMaxBone *obePtr);

								// export linear position animation from node
		void					ExportAnimPos(INode * nodePtr, AnimVector& posX, AnimVector& posY, AnimVector& posZ, Point3& refPos, Matrix3& offsetMatrix = Matrix3(TRUE));
								// export linear rotation animation from node
		void					ExportAnimRot(INode * nodePtr, AnimVector & rotX, AnimVector & rotY, AnimVector & rotZ, AnimVector & rotW, Quat & refRot);
								// export linear scale animation from node
		void					ExportAnimScale(INode * nodePtr, AnimVector & scaleX, AnimVector & scaleY, AnimVector & scaleZ, Point3 & refScale);

								// write the additional polygon data which follows immediately after the obe mesh chunks
		void					WriteExtraMeshData(ObeMesh *obeMesh);

								// read in this nodes note tracks
		void					ReadNodeNoteTracks(INode * nodePtr);

								// using the MAX mesh edge infomation try and optimise OBE mesh to quads
		void					ToQuads(ObeMesh *obeMesh, INode *node);

								// write all used texture maps into directory path
		void					WriteTextureMaps(TCHAR *path, Tab<TTexturePath>& textures);


// ********************************************************************************
// Experimental Methods
// ********************************************************************************

								// export patches
		int						ExportPatches();
};

#endif
