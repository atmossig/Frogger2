
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 2000 Interactive Studios Ltd.
//
//    File : OBEFile.h
// Purpose : Common header for both exporter and importer
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __OBEFILE__H
#define __OBEFILE__H

#include "max.h"
#include "stdmat.h"
#include "istdplug.h"
#include "modstack.h"
#include "bmmlib.h"
#if MAX_RELEASE >= 3000
#include "iparamb2.h"
#include "iparamm2.h"
#else
#include "iparamb.h"
#include "iparamm.h"
#endif

#include "meshadj.h"

#include <io.h>

#include "OBEStruct.h"
#include "CommonFiles.h"

#include "stringlist.h"
#include "textureinfolist.h"

#include "skinregister.h"
#include "skindata.h"

#include "resource.h"


// ** As of 2000/11/30 i am packing more data into the Max file format than is strictly
// ** allowed. All data will be packed into existing floats. You will notice from below
// ** that i have used 255 in the MSB of the float value as an identification marker.
// ** The ident value of 255 in the MSB of the float forces the float out of range for
// ** any possibility of a potential valid value.
// ** The union is as follows:
// **	union
// **	{
// **		float	f;
// **		UINT	f32;
// **		USHORT	f16[2];
// **		UCHAR	f8[4];
// **	} ufloat;
// **
// ** Version 1:
// **
// ** The texture UV will be stored as follows:
// **	UVVert (Point3)
// **	.x - f = U value
// **	.y - f = V value
// **	.z - f32 = 255 ident 8bits + version number 6bits + VTile/100 9bits + UTile/100 9bits
// **
// ** The gouruad vertex colours will be stored as follows:
// **	VertColor (Point3)
// **	.x - f8[0] = R  f8[1] = G  f8[2] = B  f8[3] = A
// **	.y - f = 0.0f;
// **	.z - f8[0] = ??  f8[1] = ??  f8[2] = version number  f8[3] = 255 ident
// **
// **
// ** Version 2:
// **
// ** The texture UV will be stored as follows:
// **	UVVert (Point3)
// **	.x - f = U value
// **	.y - f = V value
// **	.z - f32 = 255 ident 8bits + version number 6bits + VTile/100 9bits + UTile/100 9bits
// **
// ** The gouruad vertex colour and polygon colour will be stored as follows:
// **	VertColor (Point3)
// **	.x - f8[0] = R  f8[1] = G  f8[2] = B  f8[3] = A
// **	.y - f8[0] = R,G or B polygon colour component. (g[0] = R, g[1] = G, g[2] = B
// **	.z - f8[0] = ??  f8[1] = ??  f8[2] = version number  f8[3] = 255 ident

// packed union float
typedef struct _UFLOAT
{
	union
	{
		float	f;
		UINT	f32;
		USHORT	f16[2];
		UCHAR	f8[4];
	};
} UFLOAT;

// current packed version
#define PACKED_VERTS_VERSION	2


// OBE PerFaceData Names
#define OBEDATANAME1	_T("OBE Data")
#define OBEDATANAME2	_T("JobeData")

// "About" dialog procedure
BOOL CALLBACK AboutDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam);


/* --------------------------------------------------------------------------------
   Structure : TTexturePath
   Purpose : texture path
   Info : 
*/
typedef struct
{
	TCHAR				path[_MAX_PATH];				// texture path
	unsigned char		flags;							// flags (see above)
} TTexturePath;


/* --------------------------------------------------------------------------------
   Structure : TTextureSet
   Purpose : a texture path set containing a list of all texture paths
   Info : 
*/
typedef struct
{
	TCHAR				ident[_MAX_PATH];				// texture set name ident
	Tab<TTexturePath>	paths;							// texture paths contained in this path
} TTextureSet;


/* --------------------------------------------------------------------------------
   Function : GetNodeMesh
   Purpose : get the nodes mesh
   Parameters : max node pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

Mesh *GetNodeMesh(INode *nodePtr);


/* --------------------------------------------------------------------------------
   Function : GetUniqueMeshId
   Purpose : uniquely identify this mesh
   Parameters : max mesh
   Returns : 
   Info : 
*/

ULONG GetUniqueMeshId(Mesh *mesh);

#endif
