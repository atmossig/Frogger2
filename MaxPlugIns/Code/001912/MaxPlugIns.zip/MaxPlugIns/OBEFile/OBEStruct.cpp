
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : obestruc.cpp
// Purpose : implementation of all obe classes
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "obestruct.h"
#include "OBEFile.h"


// --------------------------------------------------------------------------------
// FileBase class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : FileBase::FileBase
   Purpose : constructor
   Parameters : 
   Returns : 
   Info 
: 
*/

FileBase::FileBase()
{
	errorFlag = 0;
}


/* --------------------------------------------------------------------------------
   Function : FileBase::FileBase
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

FileBase::~FileBase()
{
}


/* --------------------------------------------------------------------------------
   Function : FileBase::ReadData
   Purpose : read data from file
   Parameters : file handle pointer, data pointer, data length
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int FileBase::ReadData(FILE *filePtr, void *dataPtr, int dataLen)
{
	fread(dataPtr, sizeof(char), dataLen, filePtr);
	errorFlag = (ferror(filePtr) != 0) ? 1:0;
	return errorFlag ? 0:1;
}


/* --------------------------------------------------------------------------------
   Function : FileBase::WriteData
   Purpose : write data into file
   Parameters : file handle pointer, data pointer, data length
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int FileBase::WriteData(FILE *filePtr, void *dataPtr, int dataLen)
{
	fwrite(dataPtr, sizeof(char), dataLen, filePtr);
	errorFlag = (ferror(filePtr) != 0) ? 1:0;
	return errorFlag ? 0:1;
}


/* --------------------------------------------------------------------------------
   Function : FileBase::IsError
   Purpose : as error occurred?
   Parameters : 
   Returns : 0 - noerror, 1 - error
   Info : 
*/

int FileBase::IsError()
{
	return errorFlag ? 1:0;
}


// --------------------------------------------------------------------------------
// AnimVector class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : AnimVector::AnimVector
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

AnimVector::AnimVector()
{
	keyArrayPtr = NULL;
	numKeys = 0;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::AnimVector
   Purpose : constructor
   Parameters : number of vectors
   Returns : 
   Info : 
*/

AnimVector::AnimVector(int numKeys)
{
	keyArrayPtr = NULL;
	numKeys = 0;
	SetNumKeys(numKeys, FALSE);
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::~AnimVector
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

AnimVector::~AnimVector()
{
	SAFE_DELETE_ARRAY(keyArrayPtr)
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::SetNumKeys
   Purpose : set number of keys
   Parameters : number of keys, [keep current keys]
   Returns : 
   Info : 
*/

int AnimVector::SetNumKeys(int numKeys, int keepFlag)
{
	TIME_VALUE_KEY	*tempPtr;
	int				i, numCopy;

	tempPtr = (numKeys > 0) ? new TIME_VALUE_KEY[numKeys] : NULL;
	if (tempPtr != NULL && keepFlag == 1)
	{
		numCopy = min(this->numKeys, numKeys);
		if (keyArrayPtr != NULL)
			for (i=0; i<numCopy; i++)
			{
				tempPtr[i].frameNum = keyArrayPtr[i].frameNum;
				tempPtr[i].data = keyArrayPtr[i].data;
			}
	}
	SAFE_DELETE_ARRAY(keyArrayPtr)
	keyArrayPtr = tempPtr;
	this->numKeys = numKeys;

	errorFlag = 0;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::GetNumKeys
   Purpose : get number of keys
   Parameters : 
   Returns : number of keys in the array
   Info : 
*/

int AnimVector::GetNumKeys()
{
	return numKeys; 
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::GetKeyIndex
   Purpose : get key index from the frame number
   Parameters : frame number
   Returns : key index or -1 for no key
   Info : 
*/

int AnimVector::GetKeyIndex(int frameNum)
{
	int i;
	for(i=0; i < numKeys; i++)
	{
		if (keyArrayPtr[i].frameNum == frameNum)
			return i;
	}
	return -1;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::SetKey
   Purpose : set a key in the array
   Parameters : key index, key pointer
   Returns : 
   Info : 
*/

void AnimVector::SetKey(int keyIndex, TIME_VALUE_KEY *keyPtr)
{
	if (keyIndex >= numKeys || keyPtr == NULL)
	  return;
	keyArrayPtr[keyIndex].frameNum = keyPtr->frameNum;
	keyArrayPtr[keyIndex].data = keyPtr->data;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::GetKey
   Purpose : get a key from the array
   Parameters : key index, key pointer
   Returns : 
   Info : 
*/

void AnimVector::GetKey(int keyIndex, TIME_VALUE_KEY *keyPtr)
{
	if (keyIndex >= numKeys || keyPtr == NULL)
	  return;
	keyPtr->frameNum = keyArrayPtr[keyIndex].frameNum;
	keyPtr->data = keyArrayPtr[keyIndex].data;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::Clone
   Purpose : clone anim vector
   Parameters : anim vector pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int	AnimVector::Clone(AnimVector * cloneAnimVecPtr)
{
	int	i;
	if (cloneAnimVecPtr == NULL)
		return 0;
	SetNumKeys(cloneAnimVecPtr->GetNumKeys());
	for (i=0; i<numKeys; i++)
	{
		keyArrayPtr[i].frameNum = cloneAnimVecPtr->keyArrayPtr[i].frameNum;
		keyArrayPtr[i].data = cloneAnimVecPtr->keyArrayPtr[i].data;
	}
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::Read
   Purpose : read anim vector from file
   Parameters : file handle pointer, current version
   Returns : 
   Info : 
*/

int AnimVector::Read(FILE *filePtr, int version)
{
	int		i;
	long	num;

	if (!ReadData(filePtr, &num, 4))
		return 0;
	if (!SetNumKeys((int)num))
		return 0;
	for (i=0; i<(int)num; i++)
	{
		if (!ReadData(filePtr, &keyArrayPtr[i], sizeof(TIME_VALUE_KEY)))
			return 0;
//		// ** DEBUG 20/06/2000
//		DPrintf("%0.18f", keyArrayPtr[i].data);
//		//    DEBUG **
	}
	
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : AnimVector::Write
   Purpose : wirte anim vector to file
   Parameters : file handle ptr
   Returns : 
   Info : 
*/

int AnimVector::Write(FILE *filePtr)
{
	int i;

	if (!WriteData(filePtr, &numKeys, sizeof(numKeys)))
		return 0;
	for (i=0; i<numKeys; i++)
	{
		if (!WriteData(filePtr, &keyArrayPtr[i], sizeof(TIME_VALUE_KEY)))
			return 0;
//		// ** DEBUG 20/06/2000
//		DPrintf("%0.18f", keyArrayPtr[i].data);
//		//    DEBUG **
	}
	return 1;
}


// --------------------------------------------------------------------------------
// VertexType class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : VertexType::VertexType
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

VertexType::VertexType()
{
	x = y = z = NULL;
	x = new AnimVector;
	y = new AnimVector;
	z = new AnimVector;
	selected = 0;
}


/* --------------------------------------------------------------------------------
   Function : VertexType::VertexType
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

VertexType::~VertexType()
{
	SAFE_DELETE(x)
	SAFE_DELETE(y)
	SAFE_DELETE(z)
}


/* --------------------------------------------------------------------------------
   Function : VertexType::Read
   Purpose : read in from file
   Parameters : file handle pointer, current version
   Returns : 
   Info : 
*/

int VertexType::Read(FILE *filePtr, int version)
{
	x->Read(filePtr, version);
	y->Read(filePtr, version);
	z->Read(filePtr, version);
	ReadData(filePtr, &selected, sizeof(selected));
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : VertexType::Write
   Purpose : read in from file
   Parameters : file handle pointer
   Returns : 
   Info : 
*/

int VertexType::Write(FILE *filePtr)
{
	x->Write(filePtr);
	y->Write(filePtr);
	z->Write(filePtr);
	WriteData(filePtr, &selected, sizeof(selected));
	return 1;
}

	
// --------------------------------------------------------------------------------
// SortList class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : SortList::SortList
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

SortList::SortList()
{
	this->listLen = 0;
	arrayPtr = NULL;
}


/* --------------------------------------------------------------------------------
   Function : SortList::SortList
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

SortList::SortList(int listLen)
{
	this->listLen = 0;
	arrayPtr = NULL;
	SetLength(listLen);
}


/* --------------------------------------------------------------------------------
   Function : SortList::SortList
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

SortList::~SortList()
{
	listLen = 0;
	SAFE_DELETE_ARRAY(arrayPtr)
}


/* --------------------------------------------------------------------------------
   Function : SortList::SetLength
   Purpose : set the array length
   Parameters : array length
   Returns : 
   Info : 
*/

int SortList::SetLength(int listLen)
{
	int	*listPtr;

	listPtr = (listLen > 0) ? new int[listLen] : NULL;
	SAFE_DELETE_ARRAY(arrayPtr)
	arrayPtr = listPtr;
	this->listLen = listLen;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SortList::GetLength
   Purpose : get the array length
   Parameters : 
   Returns : array length
   Info : 
*/

int SortList::GetLength()
{
	return listLen;
};


/* --------------------------------------------------------------------------------
   Function : SortList::GetItem
   Purpose : get index item
   Parameters : index, data item pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SortList::GetItem(int index, int *data)
{
	if (index >= listLen)
		return 0;
	*data = arrayPtr[index];
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SortList::SetItem
   Purpose : set index item
   Parameters : index, data item pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SortList::SetItem(int index, int *data)
{
	if (index >= listLen)
		return 0;
	arrayPtr[index] = *data;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SortList::Read
   Purpose : read sortlist from file
   Parameters : file handle pointer, current version
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SortList::Read(FILE *filePtr, int version)
{
	int		i;
	long	len, data;

	ReadData(filePtr, &len, sizeof(len));
	SetLength(len);
	for (i=0; i<len; i++)
	{
		ReadData(filePtr, &data, sizeof(data));
		arrayPtr[i] = (int)data;
	}
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SortList::Read
   Purpose : read sortlist from file
   Parameters : file handle pointer, current version
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SortList::Write(FILE *filePtr)
{
	int		i;
	long	len, data;

	len = (long)listLen;
	WriteData(filePtr, &len, sizeof(len));
	for (i=0; i<len; i++)
	{
		data = (long)arrayPtr[i];
		WriteData(filePtr, &data, sizeof(data));
	}
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SortList::Clone
   Purpose : clone sortlist
   Parameters : sortlist pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SortList::Clone(SortList * cloneSort)
{
	int i;
	if (cloneSort == NULL)
		return 0;
	SetLength(cloneSort->GetLength());
	for (i=0; i<listLen; i++)
		arrayPtr[i] = cloneSort->arrayPtr[i];
	return 1;
}


// --------------------------------------------------------------------------------
// SpriteInfo class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : SpriteInfo::SpriteInfo
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

SpriteInfo::SpriteInfo()
{
	xFlipped = 0;
	yFlipped = 0;
}


/* --------------------------------------------------------------------------------
   Function : SpriteInfo::SpriteInfo
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

SpriteInfo::~SpriteInfo()
{
	xFlipped = 0;
	yFlipped = 0;
}


/* --------------------------------------------------------------------------------
   Function : SpriteInfo::CopyTo
   Purpose : copy to polygon info
   Parameters : polygon info pointer to copy to
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int	SpriteInfo::CopyTo(SpriteInfo *spriteInfoPtr)
{
	if (spriteInfoPtr == NULL)
		return 0;
	spriteInfoPtr->xPos.Clone(&xPos);
	spriteInfoPtr->yPos.Clone(&yPos);
	spriteInfoPtr->zPos.Clone(&zPos);
	spriteInfoPtr->xSize.Clone(&xSize);
	spriteInfoPtr->ySize.Clone(&ySize);
	spriteInfoPtr->xFlipped = xFlipped;
	spriteInfoPtr->yFlipped = yFlipped;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SpriteInfo::CopyFrom
   Purpose : copy from polygon info
   Parameters : polygon info pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int	SpriteInfo::CopyFrom(SpriteInfo *spriteInfoPtr)
{
	if (spriteInfoPtr == NULL)
		return 0;
	xPos.Clone(&spriteInfoPtr->xPos);
	yPos.Clone(&spriteInfoPtr->yPos);
	zPos.Clone(&spriteInfoPtr->zPos);
	xSize.Clone(&spriteInfoPtr->xSize);
	ySize.Clone(&spriteInfoPtr->ySize);
	xFlipped = spriteInfoPtr->xFlipped;
	yFlipped = spriteInfoPtr->yFlipped;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SpriteInfo::Read
   Purpose : read from file
   Parameters : file handle pointer, current version
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SpriteInfo::Read(FILE *filePtr, int version)
{
	xPos.Read(filePtr, version);
	yPos.Read(filePtr, version);
	zPos.Read(filePtr, version);
	xSize.Read(filePtr, version);
	ySize.Read(filePtr, version);
	ReadData(filePtr, &xFlipped, sizeof(xFlipped));
	ReadData(filePtr, &yFlipped, sizeof(yFlipped));
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : SpriteInfo::Write
   Purpose : write to file
   Parameters : file handle pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int SpriteInfo::Write(FILE *filePtr)
{
	xPos.Write(filePtr);
	yPos.Write(filePtr);
	zPos.Write(filePtr);
	xSize.Write(filePtr);
	ySize.Write(filePtr);
	WriteData(filePtr, &xFlipped, sizeof(xFlipped));
	WriteData(filePtr, &yFlipped, sizeof(yFlipped));
	return 1;
}


// --------------------------------------------------------------------------------
// PolyInfo class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PolyInfo::PolyInfo
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

PolyInfo::PolyInfo()
{
	// set default attributes:
	lightIntensity = 0;								// zero lighting intensity
	u = v = 0;										// zero UVs (0..1)
	gCol[0] = gCol[1] = gCol[2] = gCol[3] = 255;	// vertex gouraud colour white

	// NULL vars
	vertIndex = 0;
}


/* --------------------------------------------------------------------------------
   Function : PolyInfo::PolyInfo
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

PolyInfo::~PolyInfo()
{
}


/* --------------------------------------------------------------------------------
   Function : PolyInfo::CopyTo
   Purpose : copy to polygon info
   Parameters : polygon info pointer to copy to
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int	PolyInfo::CopyTo(PolyInfo *polyInfoPtr)
{
	if (polyInfoPtr == NULL)
		return 0;
	polyInfoPtr->vertIndex = vertIndex;
	polyInfoPtr->lightIntensity	= lightIntensity;
	polyInfoPtr->u = u;
	polyInfoPtr->v = v;
	polyInfoPtr->gCol[0] = gCol[0];
	polyInfoPtr->gCol[1] = gCol[1];
	polyInfoPtr->gCol[2] = gCol[2];
	polyInfoPtr->gCol[3] = gCol[3];
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyInfo::CopyFrom
   Purpose : copy from polygon info
   Parameters : polygon info pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int	PolyInfo::CopyFrom(PolyInfo *polyInfoPtr)
{
	if (polyInfoPtr == NULL)
		return 0;
	vertIndex = polyInfoPtr->vertIndex;
	lightIntensity = polyInfoPtr->lightIntensity;
	u = polyInfoPtr->u;
	v = polyInfoPtr->v;
	gCol[0] = polyInfoPtr->gCol[0];
	gCol[1] = polyInfoPtr->gCol[1];
	gCol[2] = polyInfoPtr->gCol[2];
	gCol[3] = polyInfoPtr->gCol[3];
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyInfo::Read
   Purpose : read info
   Parameters : file handle pointer, current version
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyInfo::Read(FILE *filePtr, int version)
{
	ReadData(filePtr, &vertIndex, 2);
	ReadData(filePtr, &lightIntensity, 1);
	ReadData(filePtr, &u, sizeof(float));
	ReadData(filePtr, &v, sizeof(float));
	if (version >= 5)
		ReadData(filePtr, gCol, 3);
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyInfo::Write
   Purpose : write info
   Parameters : file handle pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyInfo::Write(FILE *filePtr)
{
	WriteData(filePtr, &vertIndex, 2);
	WriteData(filePtr, &lightIntensity, 1);
	WriteData(filePtr, &u, sizeof(float));
	WriteData(filePtr, &v, sizeof(float));
	WriteData(filePtr, gCol, 3);
	return 1;
}


// --------------------------------------------------------------------------------
// PolyType class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : PolyType::PolyType
   Purpose : constructor
   Parameters : 
   Returns : 
   Info : 
*/

PolyType::PolyType()
{
	// set default attributes:
	texture[0] = 0;									// no texture map
	colRGB[0] = colRGB[1] = colRGB[2] = 255;		// polygon colour white
	transVal = 255;									// full translucency value
	transMode = TRANSLUCENCYMODE_ALPHA;				// use slider translucency mode
	gColMode = GOURAUDMODE_COLOUR;					// use vertex gouraud shading
	tileU = 1*1000;									// 1*1000 (tiling values are held *1000)
	tileV = 1*1000;									// 1*1000
	selected = 0;									// face not selected
	flags = OBEPOLYFLAG_DRAWTHISFACE |				// draw this face
			OBEPOLYFLAG_FILTERTEXTURE;				// filter texture map

	// NULL vars
	numVerts = 0;
	verts = NULL;
	spriteInfoPtr = NULL;

	NDOFlag = 0;									// clear NDO flag		*SAVED IN EXTRA CHUNK*
	terFlag = 0;									// clear terrain flag	*SAVED IN EXTRA CHUNK*
	dualTexture[0] = 0;								// no dual texture		*SAVED IN EXTRA CHUNK*
}


/* --------------------------------------------------------------------------------
   Function : PolyType::PolyType
   Purpose : constructor
   Parameters : number of vertices
   Returns : 
   Info : 
*/

PolyType::PolyType(int numVerts)
{
	PolyType();
	SetNumVerts(numVerts);
}


/* --------------------------------------------------------------------------------
   Function : PolyType::~PolyType
   Purpose : destructor
   Parameters : 
   Returns : 
   Info : 
*/

PolyType::~PolyType()
{
	SAFE_DELETE_ARRAY(verts)
	SAFE_DELETE(spriteInfoPtr)
}


/* --------------------------------------------------------------------------------
   Function : PolyType::SetNumVerts
   Purpose : set number of verts
   Parameters : number verts
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::SetNumVerts(int numVerts)
{
	PolyInfo	*newVertsPtr;

	newVertsPtr = (numVerts > 0) ? new PolyInfo[numVerts] : NULL;
	SAFE_DELETE_ARRAY(verts)
	verts = newVertsPtr;
	this->numVerts = numVerts;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyType::Read
   Purpose : read polygon
   Parameters : file handle pointer, current version
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::Read(FILE *filePtr, int version)
{
	long	lVal;
	short	sVal;
	int		i, spriteFlag;

	// read in polygon data
	ReadData(filePtr, texture, 32);
	ReadData(filePtr, colRGB, 3);
	ReadData(filePtr, &transVal, 1);
	if (version >= 5)
	{
		ReadData(filePtr, &transMode, 1);
		ReadData(filePtr, &gColMode, 1);
	}
	ReadData(filePtr, &lVal, 4);
	tileU = (int)lVal;
	ReadData(filePtr, &lVal, 4);
	tileV = (int)lVal;
	ReadData(filePtr, &selected, 1);
	ReadData(filePtr, &sVal, 2);
	spriteFlag = (sVal & OBEPOLYFLAG_SPRITE) ? 1:0;			// is this polygon a sprite?
	flags = (int)sVal;

	if (spriteFlag == 1)
	{
		// skip polygon count
		ReadData(filePtr, &lVal, 4);
		SetNumVerts(0);
		// build the sprite info block
		spriteInfoPtr = new SpriteInfo;
		spriteInfoPtr->Read(filePtr, version);
	}
	else
	{
		// read number of polygons
		ReadData(filePtr, &lVal, 4);
		numVerts = (int)lVal;
		// read all polygon vertices
		SetNumVerts(numVerts);
		for (i=0; i<numVerts; i++)
			verts[i].Read(filePtr, version);
	}

	// other data loaded later
	//  NDOFlag
	//  terFlag
	//  dualTexture

	return 1;
}

/* --------------------------------------------------------------------------------
   Function : PolyType::Write
   Purpose : write polygon
   Parameters : file handle pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::Write(FILE *filePtr)
{
	long	lVal;
	short	sVal;
	int		i, spriteFlag;

	// write polygon data
	WriteData(filePtr, texture, 32);
	WriteData(filePtr, colRGB, 3);
	WriteData(filePtr, &transVal, 1);
	WriteData(filePtr, &transMode, 1);
	WriteData(filePtr, &gColMode, 1);
	lVal = (long)tileU;
	WriteData(filePtr, &lVal, 4);
	lVal = (long)tileV;
	WriteData(filePtr, &lVal, 4);
	WriteData(filePtr, &selected, 1);
	sVal = (short)flags;
	spriteFlag = (sVal & OBEPOLYFLAG_SPRITE) ? 1:0;			// is this polygon a sprite?
	WriteData(filePtr, &sVal, 2);

	// is this polygon defined as a sprite?
	if (spriteFlag == 1)
	{
		// write zero polygon count
		lVal = 0;
		WriteData(filePtr, &lVal, 4);
		// write sprite data
		if (spriteInfoPtr)
			spriteInfoPtr->Write(filePtr);
	}
	else
	{
		// write number of polygons
		lVal = (long)numVerts;
		WriteData(filePtr, &lVal, 4);
		// write all polygon vertices
		for (i=0; i<numVerts; i++)
			verts[i].Write(filePtr);
	}

	// other data saved later
	//  NDOFlag
	//  terFlag
	//  dualTexture

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyType::CopyTo
   Purpose : copy to polygon
   Parameters : polygon pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::CopyTo(PolyType *polyPtr)
{
	int i;

	if (polyPtr==NULL)
		return 0;

	strcpy(polyPtr->texture, texture);
	polyPtr->colRGB[0] = colRGB[0];
	polyPtr->colRGB[1] = colRGB[1];
	polyPtr->colRGB[2] = colRGB[2];
	polyPtr->transVal = transVal;
	polyPtr->transMode = transMode;
	polyPtr->gColMode = gColMode;
	polyPtr->tileU = tileU;
	polyPtr->tileV = tileV;
	polyPtr->selected  = selected;
	polyPtr->flags = flags;
	polyPtr->numVerts = numVerts;

	polyPtr->SetNumVerts(numVerts);
	for(i=0; i<numVerts; i++)
		verts[i].CopyTo(&polyPtr->verts[i]);

	// copy additional
	polyPtr->NDOFlag = NDOFlag;
	polyPtr->terFlag = terFlag;
	memcpy(polyPtr->dualTexture, dualTexture, 32);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyType::CopyFrom
   Purpose : copy from polygon
   Parameters : polygon pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::CopyFrom(PolyType *polyPtr)
{
	int i;

	if (polyPtr==NULL)
		return 0;

	strcpy(texture, polyPtr->texture);
	colRGB[0] =	polyPtr->colRGB[0];
	colRGB[1] =	polyPtr->colRGB[1];
	colRGB[2] =	polyPtr->colRGB[2];
	transVal = polyPtr->transVal;
	transMode = polyPtr->transMode;
	gColMode = polyPtr->gColMode;
	tileU = polyPtr->tileU;
	tileV = polyPtr->tileV;
	selected = polyPtr->selected;
	flags = polyPtr->flags;
	numVerts = polyPtr->numVerts;

	if (flags & OBEPOLYFLAG_SPRITE)
	{
		// sprite polygon found
		SetNumVerts(0);
		SAFE_DELETE(spriteInfoPtr)
		spriteInfoPtr = new SpriteInfo;
		spriteInfoPtr->CopyFrom(polyPtr->spriteInfoPtr);
	}
	else
	{
		SetNumVerts(numVerts);
		for(i=0; i<numVerts; i++)
			verts[i].CopyFrom(&polyPtr->verts[i]);
	}

	// copy additional
	polyPtr->NDOFlag = NDOFlag;
	polyPtr->terFlag = terFlag;
	memcpy(polyPtr->dualTexture, dualTexture, 32);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyType::QuadToTwoTris
   Purpose : convert a quad polygon into two tris
   Parameters : triA pointer, triB pointer,
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::QuadToTwoTris(PolyType *triAPtr, PolyType *triBPtr)
{
	int	i, index;
	
	if (numVerts != 4)
		return 0;
	if (triAPtr == NULL || triBPtr == NULL)
		return 0;

	// ** triAPtr

	strcpy(triAPtr->texture, texture);
	triAPtr->colRGB[0]			= colRGB[0];
	triAPtr->colRGB[1]			= colRGB[1];
	triAPtr->colRGB[2]			= colRGB[2];
	triAPtr->transVal			= transVal;
	triAPtr->transMode			= transMode;
	triAPtr->gColMode			= gColMode;
	triAPtr->tileU				= tileU;
	triAPtr->tileV				= tileV;
	triAPtr->selected			= selected;
	triAPtr->flags				= flags;
	triAPtr->NDOFlag			= NDOFlag;
	triAPtr->terFlag			= terFlag;
	memcpy(triBPtr->dualTexture, dualTexture, 32);

	// copy over the first 3 verticies (0 to 2)
	index = 0;
	for (i=0; i<3; i++)
	{
		verts[index].CopyTo(&triAPtr->verts[i]);
		index = VERTEX_INDEX_NEXT(index, numVerts);
	}

	// ** triBPtr

	strcpy(triBPtr->texture, texture);
	triBPtr->colRGB[0]			= colRGB[0];
	triBPtr->colRGB[1]			= colRGB[1];
	triBPtr->colRGB[2]			= colRGB[2];
	triBPtr->transVal			= transVal;
	triBPtr->transMode			= transMode;
	triBPtr->gColMode			= gColMode;
	triBPtr->tileU				= tileU;
	triBPtr->tileV				= tileV;
	triBPtr->selected			= selected;
	triBPtr->flags				= flags;
	triBPtr->NDOFlag			= NDOFlag;
	triBPtr->terFlag			= terFlag;
	memcpy(triBPtr->dualTexture, dualTexture, 32);

	// copy over the next 3 verticies (2, 3 and 0)
	index = 2;
	for (i=0; i<3; i++)
	{
		verts[index].CopyTo(&triBPtr->verts[i]);
		index = VERTEX_INDEX_NEXT(index, numVerts);
	}

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : PolyType:TwoTrisToQuad
   Purpose : convert two tris in a quad
   Parameters : triA pointer, triB pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int PolyType::TwoTrisToQuad(PolyType *triAPtr, PolyType *triBPtr)
{
	if (triAPtr->numVerts != 3 || triBPtr->numVerts != 3)
		return 0;

	// copy all polygon info across
	strcpy(texture, triAPtr->texture);
	colRGB[0]			= triAPtr->colRGB[0];
	colRGB[1]			= triAPtr->colRGB[1];
	colRGB[2]			= triAPtr->colRGB[2];
	transVal			= triAPtr->transVal;
	transMode			= triAPtr->transMode;
	gColMode			= triAPtr->gColMode;
	tileU				= triAPtr->tileU;
	tileV				= triAPtr->tileV;
	selected			= triAPtr->selected;
	flags				= triAPtr->flags;
	NDOFlag				= triAPtr->NDOFlag;			
	terFlag				= triAPtr->terFlag;
	memcpy(dualTexture, triAPtr->dualTexture, 32);

	// set quad polygon
	SetNumVerts(4);


	// triA = v0-v1-v2, triB = v2-v3-v0
	verts[0].CopyFrom(&triAPtr->verts[0]);
	verts[1].CopyFrom(&triAPtr->verts[1]);
	verts[2].CopyFrom(&triAPtr->verts[2]);
	verts[3].CopyFrom(&triBPtr->verts[1]);

	return 1;
}


// --------------------------------------------------------------------------------
// ObeMesh class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : ObeMesh::ObeMesh
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

ObeMesh::ObeMesh()
{												// default attributes:
	flags = 0;										// null flags
	rgb[0] = rgb[1] = rgb[2] = 255;					// colour white
	gourMode = GOURAUDMODE_NONE;					// use flat shading
	transMode = TRANSLUCENCYMODE_ALPHA;				// use alpha translucency mode
	transValue = 255;								// full alpha
	selected = 0;									// mesh not selected

	loadPolyOrder = NULL;
	loadNumPolys = 0;

	numVert = 0;
	vertArray = NULL;
	numPoly = 0;
	polyArray = NULL;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::ObeMesh
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

ObeMesh::~ObeMesh()
{
	SAFE_DELETE_ARRAY(vertArray)
	SAFE_DELETE_ARRAY(polyArray)
	SAFE_FREE(loadPolyOrder)
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::Read
   Purpose : read in the entire obe mesh
   Parameters : file handle ptr, chunk version
   Returns : 
   Info : 
*/

int ObeMesh::Read(FILE *filePtr, int version)
{
	int		i;
	long	lVal;
	short	sVal;

	// read the mesh name
	memset(meshName, 0, 32);
	ReadData(filePtr, meshName, 32);
	DPrintf("mesh name: %s, version: %d", meshName, version);

	// read the mesh positions
	posX.Read(filePtr, version);
	posY.Read(filePtr, version);
	posZ.Read(filePtr, version);

	// read the mesh scales
	scaleX.Read(filePtr, version);
	scaleY.Read(filePtr, version);
	scaleZ.Read(filePtr, version);

	// read the mesh orientations
	orientationX.Read(filePtr, version);
	orientationY.Read(filePtr, version);
	orientationZ.Read(filePtr, version);
	orientationW.Read(filePtr, version);

	// read the mesh vertices
	ReadData(filePtr, &lVal, 4);
	numVert = (int)lVal;
	SetNumVerts(numVert);
	for (i=0; i<numVert; i++)
		vertArray[i].Read(filePtr, version);

	// read the mesh polygons
	ReadData(filePtr, &lVal, 4);
	numPoly = (int)lVal;
	SetNumPolys(numPoly);
	for (i=0; i<numPoly; i++)
		polyArray[i].Read(filePtr, version);

	// read the mesh flags
	ReadData(filePtr, &sVal, 2);
	flags = (int)sVal;

	// read the mesh RGB
	ReadData(filePtr, rgb, 3);

	if (version >= 5)
	{
		// read the mesh gouraud shading mode
		ReadData(filePtr, &gourMode, 1);

		// read the mesh translucency
		ReadData(filePtr, &transValue, 1);
		ReadData(filePtr, &transMode, 1);
	}

	if (version >= 2)
	{
		// read the mesh selection
		ReadData(filePtr, &selected, 1);
	}

	if (version >= 6)
	{
		// read the mesh sort list
		for (i=0; i < 8; i++)
			sortList[i].Read(filePtr, version);
	}

	DPrintf("vertices: %d, polygons: %d", numVert, numPoly);
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::Write
   Purpose : read in the entire obe mesh
   Parameters : file handle ptr
   Returns : 
   Info : 
*/

int ObeMesh::Write(FILE *filePtr)
{
	int		i;
	long	lVal;
	short	sVal;

	// write the mesh name
	WriteData(filePtr, meshName, 32);

	// write the mesh positions
	posX.Write(filePtr);
	posY.Write(filePtr);
	posZ.Write(filePtr);

	// write the mesh scales
	scaleX.Write(filePtr);
	scaleY.Write(filePtr);
	scaleZ.Write(filePtr);

	// write the mesh orientations
	orientationX.Write(filePtr);
	orientationY.Write(filePtr);
	orientationZ.Write(filePtr);
	orientationW.Write(filePtr);

	// write the mesh vertices
	lVal = (long)numVert;
	WriteData(filePtr, &lVal, 4);
	for (i=0; i<numVert; i++)
		vertArray[i].Write(filePtr);

	// write the mesh polygons
	lVal = (long)numPoly;
	WriteData(filePtr, &lVal, 4);
	for (i=0; i<numPoly; i++)
		polyArray[i].Write(filePtr);

	// write the mesh flags
	sVal = (short)flags;
	WriteData(filePtr, &sVal, 2);

	// write the mesh RGB
	WriteData(filePtr, rgb, 3);

	// write the mesh gouraud shading mode
	WriteData(filePtr, &gourMode, 1);

	// write the mesh translucency
	WriteData(filePtr, &transValue, 1);
	WriteData(filePtr, &transMode, 1);

	// write the mesh selection
	WriteData(filePtr, &selected, 1);

	// write the sort lists
	for (i=0; i < 8; i++)
		sortList[i].Write(filePtr);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::SetNumVerts
   Purpose : set the number of vertices
   Parameters : number of vertices
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int ObeMesh::SetNumVerts(int numVerts)
{
	VertexType	*vertPtr;
	int			i;

	vertPtr = (numVerts > 0) ? new VertexType[numVerts] : NULL;
	SAFE_DELETE_ARRAY(vertArray)
	vertArray = vertPtr;
	numVert = numVerts;
	for (i=0; i < numVert; i++)
	{
		vertArray[i].x->SetNumKeys(1, FALSE);
		vertArray[i].y->SetNumKeys(1, FALSE);
		vertArray[i].z->SetNumKeys(1, FALSE);
	}
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::SetVert
   Purpose : set vertex
   Parameters : vertex index, x, y, z
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int ObeMesh::SetVert(int vertIndex, float x, float y, float z)
{
	TIME_VALUE_KEY	key;

	if (vertIndex >= this->numVert)
		return 0;
	key.frameNum = 0;
	key.data = x;
	vertArray[vertIndex].x->SetKey(0, &key);
	key.data = y;
	vertArray[vertIndex].y->SetKey(0, &key);
	key.data = z;
	vertArray[vertIndex].z->SetKey(0, &key);
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::GetVert
   Purpose : get vertex
   Parameters : vertex index, x, y, z pointers
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int ObeMesh::GetVert(int vertIndex, float *xPtr, float *yPtr, float *zPtr)
{
	TIME_VALUE_KEY	key;

	if (vertIndex >= numVert)
		return 0;
	key.frameNum = 0;
	vertArray[vertIndex].x->GetKey(0, &key);
	*xPtr = key.data;
	vertArray[vertIndex].y->GetKey(0, &key);
	*yPtr = key.data;
	vertArray[vertIndex].z->GetKey(0, &key);
	*zPtr = key.data;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::GetVert
   Purpose : get vertex
   Parameters : vertex index, xyz pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int ObeMesh::GetVert(int vertIndex, float *xyzPtr)
{
	TIME_VALUE_KEY	key;

	if (vertIndex >= numVert)
		return 0;
	key.frameNum = 0;
	vertArray[vertIndex].x->GetKey(0, &key);
	xyzPtr[0] = key.data;
	vertArray[vertIndex].y->GetKey(0, &key);
	xyzPtr[1] = key.data;
	vertArray[vertIndex].z->GetKey(0, &key);
	xyzPtr[2] = key.data;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::SetNumPolys
   Purpose : set number of polys
   Parameters : number of polys
   Returns : 1 - noerror, 0 - error
   Info : 
*/

int ObeMesh::SetNumPolys(int numPolys)
{
	PolyType	*polygonsPtr;

	polygonsPtr = (numPolys > 0) ? new PolyType[numPolys] : NULL;
	SAFE_DELETE_ARRAY(polyArray)
	polyArray = polygonsPtr;
	numPoly = numPolys;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMesh::ToTris
   Purpose : split up the polygons into tris
   Parameters : 
   Returns : 1 - noerror, 0 - error
   Info : remember the old order of polygons for the additional data
*/

int ObeMesh::ToTris()
{
	PolyType	*polygonBuffer;
	PolyType	polygon1, polygon2;
	int			i, numAdded, numSplit;

	// any polygons exist to split?
	if (numPoly == 0)
		return 1;

	// allocate polygon work buffer
	polygonBuffer = new PolyType[numPoly*2];

	// allocate buffer in class to hold load time polygon order
	loadPolyOrder = (int *)malloc(numPoly*2*sizeof(int));
	loadNumPolys  = numPoly;

	// init all polygons in the working buffer
	for (i=0; i<numPoly*2; i++)
		polygonBuffer[i].SetNumVerts(3);

	numAdded = numSplit = 0;
	polygon1.SetNumVerts(3);
	polygon2.SetNumVerts(3);

//#if 0
	// convert this mesh to tris
	for (i=0; i<numPoly; i++)
		if ((polyArray[i].flags & OBEPOLYFLAG_SPRITE) == 0 && polyArray[i].numVerts == 4)
		{
			// quad polygon found
			polyArray[i].QuadToTwoTris(&polygon1, &polygon2);
			numSplit++;
			polygonBuffer[numAdded].CopyFrom(&polygon1);
			loadPolyOrder[numAdded] = i;
			numAdded++;
			polygonBuffer[numAdded].CopyFrom(&polygon2);
			loadPolyOrder[numAdded] = i;
			numAdded++;
		}
		else
		{
			// non-quad or sprite polygon found
			polygonBuffer[numAdded].CopyFrom(&polyArray[i]);
			loadPolyOrder[numAdded] = i;
			numAdded++;
		}
//#endif

	// rebuild mesh polygon list if any splits occurred
	if (numSplit > 0)
	{
		SAFE_DELETE_ARRAY(polyArray)
		SetNumPolys(numAdded);
		for (i=0; i<numAdded; i++)
		{
			polyArray[i].SetNumVerts(3);
			polyArray[i].CopyFrom(&polygonBuffer[i]);
		}
	}

	// release the work buffer
	SAFE_DELETE_ARRAY(polygonBuffer)

	DPrintf("Mesh '%s' converted into %d tris from %d polygons", meshName, numPoly, loadNumPolys);
	return 1;
}


// --------------------------------------------------------------------------------
// Vertex Assignment class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : VertexAssign::VertexAssign
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

VertexAssign::VertexAssign()
{
	vertIndex = SKIN_VERTASS_NULL_BONE;
	numWeights = 0;
}


/* --------------------------------------------------------------------------------
   Function : VertexAssign::~VertexAssign
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

VertexAssign::~VertexAssign()
{
	vertIndex = SKIN_VERTASS_NULL_BONE;
	numWeights = 0;
}


/* --------------------------------------------------------------------------------
   Function : VertexAssign::Read
   Purpose : read in the vertex assignment
   Parameters : file handle pointer, current version
   Returns : 
   Info : 
*/

int VertexAssign::Read(FILE *filePtr, int version)
{
	short	sVal;

	// read the vertex assignment anim
	ReadData(filePtr, &sVal, 2);
	vertIndex = (int)sVal;
	assignList.Read(filePtr, version);

	// read the vertex assignment weights
	ReadData(filePtr, &sVal, 2);
	numWeights = (int)sVal;
	weightList.Read(filePtr, version);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : VertexAssign::Write
   Purpose : write out the vertex assignment
   Parameters : file handle pointer
   Returns : 
   Info : 
*/

int VertexAssign::Write(FILE * filePtr)
{
	short	sVal;

	// write the vertex assignments
	sVal = (short)vertIndex;
	WriteData(filePtr, &sVal, 2);
	assignList.Write(filePtr);

	// write the vertex weights
	sVal = (short)numWeights;
	WriteData(filePtr, &sVal, 2);
	weightList.Write(filePtr);

	return 1;
}


// --------------------------------------------------------------------------------
// ObeBone class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : ObeBone::ObeBone
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

ObeBone::ObeBone()
{
	numVertAssigns = 0;
	vertAssignList = NULL;
}


/* --------------------------------------------------------------------------------
   Function : ObeBone::~ObeBone
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

ObeBone::~ObeBone()
{
	SAFE_DELETE_ARRAY(vertAssignList)
}


/* --------------------------------------------------------------------------------
   Function : ObeBone::SetNumAssigns
   Purpose : set the number of vertex assignments
   Parameters : file handle pointer, current version
   Returns : 
   Info : 
*/

int	ObeBone::SetNumAssigns(int numAssigns)
{
	VertexAssign	*newAssignsPtr;
	int				i;

	newAssignsPtr = (numAssigns > 0) ? new VertexAssign[numAssigns] : NULL;
	if (newAssignsPtr)
		for (i=0; i<numAssigns; i++)
		{
			newAssignsPtr[i].assignList.x->SetNumKeys(1);
			newAssignsPtr[i].assignList.y->SetNumKeys(1);
			newAssignsPtr[i].assignList.z->SetNumKeys(1);
			newAssignsPtr[i].weightList.SetNumKeys(1);
		}
	SAFE_DELETE_ARRAY(vertAssignList)
	vertAssignList = newAssignsPtr;
	numVertAssigns = numAssigns;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeBone::Read
   Purpose : read bone data
   Parameters : file handle pointer, current version
   Returns : 
   Info : 
*/

int ObeBone::Read(FILE *filePtr, int version)
{
	int		i;
	long	lVal;

	// read bone name and name of the mesh this bone references
	ReadData(filePtr, boneName, 32);
	ReadData(filePtr, meshNameRef, 32);

	// read the vertex assignments
	ReadData(filePtr, &lVal, 4);
	numVertAssigns = (int)lVal;
	SetNumAssigns(numVertAssigns);
	for(i=0; i<numVertAssigns; i++)
		vertAssignList[i].Read(filePtr, version);

	// read bone positions
	posX.Read(filePtr, version);
	posY.Read(filePtr, version);
	posZ.Read(filePtr, version);

	// read bone scales
	scaleX.Read(filePtr, version);
	scaleY.Read(filePtr, version);
	scaleZ.Read(filePtr, version);

	// read bone orientations
	orientationX.Read(filePtr, version);
	orientationY.Read(filePtr, version);
	orientationZ.Read(filePtr, version);
	orientationW.Read(filePtr, version);

	DPrintf("vertex assignments: %d", numVertAssigns);
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeBone::Write
   Purpose : write bone data
   Parameters : file handle pointer
   Returns : 
   Info : 
*/

int ObeBone::Write(FILE * filePtr)
{
	int		i;
	long	lVal;

	// write bone name and name of the mesh this bone references
	WriteData(filePtr, boneName, 32);
	WriteData(filePtr, meshNameRef, 32);

	// write the vertex assignments
	lVal = (long)numVertAssigns;
	WriteData(filePtr, &lVal, 4);
	for(i=0; i<numVertAssigns; i++)
		vertAssignList[i].Write(filePtr);

	// write bone positions
	posX.Write(filePtr);
	posY.Write(filePtr);
	posZ.Write(filePtr);

	// write bone scales
	scaleX.Write(filePtr);
	scaleY.Write(filePtr);
	scaleZ.Write(filePtr);

	// write bone orientations
	orientationX.Write(filePtr);
	orientationY.Write(filePtr);
	orientationZ.Write(filePtr);
	orientationW.Write(filePtr);

	return 1;
}


// ********************************************************************************
// Experimental Types
// ********************************************************************************

// --------------------------------------------------------------------------------
// ObeMaxBone class
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : ObeMaxBone::ObeMaxBone
   Purpose : constructor
   Parameters :
   Returns : 
   Info : 
*/

ObeMaxBone::ObeMaxBone()
{
	name[0] = 0;
	meshName[0] = 0;
	noofAssigns = 0;
	assignArray = NULL;
}


/* --------------------------------------------------------------------------------
   Function : ObeMaxBone::~ObeMaxBone
   Purpose : destructor
   Parameters :
   Returns : 
   Info : 
*/

ObeMaxBone::~ObeMaxBone()
{
	SAFE_DELETE_ARRAY(assignArray)
	noofAssigns = 0;
}


/* --------------------------------------------------------------------------------
   Function : ObeMaxBone::Write
   Purpose : write this class
   Parameters : file handle pointer
   Returns : 
   Info : 
*/

int ObeMaxBone::Write(FILE * filePtr)
{
	int		i;
	long	lVal;

	// write bone name
	WriteData(filePtr, name, 32);

	// write name of the mesh this bone references
	WriteData(filePtr, meshName, 32);

	// write inverse reference position
	WriteData(filePtr, &invRefPos.x, sizeof(invRefPos.x));
	WriteData(filePtr, &invRefPos.y, sizeof(invRefPos.y));
	WriteData(filePtr, &invRefPos.z, sizeof(invRefPos.z));

	// write inverse reference scale
	WriteData(filePtr, &invRefScale.x, sizeof(invRefScale.x));
	WriteData(filePtr, &invRefScale.y, sizeof(invRefScale.y));
	WriteData(filePtr, &invRefScale.z, sizeof(invRefScale.z));

	// write inverse reference rotation
	WriteData(filePtr, &invRefRot.x, sizeof(invRefRot.x));
	WriteData(filePtr, &invRefRot.y, sizeof(invRefRot.y));
	WriteData(filePtr, &invRefRot.z, sizeof(invRefRot.z));
	WriteData(filePtr, &invRefRot.w, sizeof(invRefRot.z));

	// write the vertex assignments
	lVal = (long)noofAssigns;
	WriteData(filePtr, &lVal, 4);
	for (i=0; i<noofAssigns; i++)
		assignArray[i].Write(filePtr);

	// write bone positions
	posX.Write(filePtr);
	posY.Write(filePtr);
	posZ.Write(filePtr);

	// write bone scales
	scaleX.Write(filePtr);
	scaleY.Write(filePtr);
	scaleZ.Write(filePtr);

	// write bone orientations
	rotX.Write(filePtr);
	rotY.Write(filePtr);
	rotZ.Write(filePtr);
	rotW.Write(filePtr);

	return 1;
}


/* --------------------------------------------------------------------------------
   Function : ObeMaxBone::NoofAssigns
   Purpose : set the number of assignments
   Parameters : number of assignments to set
   Returns : 
   Info : 
*/

void ObeMaxBone::NoofAssigns(int noof)
{
	VertexAssign	*assigns;
	int				i;

	assigns = (noof>0) ? new VertexAssign[noof] : NULL;
	if (assigns)
		for (i=0; i<noof; i++)
		{
//			assigns[i].assignList.x->SetNumKeys(1);
//			assigns[i].assignList.y->SetNumKeys(1);
//			assigns[i].assignList.z->SetNumKeys(1);
			assigns[i].weightList.SetNumKeys(1);
		}
	SAFE_DELETE_ARRAY(assignArray)
	assignArray = assigns;
	noofAssigns = noof;
}


/* --------------------------------------------------------------------------------
   Function : ObeMaxBone::Assign
   Purpose : set weighted vertex assignment n for this bone
   Parameters : assignment index, vertex index, normalised weight
   Returns : 
   Info : 
*/

void ObeMaxBone::Assign(int n, int vertn, float weight)
{
	TIME_VALUE_KEY	key;

	if (n >= noofAssigns)
		return;
	assignArray[n].vertIndex = vertn;
	assignArray[n].numWeights = 1;
	key.frameNum = 0; key.data = weight;
	assignArray[n].weightList.SetKey(0, &key);
}
