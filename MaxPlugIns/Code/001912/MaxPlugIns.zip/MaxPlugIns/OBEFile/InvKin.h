
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : InvKin.h
// Purpose : Header file for Export / Import Inverse Kinematic Parameters
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __INVKIN__H
#define __INVKIN__H

#include "OBEFile.h"


/* --------------------------------------------------------------------------------
   Function : InvKin_ImportParams
   Purpose : import nodes IK parameters
   Parameters : node pointer, OBE filename pointer
   Returns : 
   Info : 
*/

void InvKin_ImportParams(INode *node, TCHAR *OBEFilen);


/* --------------------------------------------------------------------------------
   Function : InvKin_ExportParams
   Purpose : import nodes IK parameters
   Parameters : node pointer, OBE filename pointer
   Returns : 
   Info : 
*/

void InvKin_ExportParams(INode *node, TCHAR *OBEFilen);


/* --------------------------------------------------------------------------------
   Function : InvKin_Delete
   Purpose : delete IK parameters file
   Parameters : OBE filename pointer
   Returns : 
   Info : 
*/

void InvKin_Delete(TCHAR *OBEFilen);

#endif	// __INVKIN__H