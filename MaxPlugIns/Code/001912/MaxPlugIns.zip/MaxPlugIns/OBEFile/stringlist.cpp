

#include "stringlist.h"
#include "OBEFile.h"



StringNode::StringNode(void)
{
	string=NULL;
	next = NULL;
	
}

StringNode::StringNode(char *str)
{
	string=NULL;
	next = NULL;
	

	SetStr(str);
}

StringNode::~StringNode(void)
{
	SAFE_DELETE_ARRAY(string)
}


StringNode::SetStr(char *str)
{
	SAFE_DELETE_ARRAY(string)
	string = new char[strlen(str)+1];
	strcpy(string, str);
	return TRUE;
}


/*****************************************************************************************/


StringList::StringList()
{
	head=0;
	tail=NULL;
	numNodes = 0;
}


StringList::Add(char *str)
{
StringNode *temp;

	temp = new StringNode(str);
	
	if (head==NULL)
	{
		head = temp;
		tail = temp;
		head->next=NULL;
	} else {
		tail->next = temp;
		tail = temp;
		tail->next =NULL;
	}

	numNodes++;
	return TRUE;
};


StringList::~StringList()
{
StringNode *curr=head, *next;

	while(curr!=NULL)
	{
		next = curr->next;
		SAFE_DELETE(curr);
		curr = next;
		numNodes--;
	}
}


StringList::GetIdx(char *str)
{
int idx=0;
StringNode *curr=head;

	while (curr!=NULL)
	{
		if (strcmpi(curr->string, str)==0)
			return idx;
		idx++;
		curr = curr->next;
	}

	return -1;
}


char *StringList::GetStr(int idx)
{
StringNode *curr=head;
int i=0;

	if (idx > numNodes || numNodes ==0)
		return NULL;

	
	for (i=0; i < idx; i++)
	{	
		if (idx > 0)
			curr = curr->next;
	}

	return curr->string;
}


StringList::Clear()
{
StringNode *curr=head, *next;

	while(curr!=NULL)
	{
		next = curr->next;
		SAFE_DELETE(curr);
		curr = next;
		numNodes--;
	}

	numNodes=0;
	head = NULL;
	tail = NULL;


	return 1;
}