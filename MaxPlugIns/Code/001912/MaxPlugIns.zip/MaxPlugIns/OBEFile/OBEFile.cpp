
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of OBEFile.dlu, (c) 2000 Interactive Studios Ltd.
//
//    File : OBEFile.cpp
// Purpose : Common routines for both exporter and importer
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "OBEFile.h"

#include "resource.h"


/* --------------------------------------------------------------------------------
   Function : AboutDialogProc
   Purpose : about dialog procedure
   Parameters : dialog handle, message, parameter1, parameter2
   Returns : return code
   Info : 
*/

BOOL CALLBACK AboutDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{
	switch (uMsg)
	{	
	case WM_INITDIALOG:
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
			EndDialog(hwndDlg, 1);
			return TRUE;
		}
	}
	return FALSE;
}


/* --------------------------------------------------------------------------------
   Function : GetNodeMesh
   Purpose : get the nodes mesh
   Parameters : max node pointer
   Returns : 1 - noerror, 0 - error
   Info : 
*/

Mesh *GetNodeMesh(INode *nodePtr)
{
	Object			*object;
	TriObject		*triObject;
	int				deleteIt;

	deleteIt = 0;
	object = (Object *)(nodePtr->EvalWorldState(0)).obj;

	if (object->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)) == 0)
		return NULL;
	triObject = (TriObject *)object->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
	deleteIt = (object != triObject);
	return &triObject->mesh;
}


/* --------------------------------------------------------------------------------
   Function : GetUniqueMeshId
   Purpose : uniquely identify this mesh
   Parameters : max mesh
   Returns : 
   Info : 
*/

ULONG GetUniqueMeshId(Mesh *meshPtr)
{
	ULONG	crc;
	int		*vertsPtr, *walkPtr, i;

	if (meshPtr == NULL)
		return 0;
	if ((vertsPtr = (int *)malloc(meshPtr->numFaces*3*sizeof(int))) == NULL)
		return 0;
	walkPtr = vertsPtr;

	for (i=0; i<meshPtr->numFaces; i++)
	{
		*walkPtr++ = meshPtr->faces[i].v[0];
		*walkPtr++ = meshPtr->faces[i].v[1];
		*walkPtr++ = meshPtr->faces[i].v[2];
	}
	crc = UpdateCRCData((char *)vertsPtr, meshPtr->numFaces*sizeof(int));

	SAFE_FREE(vertsPtr)
	return crc;
}
