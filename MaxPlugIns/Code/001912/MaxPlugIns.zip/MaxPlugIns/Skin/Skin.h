/**********************************************************************
 *<
	FILE: Skin.h

	DESCRIPTION:	Template Utility

	CREATED BY:

	HISTORY:

 *>	Copyright (c) 1997, All Rights Reserved.
 **********************************************************************/

#ifndef __SKIN__H
#define __SKIN__H

#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#if MAX_RELEASE >= 3000
#include "iparamb2.h"
#include "iparamm2.h"
#else
#include "iparamb.h"
#include "iparamm.h"
#endif
#include "simpobj.h"
#include "simpmod.h"
#include "decomp.h"

#include "meshadj.h"

#include "CommonFiles.h"

#define SKINOBJ_CLASS_ID	Class_ID(0x63802bf1, 0x47d67eee)
#define SKINMOD_CLASS_ID	Class_ID(0x113d74c0, 0x6595726b)

#endif // __SKIN__H
