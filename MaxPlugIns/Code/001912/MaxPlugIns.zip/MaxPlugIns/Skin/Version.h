

// -- Version Control --

#ifndef _VERSION_HEADER_
#define _VERSION_HEADER_

// current version
#define VERSION_CURRENT 1

///////////////////////////////////////////////////////
// VERSION_CURRENT 1
///////////////////////////////////////////////////////
//
//	SKINMOD_DATA_CHUNK format:
//		int Version
//		int BoneCount
//		BoneRef x BoneCount
//		int BoneSelect
//		int AssignCount
//		VertexAssign x AssignCount
//			int VertIndex
//			Point3 Vector
//
//
///////////////////////////////////////////////////////
// VERSION_CURRENT ?
///////////////////////////////////////////////////////

#endif