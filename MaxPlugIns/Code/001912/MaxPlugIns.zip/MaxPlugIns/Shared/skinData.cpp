
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Skin Data Class, (c) 1999 Interactive Studios Ltd.
//
//    File  : skindata.cpp
//   Author : Andy Slater
// Purpose  : The shared skin data container class
// Comments : 
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "skindata.h"


// --------------------------------------------------------------------------------
// Class: SkinData Methods
// --------------------------------------------------------------------------------

/* --------------------------------------------------------------------------------
   Function : SkinData::SkinData
   Purpose : Constructor
   Parameters :
   Returns : 
   Info : 
*/

SkinData::SkinData()
{
	boneRefs = NULL;
	vertexAssigns = NULL;
	boneSelectIndex = -1;
}


/* --------------------------------------------------------------------------------
   Function : SkinData::~SkinData
   Purpose : Destructor
   Parameters :
   Returns : 
   Info : 
*/

SkinData::~SkinData()
{
	boneRefs = NULL;
	vertexAssigns = NULL;
	boneSelectIndex = -1;
}


/* --------------------------------------------------------------------------------
   Function : SkinData::Clone
   Purpose : Clone local data
   Parameters :
   Returns : 
   Info : 
*/

LocalModData * SkinData::Clone()
{
	SkinData * skinData = new SkinData();
	return skinData;
}
