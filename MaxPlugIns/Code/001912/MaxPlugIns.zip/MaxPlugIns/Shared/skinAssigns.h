

// -- Vertex Assigment Class --

#ifndef _VERTASS_H_
#define _VERTASS_H_

#include "max.h"

// Invalid bone reference
#define SKIN_VERTASS_NULL_BONE -1


///////////////////////////////////////////////////////
// Vertex Assignment Class
///////////////////////////////////////////////////////

class SkinVertAssign
{
	public:
		// init/uninit
		void Init( int index );
		void UnInit( void );

		// set vertex assignment
		void Set( int index, Point3 vec );

		// index into bone reference list
		int idxBoneRef;
		// relative position vector to bone
		Point3 vec;
};


///////////////////////////////////////////////////////
// Vertex Assignment Manager Class
///////////////////////////////////////////////////////

class SkinVertAssignManager
{
	public:
		// init/uninit
		void Init( SkinBoneRefManager * boneRefList );
		void UnInit( void );

		// assignment list creation
		int CreateList( int numVerts );

		void ReAssignBone(Mesh & mesh, int idxBone);
		void AutoAssignBone(Mesh & mesh, int idxBone, int bOverWrite);
		void ClearBoneAssigns(int idxBone);

		// 
		SkinVertAssign * GetAssign( int idxVert );
		int IsValid( int idxVert );

		// manage list
		int ClearAll( Mesh & mesh );
		int Add( Mesh & mesh, int idxVert, int idxBone );
		int Sub( int idxVert, int idxBone );
		int Remap( int idxBone );

		// count all assignments for bone n
		int CountAssigns( int idxBone );

		// io
		IOResult Save( ISave *isave );
		IOResult Load( ILoad *iload, int version );

		// geometry - mesh, pivot matrix, vertices..
		TriObject * GetTriObjFromNode( INode * node, int & needDel );
		Matrix3 GetPivMatFromNode( INode * node );
		Point3 GetVertFromNode( Mesh & mesh, Matrix3 pivMat, int idxVert );

		// vars
		int numAssigns;						// number of vertex assignments in list
		SkinVertAssign * assignList;		// vertex assignment list
		TimeValue t;						// current anim time
		INode * skinNode;					// node skin bound to

	private:
		SkinBoneRefManager * boneRefList;	// bone reference list ptr
};

#endif