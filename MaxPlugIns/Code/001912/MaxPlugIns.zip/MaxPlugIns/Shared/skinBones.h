

// -- Bone Reference Linked List --

#ifndef _BONEREF_H_
#define _BONEREF_H_

#include "max.h"

// Invalid Bone Ref Selection
#define SKIN_BONEREF_INVALID_SELECTION -1
#define SKIN_BONEREF_ALL -2


///////////////////////////////////////////////////////
// Bone Reference Class
///////////////////////////////////////////////////////

class SkinBoneRef
{
	public:
		// init/uninit
		void Init( INode * boneNode );
		void UnInit( void );

		// bone info
		INode * node;
		Matrix3 transMat;		// transform matrix
		Matrix3 refMat;			// reference matrix ( frame 0 )

		// linked list info
		SkinBoneRef * next;
		SkinBoneRef * previous;

		// manage list
		inline void SetNext( SkinBoneRef * boneRef ) { next = boneRef; }
		inline void SetPrevious( SkinBoneRef * boneRef ) { previous = boneRef; }
		inline SkinBoneRef * GetNext() { return next; }
		inline SkinBoneRef * GetPrevious() { return previous; }

		// io
		int Save( ISave * isave );
		int Load( ILoad * iload );
};


///////////////////////////////////////////////////////
// Bone Reference Manager Structure
///////////////////////////////////////////////////////

class SkinBoneRefManager
{
	public:
		// init/uninit
		void Init( void );
		void UnInit( void );

		// io
		IOResult Save( ISave * isave );
		IOResult Load( ILoad * iload, int version );

		// list create / destroy
		int CreateList( INode ** boneList, int bones );
		void DeleteList();
		int AddNode( INode * boneNode );
		int DelNode( INode * boneNode );
		int DelBoneIndex( int idxBone );
		int DelBone( SkinBoneRef * boneRef );

		// manage list
		SkinBoneRef * Add( SkinBoneRef * boneRef );
		SkinBoneRef * GetFirst();
		SkinBoneRef * GetLast();
		SkinBoneRef * GetNext( SkinBoneRef * boneRef );
		SkinBoneRef * GetPrevious( SkinBoneRef * boneRef );
		SkinBoneRef * GetBone( int index );
		int Count();

		// max
		SkinBoneRef * IsTarget( INode * tarNode );
		int GetIndex( INode * node );

		// selection
		int GetBoneSelect( void );
		void SetBoneSelect( int idxBone );

		// bone reference list
		int numBones;
		SkinBoneRef * boneRefList;

		// bone reference user selection
		int boneSelect;
};

#endif
