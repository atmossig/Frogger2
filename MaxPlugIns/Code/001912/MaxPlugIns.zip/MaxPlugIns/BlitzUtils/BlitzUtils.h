
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of BlitzUtils.dlu, (c) 2000 Blitz Games Ltd.
//
//    File : BlitzUtils.h
// Purpose : Header
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __BLITZUTILS__H
#define __BLITZUTILS__H

#define DLLEXPORT	__declspec( dllexport )

#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#if MAX_RELEASE >= 3000
#include "iparamb2.h"
#include "iparamm2.h"
#else
#include "iparamb.h"
#include "iparamm.h"
#endif
#include "utilapi.h"

#include "CommonFiles.h"

#endif // __BLITZUTILS__H
