
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// This file is part of obefile.dlu, (c) 1999 Interactive Studios Ltd.
//
//    File : maxskin.cpp
// Purpose : investigating >Max3 skinning modifier
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "maxskin.h"

#include "CommonFiles.h"

int	useCount;
int	notUseCount;


/* --------------------------------------------------------------------------------
   Function : MaxSkin_IsNode
   Purpose : determine if this node as a Max skin modifier attached
   Parameters : pointer to node that could have max skin attached
   Returns : 1 - max skin modifer attached, 0 - not found
   Info : 
*/

int MaxSkin_IsNode(INode *nodePtr)
{
	int				i;
	Object			*objectPtr;
	IDerivedObject	*derivedPtr;
	Modifier		*modifierPtr;
	ModContext		*mcPtr;

	// as this nodes object been derived?
	objectPtr = nodePtr->GetObjectRef();
	if (objectPtr != NULL && objectPtr->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		// can safely cast object as a derived object
		derivedPtr = (IDerivedObject *)objectPtr;
		// loop around all modifiers searching for the skin class
		for (i=0; i<derivedPtr->NumModifiers(); i++)
		{
			// is this ours?
			modifierPtr = derivedPtr->GetModifier(i);
			if (modifierPtr->ClassID()==Class_ID(9815843,87654))
			{
				mcPtr = derivedPtr->GetModContext(i);
				if (mcPtr && mcPtr->localData)
					return 1;
			}
		}
	}
	return 0;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_GetModData
   Purpose : return a skin local modify data instance
   Parameters : max interface pointer
   Returns : mod data instance pointer
   Info : 
*/

BoneModData * MaxSkin_GetModData(Interface * maxPtr)
{
	INode			*nodePtr;
	IDerivedObject	*derivedPtr;
	Modifier		*modifierPtr;
	ModContext		*mcPtr;
	int				i;

	nodePtr = MaxSkin_GetNode(maxPtr);
	if (nodePtr == NULL)
		return NULL;
	derivedPtr = (IDerivedObject *)nodePtr->GetObjectRef();
	for (i=0; i<derivedPtr->NumModifiers(); i++)
	{
		modifierPtr = derivedPtr->GetModifier(i);
		if (modifierPtr->ClassID()==Class_ID(9815843,87654))
			if ((mcPtr = derivedPtr->GetModContext(i)) != NULL)
			{
				return (BoneModData *)mcPtr->localData;
			}
	}
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_GetModifier
   Purpose : return a skin modifier
   Parameters : max interface pointer
   Returns : modifier instance pointer
   Info : 
*/

BonesDefMod *MaxSkin_GetModifier(Interface *maxPtr)
{
	INode			*nodePtr;
	IDerivedObject	*derivedPtr;
	Modifier		*modifierPtr;
	int				i;


	nodePtr = MaxSkin_GetNode(maxPtr);
	if (nodePtr == NULL)
		return NULL;
	derivedPtr = (IDerivedObject *)nodePtr->GetObjectRef();
	for (i=0; i<derivedPtr->NumModifiers(); i++)
	{
		modifierPtr = derivedPtr->GetModifier(i);
		if (modifierPtr->ClassID()==Class_ID(9815843,87654))
			return (BonesDefMod *)modifierPtr;
	}
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_GetNode
   Purpose : return a max skin node from the scene
   Parameters : max interface pointer
   Returns : skin node pointer or NULL
   Info : 
*/

int GetSkin(INode *nodePtr, void *context)
{
	if (MaxSkin_IsNode(nodePtr))
	{
		*((INode **)context) = nodePtr;
		return NENUM_END;
	}
	return NENUM_CONTINUE;
}

INode *MaxSkin_GetNode(Interface *maxPtr)
{
	INode	*node;
	if (EnumNodes(maxPtr->GetRootNode(), GetSkin, &node))
		return node;
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_GetInfo
   Purpose : get all max skin info from node
   Parameters : pointer to node that could have max skin attached, max inteface pointer
   Returns : 
   Info : 
*/

void MaxSkin_GetInfo(INode *nodePtr, Interface *maxPtr)
{
	int				i, j;
	float			infAcc;
	BoneModData		*modData;
	BonesDefMod		*modifier;
	VertexListClass				*vertexData;
	VertexInfluenceListClass	*vertexInfo;


	if ((modData = MaxSkin_GetModData(maxPtr)) == NULL)
		return;
	if ((modifier = MaxSkin_GetModifier(maxPtr)) == NULL)
		return;

	DPrintf("Max skin info for node '%s'", nodePtr->GetName());

	// skin vertices
	DPrintf("skin vertices: %d", modData->VertexDataCount);

	// skin vertices bone influences
	for (i=0; i<modData->VertexDataCount; i++)
	{
		vertexData = modData->VertexData[i];
		DPrintf("skin vertex %d", i);
		DPrintf("  pos: x%07.2f  y%07.2f  z%07.2f", vertexData->LocalPos.x, vertexData->LocalPos.y, vertexData->LocalPos.z);
		for (j=0, infAcc = 0.f; j<vertexData->d.Count(); j++)
		{
			vertexInfo = vertexData->d.Addr(j);
			DPrintf("  bone: %d  influence: %0.2f", vertexInfo->Bones, vertexInfo->Influences);
			infAcc += vertexInfo->Influences;
		}
		DPrintf("  total influence: %0.2f", infAcc);
	}

	// output all bones max skin uses
	DPrintf("\nMax skin bone info");
	DPrintf("  skin bones: %d", modifier->BoneData.Count());
	for (i=0; i<modifier->BoneData.Count(); i++)
		DPrintf("  bone: %d  name: '%s'", i, modifier->BoneData[i].Node->GetName());

	// output bone hierarchy info
	useCount = notUseCount = 0;
	DPrintf("\nAll hierarchy bones and vertex assigns");
	EnumNodes(maxPtr->GetRootNode(), MaxSkin_GetBoneInfo, modifier);
	DPrintf("%d bones used by max skin modifier", useCount);
	DPrintf("%d bones NOT used by max skin modifier", notUseCount);
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_GetBoneInfo
   Purpose : get bone info from max node
   Parameters : pointer to node that could have max skin attached, max inteface pointer
   Returns : 
   Info : 
*/

int MaxSkin_GetBoneInfo(INode * nodePtr, void *context)
{
	BonesDefMod	*modifier;
	Object		*object;
	int			i;

	if (nodePtr == NULL)
		return NENUM_CONTINUE;
	modifier = (BonesDefMod *)context;

	object = nodePtr->GetObjectRef();
	if (object && object->SuperClassID() == HELPER_CLASS_ID && object->ClassID() == Class_ID(BONE_CLASS_ID, 0))
	{
		for (i=0; i<modifier->BoneData.Count(); i++)
			if (nodePtr == modifier->BoneData[i].Node)
			{
				break;
			}
		if (i<modifier->BoneData.Count())
		{
			DPrintf("  max bone '%s' used by skin", nodePtr->GetName());
			useCount++;
		}
		else
		{
			DPrintf("  max bone '%s' not used by skin", nodePtr->GetName());
			notUseCount++;
		}
	}
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_FindRootBone
   Purpose : get the root bone of the skinned mesh node
   Parameters : skinned mesh node pointer, max interface pointer
   Returns : root bone pointer or NULL
   Info : 
*/

INode *MaxSkin_FindRootBone(INode *node, Interface *ip)
{
	BonesDefMod		*modifier;
	INode			*root;
	int				l;

	if (node == NULL || (modifier = MaxSkin_GetModifier(ip)) == NULL)
		return NULL;
	for (l=0; l < modifier->BoneData.Count(); l++)
		if ((root = modifier->BoneData[l].Node) != NULL)
		{
			if (root->GetParentNode() == ip->GetRootNode())
			{
				break;
			}
		}
	return (l < modifier->BoneData.Count()) ? root : NULL;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_IsBone
   Purpose : determine if this node is a valid soft skinned bone
   Parameters : max interface pointer, node pointer
   Returns : 1 - soft skinned bone node, else 0
   Info : 
*/

int	MaxSkin_IsBone(Interface *ip, INode *node)
{
	BonesDefMod		*modifier;
	int				i;

	// does a max skin modifier exist in the scene?
	if ((modifier = MaxSkin_GetModifier(ip)) == NULL)
		return 0;
	// is the modifier aware of this max bone?
	for (i=0; i<modifier->BoneData.Count(); i++)
		if (modifier->BoneData[i].Node != NULL && modifier->BoneData[i].Node == node)
		{
			break;
		}
	if (i >= modifier->BoneData.Count())
		return 0;
	return 1;
}


/* --------------------------------------------------------------------------------
   Function : MaxSkin_GetModifier
   Purpose : return a skin modifier
   Parameters : max interface, node
   Returns : modifier instance
   Info : 
*/

BonesDefMod *MaxSkin_GetModifier(Interface *ip, INode *node)
{
	int				i;
	Object			*obj;
	Modifier		*mod;

	// as this nodes object been derived?
	if (node == NULL || (obj = node->GetObjectRef()) == NULL)
		return NULL;
	if (obj != NULL && obj->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		// loop around all modifiers searching for the skin class
		for (i=0; i<((IDerivedObject *)obj)->NumModifiers(); i++)
		{
			// is this ours?
			mod = ((IDerivedObject *)obj)->GetModifier(i);
			if (mod->ClassID() == Class_ID(9815843,87654))
				return (BonesDefMod *)mod;
		}
	}
	return NULL;
}
