
#include "CommonFiles.h"


/* --------------------------------------------------------------------------------
   Function : GetString
   Purpose : get string from string table resource
   Parameters : string resource id
   Returns : returns string or NULL
   Info : 
*/

TCHAR *GetString(int id)
{
	static TCHAR buf[256];

	if (hInstance)
		return LoadString(hInstance, id, buf, sizeof(buf)) ? buf : NULL;
	return NULL;
}


/* --------------------------------------------------------------------------------
   Function : GetModuleTimeString
   Purpose : get ASCIIZ time from module
   Parameters : 
   Returns : returns coordinated universal time in ASCII
   Info : 
*/

TCHAR *GetModuleTimeString()
{
	static TCHAR				days[][4] = { {_T("Sun")},{_T("Mon")},{_T("Tue")},{_T("Wed")},{_T("Thu")},{_T("Fri")},{_T("Sat")} };
	static TCHAR				mons[][4] = { {_T("Jan")},{_T("Feb")},{_T("Mar")},{_T("Apr")},{_T("May")},{_T("Jun")},{_T("Jul")},{_T("Aug")},{_T("Sep")},{_T("Oct")},{_T("Nov")},{_T("Dec")} };
	static TCHAR				outp[256];
	TCHAR						path[256];
	WIN32_FILE_ATTRIBUTE_DATA	info;
	SYSTEMTIME					time;

	sprintf(outp, "%s", _T("invalid time stamp"));
	if (GetModuleFileName(hInstance, path, 256) > 0)
		if (GetFileAttributesEx(path, GetFileExInfoStandard, &info) != 0)
		{
			if (FileTimeToSystemTime(&info.ftLastWriteTime, &time) != 0)
			{
				sprintf(outp, "%s %s %d %02d:%02d:%02d %d", days[time.wDayOfWeek], mons[time.wMonth-1], time.wDay, time.wHour, time.wMinute, time.wSecond, time.wYear);
			}
		}
	return outp;
}


/* --------------------------------------------------------------------------------
   Function : CheckModuleLatestVersion
   Purpose : checks if a latest version of this plugin module exits on the network
   Parameters : 
   Returns : -1 - later version exists, 0 - version upto date, 1 - this is later
   Info : 
*/

int CheckModuleLatestVersion()
{
	static TCHAR				path[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR], fname[_MAX_FNAME],  ext[_MAX_EXT];
	WIN32_FILE_ATTRIBUTE_DATA	info1, info2;

	// get filetime from the loaded plugin
	if (GetModuleFileName(hInstance, path, 256) == 0)
		return 0;
	if (GetFileAttributesEx(path, GetFileExInfoStandard, &info1) == 0)
		return 0;

	// get filetime from the latest version of this plugin
	_tsplitpath(path, drive, dir, fname, ext);
	_stprintf(path, "%s%s%s%s%.1f%s%s%s", _T(PLUGIN_HOME_PATH), _T("\\"), fname, _T("\\PlugIn\\Max"), ((float)MAX_RELEASE)/1000.0f, _T("\\"), fname, ext);
	if (GetFileAttributesEx(path, GetFileExInfoStandard, &info2) == 0)
		return 0;

	// return compare file times
	return CompareFileTime(&info1.ftLastWriteTime, &info2.ftLastWriteTime);
}


/* --------------------------------------------------------------------------------
   Function : EnumNodes
   Purpose : enumerate all nodes in the scene, passing a bool function to each
   Parameters : start node pointer, function pointer, context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
*/

int EnumNodes(INode *root, TEnumNodeFunc *funcPtr, void *context)
{
	int	l, ret;

	if (root == NULL)
		return 0;

	if ((ret = funcPtr(root, context)) != NENUM_CONTINUE)
		return ret;
	for (l=0; l<root->NumberOfChildren(); l++)
		if ((ret = EnumNodes(root->GetChildNode(l), funcPtr, context)) == NENUM_END)
		{
			return ret;
		}
	return NENUM_CONTINUE;
}


/* --------------------------------------------------------------------------------
   Function : EnumNodes
   Purpose : enumerate all nodes in the scene, passing a bool function to each
   Parameters : start node pointer, pre function pointer, context, post function pointer, context
   Returns : NENUM_CONTINUE - continue search, NENUM_END - terminate search, NENUM_ENDPATH - don't search below this node
*/

int EnumNodes(INode *root, TEnumNodeFunc *preFuncPtr, void *preContext, TEnumNodeFunc *postFuncPtr, void *postContext)
{
	int l, ret;

	if ((ret = preFuncPtr(root, preContext)) != NENUM_CONTINUE)
		return ret;
	for (l=0; l<root->NumberOfChildren(); l++)
		if ((ret = EnumNodes(root->GetChildNode(l), preFuncPtr, preContext, postFuncPtr, postContext)) == NENUM_END)
		{
			return ret;
		}
	if ((ret = postFuncPtr(root, postContext)) != NENUM_CONTINUE)
		return ret;
	return NENUM_CONTINUE;
}
