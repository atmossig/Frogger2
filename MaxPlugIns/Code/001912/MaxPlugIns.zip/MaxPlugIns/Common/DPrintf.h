

#ifndef __DPRINTF_H__
#define __DPRINTF_H__

#include <stdio.h>


/* --------------------------------------------------------------------------------
   Function : DPrintf_Init
   Purpose : init debug log
   Parameters : debug log filename
   Returns : 
   Info : 
*/

void DPrintf_Init(char *filen = NULL);


/* --------------------------------------------------------------------------------
   Function : DPrintf
   Purpose : debug print
   Parameters : variable argument list
   Returns : 
   Info : 
*/

void DPrintf(char *format, ...);

#endif